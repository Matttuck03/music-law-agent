# START HERE: music law knowledge pack (remix edition)
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Law last checked: 2026-11-10 to 2026-11-13 (each card shows its own date).
- Files in this pack: 9, this one included.

## How to use these files
- Pick the card that fits the question from the list below, open the file named above it, and read the card's Bottom line first, then its Rules and Gotchas.
- Every legal statement carries a claim id (M- plus four digits in square brackets). The claims a card cites follow that card in the same file, each with its source, pinpoint and verbatim quote.
- A claim tagged (unverified) was not confirmed against its source. Say so when relying on it.
- If these files do not answer a question, say "not in my files" instead of guessing.
- A pending bill is not law. Name the jurisdiction (US federal, a state, a circuit, UK or EU) before answering.

## Which file answers which question

### 01-rights-and-licensing.md
Rights and licensing: the two copyrights in a recording, exclusive rights, mechanicals and the MLC, CRB rates, PROs and consent decrees, SoundExchange, sync and master use licences.
- M01 Composition and master (law last checked 2026-11-10). Questions like: What are the two copyrights in a recorded song; Who usually owns the composition and who owns the master; Is the audio of a mix posted with video a sound recording; Does a sound recording copyright cover the song underneath; Which exclusive rights attach to a composition versus a master; Can one party license only part of a copyright.
- M02 Exclusive rights and the 114 limits (law last checked 2026-11-10). Questions like: Do I need a licence from the label if I already have the songwriter's; Does the statutory webcasting licence cover an app that streams user mixes; Can a sound-alike recording avoid the master owner; Does a PRO licence cover a platform copying and processing user audio; Does the MLC blanket licence cover songs in a user mix; Why does a sound recording have no general performance right.
- M03 Mechanicals, 115, the MLC, MMA (law last checked 2026-11-10). Questions like: Who issues the blanket mechanical licence and since when; Does a mixing platform need a mechanical licence to store or stream songs; What is the current mechanical rate; Does the MLC blanket licence cover songs in a mix posted with video; Is the Phonorecords V settlement final.
- M04 CRB rates and proceedings (Phonorecords, Web, NSS) (law last checked 2026-11-10). Questions like: What is the current mechanical rate; Do the CRB webcasting rates cover a platform that streams user mixes; What is Web VI and is there a rate for a mixing app; What is Phonorecords V and is it final; How long do CRB proceedings take and can they be appealed; Can a voluntary licence replace the CRB rate.
- M05 PROs and consent decrees (law last checked 2026-11-10). Questions like: Who are the US performing rights organizations and what do they license; Do the ASCAP and BMI consent decrees give a mixing platform a right to a licence and a rate court; Can a PRO license sync, master or remix rights for a mix; Does a PRO licence cover every co-owner of a song; What if SESAC or GMR will not license; What is different in the EU.
- M06 SoundExchange, 114 and 112 (law last checked 2026-11-10). Questions like: Does the 114 statutory licence cover a platform that streams user mixes; Who is SoundExchange and what does it collect; Does the 112 ephemeral copy exemption cover platform server copies; What are the Web VI rates and do they apply to a mixing platform; Does a platform storing or processing user audio need a licence; Is there a performance right in sound recordings for terrestrial radio.
- M07 Sync and master use licensing for video (law last checked 2026-11-10). Questions like: Does the MLC blanket licence or any statutory licence cover songs in a mix posted with video; What licences does a user need to put a commercial song in a video mix; Does a TikTok or Meta sound licence carry over to another platform; Does a platform processing a user's audio need a music licence.

### 02-platform-liability.md
Platform liability: the DMCA 512 safe harbor, secondary liability after Cox v. Sony, Content ID and sound libraries.
- M08 DMCA 512 safe harbor for a platform that hosts user mixes (law last checked 2026-11-10). Questions like: Does the safe harbor protect a platform when users upload mixes of commercial songs; What must a platform do to qualify for 512(c); Does a platform need a designated agent and when does it expire; What is a repeat infringer policy and what must it say; What happens after a counter notice; Does processing or re-encoding user audio change the answer.
- M09 Secondary liability after Cox (law last checked 2026-11-10). Questions like: Is a mixing platform liable if a user uploads a mix with songs they do not own; Does knowing users infringe make a platform contributorily liable after Cox; What is vicarious liability and does Cox change it; Does a platform still need a repeat infringer policy; Does the DMCA safe harbour still matter; Which pre-2026 cases are overtaken.
- M10 Content ID systems and platform sound libraries (law last checked 2026-11-10). Questions like: Can a mixing platform use TikTok or Meta library music; Does a library licence from Epidemic Sound or Musicbed cover mixes on a platform; Does a mixing platform need to build Content ID style filtering; What must a platform do when a rightsholder sends a takedown; What would EU Article 17 require of a platform that hosts user mixes; Is YouTube Audio Library music safe to use in mixes.

### 03-sampling-infringement-ownership.md
Sampling, infringement, ownership and deals: sampling and interpolation, infringement, fair use and damages, work for hire, transfers, termination and deal terms.
- M11 Sampling and interpolation (law last checked 2026-11-10). Questions like: Can a user put a short sample of a song or beat in a mix; Is a tiny or unrecognizable sample safe (de minimis); Does re-recording a riff or a sound-alike avoid the recording owner; If a platform licenses the recording does it also need the composition; Does fair use cover a few seconds of a sample; Does splitting or re-encoding user audio create sampling risk.
- M12 Infringement, fair use, registration, damages, limitations (law last checked 2026-11-10). Questions like: Is a 15 second clip of a song in a monetised mix fair use; How much can a copyright owner recover from a platform or a user; Does an owner have to register before suing; How long after an upload can a music claim be brought; How does a plaintiff prove a song was copied; Does a mix that uses many songs multiply the damages.
- M13 Work for hire, transfers, termination (law last checked 2026-11-10). Questions like: Who owns a song or recording a creator made for a label or publisher; Does a user who mixes others' music own the mix; Can a songwriter or artist take back a music grant years later; Does a licence signed before termination survive it; Does a transfer need to be in writing; Who owns music made for the platform by a contractor.
- M14 Deal terms (law last checked 2026-11-10). Questions like: Who owns a song after a record deal or publishing deal; Does a transfer of music rights need a signed writing; Can an artist terminate a label grant and what happens to mixes already made; Who can license a song for sync in a video, and is that negotiated each time; Does the Spotify or label deal cover use in a user mix; Can a performer's digital replica be licensed in a services contract.

### 04-ai-voice-publicity.md
AI, voice clones and publicity: AI training and outputs, voice clones and digital replicas, publicity and false endorsement.
- M15 AI training and outputs (law last checked 2026-11-10). Questions like: Can a user put AI generated music in a mix; Who owns AI generated music; Is training an AI model on songs fair use; Does the TRAIN Act or any AI music bill apply today; Does the EU or UK let AI companies train on music; Can a platform process audio a user made with AI.
- M16 Voice clones and digital replicas (law last checked 2026-11-10). Questions like: Can a user put an AI clone of a famous singer's voice in a mix; Is a platform liable for a user mix that contains a voice clone; Does the NO FAKES Act apply to a mixing platform or a processing tool; Which states protect voice; Does a soundalike need a licence; What does the UK protect.
- M17 Publicity and false endorsement (law last checked 2026-11-10). Questions like: Can a user put a pop star's voice or a soundalike in a mix; Does an AI voice clone of a singer in an uploaded mix create liability for the platform; Does the ELVIS Act or California law reach a platform that hosts the mix; Would NO FAKES make a platform set up takedown and stay down; Does a processing tool face any digital replica duty when it processes user audio.

### 05-uk-eu.md
UK and EU: UK and EU music law.
- M18 UK music copyright (law last checked 2026-11-10). Questions like: Do UK users need separate licences for the song and the recording; Is a mixing platform liable in the UK if a user uploads a mix with songs; Does the UK have a fair use rule or a parody exception a platform can rely on; Can a platform train or tune AI on UK music; Who owns a UK recording made by a producer or an employee; Do UK performers have rights over a recording used in a mix.
- M19 EU music law for an upload platform (law last checked 2026-11-10). Questions like: Would a platform that hosts user mixes be an online content sharing service provider in the EU; Does the EU hosting safe harbor protect a platform for user mixes with music; Who licenses music in the EU and on what terms; Can users rely on parody or quotation when uploading a mix; Does EU law let rightholders block AI training on their music; What does the AI Act require of model providers about copyright.

### 06-remixes-covers-dj-mixes.md
Remixes, covers, stem tools and DJ mixes: remixes and derivative works, covers and the compulsory licence, stem separation tools and DJ mixes.
- M21 Remixes and derivative works (law last checked 2026-11-13). Questions like: Who has to give permission for a remix; Who owns a remix; Can I protect a remix I made without permission; Does changing a song enough make it mine; Is a re-played version safer than using the original recording; Can a remix or mashup be fair use.
- M22 Covers and the compulsory mechanical licence (law last checked 2026-11-13). Questions like: What does a cover licence allow; Can I change the arrangement of a song I cover; Does a cover licence cover a remix or mashup; Why does a cover in a video need a sync licence; Does a cover licence let me use the original recording; What do distributors require for a cover.
- M23 Stem tools and DJ mixes (law last checked 2026-11-13). Questions like: Is it legal to host or stream DJ mixes of commercial songs; Is the maker of a stem splitter or mixing tool liable for what users do; Does the statutory webcasting licence cover saved or on-demand mixes; How do licensed mix services clear the tracks; What does a live DJ stream need; Is splitting a song into stems a copy.

### 07-remix-platform-part1.md
Remix platform, part 1: licensed platform models and distributor rules, the remix platform application and the remix playbooks.
- M24 Licensed platform models, distributor rules and stem model licences (law last checked 2026-11-13). Questions like: How do licensed mix platforms clear the music; Will a distributor take a remix or a cover; Can we use an open source stem splitter in a paid product; Is a code licence the same as a licence for the model weights; What does it mean when a model page says nothing about a licence; Which licences would a mix platform need to sign.
- M25 DJ-mix platform application, feature by feature (law last checked 2026-11-13). Questions like: Which features of a mixing app need licences; Is private mixing on my own device lower risk than sharing; What happens when users upload commercial tracks; Can users export or download their mixes; Does charging money change the legal risk; Do Canada, Australia, the UK or the EU treat user remixes differently.
- playbook Questions for a licensed music attorney.

### 07-remix-platform-part2.md
Remix platform, part 2: licensed platform models and distributor rules, the remix platform application and the remix playbooks.
- playbook DJ-mix platform playbook.
- playbook Quick answers for the DJ-mix platform team.
