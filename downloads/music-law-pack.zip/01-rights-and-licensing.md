# Music law knowledge pack: Rights and licensing
- File: 01-rights-and-licensing.md, part of the music law knowledge pack (remix edition).
- Contains: M01 Composition and master; M02 Exclusive rights and the 114 limits; M03 Mechanicals, 115, the MLC, MMA; M04 CRB rates and proceedings (Phonorecords, Web, NSS); M05 PROs and consent decrees; M06 SoundExchange, 114 and 112; M07 Sync and master use licensing for video. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-10.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M01 Composition and master
- Law last checked: 2026-11-10. Volatility: low.
- Use for questions like: What are the two copyrights in a recorded song; Who usually owns the composition and who owns the master; Is the audio of a mix posted with video a sound recording; Does a sound recording copyright cover the song underneath; Which exclusive rights attach to a composition versus a master; Can one party license only part of a copyright

### Bottom line
- In the US (federal), a recorded song carries two separate copyrights: the musical work (composition) and the sound recording (master) [M-0028, M-0029, M-0025].
- Owning or licensing one never gives you the other. Different people usually control them, and any use in a video needs permission from each owner (analysis).
- The statute defines "sound recordings" to exclude sounds accompanying an audiovisual work [M-0030, M-0337, M-0508]. That carve-out is why a track placed in a video needs direct sync and master use licences (analysis).
- Nothing on this card says any song is cleared. Name the missing licence and who grants it.

### Rules
#### Two works
- 17 U.S.C. 102(a) lists musical works, including any accompanying words, as copyrightable [M-0028]. It lists sound recordings as their own category [M-0029, M-0105].
- The Copyright Office says a sound recording is a separate work from the composition, and a sound recording copyright is not a substitute for copyright in the underlying composition (regulator guidance, Circular 56A) [M-0025].
- The Office treats a sound recording as a derivative work of the underlying composition (regulator guidance, not statute) [M-0026]. Section 101 defines a derivative work as one based on preexisting works, such as a sound recording or musical arrangement [M-0035].
- Authors of the composition are composers, lyricists and songwriters. Authors of the recording are performers, producers and sound engineers, as the circular chart lists them [M-0027].

#### Definitions that matter for video
- A "sound recording" results from fixing a series of sounds, but not including the sounds accompanying a motion picture or other audiovisual work [M-0030, M-0337, M-0508].
- "Phonorecords" are material objects fixing sounds, other than sounds accompanying an audiovisual work [M-0031, M-0338, M-0119].
- "Copies" are material objects other than phonorecords in which a work is fixed [M-0033]. The statute does not say how that applies to a video file with music in it.
- Reading of the definition (unverified): the audio track of a short video is not itself a sound recording, but a commercial track inside it keeps its own sound recording and composition copyrights [M-0032]. This is an inference, not statutory text.
- The 114 and 115 statutory licences are not a route for music placed in a video. Sync (composition) and master use (recording) are direct licences (analysis) [M-0030].

#### Rights that attach
- Reproduction (106(1)): both musical works and sound recordings carry it, subject to sections 107 to 122 [M-0108, M-0334].
- Public performance of a musical work (106(4)) is an exclusive right of the composition owner [M-0106, M-0335, M-0183].
- Sound recordings have a public performance right only by digital audio transmission (106(6)) [M-0107, M-0336].
- Performance societies license public performance of nondramatic musical works for owners. That is the performance leg only [M-0341].
- The performance right is separate from reproduction, distribution and sync (analysis) [M-0183].

#### Ownership and splitting rights
- Copyright vests first in the author. Authors of a joint work are co-owners [M-0037]. A joint work is prepared by two or more authors intending their contributions to merge into inseparable or interdependent parts of a unitary whole [M-0036].
- Ownership can be transferred in whole or in part by any conveyance or by operation of law [M-0038].
- Any exclusive right, and any subdivision of it, can be transferred and owned separately [M-0039]. So one right (for example sync) can sit with a different party from another (for example performance).
- A transfer of ownership includes an assignment or exclusive licence but not a nonexclusive licence [M-0034].
- Work made for hire: an employee's work within the scope of employment, or a commissioned work in a listed category with a signed written agreement [M-0045, M-0046]. The employer or commissioning party is then the author and owner unless a signed writing says otherwise [M-0048].
- The listed categories do not name sound recordings. Whether a master is made for hire turns on the employee prong or fitting a category such as compilation or part of an audiovisual work (analysis, unsettled) [M-0047]. Detail is in M13.

### Gotchas
- "I bought or streamed the song" gives a listener right, not a sync or master use licence (analysis).
- A master copyright does not cover the song, and a composition licence does not cover the recording [M-0025].
- Section 101 excludes video audio from "sound recording", but that does not strip the embedded song of protection (unverified) inference [M-0032]. Do not read the carve-out as "music in videos is free".
- Statutory 114 and 115 licences are not a shortcut for videos [M-0030].
- The M-0047 "unsettled" point is analysis. Source support beyond section 101 was not checked on the ledger.
- Circular 56A is regulator guidance, not statute [M-0025, M-0026]. The author chart flattens in the saved text, so lists are as given in the circular [M-0027].
- Statute text is as saved 2026-11-10. Check for amendment before relying on it.

### Open questions for counsel
- US federal: for a short video with a commercial track baked into the audio, do you read the section 101 definitions to leave the track's own sound recording copyright intact, and is there case law supporting that (M-0032 is only an inference, unverified)?
- US federal: does a platform re-encoding a creator's uploaded audio need its own licence, or can it rely on the creator's licence and a terms of service allocation?
- US federal: is a live stream performing a licensed song a performance by the platform, the creator or both, and which PRO or direct licences must exist?
- US federal: for a commissioned track used in creator videos, is a master "made for hire" under the audiovisual or compilation category in the current case law (M-0047)?
- Which counsel should draft the creator terms that require creators to hold both composition and master permissions?

### Sources
- co-circular-56a: U.S. Copyright Office, Circular 56A (https://www.copyright.gov/circs/circ56a.pdf)
- usc17-101: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101)
- usc17-102: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102)
- usc17-106: 17 U.S.C. 106 exclusive rights (https://www.law.cornell.edu/uscode/text/17/106)
- usc17-201: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201)

### Claims cited in M01
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0028] VERIFIED
- Claim: 17 U.S.C. 102(a) lists musical works, including any accompanying words, among the categories of copyrightable original works of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(2)
- Quote: "musical works, including any accompanying words; (3) dramatic"
- Checked: 2026-11-10

#### [M-0029] VERIFIED
- Claim: Sound recordings are listed as their own category of copyrightable work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "sound recordings; and (8)"
- Checked: 2026-11-10

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0030] VERIFIED
- Claim: Section 101 defines a sound recording as a work resulting from fixation of a series of sounds, excluding sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "sound recordings"
- Quote: "“Sound recordings” are works that result from the fixation of a series of musical, spoken, or other sounds, but not including the sounds accompanying a motion picture or other audiovisual work, regardless of the nature of the material objects, such"
- Checked: 2026-11-10

#### [M-0337] VERIFIED
- Claim: The statutory definition of "sound recordings" in section 101 excludes the sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'sound recordings'
- Quote: "but not including the sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0508] VERIFIED
- Claim: The 17 U.S.C. 101 definition of "sound recordings" excludes the sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "sound recordings"
- Quote: "but not including the sounds accompanying a motion picture or other audiovisual work, regardless of the"
- Checked: 2026-11-10

#### [M-0105] VERIFIED
- Claim: The listed categories of copyrightable works include sound recordings, separately from musical works.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "(7) sound recordings; and"
- Checked: 2026-11-10

#### [M-0026] VERIFIED
- Claim: The Copyright Office treats a sound recording as a derivative work of the underlying musical composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a substitute for, copyright"
- Checked: 2026-11-10

#### [M-0035] VERIFIED
- Claim: A derivative work is a work based upon one or more preexisting works, such as a sound recording or musical arrangement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "derivative work"
- Quote: "A “derivative work” is a work based upon one or more preexisting works, such as a translation, musical arrangement, dramatization, fictionalization, motion picture version, sound recording, art reproduction, abridgment, condensation"
- Checked: 2026-11-10

#### [M-0027] VERIFIED
- Claim: Authors of the composition are composers, lyricists and songwriters; authors of the sound recording are performers, producers and sound engineers (as listed in the circular chart).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A chart, Who is the author
- Quote: "Composers Lyricists Songwriters Performers Producers Sound Engineers How is it fixed? Copy"
- Checked: 2026-11-10

#### [M-0031] VERIFIED
- Claim: Section 101 defines phonorecords as material objects in which sounds, other than those accompanying an audiovisual work, are fixed and from which they can be perceived or reproduced.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "phonorecords"
- Quote: "“Phonorecords” are material objects in which sounds, other than those accompanying a motion picture or other audiovisual work, are fixed by any method now known or later developed, and from which the sounds can be perceived, reproduced, or otherwise communicated"
- Checked: 2026-11-10

#### [M-0338] VERIFIED
- Claim: Sounds accompanying an audiovisual work are also excluded from 'phonorecords'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'phonorecords'
- Quote: "sounds, other than those accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0119] VERIFIED
- Claim: By definition, phonorecords do not include material objects in which sounds accompanying an audiovisual work are fixed.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 (phonorecords)
- Quote: "Phonorecords are material objects in which sounds, other than those accompanying a motion picture or other audiovisual work, are fixed by any method now known or later developed"
- Checked: 2026-11-10

#### [M-0033] VERIFIED
- Claim: Section 101 defines 'copies' as material objects, other than phonorecords, in which a work is fixed and from which it can be perceived, reproduced or communicated.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "copies"
- Quote: "“Copies” are material objects, other than phonorecords, in which a work is fixed by any method now known or later developed, and from which the work can be perceived, reproduced"
- Checked: 2026-11-10

#### [M-0032] UNVERIFIED (unverified)
- Claim: Because the sound recording definition excludes sounds accompanying audiovisual works, the audio track of a short video is not itself a sound recording, but a music track embedded in it keeps its own sound recording and composition copyrights (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "sound recordings"
- Quote: "but not including the sounds accompanying a motion picture or other audiovisual work, regardless of the"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0334] VERIFIED
- Claim: The copyright owner has the exclusive right (subject to sections 107 through 122) to reproduce the copyrighted work in copies or phonorecords.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0335] VERIFIED
- Claim: Public performance of a musical work is an exclusive right of the musical work owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly"
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0336] VERIFIED
- Claim: For sound recordings the 106(6) public performance right is limited to performance by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0341] VERIFIED
- Claim: Performance rights societies license public performance of nondramatic musical works for the owners; this is the performance leg of the stack.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'performing rights society'
- Quote: "licenses the public performance of nondramatic musical works on behalf of copyright owners of such works"
- Checked: 2026-11-10

#### [M-0037] VERIFIED
- Claim: Copyright vests initially in the author or authors; authors of a joint work are co-owners.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(a)
- Quote: "Copyright in a work protected under this title vests initially in the author or authors of the work. The authors of a joint work are coowners of copyright in the"
- Checked: 2026-11-10

#### [M-0036] VERIFIED
- Claim: A joint work is prepared by two or more authors with the intention that contributions merge into inseparable or interdependent parts of a unitary whole.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "joint work"
- Quote: "A “joint work” is a work prepared by two or more authors with the intention that their contributions be merged into inseparable or interdependent parts of a unitary whole. “Literary works” are works, other than"
- Checked: 2026-11-10

#### [M-0038] VERIFIED
- Claim: Ownership of a copyright may be transferred in whole or in part by any means of conveyance or by operation of law.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(1)
- Quote: "The ownership of a copyright may be transferred in whole or in part by any means of conveyance or by operation of law, and may be bequeathed by will or"
- Checked: 2026-11-10

#### [M-0039] VERIFIED
- Claim: Any of the exclusive rights, and any subdivision of them, may be transferred and owned separately.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(2)
- Quote: "Any of the exclusive rights comprised in a copyright, including any subdivision of any of the rights specified by section 106, may be transferred as provided by clause (1) and"
- Checked: 2026-11-10

#### [M-0034] VERIFIED
- Claim: A transfer of copyright ownership includes an assignment or exclusive licence but excludes a nonexclusive licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "transfer of copyright ownership"
- Quote: "any other conveyance, alienation, or hypothecation of a copyright or of any of the exclusive rights comprised in a copyright, whether or not it is limited in time or place of effect, but not including a nonexclusive license."
- Checked: 2026-11-10

#### [M-0045] VERIFIED
- Claim: Section 101 defines a work made for hire as a work prepared by an employee within the scope of employment, or one of nine commissioned categories with a signed written agreement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire"
- Quote: "A “work made for hire” is-- (1) a work prepared by an employee within the scope of his or her employment; or (2) a work"
- Checked: 2026-11-10

#### [M-0046] VERIFIED
- Claim: A commissioned (non-employee) work counts as made for hire only if it falls in an enumerated category, including a contribution to a collective work, part of a motion picture or other audiovisual work, and a compilation, and the parties expressly agree in a signed written instrument.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "a work specially ordered or commissioned for use as a contribution to a collective work, as a part of a motion picture or other audiovisual work, as a translation, as a supplementary work, as a compilation, as an instructional text"
- Checked: 2026-11-10

#### [M-0048] VERIFIED
- Claim: In a work made for hire the employer or commissioning party is the author and, unless the parties agree otherwise in a signed writing, owns all rights in the copyright.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(b)
- Quote: "In the case of a work made for hire, the employer or other person for whom the work was prepared is considered the author for purposes of this title, and, unless the parties have expressly agreed otherwise in a written"
- Checked: 2026-11-10

#### [M-0047] VERIFIED
- Claim: The category list does not name sound recordings; whether a sound recording is made for hire turns on the employee prong or on fitting a listed category such as compilation or part of an audiovisual work (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "as a part of a motion picture or other audiovisual work, as a translation, as a"
- Checked: 2026-11-10

## M02 Exclusive rights and the 114 limits
- Law last checked: 2026-11-10. Volatility: low.
- Use for questions like: Do I need a licence from the label if I already have the songwriter's; Does the statutory webcasting licence cover an app that streams user mixes; Can a sound-alike recording avoid the master owner; Does a PRO licence cover a platform copying and processing user audio; Does the MLC blanket licence cover songs in a user mix; Why does a sound recording have no general performance right

### Bottom line
- US federal law: a song is two copyrights. The composition (words and music) and the sound recording (the recorded performance) are separate works with separate owners [M-0025, M-0028, M-0029].
- The statutory licences in 112, 114 and 115 do not cover music placed in a video. A platform that hosts music in user videos needs direct licences: sync from the composition owner and master use from the recording owner [M-0112, M-0340, M-0179, M-0180].
- Re-encoding is still copying the sounds [M-0108, M-0110]. (analysis) Blurring or muting is not a licence either. This card is not legal advice; see the counsel section.

### Rules
#### Two works
- A sound recording is a separate work from the composition. Owning one is not a substitute for the other (regulator guidance, Circular 56A) [M-0025].
- The Copyright Office treats a sound recording as a derivative work of the composition (regulator guidance) [M-0026].
- Authors of the composition are composers, lyricists and songwriters. Authors of the recording are performers, producers and sound engineers [M-0027].
- 17 U.S.C. 102(a) lists musical works with any accompanying words [M-0028] and sound recordings [M-0029, M-0105] as separate categories.

#### Rights under 106
- Both works carry the reproduction right (copies or phonorecords) [M-0108, M-0334], subject to sections 107 through 122 [M-0334].
- The composition owner has an exclusive public performance right [M-0106, M-0335, M-0183].
- A sound recording owner has only the 106(1), (2), (3) and (6) rights [M-0296]. The performance right is only by digital audio transmission [M-0107, M-0336]. There is no general public performance right under 106(4) [M-0109].

#### The 114(b) limit and sound-alikes
- The recording's reproduction right covers only duplication that recaptures the actual sounds [M-0110].
- An independent sound-alike fixation does not infringe the recording copyright [M-0111]. The composition is a separate copyright, so (analysis) a sound-alike still needs a composition licence [M-0111].

#### The 114 statutory licence
- 114(d)(2) covers subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite radio transmissions, if conditions are met [M-0114, M-0298].
- The transmission must not be part of an interactive service [M-0115, M-0298]. An interactive service lets a member of the public receive a program made for them or, on request, a particular recording [M-0113, M-0299].
- An eligible nonsubscription transmission is a noninteractive, nonsubscription digital audio transmission made as part of a service providing audio programming [M-0300].
- A "digital audio transmission" does not include transmission of any audiovisual work [M-0112, M-0297]. So the 114(d)(2) licence does not extend to a video with music [M-0112, M-0180, M-0312].
- Rates: the Judges use a willing buyer, willing seller standard [M-0167]. Rates and terms last 5 years unless otherwise agreed and bind affected owners [M-0168]. Specific rates are for M04 and M06.
- An interactive service may not publicly perform a recording unless a licence exists for each musical work in it [M-0301]. (analysis) Even an interactive service would still need a composition performance licence, from a PRO or the owner [M-0313].
- Receipts: 50 percent to the recording owner [M-0302], 45 percent to featured artists [M-0303], distributed by a nonprofit collective the Judges designate [M-0304].

#### The 112 ephemeral copy limit
- 112(e)(1) gives a statutory licence for one ephemeral phonorecord, to a transmitting organization entitled to transmit under 114(d)(1)(C)(iv) or a 114(f) statutory licence, if the listed conditions are met [M-0116].
- The 112(a) ephemeral privilege excludes motion pictures and other audiovisual works [M-0117].
- (analysis) A platform cannot rely on 112 for server copies of video with music [M-0181].

#### The 115 mechanical licence
- Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing [M-0339].
- It is limited to phonorecords whose primary purpose is distribution to the public for private use [M-0120].
- A digital phonorecord delivery does not include digital transmission of sounds accompanying a motion picture or other audiovisual work [M-0340]. The 1976 House Report says the same of sound tracks (legislative history) [M-0121].
- (analysis) So 115 does not license putting a song into a user video. Sync stays a direct licence [M-0179, M-0342].
- The Music Modernization Act blanket licence is issued through the MLC to digital music providers [M-0023, M-0122]. It covers digital phonorecord deliveries including interactive streams [M-0123, M-0124], all musical works available for compulsory licensing, except as provided in subparagraph (C) (voluntary licences and individual download authority) [M-0125], and necessary server and incidental copies [M-0126].
- Blanket licences were available only from the licence availability date [M-0127]. The MLC administers them and collects and distributes royalties [M-0128, M-0129]. Significant nonblanket licensee thresholds: over 5,000 recordings on any day in a month, or $50,000 a month or $500,000 over 12 months [M-0136]. Detail is for M03.

### Gotchas
- "We pay SoundExchange or a PRO, so we are covered": the 114 licence excludes audiovisual transmission [M-0112], and PRO licences address composition performance, not sync (see M05) [M-0088]. Neither is sync or master use.
- "The MLC licence covers songs in videos": it does not [M-0340, M-0179].
- "Muting or editing avoids it": re-encoding is still copying the sounds [M-0108, M-0110]. (analysis) Editing or muting alone is not a licence; removing the audio before publishing is the lawful path.
- "Sound recordings have no performance right": only in the general sense. A digital audio transmission right exists [M-0107].
- Rates, the MLC and the Judges' proceedings change. Check M03, M04 and M06 for 2026 figures. Facts here are statute text as of 2026-11-10.
- (unverified) M-0317 is an inference, not a verified rule.

### Open questions for counsel
- US: does a short video with a licensed library track still need a separate live-room performance licence?
- US: if a platform hosts a creator's upload with a commercial song, is the creator or the platform the direct infringer, and does 512 protect it (see M08)?
- US: does a platform's re-encoding of user audio create a reproduction exposure for the platform as opposed to the user?
- US: is a sound-alike track safe if it copies a recognisable arrangement?
- US: could a tiny live-room audio feed qualify as an interactive service under 114(j)(7)?

### Sources
- usc17-102: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102)
- usc17-106: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106)
- usc17-112: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112)
- usc17-114: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-115: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115)
- co-circular-56a: U.S. Copyright Office, Circular 56A (https://www.copyright.gov/circs/circ56a.pdf)

### Claims cited in M02
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0028] VERIFIED
- Claim: 17 U.S.C. 102(a) lists musical works, including any accompanying words, among the categories of copyrightable original works of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(2)
- Quote: "musical works, including any accompanying words; (3) dramatic"
- Checked: 2026-11-10

#### [M-0029] VERIFIED
- Claim: Sound recordings are listed as their own category of copyrightable work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "sound recordings; and (8)"
- Checked: 2026-11-10

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0340] VERIFIED
- Claim: A digital phonorecord delivery under 115 does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work, so such transmissions are outside the 115 DPD licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0179] VERIFIED
- Claim: Analysis: a 115 compulsory licence, including the MLC blanket licence under 115(d), is limited to phonorecords made mainly for distribution to the public for private use, and 101 excludes sounds accompanying audiovisual works from "phonorecords", so 115 does not license putting a song into a user video; sync stays a direct licence.
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0180] VERIFIED
- Claim: Analysis: the 114(d)(2) statutory licence covers digital audio transmissions, which exclude transmission of any audiovisual work, and requires the transmission not be part of an interactive service, so it cannot cover a short-video app.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0026] VERIFIED
- Claim: The Copyright Office treats a sound recording as a derivative work of the underlying musical composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a substitute for, copyright"
- Checked: 2026-11-10

#### [M-0027] VERIFIED
- Claim: Authors of the composition are composers, lyricists and songwriters; authors of the sound recording are performers, producers and sound engineers (as listed in the circular chart).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A chart, Who is the author
- Quote: "Composers Lyricists Songwriters Performers Producers Sound Engineers How is it fixed? Copy"
- Checked: 2026-11-10

#### [M-0105] VERIFIED
- Claim: The listed categories of copyrightable works include sound recordings, separately from musical works.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "(7) sound recordings; and"
- Checked: 2026-11-10

#### [M-0334] VERIFIED
- Claim: The copyright owner has the exclusive right (subject to sections 107 through 122) to reproduce the copyrighted work in copies or phonorecords.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0335] VERIFIED
- Claim: Public performance of a musical work is an exclusive right of the musical work owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly"
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0296] VERIFIED
- Claim: Sound recording owners have only the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0336] VERIFIED
- Claim: For sound recordings the 106(6) public performance right is limited to performance by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0109] VERIFIED
- Claim: A sound recording has no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)."
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0114] VERIFIED
- Claim: 17 U.S.C. 114(d)(2) subjects subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite digital audio radio service transmissions to statutory licensing if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)
- Quote: "a subscription digital audio transmission not exempt under paragraph (1), an eligible nonsubscription transmission, or a transmission not exempt under paragraph (1) that is made by a preexisting satellite digital audio radio service shall be subject to statutory licensing"
- Checked: 2026-11-10

#### [M-0298] VERIFIED
- Claim: The 114 statutory licence reaches subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite DARS transmissions, and the transmission must not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0113] VERIFIED
- Claim: Under 17 U.S.C. 114(j)(7), an interactive service is one that lets a member of the public receive on request a transmission of a particular sound recording selected by or for the recipient.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0299] VERIFIED
- Claim: An interactive service is one that lets a member of the public receive a program made for the recipient or, on request, a particular sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0300] VERIFIED
- Claim: An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission, not exempt under (d)(1), made as part of a service providing audio programming consisting in whole or in part of performances of sound recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(6)
- Quote: "An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission not exempt under subsection (d)(1) that is made as part of a service that provides audio programming consisting, in whole or in part, of performances of sound recordings"
- Checked: 2026-11-10

#### [M-0297] VERIFIED
- Claim: A digital audio transmission is a digital transmission that embodies a sound recording and does not include transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "A digital audio transmission is a digital transmission as defined in section 101, that embodies the transmission of a sound recording. This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0312] VERIFIED
- Claim: Analysis: the 17 U.S.C. 114 statutory licence does not cover short videos on a user upload platform because a "digital audio transmission" under 114(j)(5) does not include the transmission of any audiovisual work.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0167] VERIFIED
- Claim: The Judges' standard for 114(d)(2) rates is the rates a willing buyer and willing seller would negotiate in the marketplace.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(B)
- Quote: "The Copyright Royalty Judges shall establish rates and terms that most clearly represent the rates and terms that would have been negotiated in the marketplace between a willing buyer and a willing seller."
- Checked: 2026-11-10

#### [M-0168] VERIFIED
- Claim: 114(d)(2) rates and terms set by the Judges are for a 5-year period (or other period agreed) and bind all copyright owners of sound recordings and entities performing sound recordings affected.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(A)-(B)
- Quote: "be binding on all copyright owners of sound recordings and entities performing sound recordings affected by this paragraph during the 5-year period specified in subparagraph (A)"
- Checked: 2026-11-10

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0313] VERIFIED
- Claim: Analysis: if a platform qualified as an interactive service, 114(d)(3)(C) would still require a licence for the public performance of each musical work in the sound recording, which may come from a performing rights society or the copyright owner.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0302] VERIFIED
- Claim: Statutory 114 receipts split 50 percent to the sound recording copyright owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(A)
- Quote: "50 percent of the receipts shall be paid to the copyright owner of the exclusive right under section 106(6) of this title to publicly perform a sound recording by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0303] VERIFIED
- Claim: Statutory 114 receipts pay 45 percent to the featured recording artists.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(D)
- Quote: "45 percent of the receipts shall be paid, on a per sound recording basis, to the recording artist or artists featured on such sound recording"
- Checked: 2026-11-10

#### [M-0304] VERIFIED
- Claim: A nonprofit collective designated by the Copyright Royalty Judges distributes statutory 114 receipts.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)
- Quote: "a nonprofit collective designated by the Copyright Royalty Judges to distribute receipts from the licensing of transmissions in accordance with subsection (f) shall distribute such receipts as follows"
- Checked: 2026-11-10

#### [M-0116] VERIFIED
- Claim: 17 U.S.C. 112(e)(1) gives a transmitting organization entitled to transmit under 114(d)(1)(C)(iv) or a 114(f) statutory licence a statutory licence to make no more than 1 ephemeral phonorecord of the sound recording, if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(e)(1)
- Quote: "transmitting organization entitled to transmit to the public a performance of a sound recording under the limitation on exclusive rights specified by section 114(d)(1)(C)(iv) or under a statutory license in accordance with section 114(f) is entitled to a statutory license"
- Checked: 2026-11-10

#### [M-0117] VERIFIED
- Claim: The 112(a) ephemeral recording privilege excludes motion pictures and other audiovisual works.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(a)(1)
- Quote: "except in the case of a motion picture or other audiovisual work, it is not an infringement of copyright for a transmitting organization"
- Checked: 2026-11-10

#### [M-0181] VERIFIED
- Claim: Analysis: the 112(a)(1) ephemeral copy exemption excludes audiovisual works and the 112(e) statutory licence attaches only to transmissions under 114 licences, so a platform cannot rely on 112 for server copies of video-with-music.
- Jurisdiction: analysis
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(a)(1), (e)(1)
- Quote: "except in the case of a motion picture or other audiovisual work, it is not an infringement of copyright for a transmitting organization"
- Checked: 2026-11-10

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0120] VERIFIED
- Claim: The 115 compulsory licence is limited to phonorecords whose primary purpose is distribution to the public for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0121] VERIFIED
- Claim: 1976 House Report: the 115 compulsory licence does not reach sound tracks accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115, H.R. Rep. 94-1476 note on 115(a)(1)
- Quote: "(including disks and audio tapes but not the sound tracks or other sound records accompanying a motion picture or other audiovisual work)"
- Checked: 2026-11-10

#### [M-0342] VERIFIED
- Claim: Analysis: the 17 U.S.C. 115 statutory mechanical licence does not reach music placed in a video, because a digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work; sync and master use therefore need direct licences (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0023] VERIFIED
- Claim: Under the Music Modernization Act, a digital music provider can obtain a blanket mechanical license through the mechanical licensing collective.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0123] VERIFIED
- Claim: Covered activity means making a digital phonorecord delivery of a musical work (permanent download, limited download, interactive stream) that qualifies for a compulsory licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(7)
- Quote: "The term covered activity means the activity of making a digital phonorecord delivery of a musical work, including in the form of a permanent download, limited download, or interactive stream"
- Checked: 2026-11-10

#### [M-0124] VERIFIED
- Claim: A digital phonorecord delivery is a delivery of a phonorecord by digital transmission of a sound recording; it includes an interactive stream.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "includes a permanent download, a limited download, or an interactive stream."
- Checked: 2026-11-10

#### [M-0125] VERIFIED
- Claim: The blanket licence covers all musical works (or shares) available for compulsory licensing for covered activities, except as provided in subparagraph (C) (voluntary licences and individual download authority).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(i)
- Quote: "covers all musical works (or shares of such works) available for compulsory licensing under this section for purposes of engaging in covered activities, except as provided in subparagraph (C);"
- Checked: 2026-11-10

#### [M-0126] VERIFIED
- Claim: The blanket licence includes server, intermediate, archival and incidental reproductions reasonable and necessary for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(ii)
- Quote: "includes the making and distribution of server, intermediate, archival, and incidental reproductions of musical works that are reasonable and necessary for the digital music provider to engage in covered activities"
- Checked: 2026-11-10

#### [M-0127] VERIFIED
- Claim: Blanket licences were made available only from the license availability date; none was effective before.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(2)(B)
- Quote: "Blanket licenses shall be made available by the mechanical licensing collective on and after the license availability date."
- Checked: 2026-11-10

#### [M-0128] VERIFIED
- Claim: The MLC administers blanket licences, including notices of license and usage reports.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(I)
- Quote: "Offer and administer blanket licenses, including receipt of notices of license and reports of usage from digital music providers."
- Checked: 2026-11-10

#### [M-0129] VERIFIED
- Claim: The MLC collects and distributes royalties from digital music providers for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(II)
- Quote: "Collect and distribute royalties from digital music providers for covered activities."
- Checked: 2026-11-10

#### [M-0136] VERIFIED
- Claim: A significant nonblanket licensee (an entity operating under voluntary or individual download licences, not under a blanket licence) is one that on any day in a calendar month makes more than 5,000 different sound recordings of musical works available through its service, or meets the revenue thresholds ($50,000 a month; $500,000 over 12 months).
- Jurisdiction: industry
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(31)(A)(iii)(I)
- Quote: "on any day in a calendar month, makes more than 5,000 different sound recordings of musical works available through such service"
- Checked: 2026-11-10

#### [M-0088] VERIFIED
- Claim: In the US public performance rights for compositions come through PROs (ASCAP, BMI, GMR, SESAC) under blanket licences, with usage reporting duties and one to four year terms.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "In the United States, public performance rights are generally obtained through intermediaries known as performing rights organizations (“PROs”), which negotiate blanket licenses with copyright users for the public performance of"
- Checked: 2026-11-10

#### [M-0317] UNVERIFIED (unverified)
- Claim: Analysis: PRO licences cover the composition's public performance only. A tool that re-encodes the user's own video and audio for the user is not itself performing music to the public (inference), so its PRO exposure turns on public distribution, not on the private rendering.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

## M03 Mechanicals, 115, the MLC, MMA
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Who issues the blanket mechanical licence and since when; Does a mixing platform need a mechanical licence to store or stream songs; What is the current mechanical rate; Does the MLC blanket licence cover songs in a mix posted with video; Is the Phonorecords V settlement final

### Bottom line
- US federal law. The 115 mechanical licence covers the composition only, for phonorecords made mainly for private-use distribution, and it does not reach music placed in a video [M-0120, M-0340, M-0342]. Sync (composition) and master use (recording) need direct licences from the rights holders (analysis) [M-0179].
- The MLC issues the MMA blanket licence to digital music providers for covered activities [M-0023, M-0128]. The Copyright Office continued the MLC designation on June 3, 2026 [M-0131].
- The 2026 rate for physical phonorecords and permanent downloads is 13.1 cents per work or 2.52 cents per minute, whichever is larger, and it is a 2026 rate only [M-0142, M-0143].
- Not legal advice. A licensed music attorney must confirm any claim that a platform needs no licence.

### Rules
#### What 115 covers (17 U.S.C.)
- 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing [M-0339].
- A person may obtain the compulsory licence only if the primary purpose is distributing phonorecords to the public for private use [M-0120].
- The definition of a digital phonorecord delivery excludes digital transmission of sounds accompanying a motion picture or other audiovisual work [M-0340].
- The 1976 House Report (legislative history, not binding) said the licence does not reach sound tracks accompanying audiovisual works. Clause numbering has since changed, so treat it as history only [M-0121].
- Analysis: 115, including the 115(d) blanket licence, does not license putting a song into a user video. Sync stays a direct licence [M-0179, M-0342].
- The Copyright Office said in 2015 (regulator report, not binding) that consumer audiovisual uses should stay in the free market, and it did not recommend a compulsory licence for them [M-0140]. The MMA did not add audiovisual uses [M-0120].
- "Sync" is an industry term for reproducing a musical work synchronized to visual content [M-0141] (industry practice).

#### The MMA blanket licence and the MLC
- A digital music provider can obtain a blanket mechanical licence through the MLC [M-0023, M-0122]. It covers digital phonorecord deliveries, meaning permanent downloads, limited downloads and interactive streams [M-0123, M-0124].
- It covers all musical works available for compulsory licensing for covered activities, except as provided in subparagraph (C), which covers voluntary licences [M-0125].
- It includes server, intermediate, archival and incidental reproductions reasonable and necessary for covered activities [M-0126].
- The MLC administers blanket licences, including notices of licence and usage reports [M-0128]. It collects and distributes royalties from providers [M-0129].
- A provider obtains the blanket licence by submitting a notice of licence to the MLC (regulation, 37 CFR 210.24) [M-0137].
- Blanket licences were available only from the licence availability date [M-0127]. The MLC says it began administering them on January 1, 2021 (MLC website, volatile) [M-0133].
- A provider may keep or enter voluntary licences with publishers instead of, or alongside, the blanket licence (MLC FAQ) [M-0135].
- A significant nonblanket licensee is one operating under voluntary or individual download licences that offers more than 5,000 different sound recordings on any day in a month, or meets revenue thresholds ($50,000 a month; $500,000 over 12 months) [M-0136].
- The Register designated the MLC and the Digital Licensee Coordinator effective July 8, 2019 [M-0130]. The Office opened a periodic review in 2024 [M-0132] and, in its first review, continued both designations effective June 3, 2026 [M-0007, M-0131].
- The DLC coordinates communication among the providers affected by the MMA (MLC FAQ; the statute is the primary source) [M-0134].

#### Rates (Copyright Royalty Board, regulations)
- Part 385 sets rates only where a 115 compulsory licence is obtained and the exclusive rights are implicated [M-0138]. Voluntary licence rates and terms apply in lieu of part 385 [M-0139].
- 2026 only: the larger of 13.1 cents per work or 2.52 cents per minute of playing time or fraction, for physical phonorecords and permanent downloads [M-0142]. The cost of living notice sets this effective December 1, 2025, applicable January 1 to December 31, 2026 [M-0143], using CPI-U 324.800 against a November 2022 base of 298.012 [M-0144].
- Ringtones: a flat 24 cents per work [M-0145].
- Streaming and limited downloads: the all-in royalty is the greater of a percent of service provider revenue and the TCC prong [M-0147]. The percent runs 15.1 (2023) to 15.35 (2027) [M-0146].
- Phonorecords IV applies from January 1, 2023 through December 31, 2027 [M-0148]. A March 2024 correction fixed capitalization and a late-fee term [M-0149].
- Phonorecords V, for 2028 to 2032, began on December 31, 2025 [M-0150]. Petitions to participate were due January 30, 2026 [M-0151].
- Proposed only: on July 10, 2026 the Judges published a proposed partial settlement that would continue the physical, permanent download, ringtone and bundle rates with only continuing inflation adjustments [M-0152, M-0153]. Comments were due August 10, 2026. Final adoption is unconfirmed as of 2026-11-10. It is not law. The notice does not settle streaming (inference per the row note) [M-0153].

### Gotchas
- "The MLC covers me" is wrong for video. The blanket licence is a 115 licence for phonorecords and digital deliveries, not sync [M-0122, M-0179].
- The 13.1 cent figure is 2026 only and adjusts annually [M-0142, M-0143]. Check the Federal Register for 2027 before quoting a rate.
- Phonorecords V is a proposal as of the July 10, 2026 notice. Do not say the 2028 to 2032 rates are set [M-0152].
- Rates cover composition royalties only, not the master recording.
- The statutory percent table ends with royalty year 2027 [M-0146, M-0148].
- MLC website statements (start date, FAQ answers) are MLC's own words, captured 2026-11-10, and may change [M-0133, M-0135].
- Open source gaps: Phonorecords V final rule is not in the ledger. Do not guess it.

### Open questions for counsel
- US: Does any platform feature, such as a standalone audio or playlist function, make the platform a digital music provider that must file a notice of licence with the MLC?
- US: For user video with licensed library music, what warranties and indemnities should a platform require from the library and from creators?
- US: Does a platform's private re-encode of a user's own audio need any licence, or only the user's rights?
- US: Should a platform watch Phonorecords V for any term change affecting streaming rates after 2027?

### Sources
- usc17-115: 17 U.S.C. 115 (https://www.law.cornell.edu/uscode/text/17/115)
- cfr37-385: 37 CFR Part 385 (eCFR as of 2026-10-26)
- cfr37-210: 37 CFR Part 210
- crb-phono-cola-2026: 2026 COLA notice, 90 FR (Dec. 1, 2025)
- crb-phono4-final, crb-phono4-corrections-2024: Phonorecords IV
- crb-phono5-commencement, crb-phono5-proposed-settlement-2026: Phonorecords V
- fr-mlc-designation-2019, fr-mlc-periodic-review-noi-2024, fr-mlc-continuing-designation-2026: MLC and DLC designation
- mlc-dsp-faqs-blanket-license: The MLC DSP FAQs (https://www.themlc.com/dsp-faqs)
- co-music-marketplace-2015: Copyright and the Music Marketplace (2015)

### Claims cited in M03
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0120] VERIFIED
- Claim: The 115 compulsory licence is limited to phonorecords whose primary purpose is distribution to the public for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0340] VERIFIED
- Claim: A digital phonorecord delivery under 115 does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work, so such transmissions are outside the 115 DPD licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0342] VERIFIED
- Claim: Analysis: the 17 U.S.C. 115 statutory mechanical licence does not reach music placed in a video, because a digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work; sync and master use therefore need direct licences (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0179] VERIFIED
- Claim: Analysis: a 115 compulsory licence, including the MLC blanket licence under 115(d), is limited to phonorecords made mainly for distribution to the public for private use, and 101 excludes sounds accompanying audiovisual works from "phonorecords", so 115 does not license putting a song into a user video; sync stays a direct licence.
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0023] VERIFIED
- Claim: Under the Music Modernization Act, a digital music provider can obtain a blanket mechanical license through the mechanical licensing collective.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0128] VERIFIED
- Claim: The MLC administers blanket licences, including notices of license and usage reports.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(I)
- Quote: "Offer and administer blanket licenses, including receipt of notices of license and reports of usage from digital music providers."
- Checked: 2026-11-10

#### [M-0131] VERIFIED
- Claim: The Copyright Office completed its first periodic review in 2026 and continued both the MLC and DLC designations.
- Jurisdiction: US-federal
- Source: Copyright Office, Periodic Review of the Designations of the MLC and DLC, notice of continuing designation, 91 FR (June 3, 2026), FR Doc. 2026-11117 (https://www.federalregister.gov/documents/full_text/text/2026/06/03/2026-11117.txt), source id fr-mlc-continuing-designation-2026
- Pinpoint: 91 FR 33208 (June 3, 2026), Summary; DATES: Effective June 3, 2026
- Quote: "has completed its first periodic review of the existing designations of the mechanical licensing collective and digital licensee coordinator and has determined that both designations should be continued."
- Checked: 2026-11-10

#### [M-0142] VERIFIED
- Claim: 2026 mechanical rate for physical phonorecords and permanent downloads is the larger of 13.1 cents per work or 2.52 cents per minute.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.11(a)(1)
- Quote: "the royalty rate payable for each work embodied in the phonorecord or Permanent Download shall be either 13.1 cents or 2.52 cents per minute of playing time or fraction thereof, whichever amount is larger."
- Checked: 2026-11-10

#### [M-0143] VERIFIED
- Claim: The 2026 COLA notice sets 13.1 cents per work and 2.52 cents per minute, effective December 1, 2025, applicable January 1 to December 31, 2026.
- Jurisdiction: US-federal
- Source: CRB, Cost of Living Adjustment to Royalty Rates and Terms for Making and Distributing Phonorecords (2026 rates), 90 FR (Dec. 1, 2025), FR Doc. 2025-21695 (https://www.federalregister.gov/documents/full_text/text/2025/12/01/2025-21695.txt), source id crb-phono-cola-2026
- Pinpoint: 90 FR 55044-55045 (Dec. 1, 2025)
- Quote: "The adjusted rates for 2026 are 13.1 cents for the per-work rate and 2.52 cents for the per-minute rate."
- Checked: 2026-11-10

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0121] VERIFIED
- Claim: 1976 House Report: the 115 compulsory licence does not reach sound tracks accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115, H.R. Rep. 94-1476 note on 115(a)(1)
- Quote: "(including disks and audio tapes but not the sound tracks or other sound records accompanying a motion picture or other audiovisual work)"
- Checked: 2026-11-10

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0141] VERIFIED
- Claim: The sync right is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), ch. 1 background
- Quote: "the right to synchronize musical works to visual content (e.g., in a music video). The synchronization (or synch right) is a species of the reproduction right and may also implicate the derivative work right."
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0123] VERIFIED
- Claim: Covered activity means making a digital phonorecord delivery of a musical work (permanent download, limited download, interactive stream) that qualifies for a compulsory licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(7)
- Quote: "The term covered activity means the activity of making a digital phonorecord delivery of a musical work, including in the form of a permanent download, limited download, or interactive stream"
- Checked: 2026-11-10

#### [M-0124] VERIFIED
- Claim: A digital phonorecord delivery is a delivery of a phonorecord by digital transmission of a sound recording; it includes an interactive stream.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "includes a permanent download, a limited download, or an interactive stream."
- Checked: 2026-11-10

#### [M-0125] VERIFIED
- Claim: The blanket licence covers all musical works (or shares) available for compulsory licensing for covered activities, except as provided in subparagraph (C) (voluntary licences and individual download authority).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(i)
- Quote: "covers all musical works (or shares of such works) available for compulsory licensing under this section for purposes of engaging in covered activities, except as provided in subparagraph (C);"
- Checked: 2026-11-10

#### [M-0126] VERIFIED
- Claim: The blanket licence includes server, intermediate, archival and incidental reproductions reasonable and necessary for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(ii)
- Quote: "includes the making and distribution of server, intermediate, archival, and incidental reproductions of musical works that are reasonable and necessary for the digital music provider to engage in covered activities"
- Checked: 2026-11-10

#### [M-0129] VERIFIED
- Claim: The MLC collects and distributes royalties from digital music providers for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(II)
- Quote: "Collect and distribute royalties from digital music providers for covered activities."
- Checked: 2026-11-10

#### [M-0137] VERIFIED
- Claim: A digital music provider obtains the blanket licence by submitting a notice of license to the MLC.
- Jurisdiction: US-federal
- Source: 37 CFR Part 210 compulsory license for making and distributing phonorecords, blanket license and MLC reporting (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=210), source id cfr37-210
- Pinpoint: 37 CFR 210.24(d)
- Quote: "to obtain a blanket license, a digital music provider must submit a notice of license to the mechanical licensing collective."
- Checked: 2026-11-10

#### [M-0127] VERIFIED
- Claim: Blanket licences were made available only from the license availability date; none was effective before.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(2)(B)
- Quote: "Blanket licenses shall be made available by the mechanical licensing collective on and after the license availability date."
- Checked: 2026-11-10

#### [M-0133] VERIFIED
- Claim: The MLC began administering blanket mechanical licences on January 1, 2021.
- Jurisdiction: industry
- Source: The MLC: DSP FAQs (blanket mechanical license under 17 U.S.C. 115 for digital service providers) (https://www.themlc.com/dsp-faqs), source id mlc-dsp-faqs-blanket-license
- Pinpoint: MLC DSP FAQs, 'When did the blanket license become effective?'
- Quote: "The Blanket License administered by The MLC became effective on January 1, 2021."
- Checked: 2026-11-10

#### [M-0135] VERIFIED
- Claim: A DSP may keep or enter voluntary licences with publishers instead of, or alongside, the blanket licence.
- Jurisdiction: industry
- Source: The MLC: DSP FAQs (blanket mechanical license under 17 U.S.C. 115 for digital service providers) (https://www.themlc.com/dsp-faqs), source id mlc-dsp-faqs-blanket-license
- Pinpoint: MLC DSP FAQs, voluntary licences answer
- Quote: "Obtaining the Blanket License does not preclude DSPs from maintaining or entering into voluntary licenses directly with music publishers or other musical works rightsholders."
- Checked: 2026-11-10

#### [M-0136] VERIFIED
- Claim: A significant nonblanket licensee (an entity operating under voluntary or individual download licences, not under a blanket licence) is one that on any day in a calendar month makes more than 5,000 different sound recordings of musical works available through its service, or meets the revenue thresholds ($50,000 a month; $500,000 over 12 months).
- Jurisdiction: industry
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(31)(A)(iii)(I)
- Quote: "on any day in a calendar month, makes more than 5,000 different sound recordings of musical works available through such service"
- Checked: 2026-11-10

#### [M-0130] VERIFIED
- Claim: The Register designated Mechanical Licensing Collective, Inc. as the MLC and Digital Licensee Coordinator, Inc. as the DLC, effective July 8, 2019.
- Jurisdiction: US-federal
- Source: Copyright Office, Designation of Music Licensing Collective and Digital Licensee Coordinator, final rule, 84 FR (July 8, 2019), FR Doc. 2019-14376 (https://www.federalregister.gov/documents/full_text/text/2019/07/08/2019-14376.txt), source id fr-mlc-designation-2019
- Pinpoint: 84 FR 32274 (July 8, 2019), Summary; DATES: Effective July 8, 2019
- Quote: "the Register designates Mechanical Licensing Collective, Inc. as the mechanical licensing collective and Digital Licensee Coordinator, Inc. as the digital licensee coordinator"
- Checked: 2026-11-10

#### [M-0132] VERIFIED
- Claim: The Office opened the periodic review in 2024 by notification of inquiry.
- Jurisdiction: US-federal
- Source: Copyright Office, Periodic Review of the Designations of the MLC and DLC, notification of inquiry, 89 FR (Jan. 30, 2024), FR Doc. 2024-01781 (https://www.federalregister.gov/documents/full_text/text/2024/01/30/2024-01781.txt), source id fr-mlc-periodic-review-noi-2024
- Pinpoint: 89 FR 5940 (Jan. 30, 2024), Summary
- Quote: "regarding whether the existing designations of the mechanical licensing collective and digital licensee coordinator should be continued."
- Checked: 2026-11-10

#### [M-0007] VERIFIED
- Claim: The Copyright Office continued the designations of the mechanical licensing collective and the digital licensee coordinator in a notice published June 3, 2026.
- Jurisdiction: US-federal
- Source: Copyright Office, Periodic Review of the Designations of the MLC and DLC, notice of continuing designation, 91 FR (June 3, 2026), FR Doc. 2026-11117 (https://www.federalregister.gov/documents/full_text/text/2026/06/03/2026-11117.txt), source id fr-mlc-continuing-designation-2026
- Pinpoint: Federal Register 91 FR (June 3, 2026), SUMMARY and DATES
- Quote: "has completed its first periodic review of the existing designations of the mechanical licensing collective and digital licensee coordinator and has determined that both designations should be continued."
- Checked: 2026-11-10

#### [M-0134] VERIFIED
- Claim: The DLC is tasked with coordinating communication between the DSPs impacted by the MMA (the same FAQ passage adds feedback to the MLC and assisting in collecting each DSP's share of MLC funding).
- Jurisdiction: industry
- Source: The MLC: DSP FAQs (blanket mechanical license under 17 U.S.C. 115 for digital service providers) (https://www.themlc.com/dsp-faqs), source id mlc-dsp-faqs-blanket-license
- Pinpoint: MLC DSP FAQs, 'What is the Digital Licensee Coordinator?'
- Quote: "tasked with coordinating communication between the DSPs impacted by the MMA"
- Checked: 2026-11-10

#### [M-0138] VERIFIED
- Claim: Part 385 sets rates only where a compulsory licence under 115 is obtained and the exclusive rights are implicated.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.1(c)
- Quote: "This part is intended only to set rates and terms for situations in which the exclusive rights of a Copyright Owner are implicated and a compulsory license pursuant to 17 U.S.C. 115 is obtained."
- Checked: 2026-11-10

#### [M-0139] VERIFIED
- Claim: Voluntary licence rates and terms apply in lieu of part 385.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.1(d)
- Quote: "The rates and terms of any license agreements entered into by Copyright Owners and Licensees relating to use of musical works within the scope of those license agreements shall apply in lieu of the rates and terms of this part."
- Checked: 2026-11-10

#### [M-0144] VERIFIED
- Claim: The 2026 COLA used the CPI-U published before December 1, 2025 (324.800), against a November 2022 base of 298.012.
- Jurisdiction: US-federal
- Source: CRB, Cost of Living Adjustment to Royalty Rates and Terms for Making and Distributing Phonorecords (2026 rates), 90 FR (Dec. 1, 2025), FR Doc. 2025-21695 (https://www.federalregister.gov/documents/full_text/text/2025/12/01/2025-21695.txt), source id crb-phono-cola-2026
- Pinpoint: 90 FR 55044 (Dec. 1, 2025)
- Quote: "is 324.800."
- Checked: 2026-11-10

#### [M-0145] VERIFIED
- Claim: Ringtones carry a flat 24 cent royalty rate per work.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.11(b)
- Quote: "the royalty rate payable for each work embodied therein shall be 24 cents."
- Checked: 2026-11-10

#### [M-0147] VERIFIED
- Claim: Step 1 all-in royalty is the greater of the percent of Service Provider Revenue and the TCC Prong Calculation.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.21(b)(1)
- Quote: "the all-in royalty for each Offering in this subpart with the exception of Mixed Service Bundles shall be the greater of:"
- Checked: 2026-11-10

#### [M-0146] VERIFIED
- Claim: Streaming and limited-download all-in royalty is the greater of a percent of service provider revenue and the TCC prong; the percent rises 15.1 (2023) to 15.35 (2027).
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.21(b)(1), Table 1
- Quote: "Percent of Service Provider Revenue 15.1 15.2 15.25 15.3 15.35"
- Checked: 2026-11-10

#### [M-0148] VERIFIED
- Claim: Phonorecords IV regulations apply from January 1, 2023 through December 31, 2027.
- Jurisdiction: US-federal
- Source: CRB, Determination of Royalty Rates and Terms for Making and Distributing Phonorecords (Phonorecords IV), final rule (2023-2027), 87 FR (Dec. 30, 2022), FR Doc. 2022-28316 (https://www.federalregister.gov/documents/full_text/text/2022/12/30/2022-28316.txt), source id crb-phono4-final
- Pinpoint: 87 FR 80448 (Dec. 30, 2022), Summary; DATES: Effective Jan. 1, 2023
- Quote: "set rates and terms applicable during the period from January 1, 2023 through December 31, 2027, for the statutory license for making and distributing phonorecords of nondramatic musical works."
- Checked: 2026-11-10

#### [M-0149] VERIFIED
- Claim: A March 2024 correction amended capitalization and a late-fee term in the Phonorecords IV regulations, effective March 18, 2024.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords IV corrections, 89 FR (Mar. 18, 2024), FR Doc. 2024-05704 (https://www.federalregister.gov/documents/full_text/text/2024/03/18/2024-05704.txt), source id crb-phono4-corrections-2024
- Pinpoint: 89 FR 19274 (Mar. 18, 2024), Summary; DATES
- Quote: "This document corrects the final regulations to add capitalization to certain defined terms and to correct a term regarding late fees."
- Checked: 2026-11-10

#### [M-0150] VERIFIED
- Claim: Phonorecords V commenced December 31, 2025 for the 2028 to 2032 period.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Making and Distributing Phonorecords (Phonorecords V), commencement notice and request for petitions to participate (2028-2032), 90 FR (Dec. 31, 2025), FR Doc. 2025-24044 (https://www.federalregister.gov/documents/full_text/text/2025/12/31/2025-24044.txt), source id crb-phono5-commencement
- Pinpoint: 90 FR 61424 (Dec. 31, 2025), Summary
- Quote: "announce commencement of a proceeding to determine reasonable rates and terms for making and distributing phonorecords for the period beginning January 1, 2028, and ending December 31, 2032."
- Checked: 2026-11-10

#### [M-0151] VERIFIED
- Claim: Phonorecords V petitions to participate were due January 30, 2026.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Making and Distributing Phonorecords (Phonorecords V), commencement notice and request for petitions to participate (2028-2032), 90 FR (Dec. 31, 2025), FR Doc. 2025-24044 (https://www.federalregister.gov/documents/full_text/text/2025/12/31/2025-24044.txt), source id crb-phono5-commencement
- Pinpoint: 90 FR 61424 (Dec. 31, 2025), DATES
- Quote: "Petitions to Participate and the filing fee are due no later than January 30, 2026."
- Checked: 2026-11-10

#### [M-0152] VERIFIED
- Claim: On July 10, 2026 the Judges published a proposed partial settlement that would continue the Subpart B rates (physical, permanent downloads, ringtones, music bundles) for 2028 to 2032 with only continuing inflation adjustments to physical and permanent download rates; comments were due Aug. 10, 2026.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords V, notice of proposed settlement (continuation of regulations for 2028-2032), 91 FR (July 10, 2026), FR Doc. 2026-13996 (https://www.federalregister.gov/documents/full_text/text/2026/07/10/2026-13996.txt), source id crb-phono5-proposed-settlement-2026
- Pinpoint: 91 FR 42698-42699 (July 10, 2026), FR Doc. 2026-13996; quote at p. 42699
- Quote: "should not be amended except for continuing inflation adjustments to the rates for physical phonorecords and permanent downloads"
- Checked: 2026-11-10

#### [M-0153] VERIFIED
- Claim: Phonorecords V: the June 29, 2026 motion published for comment on July 10, 2026 proposes a partial settlement for Subpart B configurations only (physical phonorecords, permanent downloads, ringtones, music bundles) for 2028-2032; the notice does not settle streaming rates, which (inference) remain in the proceeding.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords V, notice of proposed settlement (continuation of regulations for 2028-2032), 91 FR (July 10, 2026), FR Doc. 2026-13996 (https://www.federalregister.gov/documents/full_text/text/2026/07/10/2026-13996.txt), source id crb-phono5-proposed-settlement-2026
- Pinpoint: 91 FR 42699 (July 10, 2026), FR Doc. 2026-13996
- Quote: "partial settlement regarding the rates and terms under Section 115 of the Copyright Act, namely, for physical phonorecords, permanent downloads, ringtones, and music bundles for the 2028-2032 rate period"
- Checked: 2026-11-10

## M04 CRB rates and proceedings (Phonorecords, Web, NSS)
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: What is the current mechanical rate; Do the CRB webcasting rates cover a platform that streams user mixes; What is Web VI and is there a rate for a mixing app; What is Phonorecords V and is it final; How long do CRB proceedings take and can they be appealed; Can a voluntary licence replace the CRB rate

### Bottom line
- US federal: the Copyright Royalty Judges (CRB) set the rates and terms for the statutory licences in 17 U.S.C. 112(e), 114 and 115 [M-0170]. Section 115 is the mechanical licence for the musical work (composition) [M-0148]. Sections 112(e) and 114 are the digital performance and ephemeral licences for the sound recording (master) [M-0158].
- None of these rates is a price for putting music in a video. Part 385 says it sets rates only where a section 115 compulsory licence is obtained and the exclusive rights are implicated [M-0138]. Sync (composition) and master use (recording) still need direct licences from the rights holders (analysis).
- Rates move by period. The 2026 mechanical rate is 13.1 cents per work or 2.52 cents per minute, whichever is larger, for 2026 only [M-0142, M-0143]. Web V rates are 2025 only. Web VI is not fully codified for a commercial non broadcaster app (unverified) [M-0182]. Phonorecords V is a proposed settlement, not law.

### Rules
#### Who sets rates, and how (17 U.S.C. 801 to 804)
- US federal (statute): the Librarian of Congress appoints three full time Copyright Royalty Judges, one of them Chief [M-0169].
- The Judges determine reasonable terms and rates under sections 112(e), 114, 115, 116, 118, 119 and 1004 [M-0170].
- The Judges may adopt a settlement among some or all participants. They may decline to bind non parties only if a participant objects and the record shows no reasonable basis [M-0171].
- Section 115 (Phonorecords) proceedings recur every fifth calendar year, or at other times agreed under 115(c)(3)(B) to (C) [M-0177].
- Timeline (statute): for section 804(b)(2) proceedings, notice of commencement by January 5 of the year specified [M-0172]. Phonorecords V commenced December 31, 2025 [M-0150]. Petitions to participate are due 30 days after that notice [M-0173]. The voluntary negotiation period is 3 months [M-0174]. The determination is due not later than 11 months after the 21 day settlement conference period ends [M-0175].
- Appeal goes to the D.C. Circuit within 30 days after Federal Register publication [M-0176].
- The Copyright Office opened the periodic review of the MLC designation by notification of inquiry on January 30, 2024 (89 FR 5940) [M-0132].
- Reports of use: preexisting subscription services must deliver them to the designated Collective within 45 days after the close of each month (37 CFR 370.3(b)) [M-0178]. A Collective is an organization designated under a statutory licence by CRB determination [M-0305].

#### Phonorecords: section 115 mechanical rates (37 CFR Part 385)
- Part 385 applies only where the exclusive rights of a copyright owner are implicated and a section 115 compulsory licence is obtained [M-0138].
- Voluntary licence rates and terms apply in lieu of Part 385 [M-0139].
- Phonorecords IV (regulation): applies January 1, 2023 through December 31, 2027 [M-0148]. A March 18, 2024 correction fixed capitalization and a late fee term [M-0149].
- Physical phonorecords and permanent downloads, 2026 only: the larger of 13.1 cents per work or 2.52 cents per minute of playing time or fraction [M-0142]. The December 1, 2025 notice applied the cost of living adjustment for January 1 to December 31, 2026 [M-0143]. It used a CPI-U of 324.800 against a November 2022 base of 298.012 [M-0144]. The rate adjusts each year.
- Ringtones: flat 24 cents per work [M-0145].
- Streaming and limited downloads (Subpart C, 2023 to 2027): the all in royalty is the greater of a percent of service provider revenue and the TCC prong, with Mixed Service Bundles excepted [M-0147]. The revenue percent runs 15.1 (2023) to 15.35 (2027) [M-0146].
- Phonorecords V (2028 to 2032): the Judges announced commencement on December 31, 2025 [M-0150]. Petitions to participate were due January 30, 2026 [M-0151].
- Phonorecords V proposal: on July 10, 2026 the Judges published a proposed partial settlement that would continue the Subpart B rates (physical, permanent downloads, ringtones, music bundles) for 2028 to 2032 with only continuing inflation adjustments to physical and permanent download rates [M-0152]. Comments were due August 10, 2026 [M-0152]. The notice covers Subpart B configurations only [M-0153]. It does not settle streaming (analysis, from M-0153).

#### Webcasting: sections 114 and 112(e) (37 CFR Parts 380, 383)
- Web V (regulation): Part 380 codified rates for January 1, 2021 through December 31, 2025. That period has ended [M-0157, M-0158, M-0306].
- Web V commercial webcaster rates, 2025 only: $0.0032 per performance (subscription) and $0.0025 per performance (nonsubscription) [M-0154, M-0307]. Minimum fee $1,000 per channel or station per year [M-0155]. Royalties are credited 5 percent to ephemeral recordings and 95 percent to section 114 [M-0156].
- Voluntary licence agreements may apply in lieu of the Part 380 rates and terms [M-0306].
- Web VI (2026 to 2030) commenced by Federal Register notice on January 5, 2024 [M-0184]. The Judges adopted four final rules, effective March 10, 2026 [M-0010].
- Web VI commercial broadcasters: $0.0028 per performance in 2026 rising to $0.0032 in 2030 [M-0159]. Minimum fee $1,100 (2026) to $1,250 (2029 and 2030) [M-0160]. The rule came from a SoundExchange and NAB settlement [M-0162], proposed May 16, 2025 (90 FR 20977) [M-0185].
- Web VI Educational Media Foundation: $7,125,000 for 2026, rising to about $8.3 million in 2030, one named licensee [M-0163]. Noncommercial educational webcaster minimum fee starts at $800 in 2026 [M-0164].
- A Commercial Broadcaster is a Commercial Webcaster a material part of whose business is owning and operating FCC licensed terrestrial AM or FM stations. A non broadcaster app is outside that subpart [M-0161].
- Commercial non broadcaster Web VI rule: not published as of 2026-11-10 in the saved set. The saved sources show only the four settlement rules. That absence rests on a search capture, not rule text (unverified) [M-0182].

#### New subscription services: NSS V (37 CFR Part 383)
- NSS V (2026 to 2030) covers digital performances by new subscription services that provide transmissions to residential subscribers as part of a cable or satellite television bundle [M-0166].
- Stand alone contracts: the 2025 base of $0.0234 per subscriber per month, as adjusted by the annual royalty fee adjustment [M-0165]. Bundled contracts: $0.0390 base, same adjustment [M-0507]. The saved text has placeholders for the 2026 amounts, so the 2026 figure is not stated here.

### Gotchas
- "Statutory rate means I can use any song in my video." No. The rates are for the statutory licences only, and Part 385 is limited to compulsory licence use [M-0138].
- The 13.1 cent figure is a 2026 rate only. Check the notice for 2027 when it publishes [M-0142, M-0143]. The saved eCFR file also holds an older Phonorecords III copy (9.1 cents); ignore it [M-0139].
- Web V ($0.0025 and $0.0032) is 2025 only. Do not use it as a 2026 rate [M-0154, M-0307].
- Web VI is not one rule. Four rules are final for broadcasters, EMF and noncommercial educational webcasters [M-0010]. A commercial non broadcaster rule is not published as of 2026-11-10 (unverified) [M-0182]. Never state a Web VI commercial non broadcaster rate.
- Phonorecords V is a proposal. A Federal Register search on 2026-11-10 showed no later final rule for docket 25-CRB-0013-PR, so final adoption is unconfirmed [M-0152]. Not law.
- NSS V 2026 amounts are bracketed in the saved text. Needs source: the December 2025 final rate notice [M-0165].
- Rate periods end on set dates (Phonorecords IV on December 31, 2027 [M-0148]). Expect a new determination or an adopted settlement for 2028 on.
- Treating a CRB rate as a cap on a direct licence quote is wrong. Direct deals are priced by agreement [M-0139].

### Open questions for counsel
- US federal: does any statutory licence (115, 114, 112(e)) apply to a short video app that distributes user videos with licensed or unlicensed music, or is every such use a sync plus master direct licence?
- US federal: if the Judges adopt the Phonorecords V Subpart B settlement, does anything change for an app that is not a phonorecord distributor?
- US federal: is any platform feature (live streams, audio only streams) a digital audio transmission that could fall under Web VI, and which rate class would apply with no commercial non broadcaster rule published?
- US federal: is a platform's audio plan, if any, a new subscription service within NSS V, or outside it?
- US federal: what does the commercial non broadcaster Web VI status mean for exposure today?

### Sources
- usc17-801: 17 U.S.C. 801 (https://www.law.cornell.edu/uscode/text/17/801)
- usc17-803: 17 U.S.C. 803 (https://www.law.cornell.edu/uscode/text/17/803)
- usc17-804: 17 U.S.C. 804 (https://www.law.cornell.edu/uscode/text/17/804)
- cfr37-385: 37 CFR Part 385 (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385)
- cfr37-380: 37 CFR Part 380 (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380)
- cfr37-370: 37 CFR Part 370 (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370)
- crb-phono-cola-2026, crb-phono4-final, crb-phono4-corrections-2024, crb-phono5-commencement, crb-phono5-proposed-settlement-2026: CRB Federal Register notices (https://www.federalregister.gov/documents/full_text/text/2025/12/01/2025-21695.txt, https://www.federalregister.gov/documents/full_text/text/2022/12/30/2022-28316.txt, https://www.federalregister.gov/documents/full_text/text/2024/03/18/2024-05704.txt, https://www.federalregister.gov/documents/full_text/text/2025/12/31/2025-24044.txt, https://www.federalregister.gov/documents/full_text/text/2026/07/10/2026-13996.txt)
- crb-web5-final, crb-web6-final-commercial-broadcasters, crb-web6-final-emf, crb-web6-final-noncommercial-educational, crb-web6-commercial-nonbroadcasters (stub), crb-nss5-final: CRB Federal Register notices (https://www.federalregister.gov/documents/full_text/text/2021/10/27/2021-20621.txt, https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt, https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04631.txt, https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04630.txt, https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=%22Web+VI%22&conditions%5Bagencies%5D%5B%5D=copyright-royalty-board&order=newest, https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt)
- fr-mlc-periodic-review-noi-2024: 89 FR 5940 (https://www.federalregister.gov/documents/full_text/text/2024/01/30)

### Claims cited in M04
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0170] VERIFIED
- Claim: The Judges determine reasonable terms and rates under sections 112(e), 114, 115, 116, 118, 119 and 1004.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(b)(1)
- Quote: "To make determinations and adjustments of reasonable terms and rates of royalty payments as provided in sections 112(e), 114, 115, 116, 118, 119, and 1004."
- Checked: 2026-11-10

#### [M-0148] VERIFIED
- Claim: Phonorecords IV regulations apply from January 1, 2023 through December 31, 2027.
- Jurisdiction: US-federal
- Source: CRB, Determination of Royalty Rates and Terms for Making and Distributing Phonorecords (Phonorecords IV), final rule (2023-2027), 87 FR (Dec. 30, 2022), FR Doc. 2022-28316 (https://www.federalregister.gov/documents/full_text/text/2022/12/30/2022-28316.txt), source id crb-phono4-final
- Pinpoint: 87 FR 80448 (Dec. 30, 2022), Summary; DATES: Effective Jan. 1, 2023
- Quote: "set rates and terms applicable during the period from January 1, 2023 through December 31, 2027, for the statutory license for making and distributing phonorecords of nondramatic musical works."
- Checked: 2026-11-10

#### [M-0158] VERIFIED
- Claim: The Web V final determination (86 FR, Oct. 27, 2021) set rates and terms for two statutory licences (digital performance and ephemeral recordings) for 2021 to 2025.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings and Making of Ephemeral Copies (Web V), final rule and order (2021-2025), 86 FR (Oct. 27, 2021), FR Doc. 2021-20621 (https://www.federalregister.gov/documents/full_text/text/2021/10/27/2021-20621.txt), source id crb-web5-final
- Pinpoint: 86 FR (Oct. 27, 2021), Summary
- Quote: "for the period beginning January 1, 2021, and ending on December 31, 2025."
- Checked: 2026-11-10

#### [M-0138] VERIFIED
- Claim: Part 385 sets rates only where a compulsory licence under 115 is obtained and the exclusive rights are implicated.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.1(c)
- Quote: "This part is intended only to set rates and terms for situations in which the exclusive rights of a Copyright Owner are implicated and a compulsory license pursuant to 17 U.S.C. 115 is obtained."
- Checked: 2026-11-10

#### [M-0142] VERIFIED
- Claim: 2026 mechanical rate for physical phonorecords and permanent downloads is the larger of 13.1 cents per work or 2.52 cents per minute.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.11(a)(1)
- Quote: "the royalty rate payable for each work embodied in the phonorecord or Permanent Download shall be either 13.1 cents or 2.52 cents per minute of playing time or fraction thereof, whichever amount is larger."
- Checked: 2026-11-10

#### [M-0143] VERIFIED
- Claim: The 2026 COLA notice sets 13.1 cents per work and 2.52 cents per minute, effective December 1, 2025, applicable January 1 to December 31, 2026.
- Jurisdiction: US-federal
- Source: CRB, Cost of Living Adjustment to Royalty Rates and Terms for Making and Distributing Phonorecords (2026 rates), 90 FR (Dec. 1, 2025), FR Doc. 2025-21695 (https://www.federalregister.gov/documents/full_text/text/2025/12/01/2025-21695.txt), source id crb-phono-cola-2026
- Pinpoint: 90 FR 55044-55045 (Dec. 1, 2025)
- Quote: "The adjusted rates for 2026 are 13.1 cents for the per-work rate and 2.52 cents for the per-minute rate."
- Checked: 2026-11-10

#### [M-0182] UNVERIFIED (unverified)
- Claim: Analysis: Web VI rates saved so far are for broadcasters, public radio, noncommercial educational webcasters and EMF; they set no price for a commercial non-broadcaster, and are moot for video anyway.
- Jurisdiction: analysis
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.40
- Quote: "Commercial Broadcaster is a Commercial Webcaster, a material part of the business of which consists of owning and operating one or more terrestrial AM or FM broadcast radio stations licensed as such by the Federal Communications Commission."
- Checked: 2026-11-10

#### [M-0169] VERIFIED
- Claim: The Librarian appoints three full-time Copyright Royalty Judges, one of them Chief.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(a)
- Quote: "The Librarian of Congress shall appoint 3 full-time Copyright Royalty Judges, and shall appoint 1 of the 3 as the Chief Copyright Royalty Judge."
- Checked: 2026-11-10

#### [M-0171] VERIFIED
- Claim: The Judges may adopt a settlement among some or all participants, and may decline for non-parties only if a participant objects and the record shows no reasonable basis.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(b)(7)(A)(ii)
- Quote: "the Copyright Royalty Judges may decline to adopt the agreement as a basis for statutory terms and rates for participants that are not parties to the agreement, if any participant described in clause (i) objects to the agreement"
- Checked: 2026-11-10

#### [M-0177] VERIFIED
- Claim: Section 115 proceedings recur every fifth calendar year (Phonorecords proceedings).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 804 institution of proceedings (https://www.law.cornell.edu/uscode/text/17/804), source id usc17-804
- Pinpoint: 17 U.S.C. 804(b)(4)
- Quote: "may be filed in the year 2006 and in each subsequent fifth calendar year"
- Checked: 2026-11-10

#### [M-0172] VERIFIED
- Claim: The Judges publish notice of commencement by January 5 of a year specified in 804(b)(2) (other 804(b) provisions use (III) to (V)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 803 proceedings of Copyright Royalty Judges (https://www.law.cornell.edu/uscode/text/17/803), source id usc17-803
- Pinpoint: 17 U.S.C. 803(b)(1)(A)(i)(II)
- Quote: "by no later than January 5 of a year specified in paragraph (2) of section 804(b) for the commencement of proceedings;"
- Checked: 2026-11-10

#### [M-0150] VERIFIED
- Claim: Phonorecords V commenced December 31, 2025 for the 2028 to 2032 period.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Making and Distributing Phonorecords (Phonorecords V), commencement notice and request for petitions to participate (2028-2032), 90 FR (Dec. 31, 2025), FR Doc. 2025-24044 (https://www.federalregister.gov/documents/full_text/text/2025/12/31/2025-24044.txt), source id crb-phono5-commencement
- Pinpoint: 90 FR 61424 (Dec. 31, 2025), Summary
- Quote: "announce commencement of a proceeding to determine reasonable rates and terms for making and distributing phonorecords for the period beginning January 1, 2028, and ending December 31, 2032."
- Checked: 2026-11-10

#### [M-0173] VERIFIED
- Claim: Petitions to participate are due 30 days after the commencement notice.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 803 proceedings of Copyright Royalty Judges (https://www.law.cornell.edu/uscode/text/17/803), source id usc17-803
- Pinpoint: 17 U.S.C. 803(b)(1)(A)(ii)
- Quote: "Petitions to participate shall be filed by no later than 30 days after publication of notice of commencement of a proceeding"
- Checked: 2026-11-10

#### [M-0174] VERIFIED
- Claim: The voluntary negotiation period in a rate proceeding is 3 months.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 803 proceedings of Copyright Royalty Judges (https://www.law.cornell.edu/uscode/text/17/803), source id usc17-803
- Pinpoint: 17 U.S.C. 803(b)(3)(B)
- Quote: "The voluntary negotiation period initiated under subparagraph (A) shall be 3 months."
- Checked: 2026-11-10

#### [M-0175] VERIFIED
- Claim: The Judges must issue a determination not later than 11 months after the 21-day settlement conference period ends (and, for successor rates, no later than 15 days before current rates expire).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 803 proceedings of Copyright Royalty Judges (https://www.law.cornell.edu/uscode/text/17/803), source id usc17-803
- Pinpoint: 17 U.S.C. 803(c)(1)
- Quote: "not later than 11 months after the conclusion of the 21-day settlement conference period"
- Checked: 2026-11-10

#### [M-0176] VERIFIED
- Claim: A determination may be appealed to the D.C. Circuit within 30 days after Federal Register publication.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 803 proceedings of Copyright Royalty Judges (https://www.law.cornell.edu/uscode/text/17/803), source id usc17-803
- Pinpoint: 17 U.S.C. 803(d)(1)
- Quote: "may, within 30 days after the publication of the determination in the Federal Register, be appealed, to the United States Court of Appeals for the District of Columbia Circuit"
- Checked: 2026-11-10

#### [M-0132] VERIFIED
- Claim: The Office opened the periodic review in 2024 by notification of inquiry.
- Jurisdiction: US-federal
- Source: Copyright Office, Periodic Review of the Designations of the MLC and DLC, notification of inquiry, 89 FR (Jan. 30, 2024), FR Doc. 2024-01781 (https://www.federalregister.gov/documents/full_text/text/2024/01/30/2024-01781.txt), source id fr-mlc-periodic-review-noi-2024
- Pinpoint: 89 FR 5940 (Jan. 30, 2024), Summary
- Quote: "regarding whether the existing designations of the mechanical licensing collective and digital licensee coordinator should be continued."
- Checked: 2026-11-10

#### [M-0178] VERIFIED
- Claim: Preexisting subscription services must deliver Reports of Use to the designated Collective within 45 days after the close of each month (37 CFR 370.3(b)).
- Jurisdiction: US-federal
- Source: 37 CFR Part 370 notice and recordkeeping requirements for statutory licenses (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370), source id cfr37-370
- Pinpoint: 37 CFR 370.3(b) (reports of use, preexisting subscription services)
- Quote: "Reports of Use shall be delivered on or before the forty-fifth day after the close of each month."
- Checked: 2026-11-10

#### [M-0305] VERIFIED
- Claim: The notice and reporting rules define a Collective as an organization designated under a statutory licence by determination of the Copyright Royalty Judges.
- Jurisdiction: US-federal
- Source: 37 CFR Part 370 notice and recordkeeping requirements for statutory licenses (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370), source id cfr37-370
- Pinpoint: 37 CFR 370.1 (general definitions, Collective)
- Quote: "Collective is a collection and distribution organization that is designated under one or both of the statutory licenses by determination of the Copyright Royalty Judges"
- Checked: 2026-11-10

#### [M-0139] VERIFIED
- Claim: Voluntary licence rates and terms apply in lieu of part 385.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.1(d)
- Quote: "The rates and terms of any license agreements entered into by Copyright Owners and Licensees relating to use of musical works within the scope of those license agreements shall apply in lieu of the rates and terms of this part."
- Checked: 2026-11-10

#### [M-0149] VERIFIED
- Claim: A March 2024 correction amended capitalization and a late-fee term in the Phonorecords IV regulations, effective March 18, 2024.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords IV corrections, 89 FR (Mar. 18, 2024), FR Doc. 2024-05704 (https://www.federalregister.gov/documents/full_text/text/2024/03/18/2024-05704.txt), source id crb-phono4-corrections-2024
- Pinpoint: 89 FR 19274 (Mar. 18, 2024), Summary; DATES
- Quote: "This document corrects the final regulations to add capitalization to certain defined terms and to correct a term regarding late fees."
- Checked: 2026-11-10

#### [M-0144] VERIFIED
- Claim: The 2026 COLA used the CPI-U published before December 1, 2025 (324.800), against a November 2022 base of 298.012.
- Jurisdiction: US-federal
- Source: CRB, Cost of Living Adjustment to Royalty Rates and Terms for Making and Distributing Phonorecords (2026 rates), 90 FR (Dec. 1, 2025), FR Doc. 2025-21695 (https://www.federalregister.gov/documents/full_text/text/2025/12/01/2025-21695.txt), source id crb-phono-cola-2026
- Pinpoint: 90 FR 55044 (Dec. 1, 2025)
- Quote: "is 324.800."
- Checked: 2026-11-10

#### [M-0145] VERIFIED
- Claim: Ringtones carry a flat 24 cent royalty rate per work.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.11(b)
- Quote: "the royalty rate payable for each work embodied therein shall be 24 cents."
- Checked: 2026-11-10

#### [M-0147] VERIFIED
- Claim: Step 1 all-in royalty is the greater of the percent of Service Provider Revenue and the TCC Prong Calculation.
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.21(b)(1)
- Quote: "the all-in royalty for each Offering in this subpart with the exception of Mixed Service Bundles shall be the greater of:"
- Checked: 2026-11-10

#### [M-0146] VERIFIED
- Claim: Streaming and limited-download all-in royalty is the greater of a percent of service provider revenue and the TCC prong; the percent rises 15.1 (2023) to 15.35 (2027).
- Jurisdiction: US-federal
- Source: 37 CFR Part 385 rates and terms for making and distributing phonorecords (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=385), source id cfr37-385
- Pinpoint: 37 CFR 385.21(b)(1), Table 1
- Quote: "Percent of Service Provider Revenue 15.1 15.2 15.25 15.3 15.35"
- Checked: 2026-11-10

#### [M-0151] VERIFIED
- Claim: Phonorecords V petitions to participate were due January 30, 2026.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Making and Distributing Phonorecords (Phonorecords V), commencement notice and request for petitions to participate (2028-2032), 90 FR (Dec. 31, 2025), FR Doc. 2025-24044 (https://www.federalregister.gov/documents/full_text/text/2025/12/31/2025-24044.txt), source id crb-phono5-commencement
- Pinpoint: 90 FR 61424 (Dec. 31, 2025), DATES
- Quote: "Petitions to Participate and the filing fee are due no later than January 30, 2026."
- Checked: 2026-11-10

#### [M-0152] VERIFIED
- Claim: On July 10, 2026 the Judges published a proposed partial settlement that would continue the Subpart B rates (physical, permanent downloads, ringtones, music bundles) for 2028 to 2032 with only continuing inflation adjustments to physical and permanent download rates; comments were due Aug. 10, 2026.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords V, notice of proposed settlement (continuation of regulations for 2028-2032), 91 FR (July 10, 2026), FR Doc. 2026-13996 (https://www.federalregister.gov/documents/full_text/text/2026/07/10/2026-13996.txt), source id crb-phono5-proposed-settlement-2026
- Pinpoint: 91 FR 42698-42699 (July 10, 2026), FR Doc. 2026-13996; quote at p. 42699
- Quote: "should not be amended except for continuing inflation adjustments to the rates for physical phonorecords and permanent downloads"
- Checked: 2026-11-10

#### [M-0153] VERIFIED
- Claim: Phonorecords V: the June 29, 2026 motion published for comment on July 10, 2026 proposes a partial settlement for Subpart B configurations only (physical phonorecords, permanent downloads, ringtones, music bundles) for 2028-2032; the notice does not settle streaming rates, which (inference) remain in the proceeding.
- Jurisdiction: US-federal
- Source: CRB, Phonorecords V, notice of proposed settlement (continuation of regulations for 2028-2032), 91 FR (July 10, 2026), FR Doc. 2026-13996 (https://www.federalregister.gov/documents/full_text/text/2026/07/10/2026-13996.txt), source id crb-phono5-proposed-settlement-2026
- Pinpoint: 91 FR 42699 (July 10, 2026), FR Doc. 2026-13996
- Quote: "partial settlement regarding the rates and terms under Section 115 of the Copyright Act, namely, for physical phonorecords, permanent downloads, ringtones, and music bundles for the 2028-2032 rate period"
- Checked: 2026-11-10

#### [M-0157] VERIFIED
- Claim: Web V codified rates and terms for the period January 1, 2021 through December 31, 2025 (period now ended; Web VI follows).
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.1(a)
- Quote: "during the period January 1, 2021, through December 31, 2025."
- Checked: 2026-11-10

#### [M-0306] VERIFIED
- Claim: 37 CFR Part 380 as saved (eCFR 2026-10-26) sets webcasting rates and terms under 17 U.S.C. 114 and 112(e) for January 1, 2021 through December 31, 2025, and voluntary licence agreements may apply in lieu of them.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.1(a), (d)
- Quote: "Notwithstanding the royalty rates and terms established in any subparts of this part, the rates and terms of any license agreements entered into by Copyright Owners and Licensees may apply in lieu of these rates and terms"
- Checked: 2026-11-10

#### [M-0154] VERIFIED
- Claim: Web V rates for commercial webcasters in 2025 were $0.0032 per performance (subscription) and $0.0025 per performance (nonsubscription).
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(a)(1)
- Quote: "Commercial webcasters: $0.0032 per Performance for subscription services and $0.0025 per Performance for nonsubscription services."
- Checked: 2026-11-10

#### [M-0307] VERIFIED
- Claim: Under the 2025 commercial webcaster rate, nonsubscription services paid $0.0025 per performance and subscription services $0.0032.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR Part 380 subpart B, royalty fees for 2025
- Quote: "Commercial webcasters: $0.0032 per Performance for subscription services and $0.0025 per Performance for nonsubscription services"
- Checked: 2026-11-10

#### [M-0155] VERIFIED
- Claim: Web V minimum fee is $1,000 per channel or station per year, credited against royalties.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(b)
- Quote: "Licensees must pay the Collective a minimum fee of $1,000 each year for each channel or station."
- Checked: 2026-11-10

#### [M-0156] VERIFIED
- Claim: Web V royalties are credited 5 percent to ephemeral recordings and 95 percent to section 114.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(d)
- Quote: "The Collective must credit 5% of all royalty payments as payment for Ephemeral Recordings and credit the remaining 95% to section 114 royalties."
- Checked: 2026-11-10

#### [M-0184] VERIFIED
- Claim: Web VI (2026-2030) commenced by Federal Register notice on January 5, 2024 for the web licences.
- Jurisdiction: US-federal
- Source: STUB (no such determination published as of 2026-11-10; FR search returns only the 4 settlement rules): CRB Web VI determination, commercial non-broadcasters (FR search; none published as of 2026-11-10) (https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=%22Web+VI%22&conditions%5Bagencies%5D%5B%5D=copyright-royalty-board&order=newest), source id crb-web6-commercial-nonbroadcasters
- Pinpoint: 89 FR (Jan. 5, 2024), FR Doc. 2023-28516 (FR API search result)
- Quote: "announce commencement of a proceeding to determine reasonable rates and terms for two statutory licenses permitting the digital performance of sound recordings over the internet"
- Checked: 2026-11-10

#### [M-0010] VERIFIED
- Claim: Web VI final rules for commercial broadcasters, Educational Media Foundation, noncommercial educational webcasters and certain public radio stations took effect March 10, 2026, for the period January 1, 2026 through December 31, 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: FR 91 (March 10, 2026), DATES
- Quote: "DATES: Effective March 10, 2026."
- Checked: 2026-11-10

#### [M-0159] VERIFIED
- Claim: Web VI commercial broadcaster nonsubscription rate is $0.0028 per performance in 2026 rising to $0.0032 in 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.41(a); 91 FR 11458 (Mar. 10, 2026)
- Quote: "2026: $0.0028 per Performance; (2) 2027: $0.0029 per Performance; (3) 2028: $0.0030 per Performance; (4) 2029: $0.0031 per Performance; and (5) 2030: $0.0032 per Performance."
- Checked: 2026-11-10

#### [M-0160] VERIFIED
- Claim: Web VI commercial broadcaster minimum fee per channel or station is $1,100 (2026) to $1,250 (2029, 2030).
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.41(b)(1); 91 FR 11458
- Quote: "(i) 2026: $1,100; (ii) 2027: $1,150; (iii) 2028: $1,200; (iv) 2029: $1,250; and (v) 2030: $1,250."
- Checked: 2026-11-10

#### [M-0162] VERIFIED
- Claim: The Web VI commercial broadcaster rates and terms were the subject of a settlement between SoundExchange and the National Association of Broadcasters (NAB), which the Judges adopted as proposed.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 91 FR 11458 (Mar. 10, 2026), Background
- Quote: "The rates and terms in the proposed rule were the subject of a settlement between SoundExchange, Inc."
- Checked: 2026-11-10

#### [M-0185] VERIFIED
- Claim: The Web VI commercial broadcaster proposed rule (settlement) was published for comment on May 16, 2025 (90 FR 20977), before final adoption in 2026.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 91 FR 11458 (Mar. 10, 2026), Background (90 FR 20977)
- Quote: "On May 16, 2025, the Copyright Royalty Judges"
- Checked: 2026-11-10

#### [M-0163] VERIFIED
- Claim: Web VI sets Educational Media Foundation payments at $7,125,000 for 2026 rising to about $8.3 million in 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, Educational Media Foundation (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04631 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04631.txt), source id crb-web6-final-emf
- Pinpoint: 37 CFR 380.51(a); 91 FR (Mar. 10, 2026)
- Quote: "2026: $7,125,000.00 ($593,750.00 per month); (2) 2027: $7,410,000.00 ($617,500.00 per month); (3) 2028: $7,706,400.00 ($642,200.00 per month); (4) 2029: $8,014,656.00 ($667,888.00 per month); and (5) 2030: $8,335,242.24 ($694,603.52 per month)."
- Checked: 2026-11-10

#### [M-0164] VERIFIED
- Claim: Web VI noncommercial educational webcaster minimum fee starts at $800 in 2026.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, noncommercial educational webcasters (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04630 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04630.txt), source id crb-web6-final-noncommercial-educational
- Pinpoint: 37 CFR 380.21(a); 91 FR (Mar. 10, 2026)
- Quote: "The Minimum Fee for each year of the royalty period is: (1) 2026: $800; (2) 2027: $850;"
- Checked: 2026-11-10

#### [M-0161] VERIFIED
- Claim: In the saved Web VI commercial broadcaster rule a Commercial Broadcaster is a Commercial Webcaster a material part of whose business is owning and operating FCC-licensed terrestrial AM or FM stations, so a non-broadcaster app is not covered by that subpart.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.40 (definition of Commercial Broadcaster)
- Quote: "Commercial Broadcaster is a Commercial Webcaster, a material part of the business of which consists of owning and operating one or more terrestrial AM or FM broadcast radio stations licensed as such by the Federal Communications Commission."
- Checked: 2026-11-10

#### [M-0166] VERIFIED
- Claim: NSS V covers digital performances by new subscription services that provide transmissions to residential subscribers as part of a cable or satellite television bundle (2026-2030).
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 91 FR (Mar. 10, 2026), Background
- Quote: "new subscription services that provide transmissions to residential subscribers as part of a cable or satellite television bundle"
- Checked: 2026-11-10

#### [M-0165] VERIFIED
- Claim: NSS V (2026-2030): per-Subscriber monthly payment for Stand-Alone Contracts is the 2025 royalty rate of $0.0234 as adjusted by the annual royalty fee adjustment.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 37 CFR 383.3(a); 91 FR (Mar. 10, 2026)
- Quote: "equivalent to the 2025 royalty rate of $0.0234, as adjusted by the annual royalty fee adjustment"
- Checked: 2026-11-10

#### [M-0507] VERIFIED
- Claim: NSS V (2026-2030): per-Subscriber monthly payment for Bundled Contracts is the 2025 royalty rate of $0.0390 as adjusted by the annual royalty fee adjustment.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 37 CFR 383.3(a)(2)
- Quote: "equivalent to the 2025 royalty rate of $0.0390"
- Checked: 2026-11-10

## M05 PROs and consent decrees
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Who are the US performing rights organizations and what do they license; Do the ASCAP and BMI consent decrees give a mixing platform a right to a licence and a rate court; Can a PRO license sync, master or remix rights for a mix; Does a PRO licence cover every co-owner of a song; What if SESAC or GMR will not license; What is different in the EU

### Bottom line
- US federal: a PRO collectively licenses public performance rights in musical works [M-0328, M-0341]. ASCAP's decree bars it from licensing sync (the composition placed in a video) or any right other than public performance [M-0256]. Master use (the recording) is not a composition right at all (analysis). Whether BMI, SESAC and GMR have the same limit is inference (analysis) [M-0311].
- ASCAP's decree gives a music user a right to a licence on written request and a rate court [M-0259, M-0263]. For BMI the rows show a rate court with the fee burden on BMI [M-0266, M-0268]; no BMI row here shows the right to a licence. SESAC is not under a decree [M-0320]. GMR is not under the decrees on the DOJ statement and a commenter's view, not an Office finding [M-0278, M-0293].
- A PRO licence is not a clearance for a video. The platform or the creator still needs direct sync and master licences (analysis) [M-0311].
- Decree law is volatile. The decree texts here are saved editions, and the Copyright Office ran an inquiry in 2025 and delivered a letter on 2025-11-20 with no policy recommendations [M-0283, M-0288, M-0290].

### Rules
#### What a PRO is (US federal)
- A PRO contracts with songwriters and publishers for authority to license public performance rights, then offers collective licences of those rights to users [M-0328].
- The Copyright Office lists ASCAP (1914), SESAC (1931) and BMI (1939) as the established PROs. It says three more formed later: GMR (2013), PRO Music Rights (2018) and AllTrack (2019) [M-0285, M-0329].
- DOJ described GMR in 2016 as a fourth PRO with a collection considerably smaller than ASCAP or BMI [M-0330].

#### ASCAP decree (court decision, Second Amended Final Judgment, S.D.N.Y. 2001, saved 2016 filing edition)
- ASCAP may license only public performance rights in compositions, and only on a nonexclusive basis [M-0256].
- ASCAP members keep the right to license performance rights directly to music users. ASCAP may not interfere [M-0257].
- A blanket licence is a nonexclusive licence to perform ASCAP music at a fee that does not vary with how much ASCAP music the user performs [M-0258].
- ASCAP must grant a nonexclusive licence to all works in its repertory to any music user that asks in writing [M-0259].
- A through-to-the-audience licence covers performances in content a licensee delivers to another music user with whom it has an economic relationship [M-0260].
- ASCAP must issue that licence on request to broadcasters, on-line users and operators of new transmission technologies. It need not cover performances outside the United States [M-0261]. The fee must take into account the value of all performances made under it [M-0262].
- If no fee is agreed within 60 days of the licence request, the music user may apply to the rate court for a reasonable fee [M-0263]. ASCAP carries the burden of proving its fee is reasonable, except that a per-segment licensee carries a tracking burden [M-0264].
- While negotiation or a rate proceeding is pending, either side may ask the court for an interim fee [M-0265].
- Status: no termination found in a 2026-11-10 read-only check of justice.gov [M-0256, M-0257].

#### BMI decree (court decision, Final Judgment as amended 1994, Article XIV only saved)
- In a BMI rate proceeding BMI carries the burden of proving its requested fee is reasonable [M-0266].
- Once the rate court fixes a fee, BMI must offer a comparable fee to similarly situated applicants who later ask [M-0267].
- An applicant or BMI may ask the rate court for an interim fee [M-0268].
- DOJ's 2021 statement says the decrees require ASCAP and BMI to offer the same terms to similarly situated users in the same industry, and to provide through-to-the-audience licences to certain users on request [M-0276, M-0277].

#### Full-work against fractional licensing
- DOJ's 2016 statement closed its review without seeking to change the decrees. It took the view that they require full-work licences [M-0269]. That is DOJ's view only.
- DOJ described a full-work licence as each PRO licensing the work so the user can perform it without infringement risk. It described a fractional licence as each PRO licensing only its own share, so the user needs the other co-owners' PROs too [M-0270, M-0271].
- The S.D.N.Y. held in 2016 that the BMI decree neither bars fractional licensing nor requires full-work licensing [M-0272]. The Second Circuit affirmed on 2017-12-19 by summary order, which has no precedential effect [M-0273].
- DOJ's 2021 statement says the Second Circuit disagreed with its view and that the BMI decree does not require full-work licences. Whether PROs should offer them is still debated [M-0274, M-0275].
- Do not say a PRO must license full works. For BMI the decree does not require full-work licences [M-0275]. ASCAP's treatment is not decided by these rows.

#### Rates and the rate court
- The Second Circuit held in Pandora v. ASCAP (2015) that the ASCAP decree unambiguously precludes partial withdrawals of public performance licensing rights [M-0281].
- It upheld a 1.85 percent of revenue rate for Pandora and ASCAP. The rate period is 2011 to 2015 and it is not a current rate [M-0282].
- The MMA partly repealed the bar on considering sound recording digital performance rates when setting musical work performance rates [M-0279].
- The MMA requires DOJ to notify Congress before moving to terminate a decree [M-0280].

#### Who is not under a decree
- The decrees regulate only ASCAP and BMI. Other PROs are free of the same constraints [M-0278].
- SESAC has never been under an antitrust consent decree [M-0320, M-0333]. A commenter quoted by the Office says SESAC, GMR, Pro Music Rights and AllTrack are not governed by decrees. That is a commenter view, not an Office finding [M-0293].
- The Office says the decrees are an important factor in new PRO formation, because other PROs are not under a decree [M-0292].
- Interested parties disagree. ASCAP says music users must pay SESAC and GMR what their repertories are worth [M-0331]. RMLC and MPA say non-decree PROs can extract disproportionate royalties [M-0332]. These are party positions, not findings.

#### SESAC and the Meredith settlement (court decision, S.D.N.Y. 2015)
- Television stations alleged SESAC's all-or-nothing blanket licence violated Sherman Act section 1 [M-0319]. SESAC agreed to pay $58.5 million into a settlement fund [M-0321].
- SESAC agreed to offer class stations a blanket licence and alternatives, protection from infringement claims while negotiating, and binding arbitration of industry-wide terms [M-0323, M-0324, M-0325]. The restrictions run 2016 to 2035 and cover local commercial television stations in the class [M-0322, M-0326].
- This is the television history, not a radio or digital arrangement [M-0333].

#### Copyright Office PRO inquiry (regulator)
- The Office opened a notice of inquiry on PROs and the public performance right on 2025-02-10 at Congress's request [M-0283, M-0008]. Comments were due 2025-04-11 and replies 2025-05-27 [M-0284].
- Topics included added cost from paying additional PROs and clarity for entities seeking PRO licences [M-0286, M-0287].
- The Office delivered its letter to House Judiciary leaders on 2025-11-20 and received over 5,000 comments [M-0288, M-0289]. The letter summarises commenter views and says these are not Office policy recommendations [M-0290].
- GMR and SESAC have joined BMI and ASCAP in committing to put repertoire data on Songview [M-0291].

#### SoundExchange is not a PRO
- SoundExchange says it is the sole organization designated by the US government to administer the section 114 sound recording licence [M-0294]. It covers the master side digital performance right, not the composition. See M06.
- It says it collects from services such as Pandora, SiriusXM and iHeartRadio [M-0295].

#### EU (foreign law)
- Directive 2014/26/EU Art. 5(2): rightholders may authorise a collective management organisation of their choice for the rights and territories of their choice [M-0308].
- Art. 16(1): organisations and users must negotiate licences in good faith and share necessary information [M-0309].
- Art. 16(2): licensing terms must rest on objective and non-discriminatory criteria [M-0310]. See M19.

### Gotchas
- "We have a blanket licence" does not mean sync or master are cleared [M-0256, M-0311].
- DOJ's full-work view is DOJ's view only. It was rejected for the BMI decree [M-0269, M-0272, M-0273].
- The Second Circuit BMI ruling is a summary order with no precedential effect [M-0273].
- The 1.85 percent Pandora rate is a 2011 to 2015 period rate, not a current rate [M-0282].
- The ASCAP decree text is a saved 2016 filing edition and the BMI row covers Article XIV only. No termination or change was found as of 2026-11-10, but check docket changes.
- The Office's 2025 letter is a summary of views, not a recommendation or a change in law [M-0290].
- A PRO licence for the US does not cover other territories. AFJ2 through-to-the-audience licences need not cover performances outside the United States [M-0261].
- Gap, needs source: RMLC v. GMR and SESAC settlement terms are not in the ledger. Do not describe them.

### Open questions for counsel
- US federal: would a livestream with a performer's background music need ASCAP, BMI, SESAC and GMR licences, and would a platform blanket licence cover creators' streams?
- US federal: does the through-to-the-audience licence fit a platform, and how should the request be made under AFJ2 and the BMI decree?
- US federal: for co-owned songs, how should a platform handle fractional licensing across four PROs?
- US federal: is the 2025 Copyright Office PRO inquiry likely to produce legislation that changes decree rights?
- EU: would an EU rollout negotiate with collective management organisations under Directive 2014/26/EU, and which territories?

### Sources
- doj-ascap-afj2-2001: United States v. ASCAP, Second Amended Final Judgment (https://www.justice.gov/opa/file/8507)
- doj-bmi-fj-1994: United States v. BMI, Final Judgment as amended 1994 (https://www.justice.gov/atr/case-document/file/489866/dl)
- doj-ascap-bmi-closing-2016: DOJ closing statement, 2016-08-04 (https://www.justice.gov/atr/file/882101/download)
- doj-ascap-bmi-closing-2021: DOJ closing statement, 2021-01-15 (https://www.justice.gov/atr/page/file/1355391/dl)
- ca2-us-bmi-2017: United States v. BMI, 720 F. App'x 14 (2d Cir. 2017) (https://storage.courtlistener.com/pdf/2017/12/19/united_states_v._broadcast_music_inc..pdf)
- ca2-pandora-ascap-2015: Pandora v. ASCAP, 785 F.3d 73 (2d Cir. 2015) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01158/pdf/USCOURTS-ca2-14-01158-0.pdf)
- sdny-meredith-sesac-2015: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (https://static.case.law/f-supp-3d/87/html/0650-01.html)
- fr-pro-noi-2025: Copyright Office PRO notice of inquiry, 90 FR (2025-02-10) (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt)
- co-pro-letter-2025: Copyright Office letter on PROs, 2025-11-20 (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf)
- soundexchange-about: SoundExchange About page (https://www.soundexchange.com/about/)
- eu-crm-2014-26: Directive 2014/26/EU (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L002)

### Claims cited in M05
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0328] VERIFIED
- Claim: The Copyright Office describes a PRO generally as contracting with songwriters and publishers for authority to license public performance rights and then providing collective licenses of those rights to users.
- Jurisdiction: US-federal
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR (Feb. 10, 2025), Background, Part a
- Quote: "a PRO contracts with songwriters and publishers for the authority to license the public performance rights"
- Checked: 2026-11-10

#### [M-0341] VERIFIED
- Claim: Performance rights societies license public performance of nondramatic musical works for the owners; this is the performance leg of the stack.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'performing rights society'
- Quote: "licenses the public performance of nondramatic musical works on behalf of copyright owners of such works"
- Checked: 2026-11-10

#### [M-0256] VERIFIED
- Claim: The ASCAP Second Amended Final Judgment bars ASCAP from licensing any rights in musical compositions other than public performance rights, and only on a non-exclusive basis.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(A)
- Quote: "Holding, acquiring, licensing, enforcing, or negotiating concerning any foreign or domestic rights in copyrighted musical compositions other than rights of public performance on a non-exclusive basis"
- Checked: 2026-11-10

#### [M-0311] VERIFIED
- Claim: Analysis: AFJ2 Sec. IV(A) enjoins ASCAP from licensing rights in musical compositions other than non-exclusive public performance rights, so ASCAP cannot grant sync rights; master rights are not compositions at all, so a platform would still need publisher sync and label master licences (inference; BMI, SESAC and GMR scope not shown by saved text).
- Jurisdiction: analysis
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(A)
- Quote: "Holding, acquiring, licensing, enforcing, or negotiating concerning any foreign or domestic rights in copyrighted musical compositions other than rights of public performance on a non-exclusive basis"
- Checked: 2026-11-10

#### [M-0259] VERIFIED
- Claim: ASCAP must grant a non-exclusive license to perform all works in its repertory to any music user that makes a written request.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. VI
- Quote: "ASCAP is hereby ordered and directed to grant to any music user making a written request therefor a non-exclusive license to perform all of the works in the ASCAP"
- Checked: 2026-11-10

#### [M-0263] VERIFIED
- Claim: If ASCAP and a music user cannot agree on a fee within 60 days of the licence request, the music user may apply to the rate court for a determination of a reasonable fee.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IX(A)
- Quote: "If the parties are unable to reach agreement within sixty (60) days from the date when the request for a license is received by ASCAP"
- Checked: 2026-11-10

#### [M-0266] VERIFIED
- Claim: In a BMI rate proceeding BMI carries the burden of proving the reasonableness of the fee it requests.
- Jurisdiction: case-law
- Source: United States v. Broadcast Music, Inc., Final Judgment (S.D.N.Y. 1966, Civ. No. 64-3787) as amended November 18, 1994 (Article XIV rate court) (https://www.justice.gov/atr/case-document/file/489866/dl), source id doj-bmi-fj-1994
- Pinpoint: BMI Final Judgment Art. XIV(A)
- Quote: "defendant shall have the burden of proof to establish the reasonableness of the fee requested by it"
- Checked: 2026-11-10

#### [M-0268] VERIFIED
- Claim: An applicant to BMI or BMI itself may ask the rate court to fix an interim fee pending a final reasonableness determination.
- Jurisdiction: case-law
- Source: United States v. Broadcast Music, Inc., Final Judgment (S.D.N.Y. 1966, Civ. No. 64-3787) as amended November 18, 1994 (Article XIV rate court) (https://www.justice.gov/atr/case-document/file/489866/dl), source id doj-bmi-fj-1994
- Pinpoint: BMI Final Judgment Art. XIV(B)
- Quote: "either the applicant or defendant may apply to this Court to fix an interim fee pending final determination of what constitutes a reasonable fee"
- Checked: 2026-11-10

#### [M-0320] VERIFIED
- Claim: The court noted SESAC has never been subject to an antitrust consent decree.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 656 (background)
- Quote: "SESAC has never been subject to such a consent decree"
- Checked: 2026-11-10

#### [M-0278] VERIFIED
- Claim: DOJ's Jan. 15, 2021 statement closing its review observes that the ASCAP and BMI decrees regulate only those two PROs, leaving other PROs free of the same constraints.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "the decrees regulate only ASCAP and BMI, leaving other PROs free to operate without the same constraints"
- Checked: 2026-11-10

#### [M-0293] VERIFIED
- Claim: A commenter quoted in the letter says SESAC, GMR, Pro Music Rights and AllTrack are not governed by consent decrees.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter, fn. quoting RITE Royalties Coalition Initial Comments at 8
- Quote: "SESAC, GMR, Pro Music Rights, and AllTrack, are not governed by consent decrees"
- Checked: 2026-11-10

#### [M-0283] VERIFIED
- Claim: The Copyright Office opened a notice of inquiry on PROs and the public performance right for musical works at Congress's request.
- Jurisdiction: regulator
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR 9253 (Feb. 10, 2025), Summary
- Quote: "The U.S. Copyright Office is collecting information regarding issues related to performance rights organizations PROs and the Copyright Act's public performance right for musical works"
- Checked: 2026-11-10

#### [M-0288] VERIFIED
- Claim: The Copyright Office delivered its PRO response letter to House Judiciary leaders on November 20, 2025, answering their September 11, 2024 request.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter p.1
- Quote: "We are pleased to deliver this response to your letter dated September 11, 2024, which asked the Copyright Office the Office to examine certain practices involving licensing fees paid to performing rights organizations"
- Checked: 2026-11-10

#### [M-0290] VERIFIED
- Claim: The November 2025 letter summarises commenters' views and says those summaries are not policy recommendations of the Office.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter p.3
- Quote: "although the enclosed summaries reflect views of commenters, rather than policy recommendations of the Office"
- Checked: 2026-11-10

#### [M-0285] VERIFIED
- Claim: The NOI lists ASCAP (1914), SESAC (1931) and BMI (1939) as the established PROs and says three more were formed: GMR (2013), PRO Music Rights (2018) and AllTrack (2019).
- Jurisdiction: regulator
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR 9253, background
- Quote: "three new PROs have been formed: Global Music Rights (or GMR) in 2013, PRO Music Rights in 2018, and AllTrack in 2019"
- Checked: 2026-11-10

#### [M-0329] VERIFIED
- Claim: Global Music Rights (GMR) is a US PRO formed in 2013, one of three newer PROs formed after ASCAP (1914), SESAC (1931) and BMI (1939).
- Jurisdiction: US-federal
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR (Feb. 10, 2025), Background, Part a
- Quote: "three new PROs have been formed: Global Music Rights (or ``GMR'') in 2013"
- Checked: 2026-11-10

#### [M-0330] VERIFIED
- Claim: In its 2016 closing statement the DOJ described Global Music Rights as a fourth PRO, with a collection of songs considerably smaller than ASCAP or BMI.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees (August 4, 2016; full-work licensing) (https://www.justice.gov/atr/file/882101/download), source id doj-ascap-bmi-closing-2016
- Pinpoint: DOJ closing statement Aug. 4, 2016, pp. 5-6 (sentence crosses page break)
- Quote: "a fourth PRO called Global Music Rights, also controlling a collection of songs"
- Checked: 2026-11-10

#### [M-0257] VERIFIED
- Claim: ASCAP members keep the right to license performance rights directly to music users, and ASCAP may not interfere with that right.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(B)
- Quote: "Limiting, restricting, or interfering with the right of any member to issue, directly or through an agent other than a performing rights organization, non-exclusive licenses to music users for rights of public performance"
- Checked: 2026-11-10

#### [M-0258] VERIFIED
- Claim: AFJ2 defines a blanket license as a non-exclusive license to perform ASCAP music at a fee that does not vary with how much ASCAP music the user performs.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. II (Blanket License)
- Quote: "Blanket License means a non-exclusive license that authorizes a music user to perform ASCAP music, the fee for which does not vary depending on the extent to which the music user in fact performs ASCAP music"
- Checked: 2026-11-10

#### [M-0260] VERIFIED
- Claim: AFJ2 defines a through-to-the-audience licence as covering performances in content a licensee delivers to another music user with whom it has an economic relationship.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. II (Through-to-the-Audience License)
- Quote: "Through-to-the-Audience License means a license that authorizes the simultaneous or so-called delayed performances of ASCAP music that are contained in content transmitted or delivered by a music user to another music user"
- Checked: 2026-11-10

#### [M-0261] VERIFIED
- Claim: ASCAP must issue a through-to-the-audience licence on request to broadcasters, on-line users and operators of new transmission technologies; it need not cover performances outside the United States.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. V
- Quote: "ASCAP is hereby ordered and directed to issue, upon request, a through-to-the-audience license to a broadcaster, an on-line user, a background/foreground music service, and an operator of any yet-to-be-developed technology"
- Checked: 2026-11-10

#### [M-0262] VERIFIED
- Claim: The fee for a through-to-the-audience licence must take into account the value of all performances made under it.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. V
- Quote: "The fee for a through-to-the-audience license shall take into account the value of all performances made pursuant to the license"
- Checked: 2026-11-10

#### [M-0264] VERIFIED
- Claim: In an AFJ2 rate proceeding the burden is on ASCAP to prove its requested fee is reasonable, except that a per-segment licensee carries a tracking burden.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IX(B)
- Quote: "In any such proceeding, the burden of proof shall be on ASCAP to establish the reasonableness of the fee it seeks"
- Checked: 2026-11-10

#### [M-0265] VERIFIED
- Claim: While negotiations or a rate proceeding are pending, either the music user or ASCAP may ask the court to fix an interim fee.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IX(F)
- Quote: "pending the completion of any negotiations or pending proceedings provided for in Section IX(A) of this Second Amended Final Judgment, either the music user or ASCAP may apply to the Court to fix an interim fee"
- Checked: 2026-11-10

#### [M-0267] VERIFIED
- Claim: Once the rate court fixes a BMI fee, BMI must offer a comparable fee to all similarly situated applicants who later request a licence.
- Jurisdiction: case-law
- Source: United States v. Broadcast Music, Inc., Final Judgment (S.D.N.Y. 1966, Civ. No. 64-3787) as amended November 18, 1994 (Article XIV rate court) (https://www.justice.gov/atr/case-document/file/489866/dl), source id doj-bmi-fj-1994
- Pinpoint: BMI Final Judgment Art. XIV(C)
- Quote: "When a reasonable fee has been finally determined by this Court, defendant shall be required to offer a license at a comparable fee to all other applicants similarly situated who shall thereafter request a license of defendant"
- Checked: 2026-11-10

#### [M-0276] VERIFIED
- Claim: DOJ's 2021 statement notes the decrees require ASCAP and BMI to provide through-to-the-audience licences to certain users on request.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "The decrees further require ASCAP and BMI to provide through-to-the-audience licenses to certain users upon request"
- Checked: 2026-11-10

#### [M-0277] VERIFIED
- Claim: DOJ's 2021 statement notes the decrees require ASCAP and BMI to offer the same terms to similarly situated users in the same industry.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "The decrees also require ASCAP and BMI to offer the same license terms to similarly situated users in the same industry"
- Checked: 2026-11-10

#### [M-0269] VERIFIED
- Claim: DOJ's Aug. 4, 2016 statement closed its review without seeking to modify the decrees and took the view that they require full-work licences (a view later rejected for BMI by S.D.N.Y. and the 2d Cir.).
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees (August 4, 2016; full-work licensing) (https://www.justice.gov/atr/file/882101/download), source id doj-ascap-bmi-closing-2016
- Pinpoint: DOJ statement Aug. 4, 2016, introduction
- Quote: "The Division has now concluded its investigation and has decided not to seek to modify the consent decrees. As discussed in detail below, the consent decrees"
- Checked: 2026-11-10

#### [M-0270] VERIFIED
- Claim: DOJ described a full-work licence as one where each PRO offers non-exclusive licences to the work entitling the user to perform it without risk of infringement liability (a framework the BMI decree was held not to require).
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees (August 4, 2016; full-work licensing) (https://www.justice.gov/atr/file/882101/download), source id doj-ascap-bmi-closing-2016
- Pinpoint: DOJ statement Aug. 4, 2016, Sec. II
- Quote: "Under a full-work license, each PRO would offer nonexclusive licenses to the work entitling the user to perform the work without risk of infringement liability"
- Checked: 2026-11-10

#### [M-0271] VERIFIED
- Claim: DOJ described a fractional licence as one where each PRO licenses only its own interests and the licensee must obtain additional licences from the PROs representing other co-owners before performing the work.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees (August 4, 2016; full-work licensing) (https://www.justice.gov/atr/file/882101/download), source id doj-ascap-bmi-closing-2016
- Pinpoint: DOJ statement Aug. 4, 2016, Sec. II
- Quote: "Under a fractional license, each PRO would offer a license only to the interests it holds in a work, and require that the licensee obtain additional licenses from the PROs representing other co-owners before performing the work"
- Checked: 2026-11-10

#### [M-0272] VERIFIED
- Claim: The Southern District of New York held in 2016 that the BMI decree neither bars fractional licensing nor requires full-work licensing.
- Jurisdiction: case-law
- Source: United States v. Broadcast Music, Inc., No. 16-3830-cv, 720 F. App'x 14 (2d Cir. Dec. 19, 2017) (summary order, fractional licensing) (https://storage.courtlistener.com/pdf/2017/12/19/united_states_v._broadcast_music_inc..pdf), source id ca2-us-bmi-2017
- Pinpoint: 207 F. Supp. 3d 374, 377 (as quoted in 720 F. App'x 14)
- Quote: "Consent Decree neither bars fractional licensing nor requires full-work licensing"
- Checked: 2026-11-10

#### [M-0273] VERIFIED
- Claim: The Second Circuit (Dec. 19, 2017, summary order) affirmed the S.D.N.Y. judgment that the BMI consent decree neither requires full-work licensing nor prohibits fractional licensing.
- Jurisdiction: case-law
- Source: United States v. Broadcast Music, Inc., No. 16-3830-cv, 720 F. App'x 14 (2d Cir. Dec. 19, 2017) (summary order, fractional licensing) (https://storage.courtlistener.com/pdf/2017/12/19/united_states_v._broadcast_music_inc..pdf), source id ca2-us-bmi-2017
- Pinpoint: 720 F. App'x 14, 2d Cir. No. 16-3830-cv
- Quote: "The court ruled that the consent decree neither requires full-work licensing nor prohibits fractional licensing of BMI's affiliates' compositions"
- Checked: 2026-11-10

#### [M-0274] VERIFIED
- Claim: DOJ's January 15, 2021 statement says the Second Circuit disagreed with the Division's full-work view and held the BMI decree permits fractional licensing.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "The U.S. Court of Appeals for the Second Circuit disagreed, affirming a district court decision that the BMI consent decree (which contains similar language as the ASCAP decree) permits fractional licensing"
- Checked: 2026-11-10

#### [M-0275] VERIFIED
- Claim: DOJ's 2021 statement says the BMI decree does not require BMI to offer full-work licences, and whether PROs should is still debated.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "What is clear for present purposes, following the Second Circuit's ruling, is that the BMI consent decree does not require BMI to do so"
- Checked: 2026-11-10

#### [M-0281] VERIFIED
- Claim: The Second Circuit held in Pandora v. ASCAP (2015) that the ASCAP decree unambiguously precludes partial withdrawals of public performance licensing rights.
- Jurisdiction: case-law
- Source: Pandora Media, Inc. v. ASCAP (In re Pandora Media), 785 F.3d 73 (2d Cir. 2015) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01158/pdf/USCOURTS-ca2-14-01158-0.pdf), source id ca2-pandora-ascap-2015
- Pinpoint: 785 F.3d 73 (2d Cir. 2015), opening
- Quote: "ground that the consent decree governing Respondent-Appellant's licensing activities unambiguously precludes partial withdrawals of public performance licensing rights. We AFFIRM."
- Checked: 2026-11-10

#### [M-0282] VERIFIED
- Claim: The Second Circuit upheld the rate court's 1.85 percent of revenue rate for the Pandora-ASCAP licence.
- Jurisdiction: case-law
- Source: Pandora Media, Inc. v. ASCAP (In re Pandora Media), 785 F.3d 73 (2d Cir. 2015) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01158/pdf/USCOURTS-ca2-14-01158-0.pdf), source id ca2-pandora-ascap-2015
- Pinpoint: 785 F.3d 73; slip op. 15-16 (Doc. 230-1 PDF pp. 15-16)
- Quote: "determination that a 1.85% rate was reasonable for the duration of"
- Checked: 2026-11-10

#### [M-0279] VERIFIED
- Claim: The Music Modernization Act partly repealed the bar on considering sound recording digital performance rates when setting musical work performance rates.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021, MMA discussion
- Quote: "The Act partially repealed the limitation on considering digital performance license rates for sound recordings in setting license rates for the performance of musical works"
- Checked: 2026-11-10

#### [M-0280] VERIFIED
- Claim: The MMA requires DOJ to notify Congress before moving to terminate one of the decrees.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021, MMA discussion
- Quote: "It also requires the Department of Justice to notify Congress before moving to terminate one of the decrees"
- Checked: 2026-11-10

#### [M-0333] VERIFIED
- Claim: SESAC has never been under a consent decree; until 2007 SESAC and the TV station committee (TMLC) negotiated industry-wide blanket licences or arbitrated them under a contractual duty to arbitrate. This is the TV history, not the radio RMLC arbitration.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 656
- Quote: "SESAC has never been subject to such a consent decree. Until 2007, SESAC and the TMLC had successfully negotiated industry-wide blanket licenses or had arbitrated the terms of such licenses pursuant to a contractual duty to arbitrate disputes."
- Checked: 2026-11-10

#### [M-0292] VERIFIED
- Claim: The Office says the ASCAP and BMI decrees are an important factor in new PRO formation because other PROs are not under a decree.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter p.4
- Quote: "the antitrust consent decrees governing ASCAP and BMI are an important factor related to the formation of new PROs which, while still subject to antitrust law, are not subject to the more stringent restrictions associated with a consent decree"
- Checked: 2026-11-10

#### [M-0331] VERIFIED
- Claim: ASCAP's reply comment (quoted in the Copyright Office's Nov. 20, 2025 letter, n.9) says that because SESAC and GMR are not subject to consent decrees, music users must pay those PROs what their repertories are worth; this is an interested party's statement, not a holding.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Copyright Office letter (Nov. 20, 2025), n.9 quoting ASCAP Reply Comments at 5
- Quote: "Because SESAC and GMR are not subject to compulsory access requirement pursuant to consent decrees, music users must pay those PROs what the value of the PRO repertories are worth to them."
- Checked: 2026-11-10

#### [M-0332] VERIFIED
- Claim: In a Copyright Office letter the Office cites RMLC and MPA joint initial comments discussing a belief that PROs not under consent decrees can extract comparatively disproportionate royalties.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Copyright Office letter (Nov. 20, 2025), n.9 (RMLC & MPA Initial Comments at 6, 10-13)
- Quote: "RMLC & MPA Initial Comments at 6, 10-13 (discussing belief that PROs that are not subject to consent decrees can extract comparatively disproportionate royalties)"
- Checked: 2026-11-10

#### [M-0319] VERIFIED
- Claim: Meredith v. SESAC: television stations alleged SESAC's all-or-nothing blanket licence violated Sherman Act section 1.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 654-55
- Quote: "Plaintiffs alleged that SESAC and its affiliates thereby violated 1 of the Sherman Act"
- Checked: 2026-11-10

#### [M-0321] VERIFIED
- Claim: SESAC agreed to pay $58.5 million into a settlement fund for local television stations.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 657
- Quote: "SESAC has agreed to pay $58.5 million into a settlement fund"
- Checked: 2026-11-10

#### [M-0323] VERIFIED
- Claim: SESAC agreed to offer class stations a blanket licence and viable alternatives to it.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 657
- Quote: "offer all local stations a blanket license and viable alternatives to it"
- Checked: 2026-11-10

#### [M-0324] VERIFIED
- Claim: SESAC agreed to protect class stations from infringement claims while licence negotiations are pending.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 657
- Quote: "relieve local stations from the threat of copyright infringement claims during the pendency of license negotiations"
- Checked: 2026-11-10

#### [M-0325] VERIFIED
- Claim: SESAC agreed to binding arbitration with the television station committee when industry-wide fees or terms cannot be agreed.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 657
- Quote: "enter into binding arbitration when the TMLC and SESAC are unable to reach agreement on industry-wide license fees and/or terms"
- Checked: 2026-11-10

#### [M-0322] VERIFIED
- Claim: The conduct restrictions in the SESAC settlement govern SESAC dealings for 20 years (2016 to 2035) with local television stations in the settlement class.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 657
- Quote: "SESAC has agreed to various conduct restrictions that will govern its dealings during the next 20 years (from 2016 until 2035) with any local television station in the settlement class"
- Checked: 2026-11-10

#### [M-0326] VERIFIED
- Claim: The settlement class is owners of full-power local commercial television stations that obtained licenses from SESAC from January 1, 2008 (to the preliminary approval order date), per the class definition.
- Jurisdiction: case-law
- Source: Meredith Corp. v. SESAC LLC, 87 F. Supp. 3d 650 (S.D.N.Y. 2015) (final approval of class settlement) (https://static.case.law/f-supp-3d/87/html/0650-01.html), source id sdny-meredith-sesac-2015
- Pinpoint: 87 F. Supp. 3d 650, 659, Part II.A
- Quote: "All owners of full-power local commercial television stations in the United States and its territories (including Puerto Rico) that obtained licenses from Defendant during the period from January 1, 2008"
- Checked: 2026-11-10

#### [M-0008] VERIFIED
- Claim: The Copyright Office opened an inquiry into performing rights organizations in 2025 and sent a letter on the inquiry dated November 20, 2025.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: letter of November 20, 2025, p.1 background paragraph
- Quote: "the Copyright Office published a Notification of Inquiry (\"NOI\") on February 10, 2025, requesting public comments."
- Checked: 2026-11-10

#### [M-0284] VERIFIED
- Claim: The NOI set comments due April 11, 2025 and reply comments due May 27, 2025.
- Jurisdiction: regulator
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR 9253, Dates
- Quote: "Eastern Time on April 11, 2025. Written reply comments must be received no later than 11:59 p.m. Eastern Time on May 27, 2025"
- Checked: 2026-11-10

#### [M-0286] VERIFIED
- Claim: The NOI's first topic asked about added cost to licensees from paying royalties to additional PROs.
- Jurisdiction: regulator
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR 9253, Topic 1
- Quote: "To what extent, if any, have there been increased financial and administrative costs imposed on licensees associated with paying royalties to additional PROs"
- Checked: 2026-11-10

#### [M-0287] VERIFIED
- Claim: The NOI's third topic asked for recommendations on improving clarity and certainty for entities seeking PRO licences.
- Jurisdiction: regulator
- Source: Copyright Office, Issues Related to Performing Rights Organizations, notice of inquiry, 90 FR (Feb. 10, 2025), FR Doc. 2025-02418 (https://www.federalregister.gov/documents/full_text/text/2025/02/10/2025-02418.txt), source id fr-pro-noi-2025
- Pinpoint: 90 FR 9253, Topic 3
- Quote: "Recommendations on how to improve clarity and certainty for entities seeking to obtain licenses from PROs to publicly perform musical works"
- Checked: 2026-11-10

#### [M-0289] VERIFIED
- Claim: The Office received over 5,000 comments in response to the NOI.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter p.1
- Quote: "The Office received over 5,000 comments in response to the NOI"
- Checked: 2026-11-10

#### [M-0291] VERIFIED
- Claim: The letter says GMR and SESAC have joined BMI and ASCAP in committing to put repertoire data on Songview.
- Jurisdiction: regulator
- Source: U.S. Copyright Office letter to House Judiciary on issues related to performing rights organizations (November 20, 2025) (https://www.copyright.gov/policy/pro-issues/usco-letter-on-issues-related-to-performing-rights-organizations.pdf), source id co-pro-letter-2025
- Pinpoint: Letter p.3
- Quote: "and ASCAP in committing to make their repertoire data available on Songview, a platform designed to provide a single source of detailed public performance copyright information"
- Checked: 2026-11-10

#### [M-0294] VERIFIED
- Claim: SoundExchange describes itself as the sole organization designated by the U.S. government to administer the Section 114 sound recording licence.
- Jurisdiction: regulator
- Source: SoundExchange: About (Section 114 statutory licence administration, who it collects for and pays) (https://www.soundexchange.com/about/), source id soundexchange-about
- Pinpoint: SoundExchange About page
- Quote: "As the sole organization designated by the U.S. government to administer the Section 114 sound recording license"
- Checked: 2026-11-10

#### [M-0295] VERIFIED
- Claim: SoundExchange says it collects digital performance royalties from services such as Pandora, SiriusXM and iHeartRadio.
- Jurisdiction: regulator
- Source: SoundExchange: About (Section 114 statutory licence administration, who it collects for and pays) (https://www.soundexchange.com/about/), source id soundexchange-about
- Pinpoint: SoundExchange About page
- Quote: "seamlessly collects and distributes digital performance royalties from platforms like Pandora, SiriusXM, iHeartRadio"
- Checked: 2026-11-10

#### [M-0308] VERIFIED
- Claim: In the EU, rightholders may authorise a collective management organisation of their choice to manage the rights and territories of their choice.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 5(2)
- Quote: "Rightholders shall have the right to authorise a collective management organisation of their choice to manage the rights, categories of rights or types of works and other subject-matter of their choice, for the territories of their choice"
- Checked: 2026-11-10

#### [M-0309] VERIFIED
- Claim: EU collective management organisations and users must negotiate licences in good faith and share necessary information.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 16(1)
- Quote: "conduct negotiations for the licensing of rights in good faith. Collective management organisations and users shall provide each other with all necessary information"
- Checked: 2026-11-10

#### [M-0310] VERIFIED
- Claim: EU licensing terms must rest on objective and non-discriminatory criteria.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 16(2)
- Quote: "Licensing terms shall be based on objective and non-discriminatory criteria"
- Checked: 2026-11-10

## M06 SoundExchange, 114 and 112
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Does the 114 statutory licence cover a platform that streams user mixes; Who is SoundExchange and what does it collect; Does the 112 ephemeral copy exemption cover platform server copies; What are the Web VI rates and do they apply to a mixing platform; Does a platform storing or processing user audio need a licence; Is there a performance right in sound recordings for terrestrial radio

### Bottom line
US federal law: the 17 U.S.C. 114 statutory licence is for audio only transmissions of the sound recording (the master). It does not cover a short video with music, because a "digital audio transmission" excludes any audiovisual work [M-0112, M-0297, M-0312]. The 112 ephemeral copy licence does not help either [M-0181]. SoundExchange says it is the designated collective for the 114 royalties, so it is not who clears music for a video platform [M-0294, M-0304]. A video platform needs direct sync (composition) and master use (recording) licences from the rights holders.

### Rules
#### What 114 gives and withholds (US federal statute)
- A sound recording owner has the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4) [M-0109, M-0296].
- The sound recording reproduction right covers only duplication that recaptures the actual sounds [M-0110].
- An independent sound-alike does not infringe the sound recording copyright. The musical work is a separate copyright, so (analysis) a sound-alike still needs a composition licence [M-0111].
- 114(d)(2) puts three kinds of audio transmission under a statutory licence if the listed conditions are met: subscription, eligible nonsubscription and preexisting satellite digital audio radio [M-0114, M-0298].
- The transmission must not be part of an interactive service [M-0115, M-0298].
- An interactive service lets a member of the public receive a program made for the recipient or, on request, a particular sound recording [M-0113, M-0299].
- An eligible nonsubscription transmission is a noninteractive, nonsubscription digital audio transmission made as part of an audio programming service [M-0300].
- A digital audio transmission embodies a sound recording and does not include transmission of any audiovisual work [M-0112, M-0297].
- An interactive service may not publicly perform a sound recording unless the musical work performance is licensed [M-0301]. (analysis) That licence may come from a performing rights society or the copyright owner [M-0313].

#### Rates and who sets them (US federal statute and regulation)
- The Copyright Royalty Judges (three, appointed by the Librarian) set 112(e) and 114 rates [M-0169, M-0170].
- The standard for 114(d)(2) rates is what a willing buyer and willing seller would agree in the marketplace [M-0167].
- Rates run for 5 years unless another period is agreed, and bind all affected owners and performers [M-0168].
- The Judges may adopt a settlement among some or all participants, and decline for non-parties only on an objection and a record showing no reasonable basis [M-0171].
- Web V (37 CFR 380) set webcasting rates for 2021 to 2025 [M-0157, M-0158, M-0306]. That period ended 2025-12-31 [M-0157].
- Web V commercial webcaster rates for 2025: $0.0032 per performance (subscription) and $0.0025 (nonsubscription) [M-0154, M-0307]. Minimum fee $1,000 per channel or station per year [M-0155]. Credit split 5 percent to ephemeral recordings and 95 percent to section 114 [M-0156].
- Web VI began by Federal Register notice on 2024-01-05 [M-0184]. Final rules for commercial broadcasters, Educational Media Foundation, noncommercial educational webcasters and certain public radio stations took effect 2026-03-10 for 2026 to 2030 [M-0010].
- Web VI commercial broadcasters (settlement between SoundExchange and NAB, adopted as proposed) [M-0162, M-0185]: nonsubscription rate $0.0028 per performance in 2026 rising to $0.0032 in 2030 [M-0159]. Minimum fee $1,100 (2026) to $1,250 (2029, 2030) [M-0160].
- A Commercial Broadcaster is a webcaster with a material business in FCC licensed AM or FM stations, so a non-broadcaster app is outside that subpart [M-0161].
- Web VI other licensees: Educational Media Foundation $7,125,000 for 2026 [M-0163]; noncommercial educational minimum fee $800 in 2026 [M-0164].
- NSS V (2026 to 2030) covers new subscription services delivered as part of a cable or satellite TV bundle [M-0166]. Stand-alone monthly per-subscriber base is $0.0234 (2025 rate, then adjusted) [M-0165]. Bundled base is $0.0390 [M-0507].
- Preexisting subscription services deliver Reports of Use to the Collective within 45 days after each month [M-0178]. A Collective is the organization the Judges designate for a statutory licence [M-0305].

#### SoundExchange and the money (US federal)
- SoundExchange says it is the sole organization the US government designated to administer the 114 licence [M-0294]. That is its own description, captured 2026-11-10.
- It says it collects from services such as Pandora, SiriusXM and iHeartRadio [M-0295]. Naming a service is not a statement of its current licence status.
- A nonprofit collective picked by the Judges distributes 114 receipts [M-0304]. Split: 50 percent to the sound recording copyright owner [M-0302], 45 percent to featured recording artists [M-0303].

#### 112 ephemeral copies (US federal statute)
- 112(a)(1) excludes motion pictures and other audiovisual works [M-0117].
- 112(e)(1) gives a transmitting organization entitled to transmit under 114(d)(1)(C)(iv) or a 114(f) licence a statutory licence for no more than 1 ephemeral phonorecord, if conditions are met [M-0116].

#### Pending bills (not law)
- AMFA: H.R. 861 would give sound recordings a public performance right by audio transmission, reaching terrestrial broadcast, and its audio transmission definition excludes audiovisual works [M-0480]. S. 326 was introduced 2025-01-30 and referred to Senate Judiciary [M-0504]. Neither is law.

### Gotchas
- Web V rates are 2025 only [M-0157, M-0307]. Web VI is not fully codified: none is in the saved sources for a commercial non-broadcaster as of 2026-11-10 [M-0010, M-0161] (unverified, M-0182). Do not state a Web VI rate for a commercial non-broadcaster. The Web VI rates above are for broadcasters and other named classes only.
- NSS V 2026 amounts are adjusted bases. The saved text has placeholders for the 2026 figures [M-0165]. Do not quote a 2026 dollar amount.
- "114 licence" does not mean a platform may host a song. It covers audio transmissions only [M-0112].
- The sound recording has no general public performance right [M-0296]. Composition performance is a separate right, see M05 for PROs.
- Statutory licence terms depend on listed conditions [M-0114]. Do not assume a service qualifies.
- AMFA is a bill [M-0480, M-0504]. Do not say terrestrial radio pays sound recording owners.
- SoundExchange sources here are self-description and may change [M-0294, M-0295].

### Open questions for counsel
- US federal: does any platform feature (audio only previews, live audio streams, playlists) fall within a 114(d)(2) noninteractive service, or is every product interactive or audiovisual?
- US federal: for audio only live streams with background music, which licences are needed and who grants them?
- US federal: does a platform's re-encoding of a user's audio create any reproduction or performance exposure for the platform as a service (M-0317 is unverified)?
- US federal: what is the status of the Web VI commercial non-broadcaster determination (docket 24-CRB-0001-W)?
- US federal: should the Web V and NSS V rate figures be rechecked before any rate quote, since the NSS V 2026 figures are adjusted amounts not in the saved text?
- US federal: is there any reason to register with SoundExchange as a service at all?

### Sources
- usc17-114: 17 U.S.C. 114 (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-112: 17 U.S.C. 112 (https://www.law.cornell.edu/uscode/text/17/112)
- usc17-801: 17 U.S.C. 801 (https://www.law.cornell.edu/uscode/text/17/801)
- cfr37-380: 37 CFR Part 380, eCFR as of 2026-10-26 (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380)
- cfr37-370: 37 CFR Part 370, eCFR as of 2026-10-26 (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370)
- crb-web5-final: Web V final rule, 86 FR (Oct. 27, 2021)
- crb-web6-final-commercial-broadcasters: Web VI commercial broadcasters, 91 FR (Mar. 10, 2026)
- crb-web6-final-emf: Web VI EMF, 91 FR (Mar. 10, 2026)
- crb-web6-final-noncommercial-educational: Web VI noncommercial educational, 91 FR (Mar. 10, 2026)
- crb-nss5-final: NSS V final rule, 91 FR (Mar. 10, 2026)
- crb-web6-commercial-nonbroadcasters: stub, no determination published as of 2026-11-10
- soundexchange-about: SoundExchange About (https://www.soundexchange.com/about/)
- hr861-amfa-text: H.R. 861 (https://www.govinfo.gov/content/pkg/BILLS-119hr861ih/html/BILLS-119hr861ih.htm)
- s326-amfa-status: S. 326 BILLSTATUS (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s326.xml)

### Claims cited in M06
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0297] VERIFIED
- Claim: A digital audio transmission is a digital transmission that embodies a sound recording and does not include transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "A digital audio transmission is a digital transmission as defined in section 101, that embodies the transmission of a sound recording. This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0312] VERIFIED
- Claim: Analysis: the 17 U.S.C. 114 statutory licence does not cover short videos on a user upload platform because a "digital audio transmission" under 114(j)(5) does not include the transmission of any audiovisual work.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0181] VERIFIED
- Claim: Analysis: the 112(a)(1) ephemeral copy exemption excludes audiovisual works and the 112(e) statutory licence attaches only to transmissions under 114 licences, so a platform cannot rely on 112 for server copies of video-with-music.
- Jurisdiction: analysis
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(a)(1), (e)(1)
- Quote: "except in the case of a motion picture or other audiovisual work, it is not an infringement of copyright for a transmitting organization"
- Checked: 2026-11-10

#### [M-0294] VERIFIED
- Claim: SoundExchange describes itself as the sole organization designated by the U.S. government to administer the Section 114 sound recording licence.
- Jurisdiction: regulator
- Source: SoundExchange: About (Section 114 statutory licence administration, who it collects for and pays) (https://www.soundexchange.com/about/), source id soundexchange-about
- Pinpoint: SoundExchange About page
- Quote: "As the sole organization designated by the U.S. government to administer the Section 114 sound recording license"
- Checked: 2026-11-10

#### [M-0304] VERIFIED
- Claim: A nonprofit collective designated by the Copyright Royalty Judges distributes statutory 114 receipts.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)
- Quote: "a nonprofit collective designated by the Copyright Royalty Judges to distribute receipts from the licensing of transmissions in accordance with subsection (f) shall distribute such receipts as follows"
- Checked: 2026-11-10

#### [M-0109] VERIFIED
- Claim: A sound recording has no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)."
- Checked: 2026-11-10

#### [M-0296] VERIFIED
- Claim: Sound recording owners have only the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0114] VERIFIED
- Claim: 17 U.S.C. 114(d)(2) subjects subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite digital audio radio service transmissions to statutory licensing if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)
- Quote: "a subscription digital audio transmission not exempt under paragraph (1), an eligible nonsubscription transmission, or a transmission not exempt under paragraph (1) that is made by a preexisting satellite digital audio radio service shall be subject to statutory licensing"
- Checked: 2026-11-10

#### [M-0298] VERIFIED
- Claim: The 114 statutory licence reaches subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite DARS transmissions, and the transmission must not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0113] VERIFIED
- Claim: Under 17 U.S.C. 114(j)(7), an interactive service is one that lets a member of the public receive on request a transmission of a particular sound recording selected by or for the recipient.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0299] VERIFIED
- Claim: An interactive service is one that lets a member of the public receive a program made for the recipient or, on request, a particular sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0300] VERIFIED
- Claim: An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission, not exempt under (d)(1), made as part of a service providing audio programming consisting in whole or in part of performances of sound recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(6)
- Quote: "An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission not exempt under subsection (d)(1) that is made as part of a service that provides audio programming consisting, in whole or in part, of performances of sound recordings"
- Checked: 2026-11-10

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0313] VERIFIED
- Claim: Analysis: if a platform qualified as an interactive service, 114(d)(3)(C) would still require a licence for the public performance of each musical work in the sound recording, which may come from a performing rights society or the copyright owner.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0169] VERIFIED
- Claim: The Librarian appoints three full-time Copyright Royalty Judges, one of them Chief.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(a)
- Quote: "The Librarian of Congress shall appoint 3 full-time Copyright Royalty Judges, and shall appoint 1 of the 3 as the Chief Copyright Royalty Judge."
- Checked: 2026-11-10

#### [M-0170] VERIFIED
- Claim: The Judges determine reasonable terms and rates under sections 112(e), 114, 115, 116, 118, 119 and 1004.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(b)(1)
- Quote: "To make determinations and adjustments of reasonable terms and rates of royalty payments as provided in sections 112(e), 114, 115, 116, 118, 119, and 1004."
- Checked: 2026-11-10

#### [M-0167] VERIFIED
- Claim: The Judges' standard for 114(d)(2) rates is the rates a willing buyer and willing seller would negotiate in the marketplace.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(B)
- Quote: "The Copyright Royalty Judges shall establish rates and terms that most clearly represent the rates and terms that would have been negotiated in the marketplace between a willing buyer and a willing seller."
- Checked: 2026-11-10

#### [M-0168] VERIFIED
- Claim: 114(d)(2) rates and terms set by the Judges are for a 5-year period (or other period agreed) and bind all copyright owners of sound recordings and entities performing sound recordings affected.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(A)-(B)
- Quote: "be binding on all copyright owners of sound recordings and entities performing sound recordings affected by this paragraph during the 5-year period specified in subparagraph (A)"
- Checked: 2026-11-10

#### [M-0171] VERIFIED
- Claim: The Judges may adopt a settlement among some or all participants, and may decline for non-parties only if a participant objects and the record shows no reasonable basis.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 801 Copyright Royalty Judges, appointment and functions (https://www.law.cornell.edu/uscode/text/17/801), source id usc17-801
- Pinpoint: 17 U.S.C. 801(b)(7)(A)(ii)
- Quote: "the Copyright Royalty Judges may decline to adopt the agreement as a basis for statutory terms and rates for participants that are not parties to the agreement, if any participant described in clause (i) objects to the agreement"
- Checked: 2026-11-10

#### [M-0157] VERIFIED
- Claim: Web V codified rates and terms for the period January 1, 2021 through December 31, 2025 (period now ended; Web VI follows).
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.1(a)
- Quote: "during the period January 1, 2021, through December 31, 2025."
- Checked: 2026-11-10

#### [M-0158] VERIFIED
- Claim: The Web V final determination (86 FR, Oct. 27, 2021) set rates and terms for two statutory licences (digital performance and ephemeral recordings) for 2021 to 2025.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings and Making of Ephemeral Copies (Web V), final rule and order (2021-2025), 86 FR (Oct. 27, 2021), FR Doc. 2021-20621 (https://www.federalregister.gov/documents/full_text/text/2021/10/27/2021-20621.txt), source id crb-web5-final
- Pinpoint: 86 FR (Oct. 27, 2021), Summary
- Quote: "for the period beginning January 1, 2021, and ending on December 31, 2025."
- Checked: 2026-11-10

#### [M-0306] VERIFIED
- Claim: 37 CFR Part 380 as saved (eCFR 2026-10-26) sets webcasting rates and terms under 17 U.S.C. 114 and 112(e) for January 1, 2021 through December 31, 2025, and voluntary licence agreements may apply in lieu of them.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.1(a), (d)
- Quote: "Notwithstanding the royalty rates and terms established in any subparts of this part, the rates and terms of any license agreements entered into by Copyright Owners and Licensees may apply in lieu of these rates and terms"
- Checked: 2026-11-10

#### [M-0154] VERIFIED
- Claim: Web V rates for commercial webcasters in 2025 were $0.0032 per performance (subscription) and $0.0025 per performance (nonsubscription).
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(a)(1)
- Quote: "Commercial webcasters: $0.0032 per Performance for subscription services and $0.0025 per Performance for nonsubscription services."
- Checked: 2026-11-10

#### [M-0307] VERIFIED
- Claim: Under the 2025 commercial webcaster rate, nonsubscription services paid $0.0025 per performance and subscription services $0.0032.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR Part 380 subpart B, royalty fees for 2025
- Quote: "Commercial webcasters: $0.0032 per Performance for subscription services and $0.0025 per Performance for nonsubscription services"
- Checked: 2026-11-10

#### [M-0155] VERIFIED
- Claim: Web V minimum fee is $1,000 per channel or station per year, credited against royalties.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(b)
- Quote: "Licensees must pay the Collective a minimum fee of $1,000 each year for each channel or station."
- Checked: 2026-11-10

#### [M-0156] VERIFIED
- Claim: Web V royalties are credited 5 percent to ephemeral recordings and 95 percent to section 114.
- Jurisdiction: US-federal
- Source: 37 CFR Part 380 rates and terms for webcasting and new subscription services (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=380), source id cfr37-380
- Pinpoint: 37 CFR 380.10(d)
- Quote: "The Collective must credit 5% of all royalty payments as payment for Ephemeral Recordings and credit the remaining 95% to section 114 royalties."
- Checked: 2026-11-10

#### [M-0184] VERIFIED
- Claim: Web VI (2026-2030) commenced by Federal Register notice on January 5, 2024 for the web licences.
- Jurisdiction: US-federal
- Source: STUB (no such determination published as of 2026-11-10; FR search returns only the 4 settlement rules): CRB Web VI determination, commercial non-broadcasters (FR search; none published as of 2026-11-10) (https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=%22Web+VI%22&conditions%5Bagencies%5D%5B%5D=copyright-royalty-board&order=newest), source id crb-web6-commercial-nonbroadcasters
- Pinpoint: 89 FR (Jan. 5, 2024), FR Doc. 2023-28516 (FR API search result)
- Quote: "announce commencement of a proceeding to determine reasonable rates and terms for two statutory licenses permitting the digital performance of sound recordings over the internet"
- Checked: 2026-11-10

#### [M-0010] VERIFIED
- Claim: Web VI final rules for commercial broadcasters, Educational Media Foundation, noncommercial educational webcasters and certain public radio stations took effect March 10, 2026, for the period January 1, 2026 through December 31, 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: FR 91 (March 10, 2026), DATES
- Quote: "DATES: Effective March 10, 2026."
- Checked: 2026-11-10

#### [M-0162] VERIFIED
- Claim: The Web VI commercial broadcaster rates and terms were the subject of a settlement between SoundExchange and the National Association of Broadcasters (NAB), which the Judges adopted as proposed.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 91 FR 11458 (Mar. 10, 2026), Background
- Quote: "The rates and terms in the proposed rule were the subject of a settlement between SoundExchange, Inc."
- Checked: 2026-11-10

#### [M-0185] VERIFIED
- Claim: The Web VI commercial broadcaster proposed rule (settlement) was published for comment on May 16, 2025 (90 FR 20977), before final adoption in 2026.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 91 FR 11458 (Mar. 10, 2026), Background (90 FR 20977)
- Quote: "On May 16, 2025, the Copyright Royalty Judges"
- Checked: 2026-11-10

#### [M-0159] VERIFIED
- Claim: Web VI commercial broadcaster nonsubscription rate is $0.0028 per performance in 2026 rising to $0.0032 in 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.41(a); 91 FR 11458 (Mar. 10, 2026)
- Quote: "2026: $0.0028 per Performance; (2) 2027: $0.0029 per Performance; (3) 2028: $0.0030 per Performance; (4) 2029: $0.0031 per Performance; and (5) 2030: $0.0032 per Performance."
- Checked: 2026-11-10

#### [M-0160] VERIFIED
- Claim: Web VI commercial broadcaster minimum fee per channel or station is $1,100 (2026) to $1,250 (2029, 2030).
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.41(b)(1); 91 FR 11458
- Quote: "(i) 2026: $1,100; (ii) 2027: $1,150; (iii) 2028: $1,200; (iv) 2029: $1,250; and (v) 2030: $1,250."
- Checked: 2026-11-10

#### [M-0161] VERIFIED
- Claim: In the saved Web VI commercial broadcaster rule a Commercial Broadcaster is a Commercial Webcaster a material part of whose business is owning and operating FCC-licensed terrestrial AM or FM stations, so a non-broadcaster app is not covered by that subpart.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.40 (definition of Commercial Broadcaster)
- Quote: "Commercial Broadcaster is a Commercial Webcaster, a material part of the business of which consists of owning and operating one or more terrestrial AM or FM broadcast radio stations licensed as such by the Federal Communications Commission."
- Checked: 2026-11-10

#### [M-0163] VERIFIED
- Claim: Web VI sets Educational Media Foundation payments at $7,125,000 for 2026 rising to about $8.3 million in 2030.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, Educational Media Foundation (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04631 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04631.txt), source id crb-web6-final-emf
- Pinpoint: 37 CFR 380.51(a); 91 FR (Mar. 10, 2026)
- Quote: "2026: $7,125,000.00 ($593,750.00 per month); (2) 2027: $7,410,000.00 ($617,500.00 per month); (3) 2028: $7,706,400.00 ($642,200.00 per month); (4) 2029: $8,014,656.00 ($667,888.00 per month); and (5) 2030: $8,335,242.24 ($694,603.52 per month)."
- Checked: 2026-11-10

#### [M-0164] VERIFIED
- Claim: Web VI noncommercial educational webcaster minimum fee starts at $800 in 2026.
- Jurisdiction: US-federal
- Source: CRB, Web VI final rule, noncommercial educational webcasters (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04630 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04630.txt), source id crb-web6-final-noncommercial-educational
- Pinpoint: 37 CFR 380.21(a); 91 FR (Mar. 10, 2026)
- Quote: "The Minimum Fee for each year of the royalty period is: (1) 2026: $800; (2) 2027: $850;"
- Checked: 2026-11-10

#### [M-0166] VERIFIED
- Claim: NSS V covers digital performances by new subscription services that provide transmissions to residential subscribers as part of a cable or satellite television bundle (2026-2030).
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 91 FR (Mar. 10, 2026), Background
- Quote: "new subscription services that provide transmissions to residential subscribers as part of a cable or satellite television bundle"
- Checked: 2026-11-10

#### [M-0165] VERIFIED
- Claim: NSS V (2026-2030): per-Subscriber monthly payment for Stand-Alone Contracts is the 2025 royalty rate of $0.0234 as adjusted by the annual royalty fee adjustment.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 37 CFR 383.3(a); 91 FR (Mar. 10, 2026)
- Quote: "equivalent to the 2025 royalty rate of $0.0234, as adjusted by the annual royalty fee adjustment"
- Checked: 2026-11-10

#### [M-0507] VERIFIED
- Claim: NSS V (2026-2030): per-Subscriber monthly payment for Bundled Contracts is the 2025 royalty rate of $0.0390 as adjusted by the annual royalty fee adjustment.
- Jurisdiction: US-federal
- Source: CRB, Determination of Rates and Terms for Digital Performance of Sound Recordings by New Subscription Services (NSS V), final rule (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04627 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04627.txt), source id crb-nss5-final
- Pinpoint: 37 CFR 383.3(a)(2)
- Quote: "equivalent to the 2025 royalty rate of $0.0390"
- Checked: 2026-11-10

#### [M-0178] VERIFIED
- Claim: Preexisting subscription services must deliver Reports of Use to the designated Collective within 45 days after the close of each month (37 CFR 370.3(b)).
- Jurisdiction: US-federal
- Source: 37 CFR Part 370 notice and recordkeeping requirements for statutory licenses (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370), source id cfr37-370
- Pinpoint: 37 CFR 370.3(b) (reports of use, preexisting subscription services)
- Quote: "Reports of Use shall be delivered on or before the forty-fifth day after the close of each month."
- Checked: 2026-11-10

#### [M-0305] VERIFIED
- Claim: The notice and reporting rules define a Collective as an organization designated under a statutory licence by determination of the Copyright Royalty Judges.
- Jurisdiction: US-federal
- Source: 37 CFR Part 370 notice and recordkeeping requirements for statutory licenses (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=370), source id cfr37-370
- Pinpoint: 37 CFR 370.1 (general definitions, Collective)
- Quote: "Collective is a collection and distribution organization that is designated under one or both of the statutory licenses by determination of the Copyright Royalty Judges"
- Checked: 2026-11-10

#### [M-0295] VERIFIED
- Claim: SoundExchange says it collects digital performance royalties from services such as Pandora, SiriusXM and iHeartRadio.
- Jurisdiction: regulator
- Source: SoundExchange: About (Section 114 statutory licence administration, who it collects for and pays) (https://www.soundexchange.com/about/), source id soundexchange-about
- Pinpoint: SoundExchange About page
- Quote: "seamlessly collects and distributes digital performance royalties from platforms like Pandora, SiriusXM, iHeartRadio"
- Checked: 2026-11-10

#### [M-0302] VERIFIED
- Claim: Statutory 114 receipts split 50 percent to the sound recording copyright owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(A)
- Quote: "50 percent of the receipts shall be paid to the copyright owner of the exclusive right under section 106(6) of this title to publicly perform a sound recording by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0303] VERIFIED
- Claim: Statutory 114 receipts pay 45 percent to the featured recording artists.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(D)
- Quote: "45 percent of the receipts shall be paid, on a per sound recording basis, to the recording artist or artists featured on such sound recording"
- Checked: 2026-11-10

#### [M-0117] VERIFIED
- Claim: The 112(a) ephemeral recording privilege excludes motion pictures and other audiovisual works.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(a)(1)
- Quote: "except in the case of a motion picture or other audiovisual work, it is not an infringement of copyright for a transmitting organization"
- Checked: 2026-11-10

#### [M-0116] VERIFIED
- Claim: 17 U.S.C. 112(e)(1) gives a transmitting organization entitled to transmit under 114(d)(1)(C)(iv) or a 114(f) statutory licence a statutory licence to make no more than 1 ephemeral phonorecord of the sound recording, if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 112 ephemeral recordings (https://www.law.cornell.edu/uscode/text/17/112), source id usc17-112
- Pinpoint: 17 U.S.C. 112(e)(1)
- Quote: "transmitting organization entitled to transmit to the public a performance of a sound recording under the limitation on exclusive rights specified by section 114(d)(1)(C)(iv) or under a statutory license in accordance with section 114(f) is entitled to a statutory license"
- Checked: 2026-11-10

#### [M-0480] VERIFIED
- Claim: H.R. 861 (American Music Fairness Act, bill not law) would give sound recordings a public performance right by audio transmission, reaching terrestrial radio; its new definition of audio transmission does not include the transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: H.R. 861 (119th), American Music Fairness Act of 2025, as introduced in House January 31, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119hr861ih/html/BILLS-119hr861ih.htm), source id hr861-amfa-text
- Pinpoint: H.R.861 sec. 2(a) and (c)(1)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0504] VERIFIED
- Claim: S. 326 (American Music Fairness Act of 2025) was introduced January 30, 2025 by Sen. Blackburn and referred to the Senate Judiciary Committee; H.R. 861 is the House companion.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 326 (119th) American Music Fairness Act (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s326.xml), source id s326-amfa-status
- Pinpoint: BILLSTATUS S.326
- Quote: "Sen. Blackburn, Marsha [R-TN]"
- Checked: 2026-11-10

#### [M-0182] UNVERIFIED (unverified)
- Claim: Analysis: Web VI rates saved so far are for broadcasters, public radio, noncommercial educational webcasters and EMF; they set no price for a commercial non-broadcaster, and are moot for video anyway.
- Jurisdiction: analysis
- Source: CRB, Web VI final rule, commercial broadcasters nonsubscription webcasting (2026-2030), 91 FR (Mar. 10, 2026), FR Doc. 2026-04632 (https://www.federalregister.gov/documents/full_text/text/2026/03/10/2026-04632.txt), source id crb-web6-final-commercial-broadcasters
- Pinpoint: 37 CFR 380.40
- Quote: "Commercial Broadcaster is a Commercial Webcaster, a material part of the business of which consists of owning and operating one or more terrestrial AM or FM broadcast radio stations licensed as such by the Federal Communications Commission."
- Checked: 2026-11-10

#### [M-0317] UNVERIFIED (unverified)
- Claim: Analysis: PRO licences cover the composition's public performance only. A tool that re-encodes the user's own video and audio for the user is not itself performing music to the public (inference), so its PRO exposure turns on public distribution, not on the private rendering.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

## M07 Sync and master use licensing for video
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Does the MLC blanket licence or any statutory licence cover songs in a mix posted with video; What licences does a user need to put a commercial song in a video mix; Does a TikTok or Meta sound licence carry over to another platform; Does a platform processing a user's audio need a music licence

### Bottom line
- US federal: no statutory licence covers a song placed in a video. Sections 114 and 115 stop at audio, so a video with music needs two direct licences: sync from the composition owner (publisher) and master use from the recording owner (label or distributor) [M-0342, M-0112, M-0179].
- The MLC blanket licence is a mechanical licence for audio deliveries. It does not reach sounds accompanying an audiovisual work [M-0122, M-0340].
- Platform sound collections are often tied to one platform. Do not assume any of them covers another platform [M-0386].
- Nothing here says any song is cleared. Name the missing licence and who grants it.

### Rules
#### The two copyrights (US federal)
- A recorded song carries two copyrights: the musical work (composition, usually publisher or PRO side) and the sound recording (master, usually label or distributor) (analysis).
- Both carry the reproduction right [M-0108, M-0334]. Musical works also carry public performance [M-0106, M-0335]. Sound recordings carry public performance only by digital audio transmission [M-0107, M-0336].
- A sound recording has no general public performance right under 106(4) [M-0109, M-0296]. Its reproduction right covers only duplication that recaptures the actual sounds [M-0110].
- A sound alike made as an independent fixation does not infringe the master. The composition is a separate copyright, so (analysis) a sound alike still needs a composition licence [M-0111].

#### Why 115 does not cover video (statute)
- Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing [M-0339].
- The compulsory licence is limited to phonorecords whose primary purpose is distribution to the public for private use [M-0120]. Section 101 excludes sounds accompanying an audiovisual work from "phonorecords", so (analysis) 115 does not license music in video [M-0179].
- A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work [M-0340, M-0124]. Sync and master use licences are therefore needed (analysis) [M-0342].
- 1976 House Report (legislative history, not binding): the compulsory licence does not reach sound tracks accompanying a motion picture or other audiovisual work [M-0121].
- The MLC administers blanket licences, notices of licence and usage reports, and collects and distributes royalties [M-0128, M-0129]. The blanket covers digital phonorecord deliveries of musical works for covered activities [M-0122, M-0123, M-0125]. It includes incidental reproductions reasonable and necessary for those activities [M-0126]. That is audio delivery, not video.
- The Copyright Office (2015 report, regulator view, not binding) said consumer audiovisual (sync) uses should stay in the free market, with no compulsory licence [M-0140]. The 2018 MMA did not add audiovisual [M-0140, M-0120]. Sync is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content [M-0141].

#### Why 114 does not cover video (statute)
- A "digital audio transmission" does not include the transmission of any audiovisual work [M-0112, M-0297]. The 114(d)(2) licence therefore does not extend to a video with music [M-0112].
- The licence reaches subscription transmissions, eligible nonsubscription transmissions and preexisting satellite DARS, and the transmission must not be part of an interactive service [M-0114, M-0115, M-0298]. An interactive service lets a member of the public receive on request a transmission of a particular sound recording [M-0113, M-0299]. Eligible nonsubscription means noninteractive digital audio programming [M-0300].
- (analysis) The 114 licence does not cover short videos on a user upload platform, because they are audiovisual [M-0312, M-0180]. If such a platform were an interactive service, it would still need a licence for the public performance of each musical work in the recording [M-0301, M-0313].
- Rate standard and period for the statutory licence are willing buyer and willing seller, set for five year periods [M-0167, M-0168]. Receipts go 50 percent to the recording owner, 45 percent to featured artists, via a designated nonprofit collective [M-0302, M-0303, M-0304]. This is background only. It does not license video.

#### Who grants sync and master use (industry practice)
- Publishers act as owner or administrator of compositions and earn mechanical, performance, sync and other income [M-0079]. Sync is use of the composition combined with visual images [M-0081].
- Each sync licence is generally negotiated with the prospective licensee, and publishers pay songwriters or heirs a contractual share [M-0080, M-0100]. These are company statements in SEC filings, not law.
- Independent publishers license for film, television, advertising and digital platforms including social media and background music [M-0102].
- Master side: labels license recordings under multi year, worldwide, non automatic deals with audit rights [M-0083, M-0084]. Streaming services also license independents and aggregators [M-0085].
- Even a streaming service holding audio licences needed separate direct licences for audiovisual rights: Spotify says it recently signed direct US publisher deals for audiovisual and other rights [M-0087]. Audio-only US mechanicals run through 115 and the blanket licence [M-0086].
- Public performance of compositions comes through PROs under blanket licences [M-0088]. A sync licence is not a performance licence, and PRO coverage is separate [M-0183].
- Chain of title can be messy: label deals often treat artist services as work made for hire, with termination risk if a court disagreed [M-0052, M-0053, M-0099]. Artist deals are recoupable, option based, sometimes 360 [M-0075, M-0076, M-0077, M-0078].
- Licensors in general include labels, aggregators, artists, publishers and PROs, and losing a licence is a stated business risk for services [M-0089].

#### Libraries and platform sound collections (platform terms)
Library and platform terms, as captured 2026-11-10. Terms change, so re-check before relying.
- Epidemic Sound standard licence: personal use only, so corporate or third party content needs other licences [M-0404]; no sublicensing to third parties [M-0405].
- Musicbed: licence is per single audiovisual Project, and excludes public performance where a PRO licence is available [M-0408].
- Artlist: the saved text is site terms only; the music licence itself is not saved, so nothing is confirmed [M-0410].
- YouTube Audio Library: described as copyright safe and not claimed through Content ID [M-0411]. Creative Commons tracks need credit in the description [M-0412]. YouTube disclaims responsibility for music from other libraries [M-0413].
- TikTok Commercial Music Library (CML) User Terms: for Commercial Uses, Commercial Sounds may be posted only within TikTok [M-0382]. Posting on third party platforms needs separate rights holder licences [M-0383]. Sounds may not be used with content violating TikTok's terms or Community Guidelines [M-0384]. (analysis) This gives no rights for use on another platform [M-0386].
- Meta Sound Collection (2022 terms, 2023 archive copy): limited to use on Meta products only [M-0385]. Current page not obtained.
- Content ID is a matching system, not a licence. It scans uploads against owner files with outcomes block, monetize or track [M-0378]. It is for owners with exclusive rights to a substantial body of frequently uploaded material [M-0379].

### Gotchas
- "It is on the MLC" or "it is licensed for streaming" does not mean it is licensed for video. Mechanical audio is not sync [M-0340, M-0342].
- Library licences are often per project, per licensee and non sublicensable. A creator licence may not pass to a platform or to a third party buyer [M-0404, M-0405, M-0408].
- Platform sound licences are platform bound. TikTok commercial sounds stay in TikTok [M-0382, M-0383].
- Content ID matching is not a clearance [M-0378].
- Artlist music licence, TikTok Community Guidelines and the Meta Sound Collection current terms are needs source gaps. Meta's saved text is a 2023 archive [M-0385, M-0386, M-0410].
- Statutory text is stable. Library and platform terms are volatile: they were captured 2026-11-10 and can change without notice [M-0386, M-0408, M-0410].
- Filings (WMG, Spotify, Reservoir) are company statements about practice. They show how deals work, not what the law requires [M-0080, M-0087].

### Open questions for counsel
1. US federal: does placing a creator video re-encoded by a separate tool on a hosting platform create any separate licence need for the tool, or does exposure sit with the creator and the host [M-0317] (unverified)?
2. US federal: what direct licence structure (sync plus master use, or a blanket publisher and label deal) fits a short video app with creator uploaded music, and will majors license that use at all?
3. US federal: do live streams with music need a different set of composition and master licences than recorded uploads?
4. What notice and takedown posture should a platform take for music in creator videos, given licences are missing (see M08)?

### Sources
- usc17-106: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106)
- usc17-114: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-115: 17 U.S.C. 115 compulsory licence for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115)
- co-music-marketplace-2015: U.S. Copyright Office, Copyright and the Music Marketplace (Feb 2015)
- sec-wmg-10k-fy2025: Warner Music Group Form 10-K FY2025
- sec-spotify-20f-fy2025: Spotify Form 20-F FY2025
- sec-reservoir-10k: Reservoir Media 10-K FY2026
- terms-youtube-contentid; terms-youtube-audio-library; terms-tiktok-cml-user-terms; terms-meta-sound-collection; terms-epidemic-sound; terms-musicbed; terms-pond5-music; terms-artlist (https://support.google.com/youtube/answer/2797370?hl=en, https://support.google.com/youtube/answer/3376882, https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en, https://web.archive.org/web/20230818125438id_/https://www.facebook.com/sound/collection/terms, https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf, https://www.musicbed.com/license-terms, https://web.archive.org/web/2026/https://www.pond5.com/legal/license, https://help-center.artlist.io/help-center/privacy-terms/terms-of-use)

### Claims cited in M07
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0342] VERIFIED
- Claim: Analysis: the 17 U.S.C. 115 statutory mechanical licence does not reach music placed in a video, because a digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work; sync and master use therefore need direct licences (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0179] VERIFIED
- Claim: Analysis: a 115 compulsory licence, including the MLC blanket licence under 115(d), is limited to phonorecords made mainly for distribution to the public for private use, and 101 excludes sounds accompanying audiovisual works from "phonorecords", so 115 does not license putting a song into a user video; sync stays a direct licence.
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0340] VERIFIED
- Claim: A digital phonorecord delivery under 115 does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work, so such transmissions are outside the 115 DPD licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "A digital phonorecord delivery does not include the digital transmission of sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0386] VERIFIED
- Claim: Analysis: TikTok Commercial Music Library terms for Commercial Uses permit posting Commercial Sounds only within TikTok and grant no rights for uses outside TikTok, so that library gives no rights usable on other platforms; Meta Sound Collection is similarly limited to Meta products (2023 archive copy); YouTube Audio Library not shown to be platform-tied.
- Jurisdiction: analysis
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: TikTok CML User Terms, Commercial Uses para beginning "You may only post or share"
- Quote: "You may only post or share videos that include Commercial Sounds within TikTok and by using the sharing features made available to TikTok users"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0334] VERIFIED
- Claim: The copyright owner has the exclusive right (subject to sections 107 through 122) to reproduce the copyrighted work in copies or phonorecords.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0335] VERIFIED
- Claim: Public performance of a musical work is an exclusive right of the musical work owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0336] VERIFIED
- Claim: For sound recordings the 106(6) public performance right is limited to performance by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0109] VERIFIED
- Claim: A sound recording has no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)."
- Checked: 2026-11-10

#### [M-0296] VERIFIED
- Claim: Sound recording owners have only the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0120] VERIFIED
- Claim: The 115 compulsory licence is limited to phonorecords whose primary purpose is distribution to the public for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0124] VERIFIED
- Claim: A digital phonorecord delivery is a delivery of a phonorecord by digital transmission of a sound recording; it includes an interactive stream.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(10)
- Quote: "includes a permanent download, a limited download, or an interactive stream."
- Checked: 2026-11-10

#### [M-0121] VERIFIED
- Claim: 1976 House Report: the 115 compulsory licence does not reach sound tracks accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115, H.R. Rep. 94-1476 note on 115(a)(1)
- Quote: "(including disks and audio tapes but not the sound tracks or other sound records accompanying a motion picture or other audiovisual work)"
- Checked: 2026-11-10

#### [M-0128] VERIFIED
- Claim: The MLC administers blanket licences, including notices of license and usage reports.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(I)
- Quote: "Offer and administer blanket licenses, including receipt of notices of license and reports of usage from digital music providers."
- Checked: 2026-11-10

#### [M-0129] VERIFIED
- Claim: The MLC collects and distributes royalties from digital music providers for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(3)(C)(i)(II)
- Quote: "Collect and distribute royalties from digital music providers for covered activities."
- Checked: 2026-11-10

#### [M-0123] VERIFIED
- Claim: Covered activity means making a digital phonorecord delivery of a musical work (permanent download, limited download, interactive stream) that qualifies for a compulsory licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(e)(7)
- Quote: "The term covered activity means the activity of making a digital phonorecord delivery of a musical work, including in the form of a permanent download, limited download, or interactive stream"
- Checked: 2026-11-10

#### [M-0125] VERIFIED
- Claim: The blanket licence covers all musical works (or shares) available for compulsory licensing for covered activities, except as provided in subparagraph (C) (voluntary licences and individual download authority).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(i)
- Quote: "covers all musical works (or shares of such works) available for compulsory licensing under this section for purposes of engaging in covered activities, except as provided in subparagraph (C);"
- Checked: 2026-11-10

#### [M-0126] VERIFIED
- Claim: The blanket licence includes server, intermediate, archival and incidental reproductions reasonable and necessary for covered activities.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(ii)
- Quote: "includes the making and distribution of server, intermediate, archival, and incidental reproductions of musical works that are reasonable and necessary for the digital music provider to engage in covered activities"
- Checked: 2026-11-10

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0141] VERIFIED
- Claim: The sync right is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), ch. 1 background
- Quote: "the right to synchronize musical works to visual content (e.g., in a music video). The synchronization (or synch right) is a species of the reproduction right and may also implicate the derivative work right."
- Checked: 2026-11-10

#### [M-0297] VERIFIED
- Claim: A digital audio transmission is a digital transmission that embodies a sound recording and does not include transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "A digital audio transmission is a digital transmission as defined in section 101, that embodies the transmission of a sound recording. This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0114] VERIFIED
- Claim: 17 U.S.C. 114(d)(2) subjects subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite digital audio radio service transmissions to statutory licensing if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)
- Quote: "a subscription digital audio transmission not exempt under paragraph (1), an eligible nonsubscription transmission, or a transmission not exempt under paragraph (1) that is made by a preexisting satellite digital audio radio service shall be subject to statutory licensing"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0298] VERIFIED
- Claim: The 114 statutory licence reaches subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite DARS transmissions, and the transmission must not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service"
- Checked: 2026-11-10

#### [M-0113] VERIFIED
- Claim: Under 17 U.S.C. 114(j)(7), an interactive service is one that lets a member of the public receive on request a transmission of a particular sound recording selected by or for the recipient.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0299] VERIFIED
- Claim: An interactive service is one that lets a member of the public receive a program made for the recipient or, on request, a particular sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0300] VERIFIED
- Claim: An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission, not exempt under (d)(1), made as part of a service providing audio programming consisting in whole or in part of performances of sound recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(6)
- Quote: "An eligible nonsubscription transmission is a noninteractive nonsubscription digital audio transmission not exempt under subsection (d)(1) that is made as part of a service that provides audio programming consisting, in whole or in part, of performances of sound recordings"
- Checked: 2026-11-10

#### [M-0312] VERIFIED
- Claim: Analysis: the 17 U.S.C. 114 statutory licence does not cover short videos on a user upload platform because a "digital audio transmission" under 114(j)(5) does not include the transmission of any audiovisual work.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0180] VERIFIED
- Claim: Analysis: the 114(d)(2) statutory licence covers digital audio transmissions, which exclude transmission of any audiovisual work, and requires the transmission not be part of an interactive service, so it cannot cover a short-video app.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0313] VERIFIED
- Claim: Analysis: if a platform qualified as an interactive service, 114(d)(3)(C) would still require a licence for the public performance of each musical work in the sound recording, which may come from a performing rights society or the copyright owner.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0167] VERIFIED
- Claim: The Judges' standard for 114(d)(2) rates is the rates a willing buyer and willing seller would negotiate in the marketplace.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(B)
- Quote: "The Copyright Royalty Judges shall establish rates and terms that most clearly represent the rates and terms that would have been negotiated in the marketplace between a willing buyer and a willing seller."
- Checked: 2026-11-10

#### [M-0168] VERIFIED
- Claim: 114(d)(2) rates and terms set by the Judges are for a 5-year period (or other period agreed) and bind all copyright owners of sound recordings and entities performing sound recordings affected.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(f)(1)(A)-(B)
- Quote: "be binding on all copyright owners of sound recordings and entities performing sound recordings affected by this paragraph during the 5-year period specified in subparagraph (A)"
- Checked: 2026-11-10

#### [M-0302] VERIFIED
- Claim: Statutory 114 receipts split 50 percent to the sound recording copyright owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(A)
- Quote: "50 percent of the receipts shall be paid to the copyright owner of the exclusive right under section 106(6) of this title to publicly perform a sound recording by means of a digital audio transmission"
- Checked: 2026-11-10

#### [M-0303] VERIFIED
- Claim: Statutory 114 receipts pay 45 percent to the featured recording artists.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)(D)
- Quote: "45 percent of the receipts shall be paid, on a per sound recording basis, to the recording artist or artists featured on such sound recording"
- Checked: 2026-11-10

#### [M-0304] VERIFIED
- Claim: A nonprofit collective designated by the Copyright Royalty Judges distributes statutory 114 receipts.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(g)(2)
- Quote: "a nonprofit collective designated by the Copyright Royalty Judges to distribute receipts from the licensing of transmissions in accordance with subsection (f) shall distribute such receipts as follows"
- Checked: 2026-11-10

#### [M-0079] VERIFIED
- Claim: WMG's publishing arm acts as copyright owner and/or administrator of compositions and earns mechanical, performance, synchronization, digital and other income.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 7, Music Publishing
- Quote: "Music Publishing acts as a copyright owner and/or administrator of the musical compositions and generates revenues related to the exploitation of musical compositions (as opposed to recorded music). Music publishers generally receive royalties from the use of the musical compositions"
- Checked: 2026-11-10

#### [M-0081] VERIFIED
- Claim: WMG lists synchronization as use of the musical composition in combination with visual images.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Synchronization: use of the musical composition in combination with visual images •Films or television"
- Checked: 2026-11-10

#### [M-0080] VERIFIED
- Claim: WMG says each synchronization licence is generally subject to negotiation with a prospective licensee, and publishers pay a contractually required share of sync income to songwriters or heirs.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1, Music Publishing
- Quote: "Throughout the world, each synchronization license is generally subject to negotiation with a prospective licensee and, by contract, music publishers"
- Checked: 2026-11-10

#### [M-0100] VERIFIED
- Claim: Reservoir says music publishers pay a contractually required percentage of synchronization income to songwriters or heirs and to any co-publishers, and that synchronization licences are negotiated with the prospective licensee.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Music Publishing
- Quote: "music publishers pay a contractually required percentage of synchronization income to the songwriters or their heirs and to any co-publishers. Performance royalties generate revenue through"
- Checked: 2026-11-10

#### [M-0102] VERIFIED
- Claim: Reservoir's synchronization team licenses its music for film, television and advertising, and its digital licensing covers platforms from social media and background music to fitness; synchronization was 13% of revenue in the year.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Synchronization
- Quote: "Digital licensing covers platforms that extend from social media, background music, and home fitness to music education and music therapy."
- Checked: 2026-11-10

#### [M-0083] VERIFIED
- Claim: Spotify takes sound recording and audiovisual licences from the three major label groups and Merlin; the agreements require royalties, marketing commitments and operating prescriptions, are multi-year, and permit label audit and termination.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Content License Agreements
- Quote: "We have license agreements for sound recordings and audiovisual works with record label affiliates of the three largest music companies--Universal Music Group, Sony Music Entertainment, and Warner Music Group--as well as Merlin, which represents the digital rights on"
- Checked: 2026-11-10

#### [M-0084] VERIFIED
- Claim: Spotify says label agreements generally run multi-year, are not automatically renewable, apply worldwide, and let the label terminate for non-payment, material breach or change of control.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "Generally, these license agreements have a multi-year duration, are not automatically renewable, and apply worldwide. The license agreements also allow for the record label to terminate the agreement in certain"
- Checked: 2026-11-10

#### [M-0085] VERIFIED
- Claim: Spotify also has direct licences with independent labels and aggregators such as CD Baby, DistroKid and TuneCore, with financial and data reporting obligations and audit rights.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "We also have direct license agreements with hundreds of independent labels, as well as companies known as “aggregators” (for example, CDBaby, Distrokid, and TuneCore). The majority of these agreements have"
- Checked: 2026-11-10

#### [M-0087] VERIFIED
- Claim: Spotify says it recently entered licences directly with certain US publishers for audiovisual and other rights.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "We have also recently entered into licenses directly with certain publishers for audiovisual and other rights in the United States. Most of"
- Checked: 2026-11-10

#### [M-0086] VERIFIED
- Claim: For compositions Spotify generally obtains mechanical, public performance and lyric rights; for audio-only use in the US the mechanical rights run through the Section 115 compulsory licence, with a blanket licence administered by the MLC since January 2021.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Musical Composition License Agreements
- Quote: "With respect to musical compositions, we generally obtain licenses for mechanical rights, public performance rights, and lyric rights. With respect to mechanical rights for audio-only"
- Checked: 2026-11-10

#### [M-0088] VERIFIED
- Claim: In the US public performance rights for compositions come through PROs (ASCAP, BMI, GMR, SESAC) under blanket licences, with usage reporting duties and one to four year terms.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "In the United States, public performance rights are generally obtained through intermediaries known as performing rights organizations (“PROs”), which negotiate blanket licenses with copyright users for the public performance of"
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0052] VERIFIED
- Claim: Warner Music Group says virtually all its agreements with recording artists since the Sound Recordings Act of 1971 provide that the artists render services under a work-made-for-hire relationship.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1A, termination risk factor
- Quote: "virtually all of our agreements with recording artists provide that such recording artists render services under a work-made-for-hire relationship. A termination right exists under the U.S. Copyright Act for U.S."
- Checked: 2026-11-10

#### [M-0053] VERIFIED
- Claim: WMG warns that if any of its sound recordings were found not to be works made for hire, artists or heirs could terminate the US rights, generally in a five-year window starting 35 years after release for post-1977 grants.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1A
- Quote: "If any of our commercially available sound recordings were determined not to be “works made for hire,” then the recording artists (or their heirs) could have the right to terminate the U.S. federal copyright rights they granted to"
- Checked: 2026-11-10

#### [M-0099] VERIFIED
- Claim: Reservoir Media (independent publisher and label, FY ended 2026-03-31) says virtually all its recording artist agreements provide that the artists render services under a work-made-for-hire relationship, and a termination right exists for compositions not made for hire.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1A, termination risk factor
- Quote: "virtually all of our agreements with recording artists provide that such recording artists render services under a work-made-for-hire relationship. A termination right exists under the U.S. Copyright Act for U.S."
- Checked: 2026-11-10

#### [M-0075] VERIFIED
- Claim: WMG artist contracts: royalties based on sales and other uses, advances recoupable from future royalties, and recording and production costs typically recoupable from royalties.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1, recording artist agreements
- Quote: "recording artists receive royalties based on sales and other uses of their music. We customarily provide upfront payments to recording artists called advances, which are recoupable by us from future royalties."
- Checked: 2026-11-10

#### [M-0076] VERIFIED
- Claim: WMG says its typical new-artist contract requires delivery of an EP or album and gives the label a series of options for later albums.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Our typical contract for a new recording artist requires the delivery of an extended play record known as an EP or an album and provides us with a series of options to acquire subsequent albums"
- Checked: 2026-11-10

#### [M-0077] VERIFIED
- Claim: WMG says many of its recording contracts are expanded-rights (360) deals sharing touring, merchandising, sponsorship, fan club or other ancillary revenues.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Many of the recording contracts we enter into are expanded-rights deals, in which we share in the touring, merchandising, sponsorship, fan club or other ancillary music revenues associated with those"
- Checked: 2026-11-10

#### [M-0078] VERIFIED
- Claim: WMG describes expanded-rights deals as services and participation in activities beyond recorded music such as touring, merchandising and sponsorships.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Under these agreements, we provide services to and participate in recording artists’ activities outside the traditional recorded music business such as touring, merchandising and sponsorships. We have built and acquired"
- Checked: 2026-11-10

#### [M-0089] VERIFIED
- Claim: Spotify's licensors in general include record labels, aggregators, artists, music publishers and PROs, and failure to obtain or keep those licences is a stated business risk.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 3D risk factors
- Quote: "To secure the rights to stream content, we enter into license agreements to obtain licenses from rights holders, such as record labels, aggregators, artists, music publishers, performing rights organizations, collecting"
- Checked: 2026-11-10

#### [M-0404] VERIFIED
- Claim: Epidemic Sound personal licence is for the licensee's own personal use; content for a corporate channel or on behalf of a third party needs other licences.
- Jurisdiction: platform-terms
- Source: Epidemic Sound licence terms (https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf), source id terms-epidemic-sound
- Pinpoint: License, opening grant
- Quote: "if you are creating content for a corporate channel (meaning a channel owned and/or operated by a business) or creating content on behalf of a third party, you can find other appropriate licenses"
- Checked: 2026-11-10

#### [M-0405] VERIFIED
- Claim: Epidemic Sound: the licence does not allow sublicensing the Production to third parties.
- Jurisdiction: platform-terms
- Source: Epidemic Sound licence terms (https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf), source id terms-epidemic-sound
- Pinpoint: License, 'Where can I upload my Production?'
- Quote: "The rights granted herein do not include any right to license or sublicense to any third party the right to exploit the Production"
- Checked: 2026-11-10

#### [M-0408] VERIFIED
- Claim: Musicbed licence is per single audiovisual Project and does not include the right to publicly perform where a PRO licence is available.
- Jurisdiction: platform-terms
- Source: Musicbed licence terms (https://www.musicbed.com/license-terms), source id terms-musicbed
- Pinpoint: License Terms, paras 1 and 1(xii)
- Quote: "except to the extent that the Licensed Content is not available to license through a so-called “performance rights organization” (each, a “PRO”), the Licensed Rights do not include the right to publicly perform the Licensed Content"
- Checked: 2026-11-10

#### [M-0410] VERIFIED
- Claim: Artlist: the saved terms are the site terms of use, and the music licence terms are not in the saved text.
- Jurisdiction: platform-terms
- Source: Artlist licence terms (https://help-center.artlist.io/help-center/privacy-terms/terms-of-use), source id terms-artlist
- Pinpoint: Site terms (whole)
- Quote: "you can’t use the Site and/or the Tools in any manner which is illegal, contrary to court orders and/or which was forbidden by the provisions of any law"
- Checked: 2026-11-10

#### [M-0411] VERIFIED
- Claim: YouTube Audio Library music is described as copyright-safe and not claimed through Content ID.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Keep in mind'
- Quote: "Copyright-safe music and sound effects downloaded from the Audio Library won't be claimed by a rights holder through the Content ID system"
- Checked: 2026-11-10

#### [M-0412] VERIFIED
- Claim: YouTube Audio Library: tracks under a Creative Commons licence require crediting the artist in the video description.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Give attribution'
- Quote: "If you’re using a track with a Creative Commons license, you must credit the artist in your video’s description"
- Checked: 2026-11-10

#### [M-0413] VERIFIED
- Claim: YouTube Audio Library: YouTube disclaims responsibility for issues with music from other libraries.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Keep in mind'
- Quote: "YouTube is not responsible for issues that arise from “royalty-free” music and sound effects from YouTube channels or other music libraries"
- Checked: 2026-11-10

#### [M-0382] VERIFIED
- Claim: TikTok CML User Terms: a user engaging in Commercial Uses may post videos with Commercial Sounds only within TikTok; use elsewhere needs separate rights-holder licences.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, para 'You may only post or share'
- Quote: "Commercial Uses outside of TikTok are not permitted and no rights are granted by TikTok for such uses"
- Checked: 2026-11-10

#### [M-0383] VERIFIED
- Claim: TikTok CML User Terms: for Commercial Uses, posting videos with Commercial Sounds on third-party digital platforms is an outside use needing separate rights-holder licences.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, para 'You may only post or share'
- Quote: "These types of outside uses include, but are not limited to, posting videos on third party digital platforms"
- Checked: 2026-11-10

#### [M-0384] VERIFIED
- Claim: TikTok CML: sounds may not be used in connection with content that violates TikTok's Terms or Community Guidelines.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, illegal use para
- Quote: "or in connection with any content that is illegal or otherwise violates TikTok’s “Terms of Service” (including any associated “Community Guidelines”)"
- Checked: 2026-11-10

#### [M-0385] VERIFIED
- Claim: Meta Sound Collection (2022 terms, 2023 archive): licence is limited to use on Meta products only.
- Jurisdiction: platform-terms
- Source: Meta Sound Collection Terms (web.archive.org copy of facebook.com/sound/collection/terms captured 2023-08-18; live page is JS-only) (https://web.archive.org/web/20230818125438id_/https://www.facebook.com/sound/collection/terms), source id terms-meta-sound-collection
- Pinpoint: Term A
- Quote: "content you create, upload, and distribute on the Meta Company Products (including through links to the Meta Company Products embedded in third party sites) only"
- Checked: 2026-11-10

#### [M-0378] VERIFIED
- Claim: YouTube Content ID scans each upload against owner-submitted files; a match yields block, monetize or track.
- Jurisdiction: platform-terms
- Source: YouTube Help: How Content ID works (https://support.google.com/youtube/answer/2797370?hl=en), source id terms-youtube-contentid
- Pinpoint: Help page 'What does Content ID do?'
- Quote: "If Content ID finds a match, the matching video will get a Content ID claim"
- Checked: 2026-11-10

#### [M-0379] VERIFIED
- Claim: Content ID is limited to owners with exclusive rights to a substantial body of frequently uploaded original material.
- Jurisdiction: platform-terms
- Source: YouTube Help: How Content ID works (https://support.google.com/youtube/answer/2797370?hl=en), source id terms-youtube-contentid
- Pinpoint: Help page 'Who uses Content ID?'
- Quote: "they must own exclusive rights to a substantial body of original material that is frequently uploaded to YouTube"
- Checked: 2026-11-10

#### [M-0317] UNVERIFIED (unverified)
- Claim: Analysis: PRO licences cover the composition's public performance only. A tool that re-encodes the user's own video and audio for the user is not itself performing music to the public (inference), so its PRO exposure turns on public distribution, not on the private rendering.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "do not include any right of performance under section 106(4)"
- Checked: 2026-11-10
