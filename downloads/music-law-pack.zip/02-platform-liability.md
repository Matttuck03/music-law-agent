# Music law knowledge pack: Platform liability
- File: 02-platform-liability.md, part of the music law knowledge pack (remix edition).
- Contains: M08 DMCA 512 safe harbor for a platform that hosts user mixes; M09 Secondary liability after Cox; M10 Content ID systems and platform sound libraries. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-10.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M08 DMCA 512 safe harbor for a platform that hosts user mixes
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Does the safe harbor protect a platform when users upload mixes of commercial songs; What must a platform do to qualify for 512(c); Does a platform need a designated agent and when does it expire; What is a repeat infringer policy and what must it say; What happens after a counter notice; Does processing or re-encoding user audio change the answer

### Bottom line
US federal law: 17 U.S.C. 512(c) can shield a platform from copyright damages for user uploaded videos that carry someone else's song, but only if the platform meets every condition [M-0343, M-0344, M-0345, M-0346, M-0347, M-0348, M-0357]. The safe harbor can apply to claims on both the composition and the master copyright (analysis), because it limits liability for the infringement claim itself, not a licence. It is not a licence and not a defence for the platform's own conduct. Section 230 does not add anything for copyright [M-0401, M-0402].
- Core conditions: no actual or red flag knowledge, prompt removal, no direct financial benefit with the right and ability to control, a designated agent, and a real repeat infringer policy [M-0344, M-0345, M-0346, M-0347, M-0349, M-0357].

### Rules
#### Statute (17 U.S.C. 512)
- 512(c) covers infringement by reason of storage at the direction of a user on the provider's system [M-0343].
- Knowledge: the provider must lack actual knowledge of infringement [M-0344]. Without actual knowledge it must not be aware of facts or circumstances making infringement apparent, called red flag knowledge [M-0345].
- On gaining knowledge or awareness the provider must act expeditiously to remove or disable access [M-0346].
- Financial benefit: the provider must not receive a financial benefit directly attributable to the infringement where it has the right and ability to control it [M-0347].
- Notice: on a compliant notice the provider must respond expeditiously to remove or disable the claimed material [M-0348].
- Designated agent: the safe harbor applies only if an agent is designated, made available on the service including its website, and provided to the Copyright Office [M-0349].
- Notice contents: an effective notice needs the signature of a person authorized to act for the owner of an exclusive right [M-0350]. It also needs a statement under penalty of perjury that the sender is authorized to act for the owner [M-0351]. The perjury statement attaches to authority, not to the claim that the use infringes [M-0351].
- Repeat infringers: the provider must have adopted, reasonably implemented and told subscribers about a policy to terminate repeat infringers in appropriate circumstances. The limitations apply only if it did [M-0357].
- Monitoring: the safe harbor is not conditioned on monitoring the service or seeking out infringement, except as consistent with a standard technical measure [M-0358]. This does not switch off red flag knowledge (analysis, from the row note).
- Counter notice: a counter notification needs a statement under penalty of perjury that the user believes the material was removed by mistake or misidentification [M-0356]. The provider restores the material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells the agent it has gone to court [M-0355].
- Misrepresentation: a person who knowingly materially misrepresents that material is infringing is liable for damages, costs and attorneys' fees [M-0359].

#### Agent designation (regulation, 37 CFR 201.38)
- The designation gives the provider's full legal name and physical street address [M-0352]. Parent and subsidiary are separate entities and need separate designations [M-0353].
- A designation expires three years after registration unless renewed by amending or resubmitting it [M-0354]. The source is a saved eCFR copy dated 2026-10-26; check the live eCFR before relying on it [M-0352].

#### Court decisions on knowledge and control
- Viacom v. YouTube (2d Cir. 2012): the knowledge conditions mean knowledge or awareness of specific infringing activity [M-0362]. Right and ability to control needs something more than the ability to remove or block access [M-0363]. Willful blindness can apply in the 512(c) knowledge analysis [M-0364].
- Capitol v. Vimeo (2d Cir. 2016): an employee viewing a video with a recognizable copyrighted song does not alone prove red flag knowledge [M-0365]. The test is an ordinary person without specialized music or copyright knowledge [M-0366].
- UMG v. Shelter, the Veoh case (9th Cir. 2013): the label skipped the notice protocol, which stripped it of the most powerful evidence of knowledge [M-0367].
- Ventura v. Motherless (9th Cir. 2018), a UGC site: summary judgment for the site on 512(c) was affirmed [M-0370]. Apparent knowledge and red flag are used interchangeably, and infringement must be obvious to a reasonable person [M-0371]. The site's repeat infringer handling was informal, and the court still found the safe harbor. Do not copy that as a model [M-0372]. No holding on music (row note).
- Mavrix v. LiveJournal (9th Cir. 2017): common law agency decides whether moderators' acts count as the site's own, which can undercut "storage at the direction of a user" [M-0368]. Fact disputes about volunteer moderators as agents led to reversal of summary judgment for the site [M-0369].
- Lenz v. Universal (9th Cir. 2016, amended): a rightsholder must consider fair use before sending a takedown or risk 512(f) damages [M-0360]. The test is subjective good faith [M-0361].
- Fourth Circuit reading of "repeat infringer" as repeat alleged infringer is described in the Copyright Office report [M-0376]. Cox v. Sony (U.S. 2026) addressed contributory liability, not the 512(i) reading (row note on M-0376). Contributory liability now needs inducement or a service tailored to infringement [M-0001, M-0252]. This sits outside the safe harbor and is covered in card M09.

#### Policy view (regulator report, not law)
- The Copyright Office 2020 report recommends no wholesale change to 512, only fine tuning [M-0373]. It says courts' readings of the knowledge requirements may be narrower than Congress intended [M-0374]. It says willful blindness needs deliberate avoidance of specific infringements [M-0375]. It says notice and staydown needs more study [M-0377].

### Gotchas
- 512 is not a licence. A takedown or a counter notice does not clear a song, and winning on safe harbor does not mean the music was licensed.
- "The notice was sloppy" is not a reason to ignore it. Missing signature or authority makes a notice defective, but do not just ignore it. Take it to counsel; needs source for 512(c)(3)(B) [M-0350, M-0351].
- Sending takedowns carelessly is risky for the sender too: knowing misrepresentation carries damages, and Lenz requires fair use consideration [M-0359, M-0360]. Takedown notices a platform sends itself need counsel review.
- Agent designations lapse after three years. A lapsed designation can cost the safe harbor [M-0349, M-0354].
- The safe harbor is not conditioned on monitoring [M-0358], but knowledge, red flags and willful blindness can still defeat it [M-0345, M-0364].
- Informal repeat infringer handling surviving in Ventura is not a safe rule [M-0372]. The Copyright Office noted a Fourth Circuit reading of repeat alleged infringer [M-0376].
- Blurring, muting or re-encoding audio is not a licence and does not erase prior infringement.
- Currency (as of 2026-11-10): the 37 CFR 201.38 text is a saved eCFR copy dated 2026-10-26 [M-0352]. The Copyright Office report is a report, not law [M-0373]. Cox v. Sony was decided 2026-03-25 and is limited to contributory liability [M-0001, M-0252]. Vicarious liability was not decided [M-0252].
- Contested gloss: the "right and ability to control" case law is not fully covered by the ledger [M-0347].

### Open questions for counsel
- US federal: does 512(c) protect a platform's live streams where music is streamed in real time, or only stored uploads?
- US federal: does a separate re-encoding service's processing of user audio, on device or on a server, create its own reproduction outside 512(c), and does that service need its own agent designation?
- Ninth Circuit: given Mavrix, how should a platform structure moderation and featuring so staff acts are not treated as the site's own?
- US federal: what repeat infringer policy text, strike count and reinstatement rules should a platform adopt, given the Fourth Circuit reading of "repeat" [M-0376]?
- US federal: after Cox v. Sony, what does a platform's exposure look like if a song is flagged and it keeps promoting the clip?
- Needs source: Grande remand outcome and any 2026 512 decisions are not in the ledger. No row addresses live streaming under 512 or fingerprint filtering as a standard technical measure.

### Sources
- usc17-512: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512)
- usc47-230: 47 U.S.C. 230 (https://www.law.cornell.edu/uscode/text/47/230)
- cfr37-201-38: 37 CFR 201.38 designation of agent (eCFR as of 2026-10-26)
- ca2-viacom-youtube-2012: Viacom v. YouTube, 676 F.3d 19 (2d Cir. 2012)
- ca2-capitol-vimeo-2016: Capitol Records v. Vimeo, 826 F.3d 78 (2d Cir. 2016)
- ca9-umg-shelter-2013: UMG v. Shelter Capital, 718 F.3d 1006 (9th Cir. 2013)
- ca9-lenz-2016: Lenz v. Universal, 815 F.3d 1145 (9th Cir. 2016)
- ca9-mavrix-livejournal-2017: Mavrix v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017)
- ca9-ventura-motherless-2018: Ventura Content v. Motherless, 885 F.3d 597 (9th Cir. 2018)
- co-section512-report-2020: Copyright Office, Section 512 Report (May 2020)
- scotus-cox-sony-2026: Cox Communications v. Sony Music (2026)
- ca3-hepp-2021: Hepp v. Facebook (3d Cir. 2021)

### Claims cited in M08
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0401] VERIFIED
- Claim: 47 U.S.C. 230(e)(2): section 230 does not limit or expand intellectual property law.
- Jurisdiction: US-federal
- Source: 47 U.S.C. 230 protection for private blocking and screening of offensive material (230(e)(2) IP carve-out) (https://www.law.cornell.edu/uscode/text/47/230), source id usc47-230
- Pinpoint: 47 U.S.C. 230(e)(2)
- Quote: "Nothing in this section shall be construed to limit or expand any law pertaining to intellectual property"
- Checked: 2026-11-10

#### [M-0402] VERIFIED
- Claim: Analysis: 47 U.S.C. 230(e)(2) leaves intellectual property law unchanged, so Section 230 neither adds a defence to nor limits federal copyright infringement claims against a platform.
- Jurisdiction: analysis
- Source: 47 U.S.C. 230 protection for private blocking and screening of offensive material (230(e)(2) IP carve-out) (https://www.law.cornell.edu/uscode/text/47/230), source id usc47-230
- Pinpoint: 47 U.S.C. 230(e)(2)
- Quote: "Nothing in this section shall be construed to limit or expand any law pertaining to intellectual property"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0350] VERIFIED
- Claim: One required element of an effective 512(c)(3) notice is a physical or electronic signature of a person authorized to act for the owner of an exclusive right allegedly infringed.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(i)
- Quote: "A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0351] VERIFIED
- Claim: A 512(c)(3) notice must include a statement, under penalty of perjury, that the complaining party is authorized to act for the owner of an exclusive right allegedly infringed (and that the notice information is accurate).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(vi)
- Quote: "under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0358] VERIFIED
- Claim: Applicability of 512(a)-(d) is not conditioned on a provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure under 512(i).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(m)(1)
- Quote: "a service provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure complying with the provisions of subsection (i)"
- Checked: 2026-11-10

#### [M-0356] VERIFIED
- Claim: A counter notification must include a statement under penalty of perjury that the subscriber has a good faith belief the material was removed or disabled by mistake or misidentification.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(3)(C)
- Quote: "A statement under penalty of perjury that the subscriber has a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material to be removed or disabled"
- Checked: 2026-11-10

#### [M-0355] VERIFIED
- Claim: On a counter notice the provider replaces the removed material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells its designated agent (of a court action; see rest of 512(g)(2)(C)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(2)(C)
- Quote: "replaces the removed material and ceases disabling access to it not less than 10, nor more than 14, business days following receipt of the counter notice, unless its designated agent first receives notice from the person who submitted the notification"
- Checked: 2026-11-10

#### [M-0359] VERIFIED
- Claim: A person who knowingly materially misrepresents under 512 that material or activity is infringing is liable for damages, including costs and attorneys’ fees, incurred by the alleged infringer and others (512(f)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(f)(1)
- Quote: "Any person who knowingly materially misrepresents under this section-- (1) that material or activity is infringing"
- Checked: 2026-11-10

#### [M-0352] VERIFIED
- Claim: A 512(c)(2) agent designation must give the full legal name and physical street address of the service provider.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(b)(1)(i)
- Quote: "The full legal name and physical street address of the service provider"
- Checked: 2026-11-10

#### [M-0353] VERIFIED
- Claim: Separate legal entities (parent and subsidiary) need separate designations.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(b)(1)(i)
- Quote: "Related or affiliated service providers that are separate legal entities (e.g., corporate parents and subsidiaries) are considered separate service providers, and each must have its own separate designation"
- Checked: 2026-11-10

#### [M-0354] VERIFIED
- Claim: A designation expires three years after registration unless renewed by amending or resubmitting it.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(c)(4)
- Quote: "A service provider's designation will expire and become invalid three years after it is registered with the Office"
- Checked: 2026-11-10

#### [M-0362] VERIFIED
- Claim: Viacom: the 512(c) safe harbor requires knowledge or awareness of specific infringing activity.
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (slip op. opening summary)
- Quote: "the § 512(c) safe harbor requires knowledge or awareness of specific infringing activity"
- Checked: 2026-11-10

#### [M-0363] VERIFIED
- Claim: Viacom: 'right and ability to control' requires something more than the ability to remove or block access.
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (slip op. 27-28)
- Quote: "requires something more than the ability to remove or block access to materials posted on a service provider’s website"
- Checked: 2026-11-10

#### [M-0364] VERIFIED
- Claim: Viacom: the willful blindness doctrine may be applied in the DMCA 512(c) knowledge context (first impression in the Second Circuit).
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (Part II, willful blindness)
- Quote: "The willful blindness doctrine may be applied, in appropriate circumstances, to demonstrate knowledge or awareness of specific instances of infringement under § 512(c)(1)(A)"
- Checked: 2026-11-10

#### [M-0365] VERIFIED
- Claim: Capitol v. Vimeo: employee viewing of a video containing a recognizable copyrighted song does not alone establish red flag knowledge.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (summary and Part II)
- Quote: "viewed in some fashion by a service provider’s employee is insufficient to prove knowledge or red flag knowledge of infringement"
- Checked: 2026-11-10

#### [M-0366] VERIFIED
- Claim: Capitol v. Vimeo: the red flag test uses an ordinary person without specialized knowledge of music or copyright law.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (Part II red flag)
- Quote: "obvious is an ordinary person--not endowed with specialized knowledge or"
- Checked: 2026-11-10

#### [M-0367] VERIFIED
- Claim: UMG v. Shelter (Veoh): the label's choice to skip the DMCA notice protocol 'stripped it of the most powerful evidence' of knowledge.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Shelter Capital Partners LLC (Veoh), 718 F.3d 1006 (9th Cir. 2013) (https://cdn.ca9.uscourts.gov/datastore/opinions/2013/03/14/09-55902.pdf), source id ca9-umg-shelter-2013
- Pinpoint: 718 F.3d 1006 (Part on actual knowledge)
- Quote: "UMG’s decision to forgo the DMCA notice protocol “stripped it of the most powerful evidence of a service provider’s knowledge"
- Checked: 2026-11-10

#### [M-0370] VERIFIED
- Claim: Ventura v. Motherless (UGC site): the Ninth Circuit affirmed summary judgment for the site on the 512(c) safe harbor.
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d 597, 620 (Conclusion)
- Quote: "granting summary judgment in favor of Motherless"
- Checked: 2026-11-10

#### [M-0371] VERIFIED
- Claim: Ventura: 'apparent' knowledge and 'red flag' are used interchangeably; infringement must be obvious to a reasonable person.
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d at 609
- Quote: "The statutory term "apparent" is often described, in the cases and secondary literature, as "red flag" knowledge"
- Checked: 2026-11-10

#### [M-0372] VERIFIED
- Claim: Ventura: the site's repeat infringer handling was informal (no written policy; sole owner decided terminations by volume, content, timing of complaints).
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d at 601-02
- Quote: "Motherless does not have a written policy instructing its employees on when to expel repeat infringers"
- Checked: 2026-11-10

#### [M-0368] VERIFIED
- Claim: Mavrix v. LiveJournal: common law agency applies to whether moderators' acts count as the site's own, undercutting 'storage at the direction of a user'.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 873 F.3d 1045, 1048-49
- Quote: "The issue we must decide is whether the common law of agency applies to LiveJournal’s safe harbor defense"
- Checked: 2026-11-10

#### [M-0369] VERIFIED
- Claim: Mavrix: genuine fact disputes over whether volunteer moderators were agents led to reversal of summary judgment for the site.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 873 F.3d 1045, 1048
- Quote: "there are genuine factual disputes regarding whether the moderators are LiveJournal’s agents, we reverse the district court’s summary judgment and remand for trial"
- Checked: 2026-11-10

#### [M-0360] VERIFIED
- Claim: Lenz: a rightsholder must consider fair use before sending a takedown, or risks 512(f) damages.
- Jurisdiction: case-law
- Source: Lenz v. Universal Music Corp., 815 F.3d 1145 (9th Cir. 2016) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/03/17/13-16106.pdf), source id ca9-lenz-2016
- Pinpoint: 815 F.3d 1145, amended opinion, Part on 512(f) (slip op. 19)
- Quote: "if a copyright holder ignores or neglects our unequivocal holding that it must consider fair use before sending a takedown notification, it is liable for damages under § 512(f)"
- Checked: 2026-11-10

#### [M-0361] VERIFIED
- Claim: Lenz: the test is subjective good faith belief; courts do not second-guess a genuine belief that use is not fair.
- Jurisdiction: case-law
- Source: Lenz v. Universal Music Corp., 815 F.3d 1145 (9th Cir. 2016) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/03/17/13-16106.pdf), source id ca9-lenz-2016
- Pinpoint: 815 F.3d 1145 (slip op. 19)
- Quote: "If, however, a copyright holder forms a subjective good faith belief the allegedly infringing material does not constitute fair use, we are in no position to dispute the copyright holder’s belief"
- Checked: 2026-11-10

#### [M-0376] VERIFIED
- Claim: The report notes the Fourth Circuit reads 'repeat infringer' as repeat alleged infringer, not repeat adjudicated.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, repeat infringer policies
- Quote: "a “repeat infringer” under section 512 means repeat alleged infringer, not repeat adjudicated"
- Checked: 2026-11-10

#### [M-0001] VERIFIED
- Claim: The Supreme Court decided Cox Communications v. Sony Music (No. 24-171) on March 25, 2026, reversing and remanding; contributory liability needs intent shown by inducement or a service tailored to infringement.
- Jurisdiction: case-law
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: Syllabus, Held (decided March 25, 2026; judgment 93 F.4th 222 reversed and remanded)
- Quote: "contributorily liable for a user's infringement only if it intended that the provided service be used for infringement, which can be shown only if the party induced the infringement or the provided service is tailored to that infringement"
- Checked: 2026-11-10

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0373] VERIFIED
- Claim: The Copyright Office 2020 report recommends no wholesale change to section 512, only targeted fine-tuning.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary
- Quote: "The Office is not recommending any wholesale changes to section 512"
- Checked: 2026-11-10

#### [M-0374] VERIFIED
- Claim: The report finds courts' readings of knowledge requirements may be narrower than Congress intended (actual vs red flag, willful blindness).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, knowledge requirements
- Quote: "current interpretations of the section 512 knowledge requirements for OSPs may be narrower than Congress initially intended"
- Checked: 2026-11-10

#### [M-0375] VERIFIED
- Claim: The report says courts require willful blindness to involve deliberate avoidance of specific infringements, not infringement generally.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, willful blindness
- Quote: "requires that the willful blindness involve deliberate avoidance of specific incidences of infringement, rather than avoidance of acts of infringement generally"
- Checked: 2026-11-10

#### [M-0377] VERIFIED
- Claim: The Office's 2020 report says notice-and-staydown (and website blocking) need additional study, including non-copyright implications and public input, before any proposal.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary (additional study conclusion)
- Quote: "the Office believes that additional study, including of potential non-copyright implications, with public input, would be needed in order to explore the possible contours of any such future proposals."
- Checked: 2026-11-10

## M09 Secondary liability after Cox
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Is a mixing platform liable if a user uploads a mix with songs they do not own; Does knowing users infringe make a platform contributorily liable after Cox; What is vicarious liability and does Cox change it; Does a platform still need a repeat infringer policy; Does the DMCA safe harbour still matter; Which pre-2026 cases are overtaken

### Bottom line
US federal law, as of 2026-11-10: after Cox v. Sony (U.S. 2026), a service provider is contributorily liable for a user's infringement only if it intended the service be used to infringe, shown by inducement or by a service tailored to infringement. Knowing that some users infringe is not enough [M-0001, M-0221, M-0222, M-0223]. This helps platforms, but it does not touch direct liability, vicarious liability or the section 512 safe harbour, and it gives no licence for music in uploads [M-0252].

### Rules
#### The Supreme Court decision (US federal, court decision)
- The Court decided Cox Communications v. Sony Music (No. 24-171) on March 25, 2026, reversing and remanding [M-0001, M-0226].
- Held: a provider is "contributorily liable for a user's infringement only if it intended that the provided service be used for infringement" [M-0221].
- Mere knowledge that a service will be used to infringe is insufficient to show that intent [M-0222].
- Intent can be shown two ways: inducement, or a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses) [M-0223].
- The Fourth Circuit's knowledge plus insufficient action rule went beyond those two bases and conflicted with the Court's precedent [M-0224].
- Justice Sotomayor, concurring in the judgment, said other common law theories such as aiding and abetting could apply in copyright. That is a concurrence, not the holding [M-0225].
- Cox is an internet access provider case, but the holding is stated for any "provider of a service" [M-0252]. Applying it to an app is (analysis) a fair reading, not a ruling on apps.
- Only contributory liability was before the Court. Vicarious liability is a separate theory the Court did not decide [M-0252]. Direct infringement is not addressed in the syllabus [M-0252]. The section 512 safe harbour was not decided [M-0252].

#### Baseline liability (US federal, statute)
- Anyone who violates an exclusive right of the copyright owner is an infringer [M-0220]. A platform that itself copies, performs or distributes music is a direct infringer, whatever Cox says (analysis).

#### Overtaken or vacated lower decisions (court decisions)
- Fourth Circuit (2024) affirmed willful contributory liability and reversed vicarious liability for lack of profit from subscribers' infringement [M-0228]. The contributory holding was reversed by the Supreme Court [M-0226]. Cite as history only.
- Fifth Circuit (2024, Grande) affirmed contributory liability but vacated the damages award [M-0229]. The Supreme Court granted Grande's petition on April 6, 2026, vacated and remanded in light of Cox [M-0002, M-0227]. The remand outcome is not in our sources. Needs source.
- BMG v. Cox (4th Cir. 2018) held the "knew or should have known" contributory standard is negligence and too low [M-0232]. That standard is overtaken because Cox 2026 requires more than knowledge [M-0224].

#### The DMCA safe harbour still stands apart (court decisions)
- BMG v. Cox (4th Cir. 2018): to use the section 512 safe harbour a provider must have adopted and reasonably implemented a policy to terminate repeat infringers [M-0230]. The 2018 holding on 512(i) is not disturbed by Cox 2026 [M-0230].
- BMG held the safe harbour was lost because the repeat infringer policy was not applied consistently or meaningfully [M-0231, M-0253]. The provider bears the burden of proof on the defence [M-0233].
- Copyright Office 2020 report (regulator report, not law) notes the Fourth Circuit reads "repeat infringer" as repeat alleged infringer [M-0376]. Cox 2026 did not address that 512(i) reading [M-0376].
- Viacom v. YouTube (2d Cir. 2012): 512(c) needs knowledge or awareness of specific infringing activity [M-0362]. "Right and ability to control" needs something more than the ability to remove or block [M-0363]. Willful blindness may apply in the 512(c) knowledge context [M-0364].
- Capitol v. Vimeo (2d Cir. 2016): an employee viewing a video with a recognizable song does not alone create red flag knowledge [M-0365]. The red flag test uses an ordinary person without specialized music or copyright knowledge [M-0366].
- Ventura v. Motherless (9th Cir. 2018, UGC site): summary judgment for the site on 512(c) was affirmed [M-0370]. Apparent knowledge and red flag mean infringement must be obvious to a reasonable person [M-0371]. The site's informal repeat infringer handling still passed on those facts, so do not treat it as a model [M-0372].
- Mavrix v. LiveJournal (9th Cir. 2017): common law agency decides whether moderators' acts are the site's own, which can undercut "storage at the direction of a user"; fact disputes over volunteer moderators led to reversal of summary judgment for the site [M-0368, M-0369].
- The Copyright Office 2020 report recommends no wholesale change to section 512 [M-0373]. It says courts may read knowledge requirements more narrowly than Congress intended [M-0374], and that willful blindness needs deliberate avoidance of specific infringements [M-0375]. Notice and staydown needs more study [M-0377].

### Gotchas
- "Knowledge is not enough" is not "we are safe." Inducement, tailored service, direct liability, vicarious liability and the 512 conditions all remain [M-0222, M-0252].
- Lower court cases that rely on "knew or should have known" or knowledge plus failure to act are overtaken [M-0224, M-0232]. Re-check any other circuit's secondary liability case before citing.
- The BMG repeat infringer holding is a separate 512(i) point and is not disturbed [M-0230]. Do not drop the repeat infringer policy because of Cox.
- Grande: only the April 6, 2026 vacatur is in our sources [M-0227]. The remand result is unknown. Needs source.
- Sotomayor's aiding and abetting remark is a concurrence [M-0225]. Plaintiffs may plead it, so do not call it dead.
- Cox is an ISP case. Whether courts apply it identically to hosting platforms is not settled in our sources (analysis).
- Currency: as of 2026-11-10, post-Cox lower court case law is not in the ledger. Volatility is high.

### Open questions for counsel
- US federal: given our sound features, does any product copy or marketing risk "inducement" under Cox?
- US federal: with Cox silent on vicarious liability, what is a platform's exposure from ad or subscription revenue on videos with unlicensed music?
- US federal: does a platform's server side re-encoding of user audio make it a direct actor, and does 512(c) or 512(a) fit?
- Ninth and Second Circuits: how have courts applied Cox to hosting platforms since March 2026, and what happened on the Grande remand in the Fifth Circuit?
- Does our repeat infringer policy meet BMG v. Cox, and how should it treat creators with multiple unproven notices?
- Should a platform's designated agent and notice workflow be reviewed against current Copyright Office filings?

### Sources
- scotus-cox-sony-2026: Cox Communications v. Sony Music, No. 24-171 (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf)
- scotus-cox-sony-docket: docket 24-171 (https://www.supremecourt.gov/docket/docketfiles/html/public/24-171.html)
- scotus-grande-umg-docket: docket 24-967 (https://www.supremecourt.gov/docket/docketfiles/html/public/24-967.html)
- ca4-sony-cox-2024: 93 F.4th 222 (https://www.ca4.uscourts.gov/opinions/211168.P.pdf)
- ca5-umg-grande-2024: 118 F.4th 697 (https://www.ca5.uscourts.gov/opinions/pub/23/23-50162-CV0.pdf)
- ca4-bmg-cox-2018: 881 F.3d 293 (https://static.case.law/f3d/881/html/0293-01.html)
- ca2-viacom-youtube-2012, ca2-capitol-vimeo-2016, ca9-mavrix-livejournal-2017, ca9-ventura-motherless-2018: https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf, https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf, https://static.case.law/f3d/873/html/1045-01.html, https://static.case.law/f3d/885/html/0597-01.html
- usc17-501: 17 U.S.C. 501 (https://www.law.cornell.edu/uscode/text/17/501)
- co-section512-report-2020: Copyright Office section 512 report (https://www.copyright.gov/policy/section512/section-512-full-report.pdf)

### Claims cited in M09
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0001] VERIFIED
- Claim: The Supreme Court decided Cox Communications v. Sony Music (No. 24-171) on March 25, 2026, reversing and remanding; contributory liability needs intent shown by inducement or a service tailored to infringement.
- Jurisdiction: case-law
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: Syllabus, Held (decided March 25, 2026; judgment 93 F.4th 222 reversed and remanded)
- Quote: "contributorily liable for a user's infringement only if it intended that the provided service be used for infringement, which can be shown only if the party induced the infringement or the provided service is tailored to that infringement"
- Checked: 2026-11-10

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0222] VERIFIED
- Claim: Cox (2026): mere knowledge that a service will be used to infringe is insufficient to establish the required intent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part II.B
- Quote: "mere knowledge that a service will be used to infringe is insufficient to establish the required intent to infringe."
- Checked: 2026-11-10

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0226] VERIFIED
- Claim: The Supreme Court docket for Cox v. Sony shows the judgment was reversed and remanded on March 25, 2026.
- Jurisdiction: US-federal
- Source: Supreme Court docket No. 24-171, Cox Communications, Inc. v. Sony Music Entertainment (https://www.supremecourt.gov/docket/docketfiles/html/public/24-171.html), source id scotus-cox-sony-docket
- Pinpoint: No. 24-171 docket entry Mar 25 2026
- Quote: "Judgment REVERSED and case REMANDED."
- Checked: 2026-11-10

#### [M-0224] VERIFIED
- Claim: Cox (2026): the Fourth Circuit's knowledge-plus-insufficient-action rule went beyond the two recognised bases and conflicted with the Court's precedent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part III
- Quote: "contributory liability cannot rest only on a provider’s knowledge of infringement and insufficient action to prevent it."
- Checked: 2026-11-10

#### [M-0225] VERIFIED
- Claim: Cox (2026): Justice Sotomayor, concurring in the judgment, said other common-law theories such as aiding and abetting could apply in copyright.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Sotomayor concurrence
- Quote: "precedents have left open the possibility that other common-law theories of such liability, like aiding and abetting, could apply in the copyright context."
- Checked: 2026-11-10

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0228] VERIFIED
- Claim: The Fourth Circuit (2024) affirmed willful contributory liability but reversed vicarious liability because Cox did not profit from subscribers' infringement.
- Jurisdiction: case-law
- Source: Sony Music Entertainment v. Cox Communications, Inc., 93 F.4th 222 (4th Cir. 2024) (https://www.ca4.uscourts.gov/opinions/211168.P.pdf), source id ca4-sony-cox-2024
- Pinpoint: 93 F.4th 222, intro
- Quote: "We affirm the jury’s finding of willful contributory infringement. But we reverse the vicarious liability verdict and"
- Checked: 2026-11-10

#### [M-0229] VERIFIED
- Claim: The Fifth Circuit (2024) had affirmed Grande's contributory liability but vacated the statutory damages award for a new trial, a judgment SCOTUS has now vacated.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Grande Communications Networks, L.L.C., 118 F.4th 697 (5th Cir. 2024) (vacated and remanded by S. Ct. Apr. 6, 2026) (https://www.ca5.uscourts.gov/opinions/pub/23/23-50162-CV0.pdf), source id ca5-umg-grande-2024
- Pinpoint: 118 F.4th 697, intro
- Quote: "we AFFIRM the jury’s verdict finding Grande liable for contributory copyright infringement; VACATE the jury’s damages award and REMAND for a new trial on damages; and DISMISS"
- Checked: 2026-11-10

#### [M-0002] VERIFIED
- Claim: The Supreme Court vacated the Fifth Circuit's UMG v. Grande judgment and remanded on April 6, 2026 in light of Cox v. Sony.
- Jurisdiction: case-law
- Source: Supreme Court docket No. 24-967, Grande Communications Networks, LLC v. UMG Recordings, Inc. (GVR in light of Cox, Apr. 6, 2026) (https://www.supremecourt.gov/docket/docketfiles/html/public/24-967.html), source id scotus-grande-umg-docket
- Pinpoint: docket 24-967, entry Apr 06 2026
- Quote: "Petition GRANTED. Judgment VACATED and case REMANDED for further consideration in light of Cox Communications, Inc. v. Sony Music Entertainment, 607 U. S. ___ (2026)."
- Checked: 2026-11-10

#### [M-0227] VERIFIED
- Claim: The Supreme Court granted Grande's petition on April 6, 2026, vacated the Fifth Circuit judgment and remanded in light of Cox.
- Jurisdiction: US-federal
- Source: Supreme Court docket No. 24-967, Grande Communications Networks, LLC v. UMG Recordings, Inc. (GVR in light of Cox, Apr. 6, 2026) (https://www.supremecourt.gov/docket/docketfiles/html/public/24-967.html), source id scotus-grande-umg-docket
- Pinpoint: No. 24-967 docket entry Apr 06 2026
- Quote: "Petition GRANTED. Judgment VACATED and case REMANDED for further consideration in light of Cox Communications, Inc. v. Sony Music Entertainment, 607 U. S. ___ (2026)."
- Checked: 2026-11-10

#### [M-0232] VERIFIED
- Claim: BMG v. Cox held the 'knew or should have known' contributory standard is negligence and too low.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 310 (Part III.B)
- Quote: "The formulation “should have known” reflects negligence and is therefore too low a standard."
- Checked: 2026-11-10

#### [M-0230] VERIFIED
- Claim: BMG v. Cox (4th Cir. 2018): to use the section 512 safe harbour a provider must have adopted and reasonably implemented a policy to terminate repeat infringers.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 301 (Part II.A)
- Quote: "adopted and reasonably implemented ... a policy that provides for the termination in appropriate circumstances of subscribers ... who are repeat infringers.” 17 U.S.C."
- Checked: 2026-11-10

#### [M-0231] VERIFIED
- Claim: BMG v. Cox held the safe harbour was lost because the provider failed to implement its repeat infringer policy consistently or meaningfully.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305 (Part II.B)
- Quote: "Cox failed to qualify for the DMCA safe harbor because it failed to implement its policy in any consistent or meaningful way--leaving"
- Checked: 2026-11-10

#### [M-0253] VERIFIED
- Claim: Analysis: BMG v. Cox (4th Cir. 2018) held Cox failed to qualify for the DMCA 512 safe harbour because it did not implement its repeat infringer policy consistently or meaningfully, leaving it essentially with no policy.
- Jurisdiction: analysis
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305
- Quote: "Cox failed to qualify for the DMCA safe harbor because it failed to implement its policy in any consistent or meaningful way--leaving"
- Checked: 2026-11-10

#### [M-0233] VERIFIED
- Claim: The provider bears the burden of proof on the DMCA safe harbour defence.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305 (Part II.B)
- Quote: "Cox bears the burden of proof on the DMCA safe harbor"
- Checked: 2026-11-10

#### [M-0376] VERIFIED
- Claim: The report notes the Fourth Circuit reads 'repeat infringer' as repeat alleged infringer, not repeat adjudicated.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, repeat infringer policies
- Quote: "a “repeat infringer” under section 512 means repeat alleged infringer, not repeat adjudicated"
- Checked: 2026-11-10

#### [M-0362] VERIFIED
- Claim: Viacom: the 512(c) safe harbor requires knowledge or awareness of specific infringing activity.
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (slip op. opening summary)
- Quote: "the § 512(c) safe harbor requires knowledge or awareness of specific infringing activity"
- Checked: 2026-11-10

#### [M-0363] VERIFIED
- Claim: Viacom: 'right and ability to control' requires something more than the ability to remove or block access.
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (slip op. 27-28)
- Quote: "requires something more than the ability to remove or block access to materials posted on a service provider’s website"
- Checked: 2026-11-10

#### [M-0364] VERIFIED
- Claim: Viacom: the willful blindness doctrine may be applied in the DMCA 512(c) knowledge context (first impression in the Second Circuit).
- Jurisdiction: case-law
- Source: Viacom International, Inc. v. YouTube, Inc., 676 F.3d 19 (2d Cir. 2012) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-10-03270/pdf/USCOURTS-ca2-10-03270-0.pdf), source id ca2-viacom-youtube-2012
- Pinpoint: 676 F.3d 19 (Part II, willful blindness)
- Quote: "The willful blindness doctrine may be applied, in appropriate circumstances, to demonstrate knowledge or awareness of specific instances of infringement under § 512(c)(1)(A)"
- Checked: 2026-11-10

#### [M-0365] VERIFIED
- Claim: Capitol v. Vimeo: employee viewing of a video containing a recognizable copyrighted song does not alone establish red flag knowledge.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (summary and Part II)
- Quote: "viewed in some fashion by a service provider’s employee is insufficient to prove knowledge or red flag knowledge of infringement"
- Checked: 2026-11-10

#### [M-0366] VERIFIED
- Claim: Capitol v. Vimeo: the red flag test uses an ordinary person without specialized knowledge of music or copyright law.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (Part II red flag)
- Quote: "obvious is an ordinary person--not endowed with specialized knowledge or"
- Checked: 2026-11-10

#### [M-0370] VERIFIED
- Claim: Ventura v. Motherless (UGC site): the Ninth Circuit affirmed summary judgment for the site on the 512(c) safe harbor.
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d 597, 620 (Conclusion)
- Quote: "granting summary judgment in favor of Motherless"
- Checked: 2026-11-10

#### [M-0371] VERIFIED
- Claim: Ventura: 'apparent' knowledge and 'red flag' are used interchangeably; infringement must be obvious to a reasonable person.
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d at 609
- Quote: "The statutory term "apparent" is often described, in the cases and secondary literature, as "red flag" knowledge"
- Checked: 2026-11-10

#### [M-0372] VERIFIED
- Claim: Ventura: the site's repeat infringer handling was informal (no written policy; sole owner decided terminations by volume, content, timing of complaints).
- Jurisdiction: case-law
- Source: Ventura Content v. Motherless.com, 885 F.3d 597 (9th Cir. 2018) (https://static.case.law/f3d/885/html/0597-01.html), source id ca9-ventura-motherless-2018
- Pinpoint: 885 F.3d at 601-02
- Quote: "Motherless does not have a written policy instructing its employees on when to expel repeat infringers"
- Checked: 2026-11-10

#### [M-0368] VERIFIED
- Claim: Mavrix v. LiveJournal: common law agency applies to whether moderators' acts count as the site's own, undercutting 'storage at the direction of a user'.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 873 F.3d 1045, 1048-49
- Quote: "The issue we must decide is whether the common law of agency applies to LiveJournal’s safe harbor defense"
- Checked: 2026-11-10

#### [M-0369] VERIFIED
- Claim: Mavrix: genuine fact disputes over whether volunteer moderators were agents led to reversal of summary judgment for the site.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 873 F.3d 1045, 1048
- Quote: "there are genuine factual disputes regarding whether the moderators are LiveJournal’s agents, we reverse the district court’s summary judgment and remand for trial"
- Checked: 2026-11-10

#### [M-0373] VERIFIED
- Claim: The Copyright Office 2020 report recommends no wholesale change to section 512, only targeted fine-tuning.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary
- Quote: "The Office is not recommending any wholesale changes to section 512"
- Checked: 2026-11-10

#### [M-0374] VERIFIED
- Claim: The report finds courts' readings of knowledge requirements may be narrower than Congress intended (actual vs red flag, willful blindness).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, knowledge requirements
- Quote: "current interpretations of the section 512 knowledge requirements for OSPs may be narrower than Congress initially intended"
- Checked: 2026-11-10

#### [M-0375] VERIFIED
- Claim: The report says courts require willful blindness to involve deliberate avoidance of specific infringements, not infringement generally.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, willful blindness
- Quote: "requires that the willful blindness involve deliberate avoidance of specific incidences of infringement, rather than avoidance of acts of infringement generally"
- Checked: 2026-11-10

#### [M-0377] VERIFIED
- Claim: The Office's 2020 report says notice-and-staydown (and website blocking) need additional study, including non-copyright implications and public input, before any proposal.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary (additional study conclusion)
- Quote: "the Office believes that additional study, including of potential non-copyright implications, with public input, would be needed in order to explore the possible contours of any such future proposals."
- Checked: 2026-11-10

## M10 Content ID systems and platform sound libraries
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Can a mixing platform use TikTok or Meta library music; Does a library licence from Epidemic Sound or Musicbed cover mixes on a platform; Does a mixing platform need to build Content ID style filtering; What must a platform do when a rightsholder sends a takedown; What would EU Article 17 require of a platform that hosts user mixes; Is YouTube Audio Library music safe to use in mixes

### Bottom line
- No saved platform or library licence is shown to cover music on a third party platform. TikTok's Commercial Music Library grants no rights outside TikTok [M-0382, M-0383, M-0386], and Meta Sound Collection is limited to Meta products (2023 archive copy) [M-0385].
- A Content ID style filter is a product choice in the US, not a legal duty: the DMCA safe harbor is not conditioned on monitoring [M-0358]. In the EU, Article 17 can require upload filtering style duties (EU law).
- These tools and libraries touch the composition and the master only by licence or claim. A library licence is a direct sync and master licence from the library, and only if its terms fit the use (analysis).

### Rules
#### Content ID style systems (platform terms)
- YouTube Content ID scans each upload against files that owners submit. A match leads to block, monetize or track [M-0378]. It is open only to owners with exclusive rights to a substantial body of frequently uploaded original material [M-0379]. Edition captured 2026-11-10.
- YouTube Audio Library music is described as copyright safe and not claimed through Content ID [M-0411]. The page states no licence scope outside YouTube [M-0411]. Some tracks need credit under a Creative Commons licence [M-0412]. YouTube disclaims responsibility for music from other libraries [M-0413].

#### US federal: DMCA 512(c) (statute)
- The 512(c) safe harbor covers infringement by reason of storage at a user's direction [M-0343].
- Conditions: no actual knowledge [M-0344]; no awareness of facts making infringement apparent, called red flag knowledge [M-0345]; act expeditiously to remove once aware [M-0346]; no direct financial benefit from infringement where the provider can control it [M-0347]; act expeditiously on a compliant notice [M-0348].
- The provider must designate an agent on its service and with the Copyright Office [M-0349].
- A repeat infringer policy must be adopted, reasonably implemented and told to subscribers, or the limitations do not apply [M-0357].
- The safe harbor is not conditioned on monitoring or seeking out infringement, except where a standard technical measure applies [M-0358].
- A valid notice needs an authorised signature [M-0350] and a statement under penalty of perjury that the sender is authorised to act for the owner [M-0351].
- Counter notice: the uploader states under penalty of perjury a good faith belief of mistake or misidentification [M-0356]. The provider restores the material not less than 10 nor more than 14 business days after receipt, unless the notifier first reports a court action [M-0355].
- Knowing material misrepresentation in a notice or counter notice makes the sender liable for damages and fees [M-0359]. In the Ninth Circuit a rightsholder must consider fair use before sending a takedown [M-0360]. The test is subjective good faith [M-0361] (Lenz v. Universal, court decision).
- The Copyright Office 2020 report (a report, not law) recommends only fine tuning of 512 [M-0373]. It says courts may read knowledge requirements more narrowly than Congress meant [M-0374], that willful blindness needs deliberate avoidance of specific infringements [M-0375], and that the Fourth Circuit reads repeat infringer as repeat alleged infringer [M-0376]. It says notice and staydown needs further study [M-0377].

#### EU: Directive 2019/790 Article 17 (foreign law)
- A content sharing service provider communicates to the public when it gives access to user uploads, and needs authorisation [M-0387]. The Article 14(1) hosting safe harbor does not apply to these situations [M-0388].
- Without authorisation the provider is liable unless it made best efforts to get one [M-0389], best efforts to high industry standards to make identified works unavailable [M-0390], and acted expeditiously on notice and made best efforts to prevent re-upload [M-0391].
- Providers under three years old with turnover under EUR 10 million face a lighter regime [M-0392].
- Users may rely on quotation, criticism, review, caricature, parody or pastiche [M-0393]. There is no general monitoring duty [M-0394]. Complaints get human review of disable or remove decisions [M-0395].
- CJEU Poland v Parliament (C-401/19, 26 April 2022) upheld Article 17 [M-0396]. Providers cannot be required to filter content whose unlawfulness needs an independent assessment of context and exceptions [M-0397].
- Commission 2021 guidance (non-binding) says automated blocking at upload should in principle cover only manifestly infringing uploads [M-0398].
- Text and data mining exceptions (CDSM Arts 3 and 4) are an AI topic, not a Content ID rule: Art 3 for research bodies [M-0399], Art 4 unless rightholders reserved use in machine readable form [M-0400, M-0442]. National transposition varies [M-0442].

#### Platform sound libraries and library licences (platform terms)
- TikTok Commercial Music Library: a user engaging in Commercial Uses may post videos with Commercial Sounds only within TikTok [M-0382]. Posting on third party platforms needs separate rights-holder licences [M-0383]. Sounds may not be used with content that breaks TikTok's Terms or Community Guidelines [M-0384]. Edition 2026-11-10.
- Meta Sound Collection: licence limited to Meta products [M-0385]. This is a 2022 terms copy archived 2023-08-18. The current copy was not obtained.
- Epidemic Sound: the personal licence is for the licensee's own personal use [M-0404] and does not allow sublicensing [M-0405]. Edition SingleTrackLicensesV8.
- Musicbed: the licence is per single audiovisual project and excludes public performance where a PRO licence is available [M-0408].
- Artlist: the saved text is only the site terms of use, and the music licence is not in it [M-0410].

### Gotchas
- Absence findings (Artlist site terms, YouTube Audio Library page) mean nothing was found in one saved page [M-0410, M-0411]. They do not prove permission.
- Gap, needs source: TikTok Community Guidelines are unchecked, and the current Meta Sound Collection terms were not obtained [M-0385, M-0384]. The Artlist music licence is not saved [M-0410].
- Library terms change. All editions here were captured 2026-11-10 except Meta (2023-08-18) and Pond5 (archive capture, October 2026). Recheck before relying.
- Content ID is not a licence. A claim or monetize outcome is a platform rule between owner and platform, not a grant to any other platform [M-0378] (analysis).
- A takedown sender who ignores fair use can face 512(f) damages in the Ninth Circuit [M-0360, M-0359], but a counter notice sent in bad faith carries perjury and misrepresentation risk too [M-0356, M-0359].
- Copyright Office report views are not law [M-0373, M-0376]. Commission guidance is non-binding [M-0398].
- 512(c)(1)(B) has a contested case law gloss on "right and ability to control" not covered by the ledger [M-0347].

### Open questions for counsel
- US: does a platform's live streaming fit 512(c) storage at a user's direction, or is it outside the safe harbor?
- US: is an in-app sound picker backed by a library licence a direct licence to the platform, or only to the creator, and do the use limits in that licence bind?
- US: does a re-encode or audio processing tool qualify as a service provider under 512, or does it face direct liability for copying audio?
- US and EU: should a platform adopt audio fingerprinting now, and if it does, does acting on matches create knowledge that cuts against the safe harbor?
- EU: is a user upload platform an online content sharing service provider under Article 17, and does the three year startup tier apply [M-0392]?

### Sources
- usc17-512: 17 U.S.C. 512 (https://www.law.cornell.edu/uscode/text/17/512)
- ca9-lenz-2016: Lenz v. Universal Music Corp., 815 F.3d 1145 (9th Cir. 2016) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/03/17/13-16106.pdf)
- co-section512-report-2020: Copyright Office Section 512 report, May 2020 (https://www.copyright.gov/policy/section512/section-512-full-report.pdf)
- terms-youtube-contentid: YouTube Help, How Content ID works (https://support.google.com/youtube/answer/2797370?hl=en)
- terms-youtube-audio-library: YouTube Audio Library help (https://support.google.com/youtube/answer/3376882)
- terms-tiktok-cml-user-terms: TikTok Commercial Music Library User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en)
- terms-meta-sound-collection: Meta Sound Collection Terms, archive 2023-08-18 (https://web.archive.org/web/20230818125438id_/https://www.facebook.com/sound/collection/terms)
- terms-epidemic-sound: Epidemic Sound licence terms (https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf)
- terms-musicbed: Musicbed licence terms (https://www.musicbed.com/license-terms)
- terms-pond5-music: Pond5 licence terms (https://web.archive.org/web/2026/https://www.pond5.com/legal/license)
- terms-artlist: Artlist site terms (https://help-center.artlist.io/help-center/privacy-terms/terms-of-use)
- eu-cdsm-2019-790: Directive (EU) 2019/790 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790)
- cjeu-poland-c401-19: CJEU C-401/19 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401)
- eu-com-2021-288-art17: Commission guidance COM(2021) 288 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52021DC0288)

### Claims cited in M10
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0382] VERIFIED
- Claim: TikTok CML User Terms: a user engaging in Commercial Uses may post videos with Commercial Sounds only within TikTok; use elsewhere needs separate rights-holder licences.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, para 'You may only post or share'
- Quote: "Commercial Uses outside of TikTok are not permitted and no rights are granted by TikTok for such uses"
- Checked: 2026-11-10

#### [M-0383] VERIFIED
- Claim: TikTok CML User Terms: for Commercial Uses, posting videos with Commercial Sounds on third-party digital platforms is an outside use needing separate rights-holder licences.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, para 'You may only post or share'
- Quote: "These types of outside uses include, but are not limited to, posting videos on third party digital platforms"
- Checked: 2026-11-10

#### [M-0386] VERIFIED
- Claim: Analysis: TikTok Commercial Music Library terms for Commercial Uses permit posting Commercial Sounds only within TikTok and grant no rights for uses outside TikTok, so that library gives no rights usable on other platforms; Meta Sound Collection is similarly limited to Meta products (2023 archive copy); YouTube Audio Library not shown to be platform-tied.
- Jurisdiction: analysis
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: TikTok CML User Terms, Commercial Uses para beginning "You may only post or share"
- Quote: "You may only post or share videos that include Commercial Sounds within TikTok and by using the sharing features made available to TikTok users"
- Checked: 2026-11-10

#### [M-0385] VERIFIED
- Claim: Meta Sound Collection (2022 terms, 2023 archive): licence is limited to use on Meta products only.
- Jurisdiction: platform-terms
- Source: Meta Sound Collection Terms (web.archive.org copy of facebook.com/sound/collection/terms captured 2023-08-18; live page is JS-only) (https://web.archive.org/web/20230818125438id_/https://www.facebook.com/sound/collection/terms), source id terms-meta-sound-collection
- Pinpoint: Term A
- Quote: "content you create, upload, and distribute on the Meta Company Products (including through links to the Meta Company Products embedded in third party sites) only"
- Checked: 2026-11-10

#### [M-0358] VERIFIED
- Claim: Applicability of 512(a)-(d) is not conditioned on a provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure under 512(i).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(m)(1)
- Quote: "a service provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure complying with the provisions of subsection (i)"
- Checked: 2026-11-10

#### [M-0378] VERIFIED
- Claim: YouTube Content ID scans each upload against owner-submitted files; a match yields block, monetize or track.
- Jurisdiction: platform-terms
- Source: YouTube Help: How Content ID works (https://support.google.com/youtube/answer/2797370?hl=en), source id terms-youtube-contentid
- Pinpoint: Help page 'What does Content ID do?'
- Quote: "If Content ID finds a match, the matching video will get a Content ID claim"
- Checked: 2026-11-10

#### [M-0379] VERIFIED
- Claim: Content ID is limited to owners with exclusive rights to a substantial body of frequently uploaded original material.
- Jurisdiction: platform-terms
- Source: YouTube Help: How Content ID works (https://support.google.com/youtube/answer/2797370?hl=en), source id terms-youtube-contentid
- Pinpoint: Help page 'Who uses Content ID?'
- Quote: "they must own exclusive rights to a substantial body of original material that is frequently uploaded to YouTube"
- Checked: 2026-11-10

#### [M-0411] VERIFIED
- Claim: YouTube Audio Library music is described as copyright-safe and not claimed through Content ID.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Keep in mind'
- Quote: "Copyright-safe music and sound effects downloaded from the Audio Library won't be claimed by a rights holder through the Content ID system"
- Checked: 2026-11-10

#### [M-0412] VERIFIED
- Claim: YouTube Audio Library: tracks under a Creative Commons licence require crediting the artist in the video description.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Give attribution'
- Quote: "If you’re using a track with a Creative Commons license, you must credit the artist in your video’s description"
- Checked: 2026-11-10

#### [M-0413] VERIFIED
- Claim: YouTube Audio Library: YouTube disclaims responsibility for issues with music from other libraries.
- Jurisdiction: platform-terms
- Source: YouTube Audio Library help page (use of audio library music) (https://support.google.com/youtube/answer/3376882), source id terms-youtube-audio-library
- Pinpoint: Help page, 'Keep in mind'
- Quote: "YouTube is not responsible for issues that arise from “royalty-free” music and sound effects from YouTube channels or other music libraries"
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0350] VERIFIED
- Claim: One required element of an effective 512(c)(3) notice is a physical or electronic signature of a person authorized to act for the owner of an exclusive right allegedly infringed.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(i)
- Quote: "A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0351] VERIFIED
- Claim: A 512(c)(3) notice must include a statement, under penalty of perjury, that the complaining party is authorized to act for the owner of an exclusive right allegedly infringed (and that the notice information is accurate).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(vi)
- Quote: "under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0356] VERIFIED
- Claim: A counter notification must include a statement under penalty of perjury that the subscriber has a good faith belief the material was removed or disabled by mistake or misidentification.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(3)(C)
- Quote: "A statement under penalty of perjury that the subscriber has a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material to be removed or disabled"
- Checked: 2026-11-10

#### [M-0355] VERIFIED
- Claim: On a counter notice the provider replaces the removed material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells its designated agent (of a court action; see rest of 512(g)(2)(C)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(2)(C)
- Quote: "replaces the removed material and ceases disabling access to it not less than 10, nor more than 14, business days following receipt of the counter notice, unless its designated agent first receives notice from the person who submitted the notification"
- Checked: 2026-11-10

#### [M-0359] VERIFIED
- Claim: A person who knowingly materially misrepresents under 512 that material or activity is infringing is liable for damages, including costs and attorneys’ fees, incurred by the alleged infringer and others (512(f)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(f)(1)
- Quote: "Any person who knowingly materially misrepresents under this section-- (1) that material or activity is infringing"
- Checked: 2026-11-10

#### [M-0360] VERIFIED
- Claim: Lenz: a rightsholder must consider fair use before sending a takedown, or risks 512(f) damages.
- Jurisdiction: case-law
- Source: Lenz v. Universal Music Corp., 815 F.3d 1145 (9th Cir. 2016) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/03/17/13-16106.pdf), source id ca9-lenz-2016
- Pinpoint: 815 F.3d 1145, amended opinion, Part on 512(f) (slip op. 19)
- Quote: "if a copyright holder ignores or neglects our unequivocal holding that it must consider fair use before sending a takedown notification, it is liable for damages under § 512(f)"
- Checked: 2026-11-10

#### [M-0361] VERIFIED
- Claim: Lenz: the test is subjective good faith belief; courts do not second-guess a genuine belief that use is not fair.
- Jurisdiction: case-law
- Source: Lenz v. Universal Music Corp., 815 F.3d 1145 (9th Cir. 2016) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/03/17/13-16106.pdf), source id ca9-lenz-2016
- Pinpoint: 815 F.3d 1145 (slip op. 19)
- Quote: "If, however, a copyright holder forms a subjective good faith belief the allegedly infringing material does not constitute fair use, we are in no position to dispute the copyright holder’s belief"
- Checked: 2026-11-10

#### [M-0373] VERIFIED
- Claim: The Copyright Office 2020 report recommends no wholesale change to section 512, only targeted fine-tuning.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary
- Quote: "The Office is not recommending any wholesale changes to section 512"
- Checked: 2026-11-10

#### [M-0374] VERIFIED
- Claim: The report finds courts' readings of knowledge requirements may be narrower than Congress intended (actual vs red flag, willful blindness).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, knowledge requirements
- Quote: "current interpretations of the section 512 knowledge requirements for OSPs may be narrower than Congress initially intended"
- Checked: 2026-11-10

#### [M-0375] VERIFIED
- Claim: The report says courts require willful blindness to involve deliberate avoidance of specific infringements, not infringement generally.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, willful blindness
- Quote: "requires that the willful blindness involve deliberate avoidance of specific incidences of infringement, rather than avoidance of acts of infringement generally"
- Checked: 2026-11-10

#### [M-0376] VERIFIED
- Claim: The report notes the Fourth Circuit reads 'repeat infringer' as repeat alleged infringer, not repeat adjudicated.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, repeat infringer policies
- Quote: "a “repeat infringer” under section 512 means repeat alleged infringer, not repeat adjudicated"
- Checked: 2026-11-10

#### [M-0377] VERIFIED
- Claim: The Office's 2020 report says notice-and-staydown (and website blocking) need additional study, including non-copyright implications and public input, before any proposal.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary (additional study conclusion)
- Quote: "the Office believes that additional study, including of potential non-copyright implications, with public input, would be needed in order to explore the possible contours of any such future proposals."
- Checked: 2026-11-10

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0390] VERIFIED
- Claim: Art 17(4)(b): best efforts, to high industry standards of professional diligence, to ensure unavailability of works the rightholder identified.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(b)
- Quote: "made, in accordance with high industry standards of professional diligence, best efforts to ensure the unavailability of specific works and other subject matter for which the rightholders have provided the service providers with the relevant and necessary information"
- Checked: 2026-11-10

#### [M-0391] VERIFIED
- Claim: Art 17(4)(c): act expeditiously on a substantiated notice and make best efforts to prevent future uploads (notice and stay down).
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(c)
- Quote: "made best efforts to prevent their future uploads in accordance with point (b)"
- Checked: 2026-11-10

#### [M-0392] VERIFIED
- Claim: Art 17(6): new providers under three years old with turnover under EUR 10 million have a lighter regime.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(6)
- Quote: "the services of which have been available to the public in the Union for less than three years and which have an annual turnover below EUR 10 million"
- Checked: 2026-11-10

#### [M-0393] VERIFIED
- Claim: Art 17(7): users may rely on quotation, criticism, review, caricature, parody or pastiche exceptions when uploading.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(7)
- Quote: "Member States shall ensure that users in each Member State are able to rely on any of the following existing exceptions or limitations when uploading and making available content generated by users"
- Checked: 2026-11-10

#### [M-0394] VERIFIED
- Claim: Art 17(8): no general monitoring obligation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(8)
- Quote: "The application of this Article shall not lead to any general monitoring obligation"
- Checked: 2026-11-10

#### [M-0395] VERIFIED
- Claim: Art 17(9): complaint processed without undue delay, with human review of decisions to disable or remove.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(9)
- Quote: "decisions to disable access to or remove uploaded content shall be subject to human review"
- Checked: 2026-11-10

#### [M-0396] VERIFIED
- Claim: Poland v Parliament: the Court dismissed the annulment action, upholding Art 17.
- Jurisdiction: EU
- Source: CJEU Judgment C-401/19 Republic of Poland v European Parliament and Council (26 April 2022) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401), source id cjeu-poland-c401-19
- Pinpoint: Operative part, point 1
- Quote: "Dismisses the action"
- Checked: 2026-11-10

#### [M-0397] VERIFIED
- Claim: Poland: providers cannot be required to filter content whose unlawfulness would need an independent assessment of context and exceptions.
- Jurisdiction: EU
- Source: CJEU Judgment C-401/19 Republic of Poland v European Parliament and Council (26 April 2022) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401), source id cjeu-poland-c401-19
- Pinpoint: Judgment, para 90
- Quote: "cannot be required to prevent the uploading and making available to the public of content which, in order to be found unlawful, would require an independent assessment of the content by them"
- Checked: 2026-11-10

#### [M-0398] VERIFIED
- Claim: Commission 2021 guidance: automated blocking at upload should in principle be limited to manifestly infringing uploads.
- Jurisdiction: EU
- Source: European Commission COM(2021) 288 Guidance on Article 17 of Directive 2019/790 on Copyright in the Digital Single Market (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52021DC0288), source id eu-com-2021-288-art17
- Pinpoint: Part VI (safeguards)
- Quote: "automated blocking, i.e. preventing the upload by the use of technology, should in principle be limited to manifestly infringing uploads"
- Checked: 2026-11-10

#### [M-0399] VERIFIED
- Claim: CDSM Art 3: TDM exception for research organisations and cultural heritage institutions for scientific research.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 3(1)
- Quote: "Member States shall provide for an exception to the rights provided for in Article 5(a) and Article 7(1) of Directive 96/9/EC"
- Checked: 2026-11-10

#### [M-0400] VERIFIED
- Claim: CDSM Art 4: general TDM exception for lawfully accessible works, available unless the rightholder has reserved use in an appropriate manner.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(1), (3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online"
- Checked: 2026-11-10

#### [M-0442] VERIFIED
- Claim: CDSM Art. 4(3): the TDM exception applies only if the use has not been expressly reserved by rightholders, for online content in machine-readable form.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online."
- Checked: 2026-11-10

#### [M-0384] VERIFIED
- Claim: TikTok CML: sounds may not be used in connection with content that violates TikTok's Terms or Community Guidelines.
- Jurisdiction: platform-terms
- Source: TikTok Commercial Music Library - User Terms (https://www.tiktok.com/legal/page/global/commercial-music-library-user-terms/en), source id terms-tiktok-cml-user-terms
- Pinpoint: User Terms, illegal use para
- Quote: "or in connection with any content that is illegal or otherwise violates TikTok’s “Terms of Service” (including any associated “Community Guidelines”)"
- Checked: 2026-11-10

#### [M-0404] VERIFIED
- Claim: Epidemic Sound personal licence is for the licensee's own personal use; content for a corporate channel or on behalf of a third party needs other licences.
- Jurisdiction: platform-terms
- Source: Epidemic Sound licence terms (https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf), source id terms-epidemic-sound
- Pinpoint: License, opening grant
- Quote: "if you are creating content for a corporate channel (meaning a channel owned and/or operated by a business) or creating content on behalf of a third party, you can find other appropriate licenses"
- Checked: 2026-11-10

#### [M-0405] VERIFIED
- Claim: Epidemic Sound: the licence does not allow sublicensing the Production to third parties.
- Jurisdiction: platform-terms
- Source: Epidemic Sound licence terms (https://www.epidemicsound.com/staticfiles/legacy/20/documents/SingleTrackLicensesV8.pdf), source id terms-epidemic-sound
- Pinpoint: License, 'Where can I upload my Production?'
- Quote: "The rights granted herein do not include any right to license or sublicense to any third party the right to exploit the Production"
- Checked: 2026-11-10

#### [M-0408] VERIFIED
- Claim: Musicbed licence is per single audiovisual Project and does not include the right to publicly perform where a PRO licence is available.
- Jurisdiction: platform-terms
- Source: Musicbed licence terms (https://www.musicbed.com/license-terms), source id terms-musicbed
- Pinpoint: License Terms, paras 1 and 1(xii)
- Quote: "except to the extent that the Licensed Content is not available to license through a so-called “performance rights organization” (each, a “PRO”), the Licensed Rights do not include the right to publicly perform the Licensed Content"
- Checked: 2026-11-10

#### [M-0410] VERIFIED
- Claim: Artlist: the saved terms are the site terms of use, and the music licence terms are not in the saved text.
- Jurisdiction: platform-terms
- Source: Artlist licence terms (https://help-center.artlist.io/help-center/privacy-terms/terms-of-use), source id terms-artlist
- Pinpoint: Site terms (whole)
- Quote: "you can’t use the Site and/or the Tools in any manner which is illegal, contrary to court orders and/or which was forbidden by the provisions of any law"
- Checked: 2026-11-10
