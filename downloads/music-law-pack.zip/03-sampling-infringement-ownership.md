# Music law knowledge pack: Sampling, infringement, ownership and deals
- File: 03-sampling-infringement-ownership.md, part of the music law knowledge pack (remix edition).
- Contains: M11 Sampling and interpolation; M12 Infringement, fair use, registration, damages, limitations; M13 Work for hire, transfers, termination; M14 Deal terms. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-10.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M11 Sampling and interpolation
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Can a user put a short sample of a song or beat in a mix; Is a tiny or unrecognizable sample safe (de minimis); Does re-recording a riff or a sound-alike avoid the recording owner; If a platform licenses the recording does it also need the composition; Does fair use cover a few seconds of a sample; Does splitting or re-encoding user audio create sampling risk

### Bottom line
- US federal law: an unlicensed sample needs a licence from the recording owner (master) and, if the composition is recognizably used, from the composition owner (publisher). Which of two circuits you are in decides whether "too small to matter" works as a defence [M-0249, M-0021]. The two-licence point rests on [M-0108, M-0193].
- Re-recording a riff (interpolation) or a sound-alike avoids the master owner only. The composition is still a separate copyright and still needs a licence [M-0111].
- No statute gives a safe number of seconds, and fair use is argued case by case [M-0203, M-0251].
- The section 114 statutory licence does not cover samples in video, so direct sync and master licences are needed [M-0112, M-0312]. (analysis) We have no saved row on section 115.

### Rules
- Two copyrights exist in a recording: the sound recording (master) and the musical work (composition). Both carry the reproduction right [M-0108].
- Recording owners hold only the 106(1), (2), (3) and (6) rights, and the recording's reproduction right covers only duplication that recaptures the actual sounds [M-0296, M-0110].
- Sound-alikes: an independent fixation of other sounds that imitates the recording does not infringe the sound recording copyright, per 114(b) [M-0111]. Narrow: it must be wholly new sounds, not recaptured ones.
- The musical work remains separate, so (analysis) a sound-alike or replayed interpolation still needs a musical work licence [M-0111]. Right of publicity and false endorsement are not covered here (see M17).
- Sixth Circuit (court decision): for sampling a sound recording the rule is "Get a license or do not sample", with no de minimis inquiry [M-0186].
- Ninth Circuit (court decision, VMG Salsoul, 2016): the de minimis exception applies to sound recording sampling, and the court disagrees with the Sixth Circuit [M-0188, M-0189, M-0021].
- The Ninth Circuit reads the statute and history as keeping de minimis for recordings [M-0190].
- Ninth Circuit test: a taking is de minimis only if the average audience would not recognize the appropriation [M-0191]. A three-note sample of a composition (licensed recording) was de minimis in Newton v. Diamond [M-0192].
- Other circuits are not settled in the saved set. Venue matters and a plaintiff may choose a forum (analysis, inference) [M-0249].
- Grand Upright (S.D.N.Y. 1991, district court): preliminary injunction against unlicensed sampling, with a referral to the US Attorney for possible prosecution under 17 U.S.C. 506(a) and 18 U.S.C. 2319.
- A licence for one copyright does not clear the other. In Estate of Smith v. Cash Money (S.D.N.Y. 2017) the defendants had a licence for the recording but not the composition, and that gap created the composition claim [M-0193, M-0250].
- Same case: a 35-second sample was held a fair use on its facts (district court) [M-0212]. Fair use is an affirmative defence, and the party asserting it bears the burden [M-0211]. This case is an adverse example for "licence one, skip the other" only in that fair use happened to win; it is not a safe harbour [M-0250].
- Fair use: 17 U.S.C. 107 sets a four factor, non-exhaustive test and states no number of seconds [M-0203]. The fourth factor is market effect [M-0204]. Background music in a monetised video must be argued on its facts (analysis) [M-0251].
- Proving a sample or copy claim for compositions: the Ninth Circuit en banc rejected the inverse ratio rule [M-0194]. In the Fifth Circuit even overwhelming proof of access does not establish factual copying without probative similarity [M-0195], and copying can be inferred without access only if works are strikingly similar [M-0196]. Batiste affirmed summary judgment for defendants on no evidence of copying [M-0197].
- Interpolation claims turn on protectable expression. Commonplace elements without an original combination are not protected (Ninth Circuit, Gray v. Hudson) [M-0200]. Sheeran (2d Cir. 2024): a selection and arrangement claim built on a four chord progression and syncopated harmonic rhythm failed as a matter of law [M-0202]. For pre-1978 works the 1909 Act protects the composition as defined by the deposited sheet music [M-0201].
- Williams v. Gaye (9th Cir. 2018): the Blurred Lines verdict stood because there was not an absolute absence of evidence of similarity [M-0198, M-0199].
- Statutory licences do not reach a short video: a "digital audio transmission" excludes any audiovisual work [M-0112, M-0297], and the 114(d)(2) licence also requires a non-interactive service [M-0115, M-0298]. 114 would in any case not clear the composition [M-0313].

### Gotchas
- "Sampling is fair use" is wrong as a rule. Estate of Smith found fair use on its own facts, in a district court, and we have no saved row on any later Second Circuit decision (needs source) [M-0212].
- "Licensing the recording clears the song" is wrong. The case behind it was sued on the composition [M-0193].
- The Sixth versus Ninth Circuit split is as of the saved opinions. Later Supreme Court review of the split is not in the saved set (as of 2026-11-10).
- Sound-alike safety is only for the master, only for wholly independent fixation [M-0111].
- Grand Upright and Estate of Smith are district court decisions. Grand Upright was a preliminary injunction, not a final judgment [M-0187].
- Pre-1978 works: composition rights follow the deposited sheet music in the Second Circuit [M-0201].
- Pending bills and AI sound-alike issues are in M15 to M17, not here.

### Open questions for counsel
- US federal, Second, Sixth, Ninth Circuits: which de minimis rule would a court apply to an unlicensed sample in a video hosted by a platform, and where could a plaintiff sue?
- US federal: if a platform is a host under 512 (see M08), does a sample claim change its safe harbour position?
- US federal: what clearance wording should a platform require when a creator says a sample is "cleared"?
- US federal: does a platform's server-side re-encoding and storage of a user's audio create reproduction, performance or host-style exposure for the platform, especially without terms of use or a DMCA contact?
- US federal: what is the current status of Estate of Smith on appeal (a 2d Cir. 2020 summary order is mentioned in some reports but we have no row for it), and does it support a fair use position on short samples?

### Sources
- usc17-106: 17 U.S.C. 106 (https://www.law.cornell.edu/uscode/text/17/106)
- usc17-107: 17 U.S.C. 107 (https://www.law.cornell.edu/uscode/text/17/107)
- usc17-114: 17 U.S.C. 114 (https://www.law.cornell.edu/uscode/text/17/114)
- ca9-vmg-salsoul-2016: VMG Salsoul v. Ciccone (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf)
- ca6-bridgeport-2005: Bridgeport Music v. Dimension Films (https://static.case.law/f3d/410/html/0792-01.html)
- sdny-grand-upright-1991: Grand Upright v. Warner Bros. (https://static.case.law/f-supp/780/html/0182-01.html)
- ca9-newton-diamond-2004: Newton v. Diamond (https://cdn.ca9.uscourts.gov/datastore/opinions/2004/11/09/0255983.pdf)
- sdny-estate-smith-2017: Estate of Smith v. Cash Money (https://static.case.law/f-supp-3d/253/html/0737-01.html)
- ca9-skidmore-2020, ca5-batiste-2020, ca9-williams-gaye-2018, ca9-gray-hudson-2022, ca2-sheeran-2024: https://cdn.ca9.uscourts.gov/datastore/opinions/2020/03/09/16-56057.pdf, https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf, https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf, https://cdn.ca9.uscourts.gov/datastore/opinions/2022/03/10/20-55401.pdf, https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf

### Claims cited in M11
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0249] VERIFIED
- Claim: Analysis: for an unlicensed sample of a sound recording, whether de minimis is a defence depends on the circuit: yes in the Ninth Circuit (VMG Salsoul, 2016), no in the Sixth (Bridgeport, 2005); other circuits are not settled in the saved set, so venue matters and a US plaintiff may choose a forum (inference).
- Jurisdiction: analysis
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, circuit split
- Quote: "We recognize that the Sixth Circuit held to the contrary in Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792"
- Checked: 2026-11-10

#### [M-0021] VERIFIED
- Claim: The Sixth Circuit (Bridgeport, 2005) applies no de minimis defense to sound recording sampling; the Ninth Circuit (VMG Salsoul, 2016) does, creating a circuit split.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, opinion intro, slip op. pp.4-5 (reporter pin 874 likely, saved text unpaginated)
- Quote: "We recognize that the Sixth Circuit held to the contrary in Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792 (6th Cir. 2005), but--like the leading copyright treatise and several district courts--we find Bridgeport's reasoning unpersuasive."
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0193] VERIFIED
- Claim: A Second Circuit district court found a 35-second sample of a spoken-word recording was licensed as to the recording but not as to the composition, which created the composition claim.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 743
- Quote: "Defendants obtained a license for the JSR recording, but not for the JSR composition. (Joint"
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0251] VERIFIED
- Claim: Analysis: fair use is decided case by case on the four factors in 17 U.S.C. 107, including commercial nature and amount used; the statute sets no safe length or seconds rule, so background music in a monetised video must be argued on its facts.
- Jurisdiction: analysis
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0312] VERIFIED
- Claim: Analysis: the 17 U.S.C. 114 statutory licence does not cover short videos on a user upload platform because a "digital audio transmission" under 114(j)(5) does not include the transmission of any audiovisual work.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0296] VERIFIED
- Claim: Sound recording owners have only the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0186] VERIFIED
- Claim: Sixth Circuit rule: for sampling a sound recording, the court says get a license or do not sample (no de minimis or substantial similarity inquiry).
- Jurisdiction: case-law
- Source: Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792 (6th Cir. 2005) (amended on rehearing) (Caselaw Access Project mirror) (https://static.case.law/f3d/410/html/0792-01.html), source id ca6-bridgeport-2005
- Pinpoint: 410 F.3d at 801
- Quote: "Get a license or .do not sample."
- Checked: 2026-11-10

#### [M-0188] VERIFIED
- Claim: The Ninth Circuit holds the de minimis exception applies to sound recording sampling, and expressly disagrees with the Sixth Circuit.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, Part II.B (slip op. at 32)
- Quote: "We hold that the “de minimis” exception applies to actions alleging infringement of a copyright to sound recordings."
- Checked: 2026-11-10

#### [M-0189] VERIFIED
- Claim: VMG Salsoul acknowledges Bridgeport held to the contrary and finds its reasoning unpersuasive.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, Part II.B (slip op. at 31-32)
- Quote: "We recognize that the Sixth Circuit held to the contrary in Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792 (6th Cir. 2005), but--like the leading copyright treatise and several district courts--we find Bridgeport’s reasoning unpersuasive."
- Checked: 2026-11-10

#### [M-0190] VERIFIED
- Claim: VMG Salsoul reads the statutory text and legislative history as showing Congress intended to keep the de minimis exception for sound recordings.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, statutory text discussion
- Quote: "In sum, the statutory text, confirmed by the legislative history, reveals that Congress intended to maintain the de minimis exception for copyrighted sound recordings. In"
- Checked: 2026-11-10

#### [M-0191] VERIFIED
- Claim: In the Ninth Circuit a taking is de minimis only if the average audience would not recognize the appropriation.
- Jurisdiction: case-law
- Source: Newton v. Diamond, 388 F.3d 1189 (9th Cir. 2004) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2004/11/09/0255983.pdf), source id ca9-newton-diamond-2004
- Pinpoint: 388 F.3d 1189, de minimis discussion
- Quote: "observed that a use is de minimis only if the average audience would not recognize the appropriation."
- Checked: 2026-11-10

#### [M-0192] VERIFIED
- Claim: Newton v. Diamond held a three-note sample of a composition (licensed recording) was de minimis and not actionable.
- Jurisdiction: case-law
- Source: Newton v. Diamond, 388 F.3d 1189 (9th Cir. 2004) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2004/11/09/0255983.pdf), source id ca9-newton-diamond-2004
- Pinpoint: 388 F.3d 1189, concluding paragraph
- Quote: "We hold that Beastie Boys’ use of a brief segment of that composition, consisting of three notes separated by a half-step"
- Checked: 2026-11-10

#### [M-0250] VERIFIED
- Claim: In Estate of Smith v. Cash Money (S.D.N.Y. 2017) the defendants had a licence for the recording but not for the composition and were sued on the composition; the court found fair use on its facts. Recording and composition are separate copyrights, so (analysis) a licence for one does not by itself clear the other.
- Jurisdiction: analysis
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 743
- Quote: "Defendants obtained a license for the JSR recording, but not for the JSR composition. (Joint"
- Checked: 2026-11-10

#### [M-0212] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017) held a 35-second sample in Pound Cake was a fair use of the Jimmy Smith composition.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 752
- Quote: "this Court concludes that Defendants’ inclusion of the copied portions of JSR in the recording of Pound Cake is a fair use and"
- Checked: 2026-11-10

#### [M-0211] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017): fair use is an affirmative defense and the party asserting it bears the burden.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 748 (Part on fair use; burden sentence follows)
- Quote: "Fair use is an affirmative defense to copyright infringement"
- Checked: 2026-11-10

#### [M-0204] VERIFIED
- Claim: The fourth fair use factor is the effect on the potential market for or value of the work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107(4)
- Quote: "the effect of the use upon the potential market for or value of the copyrighted"
- Checked: 2026-11-10

#### [M-0194] VERIFIED
- Claim: The Ninth Circuit en banc rejected the inverse ratio rule (a high degree of access lowering the proof of substantial similarity).
- Jurisdiction: case-law
- Source: Skidmore v. Led Zeppelin, 952 F.3d 1051 (9th Cir. 2020) (en banc) (https://cdn.ca9.uscourts.gov/datastore/opinions/2020/03/09/16-56057.pdf), source id ca9-skidmore-2020
- Pinpoint: 952 F.3d 1051, summary Part IV.A
- Quote: "the en banc court rejected the inverse ratio rule, which requires a lower standard of proof of substantial similarity when a high degree of access is"
- Checked: 2026-11-10

#### [M-0195] VERIFIED
- Claim: Fifth Circuit: even with overwhelming proof of access, a plaintiff cannot establish factual copying without some showing of probative similarity.
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, access and copying discussion
- Quote: "can’t establish factual copying “without some showing of probative similarity.”"
- Checked: 2026-11-10

#### [M-0196] VERIFIED
- Claim: In the Fifth Circuit factual copying can be inferred without proof of access only if the works are strikingly similar.
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, access and copying discussion
- Quote: "a plaintiff may raise an inference of factual copying without any proof of access if the works are “strikingly similar.”"
- Checked: 2026-11-10

#### [M-0197] VERIFIED
- Claim: Fifth Circuit in Batiste affirmed summary judgment for the defendants because there was no evidence of copying (the original quote states the district court's ground).
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, introduction
- Quote: "Finding no evidence of copying, the district court granted summary"
- Checked: 2026-11-10

#### [M-0200] VERIFIED
- Claim: Gray v. Hudson (Dark Horse): commonplace musical elements, without an original combination, are not protected, so the verdict was set aside.
- Jurisdiction: case-law
- Source: Gray v. Hudson, 28 F.4th 87 (9th Cir. 2022) (Dark Horse) (https://cdn.ca9.uscourts.gov/datastore/opinions/2022/03/10/20-55401.pdf), source id ca9-gray-hudson-2022
- Pinpoint: 28 F.4th 87, summary
- Quote: "The panel concluded that the ostinatos at issue here consisted entirely of commonplace musical elements, and the similarities between them did not arise out of an original combination of these elements."
- Checked: 2026-11-10

#### [M-0202] VERIFIED
- Claim: Sheeran held a selection-and-arrangement claim built on a four-chord progression and syncopated harmonic rhythm fails as a matter of law.
- Jurisdiction: case-law
- Source: Structured Asset Sales, LLC v. Sheeran, 120 F.4th 1066 (2d Cir. Nov. 1, 2024) (Thinking Out Loud) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf), source id ca2-sheeran-2024
- Pinpoint: 120 F.4th 1066, Part I (intro)
- Quote: "Even when combined, the four-chord progression and syncopated harmonic rhythm at issue are too unoriginal for copyright protection. Plaintiff"
- Checked: 2026-11-10

#### [M-0201] VERIFIED
- Claim: Sheeran (2d Cir. 2024): for a pre-1978 work, the Copyright Act of 1909 protects only the musical composition as defined by the sheet music deposited with the Copyright Office.
- Jurisdiction: case-law
- Source: Structured Asset Sales, LLC v. Sheeran, 120 F.4th 1066 (2d Cir. Nov. 1, 2024) (Thinking Out Loud) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf), source id ca2-sheeran-2024
- Pinpoint: 120 F.4th 1066, Part I (intro)
- Quote: "the Copyright Act of 1909 protects only the musical composition of Let’s Get It On as defined by the sheet music deposited with the Copyright Office in 1973."
- Checked: 2026-11-10

#### [M-0198] VERIFIED
- Claim: Williams v. Gaye (9th Cir. 2018) affirmed in part and reversed in part after a jury trial: the Blurred Lines verdict was upheld, damages and royalty held proper, and the vicarious liability finding and JMOL on one party's verdict were reversed.
- Jurisdiction: case-law
- Source: Williams v. Gaye, 895 F.3d 1106 (9th Cir. 2018) (amended opinion, July 11, 2018) (https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf), source id ca9-williams-gaye-2018
- Pinpoint: 895 F.3d 1106, summary
- Quote: "affirmed in part and reversed in part the district court’s judgment after a jury trial, ruling that plaintiffs’ song “Blurred"
- Checked: 2026-11-10

#### [M-0199] VERIFIED
- Claim: In Williams v. Gaye the verdict stood because there was not an absolute absence of evidence of extrinsic and intrinsic similarity.
- Jurisdiction: case-law
- Source: Williams v. Gaye, 895 F.3d 1106 (9th Cir. 2018) (amended opinion, July 11, 2018) (https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf), source id ca9-williams-gaye-2018
- Pinpoint: 895 F.3d 1106, summary
- Quote: "not an absolute absence of evidence of extrinsic and intrinsic similarity between the two"
- Checked: 2026-11-10

#### [M-0297] VERIFIED
- Claim: A digital audio transmission is a digital transmission that embodies a sound recording and does not include transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "A digital audio transmission is a digital transmission as defined in section 101, that embodies the transmission of a sound recording. This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0298] VERIFIED
- Claim: The 114 statutory licence reaches subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite DARS transmissions, and the transmission must not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service"
- Checked: 2026-11-10

#### [M-0313] VERIFIED
- Claim: Analysis: if a platform qualified as an interactive service, 114(d)(3)(C) would still require a licence for the public performance of each musical work in the sound recording, which may come from a performing rights society or the copyright owner.
- Jurisdiction: analysis
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0187] VERIFIED
- Claim: Grand Upright (S.D.N.Y. 1991) granted a preliminary injunction against unlicensed sampling, condemned it in strong terms ("Thou shalt not steal") and referred the defendants to the U.S. Attorney for consideration of prosecution under 17 U.S.C. 506(a) and 18 U.S.C. 2319.
- Jurisdiction: case-law
- Source: Grand Upright Music Ltd. v. Warner Bros. Records, Inc., 780 F. Supp. 182 (S.D.N.Y. 1991) (Caselaw Access Project mirror) (https://static.case.law/f-supp/780/html/0182-01.html), source id sdny-grand-upright-1991
- Pinpoint: 780 F. Supp. at 185
- Quote: "This matter is respectfully referred to the United States Attorney for the Southern District of New York for consideration of prosecution of these defendants under 17 U.S.C. § 506(a) and"
- Checked: 2026-11-10

## M12 Infringement, fair use, registration, damages, limitations
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Is a 15 second clip of a song in a monetised mix fair use; How much can a copyright owner recover from a platform or a user; Does an owner have to register before suing; How long after an upload can a music claim be brought; How does a plaintiff prove a song was copied; Does a mix that uses many songs multiply the damages

### Bottom line
US federal law: using a song in a video without a licence can infringe whichever copyright is used, unless a defence such as fair use applies, the composition, the recording, or both [M-0220, M-0028, M-0029]. Fair use is a case by case defence with no safe number of seconds [M-0203, M-0251]. Statutory damages run $750 to $30,000 per work, up to $150,000 if willful, but only for works registered in time [M-0215, M-0217, M-0214]. The suit deadline is three years from accrual, and a timely claim can reach old infringements (discovery rule assumed) [M-0218, M-0219].

### Rules
#### Infringement and proof (US federal unless stated)
- Anyone who violates an exclusive right of the copyright owner is an infringer [M-0220].
- Musical works, including accompanying words, are protected [M-0028]. Sound recordings are a separate category [M-0029, M-0105]. One song is therefore two works (analysis, M-0254).
- Ninth Circuit en banc (court decision, 2020): the inverse ratio rule is rejected, so strong proof of access does not lower the similarity showing [M-0194].
- Fifth Circuit (court decision, 2020): even with overwhelming proof of access, factual copying needs some probative similarity [M-0195]. Without proof of access, copying can be inferred only if the works are strikingly similar [M-0196]. Summary judgment for the defendants was affirmed for lack of evidence of copying [M-0197].
- Ninth Circuit (court decision, 2018, Blurred Lines): the verdict stood because evidence of extrinsic and intrinsic similarity was not absent [M-0199]. The panel affirmed in part and reversed in part: damages and a running royalty were proper, while the vicarious liability finding and one party's verdict were reversed [M-0198].
- Ninth Circuit (court decision, 2022, Dark Horse): commonplace musical elements, without an original combination, are not protected, so the verdict was set aside [M-0200].
- Second Circuit (court decision, 2024, Thinking Out Loud): a pre 1978 work under the 1909 Act is protected only as to the composition as defined by the deposited sheet music [M-0201]. A selection and arrangement claim built on a four chord progression and syncopated harmonic rhythm failed as a matter of law [M-0202].

#### Fair use
- Section 107 is a four factor, non exhaustive test and states no number of seconds [M-0203]. Factor four is the effect on the potential market for or value of the work [M-0204].
- Campbell (Supreme Court, 1994): fair use is case by case and bright line rules do not fit [M-0205]. Factor one asks whether the new work merely supersedes the original or adds new expression, meaning or message [M-0206]. The more transformative the use, the less weight commercialism carries [M-0207].
- Warhol (Supreme Court, 2023): factor one asks whether the use has a further purpose or different character, a matter of degree weighed against commercialism [M-0208]. The court looked at the specific use alleged to infringe, there the licensing, not the work in the abstract [M-0210]. Licensing the image to a magazine did not favour fair use [M-0209].
- Analysis: fair use is decided on the facts, including commercial nature and amount used, so background music in a monetised video must be argued case by case [M-0251].

#### Registration, damages, limitations
- Subject to exceptions in section 411, no civil action for infringement of a US work may start until preregistration or registration has been made [M-0213].
- No statutory damages or fees for infringement of a published work that began before registration, unless registered within three months of publication [M-0214].
- Statutory damages: $750 to $30,000 per work, at the owner's election [M-0215]. They are assessed per work for all infringements in the action and may be elected any time before final judgment [M-0216]. Willful infringement raises the maximum to $150,000 per work [M-0217].
- Analysis: exposure is per work, not per view or per video, and a song can be two works, composition and recording [M-0254].
- Civil limitations period: three years after the claim accrued [M-0218].
- Nealy (Supreme Court, 2024): assuming without deciding that the discovery rule applies, a timely claim can recover damages for any infringement, with no separate three year damages bar [M-0024, M-0219].

#### Safe harbour link (court decision)
- Fourth Circuit, BMG v. Cox (2018): a provider needs a repeat infringer policy adopted and reasonably implemented to use the section 512 safe harbour [M-0230]. Cox lost it by not enforcing the policy meaningfully [M-0231, M-0253]. The provider bears the burden of proof [M-0233].
- BMG's "knew or should have known" contributory standard was called negligence and too low [M-0232]. The Supreme Court in Cox (2026) later held contributory liability cannot rest only on knowledge plus insufficient action [M-0224].

### Gotchas
- No seconds rule, no "non commercial" rule, no "credit the artist" rule. The four factors decide [M-0203, M-0205].
- Transformative is a matter of degree and is judged on the specific use; licensing or monetising weighs against it [M-0208, M-0209, M-0210].
- Nealy assumed the discovery rule without deciding it [M-0024]. Do not say the Supreme Court adopted it.
- Fifth and Ninth Circuit similarity rules differ in detail; name the circuit [M-0195, M-0194]. Batiste is a Fifth Circuit rule on access, not nationwide [M-0196].
- Sheeran concerns a pre 1978 work and the 1909 Act only [M-0201].
- Williams v. Gaye is mixed: verdict stood, vicarious liability reversed [M-0198].
- BMG v. Cox on contributory liability is overtaken by Cox 2026 [M-0232, M-0224]. Its repeat infringer point on section 512(i) stands [M-0230].
- Statutory damage figures are those in the saved text as of 2026-11-10 [M-0215].
- State publicity claims and Section 230 differ by circuit: Third Circuit Hepp (2021) held 230 does not preclude them, while the Ninth Circuit reads the carve out as federal IP only [M-0485, M-0486]. Extension to voice clones is inference; see M16 and M17.
- Currency: Grande remand outcome is a needs source gap; do not guess.

### Open questions for counsel
- US federal: for a monetised video with 20 seconds of a commercial track under a creator's own edit, what is the realistic fair use position under Campbell and Warhol?
- US federal: which of a platform's catalogue risks are registered works, and does section 412 limit statutory damages for newly registered music?
- Ninth Circuit: does accrual under section 507(b) follow the discovery rule for continuing uploads, given Nealy only assumed it?
- US federal: does a live stream performance of a track create separate infringements per stream for damages purposes?
- US federal: does a platform's re-encoding of user audio expose the platform itself to a direct or secondary claim?

### Sources
- usc17-107: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107)
- usc17-102: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102)
- usc17-411, usc17-412, usc17-501, usc17-504, usc17-507: 17 U.S.C. 411, 412, 501, 504, 507 (law.cornell.edu/uscode/text/17/<section>)
- scotus-campbell-1994: Campbell v. Acuff-Rose Music, 510 U.S. 569 (1994) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf)
- scotus-warhol-2023: Andy Warhol Foundation v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf)
- scotus-nealy-2024: Warner Chappell Music v. Nealy, 601 U.S. 366 (2024) (https://www.supremecourt.gov/opinions/23pdf/22-1078_4gci.pdf)
- ca9-skidmore-2020, ca9-williams-gaye-2018, ca9-gray-hudson-2022, ca5-batiste-2020, ca2-sheeran-2024, ca4-bmg-cox-2018: case sources at https://cdn.ca9.uscourts.gov/datastore/opinions/2020/03/09/16-56057.pdf, https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf, https://cdn.ca9.uscourts.gov/datastore/opinions/2022/03/10/20-55401.pdf, https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf, https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf, https://static.case.law/f3d/881/html/0293-01.html

### Claims cited in M12
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0028] VERIFIED
- Claim: 17 U.S.C. 102(a) lists musical works, including any accompanying words, among the categories of copyrightable original works of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(2)
- Quote: "musical works, including any accompanying words; (3) dramatic"
- Checked: 2026-11-10

#### [M-0029] VERIFIED
- Claim: Sound recordings are listed as their own category of copyrightable work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "sound recordings; and (8)"
- Checked: 2026-11-10

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0251] VERIFIED
- Claim: Analysis: fair use is decided case by case on the four factors in 17 U.S.C. 107, including commercial nature and amount used; the statute sets no safe length or seconds rule, so background music in a monetised video must be argued on its facts.
- Jurisdiction: analysis
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0215] VERIFIED
- Claim: Statutory damages range from $750 to $30,000 per work, as the court considers just, at the owner's election.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "in a sum of not less than $750 or more than $30,000 as the court considers just."
- Checked: 2026-11-10

#### [M-0217] VERIFIED
- Claim: Willful infringement raises the statutory maximum to $150,000 per work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0214] VERIFIED
- Claim: No statutory damages or fees for infringement of a published work that commenced before its registration, unless registered within three months of publication.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 412 registration as prerequisite to certain remedies (https://www.law.cornell.edu/uscode/text/17/412), source id usc17-412
- Pinpoint: 17 U.S.C. 412(2)
- Quote: "any infringement of copyright commenced after first publication of the work and before the effective date of its registration, unless such registration is made within three months after the first publication of the work."
- Checked: 2026-11-10

#### [M-0218] VERIFIED
- Claim: The civil statute of limitations is three years after the claim accrued.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 507 limitations on actions (https://www.law.cornell.edu/uscode/text/17/507), source id usc17-507
- Pinpoint: 17 U.S.C. 507(b)
- Quote: "No civil action shall be maintained under the provisions of this title unless it is commenced within three years after the claim accrued."
- Checked: 2026-11-10

#### [M-0219] VERIFIED
- Claim: Nealy: a timely claim (under the discovery rule, assumed) may recover damages for any infringement, no matter how old; the Act sets no separate three-year damages bar.
- Jurisdiction: case-law
- Source: Warner Chappell Music, Inc. v. Nealy, 601 U.S. 366 (2024) (https://www.supremecourt.gov/opinions/23pdf/22-1078_4gci.pdf), source id scotus-nealy-2024
- Pinpoint: 601 U.S. 366, syllabus
- Quote: "The Copyright Act entitles a copyright owner to obtain monetary relief for any timely infringement claim, no matter when the infringement"
- Checked: 2026-11-10

#### [M-0105] VERIFIED
- Claim: The listed categories of copyrightable works include sound recordings, separately from musical works.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "(7) sound recordings; and"
- Checked: 2026-11-10

#### [M-0194] VERIFIED
- Claim: The Ninth Circuit en banc rejected the inverse ratio rule (a high degree of access lowering the proof of substantial similarity).
- Jurisdiction: case-law
- Source: Skidmore v. Led Zeppelin, 952 F.3d 1051 (9th Cir. 2020) (en banc) (https://cdn.ca9.uscourts.gov/datastore/opinions/2020/03/09/16-56057.pdf), source id ca9-skidmore-2020
- Pinpoint: 952 F.3d 1051, summary Part IV.A
- Quote: "the en banc court rejected the inverse ratio rule, which requires a lower standard of proof of substantial similarity when a high degree of access is"
- Checked: 2026-11-10

#### [M-0195] VERIFIED
- Claim: Fifth Circuit: even with overwhelming proof of access, a plaintiff cannot establish factual copying without some showing of probative similarity.
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, access and copying discussion
- Quote: "can’t establish factual copying “without some showing of probative similarity.”"
- Checked: 2026-11-10

#### [M-0196] VERIFIED
- Claim: In the Fifth Circuit factual copying can be inferred without proof of access only if the works are strikingly similar.
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, access and copying discussion
- Quote: "a plaintiff may raise an inference of factual copying without any proof of access if the works are “strikingly similar.”"
- Checked: 2026-11-10

#### [M-0197] VERIFIED
- Claim: Fifth Circuit in Batiste affirmed summary judgment for the defendants because there was no evidence of copying (the original quote states the district court's ground).
- Jurisdiction: case-law
- Source: Batiste v. Lewis, 976 F.3d 493 (5th Cir. 2020) (https://www.ca5.uscourts.gov/opinions/pub/19/19-30400-CV0.pdf), source id ca5-batiste-2020
- Pinpoint: 976 F.3d 493, introduction
- Quote: "Finding no evidence of copying, the district court granted summary"
- Checked: 2026-11-10

#### [M-0199] VERIFIED
- Claim: In Williams v. Gaye the verdict stood because there was not an absolute absence of evidence of extrinsic and intrinsic similarity.
- Jurisdiction: case-law
- Source: Williams v. Gaye, 895 F.3d 1106 (9th Cir. 2018) (amended opinion, July 11, 2018) (https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf), source id ca9-williams-gaye-2018
- Pinpoint: 895 F.3d 1106, summary
- Quote: "not an absolute absence of evidence of extrinsic and intrinsic similarity between the two"
- Checked: 2026-11-10

#### [M-0198] VERIFIED
- Claim: Williams v. Gaye (9th Cir. 2018) affirmed in part and reversed in part after a jury trial: the Blurred Lines verdict was upheld, damages and royalty held proper, and the vicarious liability finding and JMOL on one party's verdict were reversed.
- Jurisdiction: case-law
- Source: Williams v. Gaye, 895 F.3d 1106 (9th Cir. 2018) (amended opinion, July 11, 2018) (https://cdn.ca9.uscourts.gov/datastore/opinions/2018/07/11/15-56880.pdf), source id ca9-williams-gaye-2018
- Pinpoint: 895 F.3d 1106, summary
- Quote: "affirmed in part and reversed in part the district court’s judgment after a jury trial, ruling that plaintiffs’ song “Blurred"
- Checked: 2026-11-10

#### [M-0200] VERIFIED
- Claim: Gray v. Hudson (Dark Horse): commonplace musical elements, without an original combination, are not protected, so the verdict was set aside.
- Jurisdiction: case-law
- Source: Gray v. Hudson, 28 F.4th 87 (9th Cir. 2022) (Dark Horse) (https://cdn.ca9.uscourts.gov/datastore/opinions/2022/03/10/20-55401.pdf), source id ca9-gray-hudson-2022
- Pinpoint: 28 F.4th 87, summary
- Quote: "The panel concluded that the ostinatos at issue here consisted entirely of commonplace musical elements, and the similarities between them did not arise out of an original combination of these elements."
- Checked: 2026-11-10

#### [M-0201] VERIFIED
- Claim: Sheeran (2d Cir. 2024): for a pre-1978 work, the Copyright Act of 1909 protects only the musical composition as defined by the sheet music deposited with the Copyright Office.
- Jurisdiction: case-law
- Source: Structured Asset Sales, LLC v. Sheeran, 120 F.4th 1066 (2d Cir. Nov. 1, 2024) (Thinking Out Loud) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf), source id ca2-sheeran-2024
- Pinpoint: 120 F.4th 1066, Part I (intro)
- Quote: "the Copyright Act of 1909 protects only the musical composition of Let’s Get It On as defined by the sheet music deposited with the Copyright Office in 1973."
- Checked: 2026-11-10

#### [M-0202] VERIFIED
- Claim: Sheeran held a selection-and-arrangement claim built on a four-chord progression and syncopated harmonic rhythm fails as a matter of law.
- Jurisdiction: case-law
- Source: Structured Asset Sales, LLC v. Sheeran, 120 F.4th 1066 (2d Cir. Nov. 1, 2024) (Thinking Out Loud) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-23-00905/pdf/USCOURTS-ca2-23-00905-0.pdf), source id ca2-sheeran-2024
- Pinpoint: 120 F.4th 1066, Part I (intro)
- Quote: "Even when combined, the four-chord progression and syncopated harmonic rhythm at issue are too unoriginal for copyright protection. Plaintiff"
- Checked: 2026-11-10

#### [M-0204] VERIFIED
- Claim: The fourth fair use factor is the effect on the potential market for or value of the work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107(4)
- Quote: "the effect of the use upon the potential market for or value of the copyrighted"
- Checked: 2026-11-10

#### [M-0205] VERIFIED
- Claim: Campbell: fair use requires case-by-case analysis and is not simplified by bright-line rules.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 577 (Part II.A, opinion of the Court)
- Quote: "The task is not to be simplified with bright-line rules, for the statute, like the doctrine it recognizes, calls for case-by-case analysis."
- Checked: 2026-11-10

#### [M-0206] VERIFIED
- Claim: Campbell: the first factor asks whether the new work merely supersedes the original or is transformative, adding new expression, meaning or message.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus 1(b)
- Quote: "the enquiry focuses on whether the new work merely supersedes the objects of the original creation, or whether and to what extent it is "transformative,""
- Checked: 2026-11-10

#### [M-0207] VERIFIED
- Claim: Campbell: the more transformative the new work, the less the weight of factors like commercialism.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus 1(b)
- Quote: "The more transformative the new work, the less will be the significance of other factors, like"
- Checked: 2026-11-10

#### [M-0208] VERIFIED
- Claim: Warhol: the first factor focuses on whether the use has a further purpose or different character, which is a matter of degree, weighed against other considerations like commercialism.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, Part II.A (Opinion of the Court); also syllabus
- Quote: "the first fair use factor instead focuses on whether an allegedly infringing use has a further purpose or different character, which is a matter of degree"
- Checked: 2026-11-10

#### [M-0210] VERIFIED
- Claim: Warhol: the analysis is of the specific use alleged to infringe, here the licensing, not the work in the abstract.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "the specific use of Goldsmith’s photograph alleged to infringe her copyright is AWF’s licensing"
- Checked: 2026-11-10

#### [M-0209] VERIFIED
- Claim: Warhol: the purpose and character of licensing the Orange Prince image to a magazine did not favour fair use.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "The “purpose and character” of AWF’s use of Goldsmith’s photograph in commercially licensing Orange Prince to Condé Nast does not favor AWF’s fair use defense"
- Checked: 2026-11-10

#### [M-0213] VERIFIED
- Claim: Subject to the exceptions in section 411, no civil action for infringement of a US work may be instituted until preregistration or registration has been made.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 411 registration and civil infringement actions (https://www.law.cornell.edu/uscode/text/17/411), source id usc17-411
- Pinpoint: 17 U.S.C. 411(a)
- Quote: "no civil action for infringement of the copyright in any United States work shall be instituted until preregistration or registration of the copyright claim has been made in accordance with this"
- Checked: 2026-11-10

#### [M-0216] VERIFIED
- Claim: Statutory damages are assessed per work for all infringements involved in the action; the owner may elect them any time before final judgment.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "an award of statutory damages for all infringements involved in the action, with respect to any one"
- Checked: 2026-11-10

#### [M-0254] VERIFIED
- Claim: Analysis: statutory damages are awarded per work infringed, up to $150,000 per work if willful (ordinary range $750 to $30,000), and only for works registered in time (s.412); exposure is per work, not per view.
- Jurisdiction: analysis
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0024] VERIFIED
- Claim: Nealy (2024): assuming without deciding that the discovery rule governs timeliness, a copyright owner with a timely claim can recover damages for any timely claim, with no separate three-year damages limit.
- Jurisdiction: case-law
- Source: Warner Chappell Music, Inc. v. Nealy, 601 U.S. 366 (2024) (https://www.supremecourt.gov/opinions/23pdf/22-1078_4gci.pdf), source id scotus-nealy-2024
- Pinpoint: slip op., Opinion of the Court, holding
- Quote: "We hold that no such limit on damages exists. The Copyright Act entitles a copyright owner to recover damages for any timely claim."
- Checked: 2026-11-10

#### [M-0230] VERIFIED
- Claim: BMG v. Cox (4th Cir. 2018): to use the section 512 safe harbour a provider must have adopted and reasonably implemented a policy to terminate repeat infringers.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 301 (Part II.A)
- Quote: "adopted and reasonably implemented ... a policy that provides for the termination in appropriate circumstances of subscribers ... who are repeat infringers.” 17 U.S.C."
- Checked: 2026-11-10

#### [M-0231] VERIFIED
- Claim: BMG v. Cox held the safe harbour was lost because the provider failed to implement its repeat infringer policy consistently or meaningfully.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305 (Part II.B)
- Quote: "Cox failed to qualify for the DMCA safe harbor because it failed to implement its policy in any consistent or meaningful way--leaving"
- Checked: 2026-11-10

#### [M-0253] VERIFIED
- Claim: Analysis: BMG v. Cox (4th Cir. 2018) held Cox failed to qualify for the DMCA 512 safe harbour because it did not implement its repeat infringer policy consistently or meaningfully, leaving it essentially with no policy.
- Jurisdiction: analysis
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305
- Quote: "Cox failed to qualify for the DMCA safe harbor because it failed to implement its policy in any consistent or meaningful way--leaving"
- Checked: 2026-11-10

#### [M-0233] VERIFIED
- Claim: The provider bears the burden of proof on the DMCA safe harbour defence.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 305 (Part II.B)
- Quote: "Cox bears the burden of proof on the DMCA safe harbor"
- Checked: 2026-11-10

#### [M-0232] VERIFIED
- Claim: BMG v. Cox held the 'knew or should have known' contributory standard is negligence and too low.
- Jurisdiction: case-law
- Source: BMG Rights Mgmt v. Cox Communications, 881 F.3d 293 (4th Cir. 2018) (https://static.case.law/f3d/881/html/0293-01.html), source id ca4-bmg-cox-2018
- Pinpoint: 881 F.3d at 310 (Part III.B)
- Quote: "The formulation “should have known” reflects negligence and is therefore too low a standard."
- Checked: 2026-11-10

#### [M-0224] VERIFIED
- Claim: Cox (2026): the Fourth Circuit's knowledge-plus-insufficient-action rule went beyond the two recognised bases and conflicted with the Court's precedent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part III
- Quote: "contributory liability cannot rest only on a provider’s knowledge of infringement and insufficient action to prevent it."
- Checked: 2026-11-10

#### [M-0485] VERIFIED
- Claim: Hepp v. Facebook (3d Cir. 2021): state right of publicity claims fall within the 230(e)(2) intellectual property carve-out and are not precluded by Section 230.
- Jurisdiction: case-law
- Source: Hepp v. Facebook, 14 F.4th 204 (3d Cir. 2021) (https://www2.ca3.uscourts.gov/opinarch/202725p.pdf), source id ca3-hepp-2021
- Pinpoint: opinion introduction (before Part I); reporter page not marked in saved copy
- Quote: "Because those claims are encompassed within the intellectual property carve-out, § 230(e)(2), we hold they are not precluded."
- Checked: 2026-11-10

#### [M-0486] VERIFIED
- Claim: Analysis: in the Third Circuit (PA, NJ, DE) Hepp holds Section 230 does not preclude state right of publicity claims, so a platform should not expect 230 to shield such claims over voice clones there (extension to voice clones is inference); other circuits differ, and the Ninth Circuit CCBill rule as described in Hepp reads 230(e)(2) as federal IP only.
- Jurisdiction: analysis
- Source: Hepp v. Facebook, 14 F.4th 204 (3d Cir. 2021) (https://www2.ca3.uscourts.gov/opinarch/202725p.pdf), source id ca3-hepp-2021
- Pinpoint: 14 F.4th 204, 208-09
- Quote: "Because those claims are encompassed within the intellectual property carve-out, § 230(e)(2), we hold they are not precluded."
- Checked: 2026-11-10

## M13 Work for hire, transfers, termination
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Who owns a song or recording a creator made for a label or publisher; Does a user who mixes others' music own the mix; Can a songwriter or artist take back a music grant years later; Does a licence signed before termination survive it; Does a transfer need to be in writing; Who owns music made for the platform by a contractor

### Bottom line
US federal law: the first owner of a copyright is the author, unless the work is made for hire, in which case the employer or commissioning party is the author [M-0037, M-0048]. A transfer of ownership needs a signed writing [M-0040]. Authors (not work-for-hire employers) can usually terminate grants decades later, and no contract can waive that right [M-0055, M-0059]. For a platform this decides who can sign a sync licence (composition) or a master use licence (recording): you must trace title from the author through every transfer, and no ownership claim by a creator, label or publisher proves a song is cleared.

This is not legal advice. A licensed music attorney must confirm chain of title, work for hire clauses and termination notices before anyone relies on this card.

### Rules
#### Who is the author (US federal, 17 U.S.C. 101 and 201)
- Copyright vests initially in the author; authors of a joint work are co-owners [M-0037]. A joint work is made by two or more authors who intend their contributions to merge into a unitary whole [M-0036].
- A work made for hire is either work by an employee within the scope of employment, or a commissioned work in one of nine listed categories with a signed written agreement [M-0045].
- For commissioned works the categories include a contribution to a collective work, part of a motion picture or other audiovisual work, and a compilation, and the parties must expressly agree in a signed writing [M-0046].
- The employer or commissioning party is the author and owns all rights unless the parties agree otherwise in a signed writing [M-0048].
- The category list does not name sound recordings. Whether a recording is made for hire turns on the employee prong or on fitting a category such as compilation or part of an audiovisual work (analysis) [M-0047].
- Courts apply the 1909 Act "instance and expense" test to older works when deciding work made for hire under Section 304(c): Marvel v. Kirby (2d Cir. 2013) (court decision) [M-0054]. The saved quote is PARTIAL (line numbers interleave), so rely on the claim, not a block quote.
- Waite v. UMG (S.D.N.Y. 31 March 2020, motion to dismiss) (court decision): the court did not decide whether the recordings were made for hire, because the label raised it only on limitations. It found the label's authority for treating albums as compilations unpersuasive [M-0049]. It also noted that the industry frequently inserts work-for-hire language into recording contracts [M-0050]. The artists had asked for a declaration that recordings cannot be made for hire; that is a pleading, not a holding [M-0051].
- Ray Charles Foundation v. Robinson (9th Cir. 2015) (court decision): the foundation could challenge whether works were made for hire, and so not terminable. It was a real party in interest and had standing. The merits were not decided [M-0069, M-0070].

#### Transfers (US federal, 17 U.S.C. 201, 204, 205)
- Ownership can be transferred in whole or part by any means of conveyance or by operation of law [M-0038]. Each exclusive right, and any subdivision, can be owned separately [M-0039].
- A transfer of ownership, other than by operation of law, is not valid unless in a writing signed by the owner or the owner's authorized agent [M-0040].
- "Transfer of copyright ownership" covers an assignment or exclusive licence but not a nonexclusive licence [M-0034]. So a nonexclusive licence is not caught by the Section 204(a) writing rule as a transfer (analysis, narrow).
- A signed transfer can be recorded in the Copyright Office, with a real signature or a sworn or official certification of a true copy [M-0041].
- Between two conflicting transfers, the first executed wins if recorded within one month (two months abroad) or before the later one is recorded [M-0042]. The statute has a further rule for the later transfer (see 17 U.S.C. 205(d)); it is not covered by a ledger row here.
- A nonexclusive licence, recorded or not, beats a conflicting transfer if it is in a signed written instrument and was taken before the transfer or in good faith before its recordation and without notice [M-0043].

#### Which copyright, which grant
- A recording and the underlying composition are separate works with separate copyrights [M-0025]. The Office treats a recording as a derivative work of the composition [M-0026, M-0035]. Authors differ: composition by composers, lyricists and songwriters; recording by performers, producers and sound engineers as the circular lists them [M-0027].
- Section 101 excludes sounds accompanying a motion picture or other audiovisual work from "sound recordings" and "phonorecords" [M-0030, M-0031, M-0118, M-0119, M-0337, M-0338]. A music track embedded in a short video is still treated as keeping its own composition and recording copyrights, but that is an inference (unverified) [M-0032].
- Performing rights societies license public performance of nondramatic musical works for owners [M-0341]. They are not the source of a sync or master grant.

#### Duration (US federal)
- Works from 1 January 1978 on: life of the author plus 70 years, with exceptions for joint, anonymous, pseudonymous and made-for-hire works [M-0044].

#### Termination of grants (US federal)
- Section 203 applies to grants by an author executed on or after 1 January 1978, other than works made for hire and other than by will [M-0055]. Window: five years starting 35 years after execution (or after publication, or 40 years after execution, whichever ends earlier, if the grant covers publication) [M-0056].
- Notice is served two to ten years before the effective date [M-0057]. A copy must be recorded before the effective date or termination does not take effect [M-0058].
- It works notwithstanding any agreement to the contrary [M-0059]. Unless terminated, a grant lasts for the term of copyright unless it says otherwise [M-0061].
- Derivative works exception: a derivative work made under the grant before termination may continue to be used under the grant's terms, but no new derivative works may be made afterwards [M-0060].
- A further grant of terminated rights is valid only if made after the effective date, except that the original grantee or its successor can agree a further grant after notice is served [M-0062].
- Section 304(c) covers pre-1978 grants of the renewal term, other than works made for hire [M-0063]. Window: five years starting 56 years after copyright was first secured, or 1 January 1978, whichever is later [M-0064]. Notice is again two to ten years ahead, with a copy recorded [M-0065]. Same derivative works exception [M-0066].
- Mills Music v. Snyder (U.S. Supreme Court 1985) (court decision): a publisher keeps its contractual share of royalties from pre-termination recordings under the 304(c)(6)(A) exception, because the recordings are derivative works used under the grant [M-0067, M-0068].
- Copyright Office final rule, 89 FR 56586 (regulation, effective 8 August 2024): the exception does not apply to any blanket licence, so nobody is treated as owner or royalty payee of a work used under the blanket licence because of that exception [M-0071, M-0073]. It also does not apply to individual download licences, and not to voluntary licences unless the MLC is directed otherwise [M-0072]. The Office issued it because the MLC's termination dispute policy conflicted with Office guidance [M-0074].

### Gotchas
- A "work for hire" label in a contract is not self proving. Statute needs employee status or a listed category plus a signed writing [M-0045, M-0046].
- Recordings: the categories do not name sound recordings, and no case in this card decides the point [M-0047, M-0049].
- Termination cannot be contracted away [M-0059]. Work made for hire is outside it [M-0055, M-0063], so the work for hire fight is also the termination fight [M-0070].
- Termination timing: Section 203 grants made from 1978 open their window 35 years later, so the earliest windows are already open (analysis, arithmetic from [M-0056]). The 304(c) window uses 56 years [M-0064].
- Termination needs recorded notice. An unrecorded notice does not take effect [M-0058].
- Mills Music (1985) still stands in the saved record, but the 2024 Office rule bars the exception for the MLC blanket licence [M-0067, M-0071]. Do not state the 2024 rule as limiting voluntary licences without the MLC direction clause [M-0072].
- Ray Charles decided standing, not whether the works were for hire [M-0069].
- Waite (S.D.N.Y.), Marvel (2d Cir.) and Ray Charles (9th Cir.) are lower court decisions, not Supreme Court rulings, and bind only their own court or circuit. Other courts may differ (analysis).
- Waite is a motion to dismiss ruling (31 March 2020). It decided nothing on the merits of work for hire [M-0049]. Later history is not in the ledger.
- Marvel v. Kirby: the quote is PARTIAL, and later history of the judgment against two defendants is not in the saved source [M-0054].
- M-0032 is an inference about the audio of a short video and stays unverified. Say so in any answer.
- Not in the ledger: foreign termination or work for hire rules (UK and EU are other cards), state law on assignments, the Estate of Smith (2d Cir. 2020) text, any Grande or later history. Say "not checked", never guess.

### Open questions for counsel
- US: does this creator agreement (attach it) make a commissioned recording a work made for hire, or is a separate written assignment needed?
- US: for this track, what is the chain of title for the composition and the recording, and can the grantor sign a sync and master licence on the grant date?
- US: has a Section 203 or 304(c) notice been served or recorded against this catalogue, and does the derivative works exception reach new videos?
- US: does a platform's creator licence, as written, cover music a creator claims to own, and what warranty and indemnity should it contain?
- US: are a platform's terms of use enough where a user uploads audio they do not own?
- US: after the 2024 Office rule, how should a licensor and payee be identified where an MLC blanket licence and a terminated grant overlap?

### Sources
- co-circular-56a: Copyright Office Circular 56A (https://www.copyright.gov/circs/circ56a.pdf)
- usc17-101: 17 U.S.C. 101 (https://www.law.cornell.edu/uscode/text/17/101)
- usc17-201: 17 U.S.C. 201 (https://www.law.cornell.edu/uscode/text/17/201)
- usc17-203: 17 U.S.C. 203 (https://www.law.cornell.edu/uscode/text/17/203)
- usc17-204: 17 U.S.C. 204 (https://www.law.cornell.edu/uscode/text/17/204)
- usc17-205: 17 U.S.C. 205 (https://www.law.cornell.edu/uscode/text/17/205)
- usc17-302: 17 U.S.C. 302 (https://www.law.cornell.edu/uscode/text/17/302)
- usc17-304: 17 U.S.C. 304 (https://www.law.cornell.edu/uscode/text/17/304)
- sdny-waite-umg-2020: Waite v. UMG Recordings, 450 F. Supp. 3d 430 (S.D.N.Y. 2020)
- ca2-marvel-kirby-2013: Marvel Characters v. Kirby, 726 F.3d 119 (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-11-03333/pdf/USCOURTS-ca2-11-03333-0.pdf)
- scotus-mills-music-1985: Mills Music v. Snyder, 469 U.S. 153 (https://tile.loc.gov/storage-services/service/ll/usrep/usrep469/usrep469153/usrep469153.pdf)
- ca9-ray-charles-2015: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (https://cdn.ca9.uscourts.gov/datastore/opinions/2015/07/31/13-55421.pdf)
- fr-mma-termination-rule-2024: Copyright Office termination and MMA final rule, 89 FR 56586 (9 July 2024)

### Claims cited in M13
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0037] VERIFIED
- Claim: Copyright vests initially in the author or authors; authors of a joint work are co-owners.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(a)
- Quote: "Copyright in a work protected under this title vests initially in the author or authors of the work. The authors of a joint work are coowners of copyright in the"
- Checked: 2026-11-10

#### [M-0048] VERIFIED
- Claim: In a work made for hire the employer or commissioning party is the author and, unless the parties agree otherwise in a signed writing, owns all rights in the copyright.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(b)
- Quote: "In the case of a work made for hire, the employer or other person for whom the work was prepared is considered the author for purposes of this title, and, unless the parties have expressly agreed otherwise in a written"
- Checked: 2026-11-10

#### [M-0040] VERIFIED
- Claim: A transfer of copyright ownership, other than by operation of law, is not valid unless in a writing signed by the owner of the rights conveyed or the owner's authorized agent.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 204 execution of transfers of copyright ownership (https://www.law.cornell.edu/uscode/text/17/204), source id usc17-204
- Pinpoint: 17 U.S.C. 204(a)
- Quote: "A transfer of copyright ownership, other than by operation of law, is not valid unless an instrument of conveyance, or a note or memorandum of the transfer, is in writing and signed by the owner"
- Checked: 2026-11-10

#### [M-0055] VERIFIED
- Claim: Section 203 termination applies to grants by an author executed on or after January 1, 1978, other than works made for hire and other than by will.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)
- Quote: "In the case of any work other than a work made for hire, the exclusive or nonexclusive grant of a transfer or license of copyright or of any right under a copyright, executed by the author on or after January"
- Checked: 2026-11-10

#### [M-0059] VERIFIED
- Claim: Section 203 termination may be effected notwithstanding any agreement to the contrary.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(5)
- Quote: "Termination of the grant may be effected notwithstanding any agreement to the contrary, including an agreement to make a will"
- Checked: 2026-11-10

#### [M-0036] VERIFIED
- Claim: A joint work is prepared by two or more authors with the intention that contributions merge into inseparable or interdependent parts of a unitary whole.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "joint work"
- Quote: "A “joint work” is a work prepared by two or more authors with the intention that their contributions be merged into inseparable or interdependent parts of a unitary whole. “Literary works” are works, other than"
- Checked: 2026-11-10

#### [M-0045] VERIFIED
- Claim: Section 101 defines a work made for hire as a work prepared by an employee within the scope of employment, or one of nine commissioned categories with a signed written agreement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire"
- Quote: "A “work made for hire” is-- (1) a work prepared by an employee within the scope of his or her employment; or (2) a work"
- Checked: 2026-11-10

#### [M-0046] VERIFIED
- Claim: A commissioned (non-employee) work counts as made for hire only if it falls in an enumerated category, including a contribution to a collective work, part of a motion picture or other audiovisual work, and a compilation, and the parties expressly agree in a signed written instrument.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "a work specially ordered or commissioned for use as a contribution to a collective work, as a part of a motion picture or other audiovisual work, as a translation, as a supplementary work, as a compilation, as an instructional text"
- Checked: 2026-11-10

#### [M-0047] VERIFIED
- Claim: The category list does not name sound recordings; whether a sound recording is made for hire turns on the employee prong or on fitting a listed category such as compilation or part of an audiovisual work (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "as a part of a motion picture or other audiovisual work, as a translation, as a"
- Checked: 2026-11-10

#### [M-0054] VERIFIED
- Claim: In Marvel v. Kirby the Second Circuit applied the 'instance and expense' test from 1909 Act case law to decide whether the works were made for hire under Section 304(c).
- Jurisdiction: case-law
- Source: Marvel Characters, Inc. v. Kirby, 726 F.3d 119 (2d Cir. 2013) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-11-03333/pdf/USCOURTS-ca2-11-03333-0.pdf), source id ca2-marvel-kirby-2013
- Pinpoint: 726 F.3d 119 (2d Cir. 2013), Part 'The Instance and Expense Test' (saved text line ~4383)
- Quote: "To determine whether a work is "work made for hire" within the meaning of section 304(c), we apply case law interpreting that term as used in the 1909 Act"
- Checked: 2026-11-10

#### [M-0049] VERIFIED
- Claim: In Waite v. UMG (S.D.N.Y. Mar. 31, 2020), the court did not resolve whether the sound recordings were works made for hire because the label raised it only on limitations, and noted that the label's cited authority for treating albums as compilations or collective works was unpersuasive.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430, work-made-for-hire discussion (saved ECF 68 text lines 236-300)
- Quote: "The Court notes also that, in any event, defendant’s limited cited authority is unpersuasive. In support of the position that"
- Checked: 2026-11-10

#### [M-0050] VERIFIED
- Claim: The Waite court said the label's limitations argument was weakened by the music industry's practice of frequently inserting work-made-for-hire language into recording contracts, and that its position would force artists to sue within three years or lose their Section 203 right.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430, limitations discussion (saved text lines 490-497)
- Quote: "Defendant’s argument is weakened further by the music industry’s practice of frequently inserting “work made for hire” language into recording contracts.50 Its position requires that many artists, often early in their careers"
- Checked: 2026-11-10

#### [M-0051] VERIFIED
- Claim: Plaintiff artists in Waite sought a declaration that sound recordings cannot be considered a work made for hire under Section 101; the court called relevance of authorship a close issue on the limitations question.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430
- Quote: "plaintiffs seek a declaratory judgment that “[s]ound recordings cannot be considered ‘a work made for hire’” within the meaning of"
- Checked: 2026-11-10

#### [M-0069] VERIFIED
- Claim: Ray Charles Foundation v. Robinson: the Ninth Circuit held the estate's sole beneficiary had Article III standing to challenge termination notices, and was a real party in interest because the notices affected its royalties.
- Jurisdiction: case-law
- Source: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (9th Cir. 2015) (https://cdn.ca9.uscourts.gov/datastore/opinions/2015/07/31/13-55421.pdf), source id ca9-ray-charles-2015
- Pinpoint: 795 F.3d 1109 (9th Cir. 2015), summary; opinion Part II, pp. 20-21
- Quote: "Foundation was a real party in interest because the termination notices affected its right to royalties, and its claims fell within the statutory zone of"
- Checked: 2026-11-10

#### [M-0070] VERIFIED
- Claim: In Ray Charles the Ninth Circuit held the Foundation could challenge whether the underlying works were works made for hire and thus not subject to termination.
- Jurisdiction: case-law
- Source: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (9th Cir. 2015) (https://cdn.ca9.uscourts.gov/datastore/opinions/2015/07/31/13-55421.pdf), source id ca9-ray-charles-2015
- Pinpoint: 795 F.3d 1109, summary
- Quote: "it had standing to sue to challenge whether the underlying works were works made for hire and thus not subject to the"
- Checked: 2026-11-10

#### [M-0038] VERIFIED
- Claim: Ownership of a copyright may be transferred in whole or in part by any means of conveyance or by operation of law.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(1)
- Quote: "The ownership of a copyright may be transferred in whole or in part by any means of conveyance or by operation of law, and may be bequeathed by will or"
- Checked: 2026-11-10

#### [M-0039] VERIFIED
- Claim: Any of the exclusive rights, and any subdivision of them, may be transferred and owned separately.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(2)
- Quote: "Any of the exclusive rights comprised in a copyright, including any subdivision of any of the rights specified by section 106, may be transferred as provided by clause (1) and"
- Checked: 2026-11-10

#### [M-0034] VERIFIED
- Claim: A transfer of copyright ownership includes an assignment or exclusive licence but excludes a nonexclusive licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "transfer of copyright ownership"
- Quote: "any other conveyance, alienation, or hypothecation of a copyright or of any of the exclusive rights comprised in a copyright, whether or not it is limited in time or place of effect, but not including a nonexclusive license."
- Checked: 2026-11-10

#### [M-0041] VERIFIED
- Claim: A transfer or other document pertaining to a copyright may be recorded in the Copyright Office if it bears the actual signature of the person who executed it, or is accompanied by a sworn or official certification that it is a true copy of the signed original.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(a)
- Quote: "Any transfer of copyright ownership or other document pertaining to a copyright may be recorded in the Copyright Office if the document filed for recordation bears the actual signature of"
- Checked: 2026-11-10

#### [M-0042] VERIFIED
- Claim: Of two conflicting transfers, the one executed first prevails if recorded within one month after execution in the United States (two months abroad) or before the later transfer is recorded.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(d)
- Quote: "As between two conflicting transfers, the one executed first prevails if it is recorded, in the manner required to give constructive notice under subsection (c), within one month after its execution in the United States or within two months after"
- Checked: 2026-11-10

#### [M-0043] VERIFIED
- Claim: A nonexclusive license, recorded or not, prevails over a conflicting transfer of ownership if evidenced by a signed written instrument and if it was taken before the transfer's execution or in good faith before its recordation and without notice.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(e)
- Quote: "A nonexclusive license, whether recorded or not, prevails over a conflicting transfer of copyright ownership if the license is evidenced by a written instrument signed by the owner of the"
- Checked: 2026-11-10

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0026] VERIFIED
- Claim: The Copyright Office treats a sound recording as a derivative work of the underlying musical composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a substitute for, copyright"
- Checked: 2026-11-10

#### [M-0035] VERIFIED
- Claim: A derivative work is a work based upon one or more preexisting works, such as a sound recording or musical arrangement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "derivative work"
- Quote: "A “derivative work” is a work based upon one or more preexisting works, such as a translation, musical arrangement, dramatization, fictionalization, motion picture version, sound recording, art reproduction, abridgment, condensation"
- Checked: 2026-11-10

#### [M-0027] VERIFIED
- Claim: Authors of the composition are composers, lyricists and songwriters; authors of the sound recording are performers, producers and sound engineers (as listed in the circular chart).
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A chart, Who is the author
- Quote: "Composers Lyricists Songwriters Performers Producers Sound Engineers How is it fixed? Copy"
- Checked: 2026-11-10

#### [M-0030] VERIFIED
- Claim: Section 101 defines a sound recording as a work resulting from fixation of a series of sounds, excluding sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "sound recordings"
- Quote: "“Sound recordings” are works that result from the fixation of a series of musical, spoken, or other sounds, but not including the sounds accompanying a motion picture or other audiovisual work, regardless of the nature of the material objects, such"
- Checked: 2026-11-10

#### [M-0031] VERIFIED
- Claim: Section 101 defines phonorecords as material objects in which sounds, other than those accompanying an audiovisual work, are fixed and from which they can be perceived or reproduced.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "phonorecords"
- Quote: "“Phonorecords” are material objects in which sounds, other than those accompanying a motion picture or other audiovisual work, are fixed by any method now known or later developed, and from which the sounds can be perceived, reproduced, or otherwise communicated"
- Checked: 2026-11-10

#### [M-0118] VERIFIED
- Claim: By definition, sound recordings do not include sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 (sound recordings)
- Quote: "Sound recordings are works that result from the fixation of a series of musical, spoken, or other sounds, but not including the sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0119] VERIFIED
- Claim: By definition, phonorecords do not include material objects in which sounds accompanying an audiovisual work are fixed.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 (phonorecords)
- Quote: "Phonorecords are material objects in which sounds, other than those accompanying a motion picture or other audiovisual work, are fixed by any method now known or later developed"
- Checked: 2026-11-10

#### [M-0337] VERIFIED
- Claim: The statutory definition of "sound recordings" in section 101 excludes the sounds accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'sound recordings'
- Quote: "but not including the sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0338] VERIFIED
- Claim: Sounds accompanying an audiovisual work are also excluded from 'phonorecords'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'phonorecords'
- Quote: "sounds, other than those accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-10

#### [M-0032] UNVERIFIED (unverified)
- Claim: Because the sound recording definition excludes sounds accompanying audiovisual works, the audio track of a short video is not itself a sound recording, but a music track embedded in it keeps its own sound recording and composition copyrights (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "sound recordings"
- Quote: "but not including the sounds accompanying a motion picture or other audiovisual work, regardless of the"
- Checked: 2026-11-10

#### [M-0341] VERIFIED
- Claim: Performance rights societies license public performance of nondramatic musical works for the owners; this is the performance leg of the stack.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'performing rights society'
- Quote: "licenses the public performance of nondramatic musical works on behalf of copyright owners of such works"
- Checked: 2026-11-10

#### [M-0044] VERIFIED
- Claim: For works created on or after January 1, 1978, copyright generally endures for the life of the author plus 70 years, subject to the exceptions in 302(b)-(c) (joint, anonymous, pseudonymous and made-for-hire works).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 302 duration of copyright, works created on or after January 1, 1978 (https://www.law.cornell.edu/uscode/text/17/302), source id usc17-302
- Pinpoint: 17 U.S.C. 302(a) (lead-in line 30)
- Quote: "endures for a term consisting of the life of the author and 70 years after the author’s death. (b) Joint"
- Checked: 2026-11-10

#### [M-0056] VERIFIED
- Claim: Under Section 203 the termination window is five years starting 35 years after the grant is executed (or 35 years after publication or 40 years after execution, whichever ends earlier, if the grant covers publication).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(3)
- Quote: "Termination of the grant may be effected at any time during a period of five years beginning at the end of thirty-five years from the date of execution of the grant; or, if the grant covers the right of publication"
- Checked: 2026-11-10

#### [M-0057] VERIFIED
- Claim: A Section 203 notice must be served not less than two or more than ten years before the stated effective date.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(4)(A)
- Quote: "the notice shall be served not less than two or more than ten years before that date. A copy of"
- Checked: 2026-11-10

#### [M-0058] VERIFIED
- Claim: A copy of the Section 203 notice must be recorded in the Copyright Office before the effective date as a condition to taking effect.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(4)(A)
- Quote: "A copy of the notice shall be recorded in the Copyright Office before the effective date of termination, as a"
- Checked: 2026-11-10

#### [M-0061] VERIFIED
- Claim: Unless terminated, a Section 203 grant continues for the term of copyright unless it provides otherwise.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(6)
- Quote: "Unless and until termination is effected under this section, the grant, if it does not provide otherwise, continues in effect for the term of copyright"
- Checked: 2026-11-10

#### [M-0060] VERIFIED
- Claim: Section 203 derivative works exception: a derivative work prepared under authority of the grant before termination may continue to be utilized under the grant's terms, but no new derivative works may be prepared after termination.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(1)
- Quote: "A derivative work prepared under authority of the grant before its termination may continue to be utilized under the terms of the grant after its termination, but this privilege does not extend to the preparation after the termination of other"
- Checked: 2026-11-10

#### [M-0062] VERIFIED
- Claim: A further grant of any right covered by a terminated Section 203 grant is valid only if made after the effective date of termination, except that an agreement for a further grant may be made with the original grantee or its successor after notice of termination has been served.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(4)
- Quote: "A further grant, or agreement to make a further grant, of any right covered by a terminated grant is valid only if it is made after the effective date of"
- Checked: 2026-11-10

#### [M-0063] VERIFIED
- Claim: Section 304(c) termination covers pre-1978 grants of the renewal term, other than works made for hire.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 304 duration of copyright, subsisting copyrights (termination 304(c), 304(d)) (https://www.law.cornell.edu/uscode/text/17/304), source id usc17-304
- Pinpoint: 17 U.S.C. 304(c)
- Quote: "In the case of any copyright subsisting in either its first or renewal term on January 1, 1978, other than a copyright in a work made for hire, the exclusive or nonexclusive grant of a transfer or license of the"
- Checked: 2026-11-10

#### [M-0064] VERIFIED
- Claim: The Section 304(c) window is five years starting 56 years after copyright was originally secured, or January 1, 1978, whichever is later.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 304 duration of copyright, subsisting copyrights (termination 304(c), 304(d)) (https://www.law.cornell.edu/uscode/text/17/304), source id usc17-304
- Pinpoint: 17 U.S.C. 304(c)(3)
- Quote: "Termination of the grant may be effected at any time during a period of five years beginning at the end of fifty-six years from the date copyright was originally secured"
- Checked: 2026-11-10

#### [M-0065] VERIFIED
- Claim: Section 304(c) notices must also be served two to ten years before the effective date, and a copy recorded before that date.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 304 duration of copyright, subsisting copyrights (termination 304(c), 304(d)) (https://www.law.cornell.edu/uscode/text/17/304), source id usc17-304
- Pinpoint: 17 U.S.C. 304(c)(4)(A)
- Quote: "the notice shall be served not less than two or more than ten years before that date. A copy of"
- Checked: 2026-11-10

#### [M-0066] VERIFIED
- Claim: Section 304(c)(6)(A) has a derivative works exception: a derivative work prepared under authority of the grant before termination may continue to be utilized under the grant's terms.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 304 duration of copyright, subsisting copyrights (termination 304(c), 304(d)) (https://www.law.cornell.edu/uscode/text/17/304), source id usc17-304
- Pinpoint: 17 U.S.C. 304(c)(6)(A)
- Quote: "A derivative work prepared under authority of the grant before its termination may continue to be utilized under the terms of the grant after its termination, but this privilege does not extend to the preparation after the termination of other"
- Checked: 2026-11-10

#### [M-0067] VERIFIED
- Claim: Mills Music v. Snyder: Supreme Court held that a publisher keeps its contractual share of royalties from pre-termination sound recordings under the derivative works exception, because the recordings are derivative works utilized under the terms of the grant.
- Jurisdiction: case-law
- Source: Mills Music, Inc. v. Snyder, 469 U.S. 153 (1985) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep469/usrep469153/usrep469153.pdf), source id scotus-mills-music-1985
- Pinpoint: Mills Music, Inc. v. Snyder, 469 U.S. 153 (1985), syllabus
- Quote: "Held: Petitioner is entitled pursuant to § 304(c)(6)(A) to a share of the royalty income in dispute under the terms"
- Checked: 2026-11-10

#### [M-0068] VERIFIED
- Claim: The Mills Court said the sound recordings in question come within the statutory definition of a derivative work, so the Section 304(c)(6)(A) exception applies to them.
- Jurisdiction: case-law
- Source: Mills Music, Inc. v. Snyder, 469 U.S. 153 (1985) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep469/usrep469153/usrep469153.pdf), source id scotus-mills-music-1985
- Pinpoint: 469 U.S. 153, syllabus
- Quote: "The sound recordings in question come within the statutory definition of a "derivative work.""
- Checked: 2026-11-10

#### [M-0071] VERIFIED
- Claim: The Copyright Office's 2024 final rule says the derivative works exception does not apply to any blanket licence, so no one may be treated as owner or royalty payee of a work used under the blanket licence based on that exception.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, 37 CFR 210.29(b)(4)(i)(C)
- Quote: "The derivative works exception does not apply to any blanket license and no individual or entity may be construed as the copyright owner or royalty payee of a musical work (or share thereof) used pursuant to a blanket license based"
- Checked: 2026-11-10

#### [M-0073] VERIFIED
- Claim: The rule is effective August 8, 2024; MLC compliance, other than with the sections it lists (210.27(g)(2)(ii)(B)(1), 210.29(b)(4)(i)(C), 210.29(k), 210.30(c)(1)(i)(B)), was not required until the first distribution after the first payee snapshot taken after October 7, 2024.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, DATES
- Quote: "This rule is effective August 8, 2024. However, compliance by the mechanical licensing collective, other than with respect to Sec. Sec. 210.27(g)(2)(ii)(B)(1), 210.29(b)(4)(i)(C), 210.29(k), and 210.30(c)(1)(i)(B), is not required until the first distribution of royalties"
- Checked: 2026-11-10

#### [M-0072] VERIFIED
- Claim: The 2024 rule also says the exception does not apply to any individual download licence, and does not apply to any voluntary licence unless the MLC is directed otherwise.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 37 CFR 210.27(g)(2)(ii)(B)(1)-(2)
- Quote: "The derivative works exception does not apply to any individual download license and no individual or entity may be construed as the copyright owner or royalty payee of a musical"
- Checked: 2026-11-10

#### [M-0074] VERIFIED
- Claim: The Office issued the rule because the MLC's termination dispute policy conflicted with Office guidance and misread how the derivative works exception applies to the blanket licence.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, background
- Quote: "adopted a termination dispute policy (``Termination Policy'') that conflicted with prior Office guidance and was based on an erroneous interpretation of how the Copyright Act's derivative works exception (``Exception'') to termination rights applies to the statutory mechanical blanket license (``blanket"
- Checked: 2026-11-10

## M14 Deal terms
- Law last checked: 2026-11-10. Volatility: medium.
- Use for questions like: Who owns a song after a record deal or publishing deal; Does a transfer of music rights need a signed writing; Can an artist terminate a label grant and what happens to mixes already made; Who can license a song for sync in a video, and is that negotiated each time; Does the Spotify or label deal cover use in a user mix; Can a performer's digital replica be licensed in a services contract

### Bottom line
- US federal: a transfer of copyright ownership needs a writing signed by the owner [M-0040]. A nonexclusive licence is not a transfer, but a signed written licence can beat a later transfer [M-0043]. Sync (the composition) and master use (the recording) are negotiated directly with the rights holders [M-0080, M-0140].
- Label and publisher deals decide who controls each copyright. Public company filings say most label artist deals are work made for hire, with royalties, recoupable advances and options [M-0052, M-0075, M-0076]. These are company statements, not law.
- A streaming service's licences do not cover another platform. They are the service's own contracts [M-0083, M-0084]. A platform needs its own direct licences for music in video.
- Termination rights (17 U.S.C. 203) can reopen grants after 35 years, but a derivative work made before termination may keep being used [M-0056, M-0060]. Never promise that a song is cleared; ask the holder.

### Rules
#### Transfers and records (US federal, statute)
- A transfer of ownership, other than by operation of law, is not valid unless in a writing signed by the owner or the owner's authorized agent [M-0040]. Plain English: a handshake or a text thread does not move ownership. An exclusive licence is a transfer of ownership, so it also needs the signed writing (analysis).
- A transfer or other document may be recorded in the Copyright Office if signed, or certified as a true copy of the signed original [M-0041].
- Of two conflicting transfers, the first executed wins if recorded within one month after signing in the US (two abroad) or before the later transfer is recorded [M-0042].
- A signed written nonexclusive licence, recorded or not, prevails over a conflicting transfer if taken before the transfer or in good faith before its recordation and without notice [M-0043].

#### Work made for hire and the label practice (court decision, industry)
- Warner Music Group says virtually all its agreements with artists since 1971 provide that artists render services as work made for hire [M-0052]. Reservoir Media says the same of its recording artist agreements and says a termination right exists for compositions not made for hire [M-0099]. Both are the companies' own statements about their practice, not rules.
- WMG warns that if a recording were found not to be made for hire, artists or heirs could terminate US rights in a window starting 35 years after release for post 1977 grants [M-0053]. The statute counts from execution of the grant, see below.
- Waite v. UMG (S.D.N.Y. 31 March 2020, motion to dismiss): the court did not decide whether the recordings were works made for hire, because the label raised it only on limitations [M-0049]. It said the label's limitations argument was weakened by the industry habit of inserting work made for hire language, which would force artists to sue within three years or lose the Section 203 right [M-0050]. The artists sought a declaration that sound recordings cannot be works made for hire; the court called authorship a close issue on limitations [M-0051]. This is a pleading stage ruling, not a final holding.
- Ray Charles Foundation v. Robinson (9th Cir. 2015): the estate's sole beneficiary had standing to challenge termination notices [M-0069] and could challenge whether the works were made for hire and so not terminable [M-0070]. Standing only; the merits were not decided [M-0069].

#### Termination, 17 U.S.C. 203 (statute)
- Section 203 applies to grants by an author executed on or after 1 January 1978, other than works made for hire and wills [M-0055].
- The window is five years starting 35 years after execution of the grant (or 35 years after publication or 40 after execution, whichever ends earlier, if the grant covers publication) [M-0056].
- Notice must be served two to ten years before the effective date [M-0057], and a copy must be recorded before that date to take effect [M-0058].
- Termination works notwithstanding any agreement to the contrary [M-0059]. Unless terminated, a grant lasts for the term of copyright [M-0061].
- A derivative work made under the grant before termination may keep being used on the grant's terms. No new derivative works may be made after termination [M-0060]. A further grant is valid only after the effective date, except that the original grantee may agree to one after notice is served [M-0062].
- Copyright Office 2024 final rule (regulation, effective 8 August 2024): the derivative works exception does not apply to any blanket licence [M-0071], nor to any individual download licence, nor to any voluntary licence unless the MLC is directed otherwise [M-0072]. The Office acted because the MLC's termination dispute policy conflicted with Office guidance [M-0074]. Four listed sections applied immediately; MLC compliance with the rest waited for a later payee snapshot, and the Office may extend deadlines [M-0073].

#### How the deals are built (industry practice, company filings)
- Artist deals: royalties on sales and other uses, advances recoupable from future royalties, recording costs typically recoupable [M-0075]. A typical new artist contract requires delivery of an EP or album and gives the label a series of options [M-0076]. Many deals are expanded rights (360) deals sharing touring, merchandising, sponsorship and other income [M-0077, M-0078].
- Publishing: WMG's publisher owns or administers compositions and earns mechanical, performance, sync, digital and other income [M-0079]. Each sync licence is generally negotiated with the prospective licensee, and the publisher pays a contractual share of sync income to songwriters or heirs [M-0080]. Reservoir says the same, with co-publishers also sharing [M-0100]. WMG defines sync as use of the composition in combination with visual images [M-0081].
- The Copyright Office said in 2015 that consumer audiovisual (sync) uses should stay in the free market, with no compulsory licence recommended [M-0140]. Sync is an industry term for reproduction (and possibly derivative) rights in a work synchronized to visual content [M-0141]. This is a regulator report, not binding.
- Reservoir licenses sync to film, television, advertising and digital platforms from social media to fitness; sync was 13% of revenue for the year ended 31 March 2026 [M-0102]. Such social media sync deals are direct licences (analysis).
- Reservoir licenses digital music services itself or through a distributor, with fees set licence by licence [M-0104]. It treats its songwriters and artists as independent contractors and flags reclassification risk [M-0103]. It also owns or acquires label, catalogue and income participation interests [M-0101].
- Distribution deals end by contract: WMG's ADA unit distributed BMG's recordings until the agreement ended in September 2023 [M-0082].

#### What a streaming licence looks like (company filing)
- Spotify takes sound recording and audiovisual licences from the three major label groups and Merlin, with royalties, marketing commitments and operating rules, audit and termination rights [M-0083]. They are generally multi-year, not automatically renewable, worldwide, and terminable for non-payment, material breach or change of control [M-0084]. It also licenses independent labels and aggregators such as CD Baby, DistroKid and TuneCore [M-0085].
- For compositions, Spotify generally gets mechanical, performance and lyric rights. For audio only use in the US, mechanicals run through the Section 115 licence and the MLC blanket licence since January 2021 [M-0086]. That statutory route is audio only, not video.
- Spotify has recently entered direct licences with some US publishers for audiovisual and other rights [M-0087]. US performance rights come through ASCAP, BMI, GMR and SESAC blanket licences with usage reporting and one to four year terms [M-0088]. Failing to obtain or keep licences is a stated business risk [M-0089].

#### UK (foreign law)
- The author is first owner [M-0090]. An employee's musical work or film belongs first to the employer, subject to contrary agreement [M-0091]. The author of a sound recording is the producer [M-0092]. So (analysis) a UK sound recording's first owner is the producer, as the employer rule does not list sound recordings [M-0093].
- An assignment must be in writing signed by or for the assignor [M-0096]. An exclusive licence must be in writing signed by or for the owner [M-0097]. An agreement to assign future copyright, signed by the prospective owner, takes effect as an assignment when the copyright arises [M-0098].
- The owner has exclusive rights to copy, issue, rent, lend, perform, communicate to the public and adapt [M-0234]. Infringement includes authorising another to do a restricted act [M-0235]. Communication to the public covers musical works and recordings [M-0236], including on demand availability [M-0237]. (Analysis) a UK facing platform may face direct or authorising liability [M-0255].

#### Digital replicas in deals (California, statute)
- Digital replica means a computer generated, highly realistic representation readily identifiable as a person's voice or visual likeness [M-0447].
- Producing or making available a deceased personality's digital replica in an expressive audiovisual work or sound recording without consent carries the greater of $10,000 or actual damages, subject to listed exceptions [M-0448].
- A contract term letting a digital replica replace in person work is unenforceable for new performances from 1 January 2025 if it lacks a reasonably specific description of uses and the individual had no representation [M-0449].

### Gotchas
- WMG and Reservoir lines describe each company's contracts. Courts have not all agreed that recordings are works made for hire (analysis from M-0049, M-0051). Waite is a motion to dismiss ruling only.
- WMG says the window is 35 years from release; the statute counts from execution, or publication for grants covering it [M-0053, M-0056].
- Termination cannot be waived by contract [M-0059], so a deal clause saying otherwise does not stop it.
- Filings are dated: WMG fiscal year ended 30 September 2025, Spotify year ended 31 December 2025, Reservoir year ended 31 March 2026. Terms and licence lengths change.
- The Spotify direct publisher AV deals are narrow: some US publishers only [M-0087]. Do not read them as a general video licence.
- The M-0086 statutory route is audio only. A mechanical licence is not sync.
- California digital replica rows are statutes as captured 2026-11-10. California Civil Code 3344.1 covers deceased personalities, not living ones [M-0448].
- UK rules above are English law under the CDPA, not a UK guide to platform liability. UK platform case law is not in the ledger [M-0255].
- Blurring, muting or low audio quality is not a licence, and "the creator said it was theirs" is not a signed writing.

### Open questions for counsel
- US: does an uploader's licence from a distributor or aggregator ever include sync or master use for short video, or only audio distribution?
- US: if a creator's deal is a 360 or expanded rights deal, can the label claim a share of platform earnings from a video using the label's master?
- US: what warranty and indemnity should a platform require from creators who say they hold sync and master rights?
- US: does a platform's re-encoding of creator audio count as a covered use under common creator side licences, or does it need its own terms?
- US: for a catalogue song where the grant was terminated, who now grants sync, and how does a platform video made before termination continue [M-0060]?
- UK: does a platform need a UK licence structure if UK users can stream uploads, and who is the first owner of a creator made recording?
- California: do a platform's creator terms need a reasonably specific description of uses to survive Lab. Code 927 for voice or likeness [M-0449]?
- What currency check is due on the open gaps: Artlist licence terms, TikTok Community Guidelines and current Meta Sound Collection terms?

### Sources
- sec-wmg-10k-fy2025: Warner Music Group Corp., Form 10-K FY ended 30 September 2025 (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm)
- sec-spotify-20f-fy2025: Spotify Technology S.A., Form 20-F FY2025
- sec-reservoir-10k: Reservoir Media 10-K FY ended 2026-03-31
- usc17-203, usc17-204, usc17-205: 17 U.S.C. 203, 204, 205 (https://www.law.cornell.edu/uscode/text/17/203)
- fr-mma-termination-rule-2024: Copyright Office termination rule, 89 FR (9 July 2024)
- sdny-waite-umg-2020: Waite v. UMG Recordings, 450 F. Supp. 3d 430 (S.D.N.Y. 2020)
- ca9-ray-charles-2015: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (9th Cir. 2015)
- co-music-marketplace-2015: Copyright Office, Copyright and the Music Marketplace (2015)
- uk-cdpa-s9-s11, uk-cdpa-s90-s93a, uk-cdpa-s16-s21: CDPA 1988 (legislation.gov.uk)
- ca-civ-3344-1, ca-lab-927: California Civil Code 3344.1; Labor Code 927

### Claims cited in M14
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0040] VERIFIED
- Claim: A transfer of copyright ownership, other than by operation of law, is not valid unless in a writing signed by the owner of the rights conveyed or the owner's authorized agent.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 204 execution of transfers of copyright ownership (https://www.law.cornell.edu/uscode/text/17/204), source id usc17-204
- Pinpoint: 17 U.S.C. 204(a)
- Quote: "A transfer of copyright ownership, other than by operation of law, is not valid unless an instrument of conveyance, or a note or memorandum of the transfer, is in writing and signed by the owner"
- Checked: 2026-11-10

#### [M-0043] VERIFIED
- Claim: A nonexclusive license, recorded or not, prevails over a conflicting transfer of ownership if evidenced by a signed written instrument and if it was taken before the transfer's execution or in good faith before its recordation and without notice.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(e)
- Quote: "A nonexclusive license, whether recorded or not, prevails over a conflicting transfer of copyright ownership if the license is evidenced by a written instrument signed by the owner of the"
- Checked: 2026-11-10

#### [M-0080] VERIFIED
- Claim: WMG says each synchronization licence is generally subject to negotiation with a prospective licensee, and publishers pay a contractually required share of sync income to songwriters or heirs.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1, Music Publishing
- Quote: "Throughout the world, each synchronization license is generally subject to negotiation with a prospective licensee and, by contract, music publishers"
- Checked: 2026-11-10

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0052] VERIFIED
- Claim: Warner Music Group says virtually all its agreements with recording artists since the Sound Recordings Act of 1971 provide that the artists render services under a work-made-for-hire relationship.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1A, termination risk factor
- Quote: "virtually all of our agreements with recording artists provide that such recording artists render services under a work-made-for-hire relationship. A termination right exists under the U.S. Copyright Act for U.S."
- Checked: 2026-11-10

#### [M-0075] VERIFIED
- Claim: WMG artist contracts: royalties based on sales and other uses, advances recoupable from future royalties, and recording and production costs typically recoupable from royalties.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1, recording artist agreements
- Quote: "recording artists receive royalties based on sales and other uses of their music. We customarily provide upfront payments to recording artists called advances, which are recoupable by us from future royalties."
- Checked: 2026-11-10

#### [M-0076] VERIFIED
- Claim: WMG says its typical new-artist contract requires delivery of an EP or album and gives the label a series of options for later albums.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Our typical contract for a new recording artist requires the delivery of an extended play record known as an EP or an album and provides us with a series of options to acquire subsequent albums"
- Checked: 2026-11-10

#### [M-0083] VERIFIED
- Claim: Spotify takes sound recording and audiovisual licences from the three major label groups and Merlin; the agreements require royalties, marketing commitments and operating prescriptions, are multi-year, and permit label audit and termination.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Content License Agreements
- Quote: "We have license agreements for sound recordings and audiovisual works with record label affiliates of the three largest music companies--Universal Music Group, Sony Music Entertainment, and Warner Music Group--as well as Merlin, which represents the digital rights on"
- Checked: 2026-11-10

#### [M-0084] VERIFIED
- Claim: Spotify says label agreements generally run multi-year, are not automatically renewable, apply worldwide, and let the label terminate for non-payment, material breach or change of control.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "Generally, these license agreements have a multi-year duration, are not automatically renewable, and apply worldwide. The license agreements also allow for the record label to terminate the agreement in certain"
- Checked: 2026-11-10

#### [M-0056] VERIFIED
- Claim: Under Section 203 the termination window is five years starting 35 years after the grant is executed (or 35 years after publication or 40 years after execution, whichever ends earlier, if the grant covers publication).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(3)
- Quote: "Termination of the grant may be effected at any time during a period of five years beginning at the end of thirty-five years from the date of execution of the grant; or, if the grant covers the right of publication"
- Checked: 2026-11-10

#### [M-0060] VERIFIED
- Claim: Section 203 derivative works exception: a derivative work prepared under authority of the grant before termination may continue to be utilized under the grant's terms, but no new derivative works may be prepared after termination.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(1)
- Quote: "A derivative work prepared under authority of the grant before its termination may continue to be utilized under the terms of the grant after its termination, but this privilege does not extend to the preparation after the termination of other"
- Checked: 2026-11-10

#### [M-0041] VERIFIED
- Claim: A transfer or other document pertaining to a copyright may be recorded in the Copyright Office if it bears the actual signature of the person who executed it, or is accompanied by a sworn or official certification that it is a true copy of the signed original.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(a)
- Quote: "Any transfer of copyright ownership or other document pertaining to a copyright may be recorded in the Copyright Office if the document filed for recordation bears the actual signature of"
- Checked: 2026-11-10

#### [M-0042] VERIFIED
- Claim: Of two conflicting transfers, the one executed first prevails if recorded within one month after execution in the United States (two months abroad) or before the later transfer is recorded.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 205 recordation of transfers and other documents (https://www.law.cornell.edu/uscode/text/17/205), source id usc17-205
- Pinpoint: 17 U.S.C. 205(d)
- Quote: "As between two conflicting transfers, the one executed first prevails if it is recorded, in the manner required to give constructive notice under subsection (c), within one month after its execution in the United States or within two months after"
- Checked: 2026-11-10

#### [M-0099] VERIFIED
- Claim: Reservoir Media (independent publisher and label, FY ended 2026-03-31) says virtually all its recording artist agreements provide that the artists render services under a work-made-for-hire relationship, and a termination right exists for compositions not made for hire.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1A, termination risk factor
- Quote: "virtually all of our agreements with recording artists provide that such recording artists render services under a work-made-for-hire relationship. A termination right exists under the U.S. Copyright Act for U.S."
- Checked: 2026-11-10

#### [M-0053] VERIFIED
- Claim: WMG warns that if any of its sound recordings were found not to be works made for hire, artists or heirs could terminate the US rights, generally in a five-year window starting 35 years after release for post-1977 grants.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1A
- Quote: "If any of our commercially available sound recordings were determined not to be “works made for hire,” then the recording artists (or their heirs) could have the right to terminate the U.S. federal copyright rights they granted to"
- Checked: 2026-11-10

#### [M-0049] VERIFIED
- Claim: In Waite v. UMG (S.D.N.Y. Mar. 31, 2020), the court did not resolve whether the sound recordings were works made for hire because the label raised it only on limitations, and noted that the label's cited authority for treating albums as compilations or collective works was unpersuasive.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430, work-made-for-hire discussion (saved ECF 68 text lines 236-300)
- Quote: "The Court notes also that, in any event, defendant’s limited cited authority is unpersuasive. In support of the position that"
- Checked: 2026-11-10

#### [M-0050] VERIFIED
- Claim: The Waite court said the label's limitations argument was weakened by the music industry's practice of frequently inserting work-made-for-hire language into recording contracts, and that its position would force artists to sue within three years or lose their Section 203 right.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430, limitations discussion (saved text lines 490-497)
- Quote: "Defendant’s argument is weakened further by the music industry’s practice of frequently inserting “work made for hire” language into recording contracts.50 Its position requires that many artists, often early in their careers"
- Checked: 2026-11-10

#### [M-0051] VERIFIED
- Claim: Plaintiff artists in Waite sought a declaration that sound recordings cannot be considered a work made for hire under Section 101; the court called relevance of authorship a close issue on the limitations question.
- Jurisdiction: case-law
- Source: Waite v. UMG Recordings, Inc., No. 19-cv-1091 (LAK), ECF 68, Memorandum Opinion on motion to dismiss, 450 F. Supp. 3d 430 (S.D.N.Y. Mar. 31, 2020) (termination of sound recording grants) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.509551/gov.uscourts.nysd.509551.68.0.pdf), source id sdny-waite-umg-2020
- Pinpoint: 450 F. Supp. 3d 430
- Quote: "plaintiffs seek a declaratory judgment that “[s]ound recordings cannot be considered ‘a work made for hire’” within the meaning of"
- Checked: 2026-11-10

#### [M-0069] VERIFIED
- Claim: Ray Charles Foundation v. Robinson: the Ninth Circuit held the estate's sole beneficiary had Article III standing to challenge termination notices, and was a real party in interest because the notices affected its royalties.
- Jurisdiction: case-law
- Source: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (9th Cir. 2015) (https://cdn.ca9.uscourts.gov/datastore/opinions/2015/07/31/13-55421.pdf), source id ca9-ray-charles-2015
- Pinpoint: 795 F.3d 1109 (9th Cir. 2015), summary; opinion Part II, pp. 20-21
- Quote: "Foundation was a real party in interest because the termination notices affected its right to royalties, and its claims fell within the statutory zone of"
- Checked: 2026-11-10

#### [M-0070] VERIFIED
- Claim: In Ray Charles the Ninth Circuit held the Foundation could challenge whether the underlying works were works made for hire and thus not subject to termination.
- Jurisdiction: case-law
- Source: Ray Charles Foundation v. Robinson, 795 F.3d 1109 (9th Cir. 2015) (https://cdn.ca9.uscourts.gov/datastore/opinions/2015/07/31/13-55421.pdf), source id ca9-ray-charles-2015
- Pinpoint: 795 F.3d 1109, summary
- Quote: "it had standing to sue to challenge whether the underlying works were works made for hire and thus not subject to the"
- Checked: 2026-11-10

#### [M-0055] VERIFIED
- Claim: Section 203 termination applies to grants by an author executed on or after January 1, 1978, other than works made for hire and other than by will.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)
- Quote: "In the case of any work other than a work made for hire, the exclusive or nonexclusive grant of a transfer or license of copyright or of any right under a copyright, executed by the author on or after January"
- Checked: 2026-11-10

#### [M-0057] VERIFIED
- Claim: A Section 203 notice must be served not less than two or more than ten years before the stated effective date.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(4)(A)
- Quote: "the notice shall be served not less than two or more than ten years before that date. A copy of"
- Checked: 2026-11-10

#### [M-0058] VERIFIED
- Claim: A copy of the Section 203 notice must be recorded in the Copyright Office before the effective date as a condition to taking effect.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(4)(A)
- Quote: "A copy of the notice shall be recorded in the Copyright Office before the effective date of termination, as a"
- Checked: 2026-11-10

#### [M-0059] VERIFIED
- Claim: Section 203 termination may be effected notwithstanding any agreement to the contrary.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(a)(5)
- Quote: "Termination of the grant may be effected notwithstanding any agreement to the contrary, including an agreement to make a will"
- Checked: 2026-11-10

#### [M-0061] VERIFIED
- Claim: Unless terminated, a Section 203 grant continues for the term of copyright unless it provides otherwise.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(6)
- Quote: "Unless and until termination is effected under this section, the grant, if it does not provide otherwise, continues in effect for the term of copyright"
- Checked: 2026-11-10

#### [M-0062] VERIFIED
- Claim: A further grant of any right covered by a terminated Section 203 grant is valid only if made after the effective date of termination, except that an agreement for a further grant may be made with the original grantee or its successor after notice of termination has been served.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 203 termination of transfers and licenses granted by the author (https://www.law.cornell.edu/uscode/text/17/203), source id usc17-203
- Pinpoint: 17 U.S.C. 203(b)(4)
- Quote: "A further grant, or agreement to make a further grant, of any right covered by a terminated grant is valid only if it is made after the effective date of"
- Checked: 2026-11-10

#### [M-0071] VERIFIED
- Claim: The Copyright Office's 2024 final rule says the derivative works exception does not apply to any blanket licence, so no one may be treated as owner or royalty payee of a work used under the blanket licence based on that exception.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, 37 CFR 210.29(b)(4)(i)(C)
- Quote: "The derivative works exception does not apply to any blanket license and no individual or entity may be construed as the copyright owner or royalty payee of a musical work (or share thereof) used pursuant to a blanket license based"
- Checked: 2026-11-10

#### [M-0072] VERIFIED
- Claim: The 2024 rule also says the exception does not apply to any individual download licence, and does not apply to any voluntary licence unless the MLC is directed otherwise.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 37 CFR 210.27(g)(2)(ii)(B)(1)-(2)
- Quote: "The derivative works exception does not apply to any individual download license and no individual or entity may be construed as the copyright owner or royalty payee of a musical"
- Checked: 2026-11-10

#### [M-0074] VERIFIED
- Claim: The Office issued the rule because the MLC's termination dispute policy conflicted with Office guidance and misread how the derivative works exception applies to the blanket licence.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, background
- Quote: "adopted a termination dispute policy (``Termination Policy'') that conflicted with prior Office guidance and was based on an erroneous interpretation of how the Copyright Act's derivative works exception (``Exception'') to termination rights applies to the statutory mechanical blanket license (``blanket"
- Checked: 2026-11-10

#### [M-0073] VERIFIED
- Claim: The rule is effective August 8, 2024; MLC compliance, other than with the sections it lists (210.27(g)(2)(ii)(B)(1), 210.29(b)(4)(i)(C), 210.29(k), 210.30(c)(1)(i)(B)), was not required until the first distribution after the first payee snapshot taken after October 7, 2024.
- Jurisdiction: US-federal
- Source: Copyright Office, Termination Rights, Royalty Distributions, Ownership Transfers, Disputes, and the Music Modernization Act, final rule, 89 FR (July 9, 2024), FR Doc. 2024-14609 (https://www.federalregister.gov/documents/full_text/text/2024/07/09/2024-14609.txt), source id fr-mma-termination-rule-2024
- Pinpoint: 89 FR 56586, DATES
- Quote: "This rule is effective August 8, 2024. However, compliance by the mechanical licensing collective, other than with respect to Sec. Sec. 210.27(g)(2)(ii)(B)(1), 210.29(b)(4)(i)(C), 210.29(k), and 210.30(c)(1)(i)(B), is not required until the first distribution of royalties"
- Checked: 2026-11-10

#### [M-0077] VERIFIED
- Claim: WMG says many of its recording contracts are expanded-rights (360) deals sharing touring, merchandising, sponsorship, fan club or other ancillary revenues.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Many of the recording contracts we enter into are expanded-rights deals, in which we share in the touring, merchandising, sponsorship, fan club or other ancillary music revenues associated with those"
- Checked: 2026-11-10

#### [M-0078] VERIFIED
- Claim: WMG describes expanded-rights deals as services and participation in activities beyond recorded music such as touring, merchandising and sponsorships.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Under these agreements, we provide services to and participate in recording artists’ activities outside the traditional recorded music business such as touring, merchandising and sponsorships. We have built and acquired"
- Checked: 2026-11-10

#### [M-0079] VERIFIED
- Claim: WMG's publishing arm acts as copyright owner and/or administrator of compositions and earns mechanical, performance, synchronization, digital and other income.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 7, Music Publishing
- Quote: "Music Publishing acts as a copyright owner and/or administrator of the musical compositions and generates revenues related to the exploitation of musical compositions (as opposed to recorded music). Music publishers generally receive royalties from the use of the musical compositions"
- Checked: 2026-11-10

#### [M-0100] VERIFIED
- Claim: Reservoir says music publishers pay a contractually required percentage of synchronization income to songwriters or heirs and to any co-publishers, and that synchronization licences are negotiated with the prospective licensee.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Music Publishing
- Quote: "music publishers pay a contractually required percentage of synchronization income to the songwriters or their heirs and to any co-publishers. Performance royalties generate revenue through"
- Checked: 2026-11-10

#### [M-0081] VERIFIED
- Claim: WMG lists synchronization as use of the musical composition in combination with visual images.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, Item 1
- Quote: "Synchronization: use of the musical composition in combination with visual images •Films or television"
- Checked: 2026-11-10

#### [M-0141] VERIFIED
- Claim: The sync right is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), ch. 1 background
- Quote: "the right to synchronize musical works to visual content (e.g., in a music video). The synchronization (or synch right) is a species of the reproduction right and may also implicate the derivative work right."
- Checked: 2026-11-10

#### [M-0102] VERIFIED
- Claim: Reservoir's synchronization team licenses its music for film, television and advertising, and its digital licensing covers platforms from social media and background music to fitness; synchronization was 13% of revenue in the year.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Synchronization
- Quote: "Digital licensing covers platforms that extend from social media, background music, and home fitness to music education and music therapy."
- Checked: 2026-11-10

#### [M-0104] VERIFIED
- Claim: Reservoir licenses digital music services (streaming and downloads) itself or through a distributor, with fees set by licence for each service.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Recorded Music
- Quote: "We or our distributor will enter into license agreements with digital music services to make our music available for access"
- Checked: 2026-11-10

#### [M-0103] VERIFIED
- Claim: Reservoir treats its songwriters and recording artists as independent contractors, not employees, and flags the risk that regulators or courts could reclassify them.
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K, Part I Item 1A Risk Factors
- Quote: "we believe that the songwriters and recording artists with which we partner are properly characterized as independent contractors, tax or"
- Checked: 2026-11-10

#### [M-0101] VERIFIED
- Claim: Reservoir describes its recorded music business as owning or acquiring full or partial interests in labels, catalogues, or income rights to a royalty stream tied to an artist or producer (producer and income participation interests).
- Jurisdiction: industry
- Source: Reservoir Media 10-K FY ended 2026-03-31 (https://web.archive.org/web/2026/https://www.sec.gov/Archives/edgar/data/1824403/000110465926067615/rsvr-20260331x10k.htm), source id sec-reservoir-10k
- Pinpoint: Reservoir 10-K FY2026, Item 1, Recorded Music
- Quote: "The third type is the acquisition of full or partial interests in existing record labels, sound recording catalogs or income rights to a royalty stream associated with an established recording"
- Checked: 2026-11-10

#### [M-0082] VERIFIED
- Claim: WMG's distribution agreement example: its ADA unit distributed BMG's recorded music catalogue until BMG in-sourced distribution and the agreement was terminated in September 2023.
- Jurisdiction: industry
- Source: Warner Music Group Corp., Form 10-K for fiscal year ended September 30, 2025 (filed November 20, 2025) (https://web.archive.org/web/20251120142311id_/https://www.sec.gov/Archives/edgar/data/1319161/000131916125000034/wmg-20250930.htm), source id sec-wmg-10k-fy2025
- Pinpoint: WMG 10-K FY2025, MD&A, BMG Termination
- Quote: "In September 2023, the Company terminated its distribution agreement with BMG as BMG began to bring digital distribution in-house and license directly with digital service partners in fiscal 2024 while"
- Checked: 2026-11-10

#### [M-0085] VERIFIED
- Claim: Spotify also has direct licences with independent labels and aggregators such as CD Baby, DistroKid and TuneCore, with financial and data reporting obligations and audit rights.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "We also have direct license agreements with hundreds of independent labels, as well as companies known as “aggregators” (for example, CDBaby, Distrokid, and TuneCore). The majority of these agreements have"
- Checked: 2026-11-10

#### [M-0086] VERIFIED
- Claim: For compositions Spotify generally obtains mechanical, public performance and lyric rights; for audio-only use in the US the mechanical rights run through the Section 115 compulsory licence, with a blanket licence administered by the MLC since January 2021.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Musical Composition License Agreements
- Quote: "With respect to musical compositions, we generally obtain licenses for mechanical rights, public performance rights, and lyric rights. With respect to mechanical rights for audio-only"
- Checked: 2026-11-10

#### [M-0087] VERIFIED
- Claim: Spotify says it recently entered licences directly with certain US publishers for audiovisual and other rights.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "We have also recently entered into licenses directly with certain publishers for audiovisual and other rights in the United States. Most of"
- Checked: 2026-11-10

#### [M-0088] VERIFIED
- Claim: In the US public performance rights for compositions come through PROs (ASCAP, BMI, GMR, SESAC) under blanket licences, with usage reporting duties and one to four year terms.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "In the United States, public performance rights are generally obtained through intermediaries known as performing rights organizations (“PROs”), which negotiate blanket licenses with copyright users for the public performance of"
- Checked: 2026-11-10

#### [M-0089] VERIFIED
- Claim: Spotify's licensors in general include record labels, aggregators, artists, music publishers and PROs, and failure to obtain or keep those licences is a stated business risk.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 3D risk factors
- Quote: "To secure the rights to stream content, we enter into license agreements to obtain licenses from rights holders, such as record labels, aggregators, artists, music publishers, performing rights organizations, collecting"
- Checked: 2026-11-10

#### [M-0090] VERIFIED
- Claim: UK: the author of a work is its first owner of copyright, subject to the exceptions in s.11.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.11(1)
- Quote: "The author of a work is the first owner of any copyright in it, subject"
- Checked: 2026-11-10

#### [M-0091] VERIFIED
- Claim: UK: where a literary, dramatic, musical or artistic work or film is made by an employee in the course of employment, the employer is first owner subject to contrary agreement.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.11(2)
- Quote: "Where a literary, dramatic, musical or artistic work [F5, or a film,] is made by an employee in the course of his employment, his employer is the first owner of any copyright in the work"
- Checked: 2026-11-10

#### [M-0092] VERIFIED
- Claim: UK: the author of a sound recording is the producer.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.9(2)(aa)
- Quote: "in the case of a sound recording, the"
- Checked: 2026-11-10

#### [M-0093] VERIFIED
- Claim: UK: s.11(2) employer first ownership lists literary, dramatic, musical, artistic works and films but not sound recordings, so a sound recording's first owner is its author, the producer (s.9(2)(aa), s.11(1)), subject to assignment or agreement (inference).
- Jurisdiction: analysis
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA ss.9(2)(aa), 11(1)-(2)
- Quote: "is made by an employee in the course of his employment, his employer is the first owner of any copyright in the"
- Checked: 2026-11-10

#### [M-0096] VERIFIED
- Claim: UK: copyright is transmissible by assignment, testamentary disposition or operation of law, and an assignment must be in writing signed by or on behalf of the assignor.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.90(1), (3)
- Quote: "An assignment of copyright is not effective unless it is in writing signed by or on behalf of the assignor. (4)A licence"
- Checked: 2026-11-10

#### [M-0097] VERIFIED
- Claim: UK: an exclusive licence means a licence in writing signed by or on behalf of the copyright owner authorising the licensee to the exclusion of all others to exercise a right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.92(1)
- Quote: "In this Part an “exclusive licence” means a licence in writing signed by or on behalf of the copyright owner authorising the licensee to the"
- Checked: 2026-11-10

#### [M-0098] VERIFIED
- Claim: UK: an agreement to assign future copyright, signed by the prospective owner, takes effect as an assignment when the copyright comes into existence.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.91(1)
- Quote: "Where by an agreement made in relation to future copyright, and signed by or on behalf of the prospective owner of the copyright, the prospective"
- Checked: 2026-11-10

#### [M-0234] VERIFIED
- Claim: CDPA s.16(1): the copyright owner has the exclusive right to copy, issue copies, rent or lend, perform in public, communicate to the public and adapt.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(1)(a)-(e)
- Quote: "The owner of the copyright in a work has, in accordance with the following provisions of this Chapter, the exclusive right to do the following acts in the United Kingdom--"
- Checked: 2026-11-10

#### [M-0235] VERIFIED
- Claim: CDPA s.16(2): copyright is infringed by a person who without licence does, or authorises another to do, a restricted act.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(2)
- Quote: "Copyright in a work is infringed by a person who without the licence of the copyright owner does, or authorises another to do, any of the acts restricted by the"
- Checked: 2026-11-10

#### [M-0236] VERIFIED
- Claim: CDPA s.20(1): communication to the public of a musical work (and a sound recording, film or broadcast) is an act restricted by the copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(1)
- Quote: "The communication to the public of the work is an act restricted by the copyright"
- Checked: 2026-11-10

#### [M-0237] VERIFIED
- Claim: CDPA s.20(2)(b): communication to the public includes making a work available on demand, individually chosen place and time.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(2)(b)
- Quote: "the making available to the public of the work by electronic transmission in such a way that members of the public may access it from a place and at a time individually chosen by"
- Checked: 2026-11-10

#### [M-0255] VERIFIED
- Claim: UK: under CDPA s.16(2) a person infringes who without licence does or authorises another to do an act restricted by copyright, and s.20(b) restricts making a work available on demand by electronic transmission, so (analysis) a UK-facing platform may face direct or authorising liability.
- Jurisdiction: analysis
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA ss.16(2), 20(b)
- Quote: "Copyright in a work is infringed by a person who without the licence of the copyright owner does, or authorises another to do, any of the acts restricted by the"
- Checked: 2026-11-10

#### [M-0447] VERIFIED
- Claim: Cal. Civ. Code 3344.1 defines digital replica as a computer-generated, highly realistic electronic representation readily identifiable as an individual's voice or visual likeness.
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(B)(ii)(I)
- Quote: "“Digital replica” means a computer-generated, highly realistic electronic representation that is readily identifiable as the voice or visual likeness of an individual"
- Checked: 2026-11-10

#### [M-0448] VERIFIED
- Claim: Cal. Civ. Code 3344.1(a)(2)(A)(i): producing, distributing or making available a deceased personality's digital replica in an expressive audiovisual work or sound recording without prior consent carries liability of the greater of $10,000 or actual damages, subject to the exceptions in (a)(2)(A)(ii).
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(A)(i)
- Quote: "shall be liable to any injured party in an amount equal to the greater of ten thousand dollars ($10,000) or the actual damages suffered"
- Checked: 2026-11-10

#### [M-0449] VERIFIED
- Claim: Cal. Lab. Code 927: a contract term allowing a digital replica of voice or likeness in place of in-person work is unenforceable for new performances from Jan. 1, 2025 if it lacks a reasonably specific description of uses and the individual lacked representation.
- Jurisdiction: US-CA
- Source: California Labor Code s.927 Digital replica contract provisions, AB 2602 (2024) (public.law mirror) (https://california.public.law/codes/labor_code_section_927), source id ca-lab-927
- Pinpoint: Lab. Code 927(a)
- Quote: "is unenforceable only as it relates to a new performance, fixed on or after January 1, 2025, by a digital replica"
- Checked: 2026-11-10
