# Music law knowledge pack: AI, voice clones and publicity
- File: 04-ai-voice-publicity.md, part of the music law knowledge pack (remix edition).
- Contains: M15 AI training and outputs; M16 Voice clones and digital replicas; M17 Publicity and false endorsement. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-10.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M15 AI training and outputs
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Can a user put AI generated music in a mix; Who owns AI generated music; Is training an AI model on songs fair use; Does the TRAIN Act or any AI music bill apply today; Does the EU or UK let AI companies train on music; Can a platform process audio a user made with AI

### Bottom line
US federal law has no AI training rule in a statute. Whether training on recordings and songs is fair use is undecided for music: the fair use test is case by case, and the only US training rulings saved are about books, not music [M-0203, M-0421]. Purely AI-generated material is not copyrightable in the Copyright Office's view, so a creator who prompts a generator may own little or nothing in the track [M-0415, M-0416]. AI output can still copy a real song, so a licence or consent question remains for both copyrights, the composition and the master. As of 2026-11-10 the TRAIN Act is a bill, not law [M-0006].

### Rules
#### US federal: training
- Section 107 makes fair use a four factor, non exhaustive test, and the statute states no number of seconds or safe length [M-0203]. Factor four is the effect on the market for or value of the work [M-0204].
- Copyright Office, Part 3 report (regulator guidance, pre-publication version of May 2025, persuasive not binding): the Office expects some training uses will be fair use and some will not [M-0418, M-0020]. As of 2026-11-10 no final Part 3 is published [M-0020].
- The same report says fairness depends on which works were used, from what source, for what purpose, and with what controls on outputs [M-0419]. It treats lost licensing revenue as part of market harm [M-0420].
- Bartz v. Anthropic (court decision, N.D. Cal., 23 June 2025, district court, books not music): training on lawfully acquired books was fair use, described as exceedingly transformative [M-0421]. Downloading and keeping pirated copies for a central library was not excused, and the court set a trial on those copies [M-0422]. Later settlement and appeals are not in the saved sources.
- Kadrey v. Meta (court decision, N.D. Cal., 25 June 2025): the judge said in many circumstances it will be illegal to copy protected works to train generative AI without permission [M-0423]. That is dicta in a market dilution discussion; the same order gave Meta summary judgment on that record. Do not cite it as a holding that training is illegal.
- Music cases are pleadings and procedure so far. UMG, Capitol and Sony sued Suno in D. Mass. in June 2024 (No. 1:24-cv-11611) alleging copying of recordings to train its model [M-0424] (pleading, not a finding). The UMG complaint against Udio pleaded that unlicensed AI services could saturate the market and compete with genuine recordings [M-0430] (allegation only).
- UMG dismissed its claims against Udio on 3 November 2025 and Warner dismissed on 25 November 2025, without prejudice [M-0011, M-0429]. Warner and Suno stipulated to dismissal of Warner's claims against Suno on 9 December 2025; settlement terms are not in the saved text [M-0012].
- The Suno case continues for the other labels. On 18 August 2026 the court found the labels' 17 U.S.C. 1201(a)(1) stream ripping claim plausible and allowed amendment [M-0013]. That is a pleading ruling, not a merits ruling. Amended complaint filed 25 August 2026 [M-0014]. Suno argued the YouTube measure limits copying but does not control access; the court described that argument and still found the claim plausible [M-0427].
- Section 1201(a)(1)(A) bars circumventing a measure that controls access to a work [M-0489]. Section 1201(a)(2) bars trafficking in circumvention tools [M-0490]. Section 1201 does not affect fair use or other infringement defences [M-0491].
- Concord v. Anthropic (court decision, N.D. Cal., 6 Oct 2025): the court denied dismissal of contributory, vicarious and DMCA 1202(b) claims over lyrics output [M-0492]. Pleading stage, lyrics not audio. Its contributory test predates Cox v. Sony (2026), so do not use it for the current contributory standard (see M09).

#### US federal: outputs and authorship
- Musical works and sound recordings are separate categories of copyrightable work [M-0028, M-0029].
- Copyright Office, Part 2 (regulator guidance, persuasive not binding): copyright does not extend to purely AI-generated material or to material with insufficient human control over expressive elements [M-0415].
- Prompts alone do not give enough control to make the user the author, given current generally available technology [M-0416]. This is tied to today's technology and may change.
- The Office does not recommend legislation on copyrightability and expects courts to give more guidance [M-0417].

#### US federal: pending bill
- TRAIN Act (pending bill, not law): S. 2455, introduced 24 July 2025 by Sen. Welch, referred to Senate Judiciary [M-0478]. H.R. 7209, an identical House bill, introduced 22 January 2026 by Rep. Dean, referred to House Judiciary [M-0505]. Neither is law [M-0006].
- If passed, S. 2455 would let a copyright owner with a good faith belief ask a district court clerk for a subpoena to a generative AI developer for records sufficient to identify the owner's works used in training. It targets the developer, with no host duty [M-0479]. Status files are dated 2026-08-10 (S. 2455) and 2026-08-20 (H.R. 7209) [M-0006].

#### EU
- CDSM Art. 3: text and data mining exception for research organisations and cultural heritage institutions, for scientific research [M-0399].
- CDSM Art. 4: general mining exception for lawfully accessible works, unless the rightholder has reserved use in an appropriate manner [M-0400]. Art. 4(3) limits it to uses not expressly reserved, for online content by machine readable means [M-0442]. National transposition varies.
- AI Act Art. 53(1)(c): providers of general purpose AI models need a copyright policy that identifies and honours Art. 4(3) reservations [M-0439]. Art. 53(1)(d): they must publish a sufficiently detailed training content summary on the AI Office template [M-0440]. These duties apply from 2 August 2025 [M-0441]. Regulation (EU) 2026/1744 was read as not amending Art. 53 or 113(b) per the ledger notes, but that regulation text is not saved (needs source).
- The EU GPAI Code of Practice copyright chapter (voluntary, binds signatories only): Measure 1.3(1) commits signatories to comply with machine readable rights reservations when crawling [M-0493]. Measure 1.4(1)(a) commits them to technical safeguards against infringing reproduction in outputs [M-0494].
- GEMA v. OpenAI (foreign court decision, LG Munich I, 11 Nov 2025, 42 O 14139/24, first instance, lyrics not audio): memorising works in a language model is a reproduction [M-0431]. The mining exception covers copies made to build training data but not training the model itself [M-0432]. Model operators, not users, were liable for infringing outputs from simple prompts [M-0433]. Appeal to OLG Munich pending per the source header; later status unchecked.
- CDSM Art. 17 makes an online content sharing service responsible for user uploads and removes the hosting safe harbour for it [M-0387, M-0388]. See M08 and M19 for the upload regime.

#### UK
- CDPA s.29A allows copies for text and data analysis only for non commercial research by a person with lawful access, with acknowledgement [M-0239]. It does not cover commercial training.
- Data (Use and Access) Act 2025 s.135 required an economic impact assessment and s.136 a report, each within nine months of the Act [M-0434, M-0435].
- The s.136 report (March 2026, policy statement not law) says a broad exception with opt out is no longer the preferred option [M-0436, M-0015]. No AI training exception is enacted [M-0436].
- The report proposes removing protection for wholly computer generated works (CDPA s.9(3) type) while keeping protection for AI assisted works [M-0437, M-0016]. Proposal only.
- It says a digital replica or personality right is under further consideration. Exploration only [M-0438]. See M16.
- CDPA s.30A fair dealing for caricature, parody or pastiche exists, and a contract term restricting a permitted act is unenforceable [M-0240, M-0241].

### Gotchas
- "Training is fair use" is not settled for music. The US training rulings saved are about books and are district court orders [M-0421, M-0423]. Kadrey's illegality line is dicta [M-0423].
- Do not call the Udio or Suno dismissals a ruling that AI music is lawful. They are stipulated dismissals with no terms in the saved text [M-0011, M-0012, M-0429].
- Pleadings are not findings [M-0424, M-0430]. The Suno 1201 order is a leave to amend ruling [M-0013].
- The Copyright Office Part 3 is a pre-publication version and persuasive only [M-0418, M-0020]. Part 2 is persuasive, not binding [M-0415].
- The TRAIN Act, and any digital replica bill, are not law [M-0006]. A subpoena right would not itself make training lawful or unlawful [M-0479].
- GEMA v. OpenAI concerns lyrics, first instance, with an appeal pending [M-0431].
- Removing, muting or editing audio is not a licence and does not clear a track. Where the track is protected, the missing licence is sync for the composition and master use for the recording, from the publisher and the label; see M07.
- Currency: Part 3 final, appeals in GEMA, Bartz settlement, the UK policy path and Suno case history all move. Last checked 2026-11-10.

### Open questions for counsel
- US: does a creator who prompts a music generator and edits the result hold a copyright in the output that they can license to a platform?
- US: do a platform's creator terms need an AI disclosure and a warranty that AI music does not copy a protected song?
- US: what Suno or Udio terms, if any, allow commercial use on a user upload platform?
- US: does a platform's processing of creator audio need an express no training clause in its terms and vendor contracts?
- EU: if a platform serves EU users and offers an AI feature, does it count as a general purpose model provider under AI Act Art. 53, or only a downstream deployer?
- EU and UK: what does a reasonable machine readable rights reservation look like for creator uploads on a platform?
- US: has the TRAIN Act moved since 2026-08-20, and is any music AI case on appeal?

### Sources
- co-ai-part2-copyrightability-2025: Copyright Office, AI Part 2: Copyrightability (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-2-Copyrightability-Report.pdf)
- co-ai-part3-training-prepub-2025: Copyright Office, AI Part 3: Generative AI Training, pre-publication (https://www.copyright.gov/ai/)
- ndcal-bartz-anthropic-2025: Bartz v. Anthropic, ECF 231 (https://storage.courtlistener.com/recap/gov.uscourts.cand.434709/gov.uscourts.cand.434709.231.0.pdf)
- ndcal-kadrey-meta-2025: Kadrey v. Meta, ECF 598 (CourtListener)
- ndcal-concord-anthropic: Concord v. Anthropic, ECF 461 (CourtListener)
- dmass-umg-suno-complaint, dmass-umg-suno-2026, dmass-umg-suno-fac-2026, dmass-suno-warner-letter-2025: UMG v. Suno filings (CourtListener, govinfo)
- sdny-umg-udio-complaint, sdny-udio-umg-dismissal-2025, sdny-udio-warner-dismissal-2025: UMG v. Udio filings (CourtListener)
- de-lgmuenchen-gema-openai-2025: LG Munich I, GEMA v OpenAI (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False)
- s2455-train-act-status, s2455-train-act-text, hr7209-train-act-status: TRAIN Act bill status and text (govinfo)
- usc17-102, usc17-107, usc17-1201: 17 U.S.C. 102, 107, 1201 (https://www.law.cornell.edu/uscode/text/17/107)
- eu-cdsm-2019-790, eu-aiact-2024-1689, eu-gpai-code-copyright: EU Directive 2019/790, AI Act, GPAI Code (https://eur-lex.europa.eu)
- uk-cdpa-s29a, uk-cdpa-s30a, uk-duaa-2025-ai, uk-gov-ai-copyright-report-s136: UK statute and s.136 report (https://www.legislation.gov.uk)

### Claims cited in M15
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0421] VERIFIED
- Claim: Bartz v. Anthropic (N.D. Cal., Alsup J., June 23, 2025): training LLMs on lawfully acquired books was fair use, described as exceedingly transformative.
- Jurisdiction: case-law
- Source: Bartz v. Anthropic PBC, No. 3:24-cv-05417-WHA, ECF 231, Order on Fair Use (N.D. Cal. June 23, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.cand.434709/gov.uscourts.cand.434709.231.0.pdf), source id ndcal-bartz-anthropic-2025
- Pinpoint: ECF 231, p. 15
- Quote: "was exceedingly transformative and was a fair use under Section 107 of the"
- Checked: 2026-11-10

#### [M-0415] VERIFIED
- Claim: Copyright Office position: copyright does not extend to purely AI-generated material or material with insufficient human control over expressive elements.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 2: Copyrightability (January 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-2-Copyrightability-Report.pdf), source id co-ai-part2-copyrightability-2025
- Pinpoint: Part 2, Executive Summary
- Quote: "Copyright does not extend to purely AI-generated material, or material where there is insufficient human control over the expressive elements."
- Checked: 2026-11-10

#### [M-0416] VERIFIED
- Claim: Prompts alone do not give a user enough control to be the author of AI output, given current generally available technology.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 2: Copyrightability (January 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-2-Copyrightability-Report.pdf), source id co-ai-part2-copyrightability-2025
- Pinpoint: Part 2, Part V conclusion on prompts
- Quote: "The Office concludes that, given current generally available technology, prompts alone do not provide sufficient human control to make users of an AI system the authors of the output."
- Checked: 2026-11-10

#### [M-0006] VERIFIED
- Claim: The TRAIN Act is pending as S. 2455 and H.R. 7209; neither is law.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 2455 (119th) TRAIN Act (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s2455.xml), source id s2455-train-act-status
- Pinpoint: BILLSTATUS latestAction 2025-07-24 (S. 2455)
- Quote: "Read twice and referred to the Committee on the Judiciary."
- Checked: 2026-11-10

#### [M-0204] VERIFIED
- Claim: The fourth fair use factor is the effect on the potential market for or value of the work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107(4)
- Quote: "the effect of the use upon the potential market for or value of the copyrighted"
- Checked: 2026-11-10

#### [M-0418] VERIFIED
- Claim: Copyright Office Part 3 pre-publication: the Office expects some uses of copyrighted works for generative AI training will qualify as fair use and some will not.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 3: Generative AI Training, pre-publication version (May 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-3-Generative-AI-Training-Report-Pre-Publication-Version.pdf), source id co-ai-part3-training-prepub-2025
- Pinpoint: Part 3 pre-publication, fair use conclusion (Section IV)
- Quote: "The Office expects that some uses of copyrighted works for generative AI training will qualify as fair use, and some will not."
- Checked: 2026-11-10

#### [M-0020] VERIFIED
- Claim: The Copyright Office's Part 3 report on generative AI training was released as a pre-publication version in May 2025 and says a final version will follow.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 3: Generative AI Training, pre-publication version (May 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-3-Generative-AI-Training-Report-Pre-Publication-Version.pdf), source id co-ai-part3-training-prepub-2025
- Pinpoint: cover page and preface paragraph
- Quote: "The Office is releasing this pre-publication version of Part 3 in response to congressional inquiries and expressions of interest from stakeholders. A final version will be published in the near future"
- Checked: 2026-11-10

#### [M-0419] VERIFIED
- Claim: Part 3 says fairness of training depends on what works were used, from what source, for what purpose, and with what controls on outputs.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 3: Generative AI Training, pre-publication version (May 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-3-Generative-AI-Training-Report-Pre-Publication-Version.pdf), source id co-ai-part3-training-prepub-2025
- Pinpoint: Part 3 pre-publication, transformative use discussion
- Quote: "The extent to which they are fair, however, will depend on what works were used, from what source, for what purpose, and with what controls on the outputs"
- Checked: 2026-11-10

#### [M-0420] VERIFIED
- Claim: Part 3 treats lost licensing revenue as part of market harm under the fourth fair use factor.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 3: Generative AI Training, pre-publication version (May 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-3-Generative-AI-Training-Report-Pre-Publication-Version.pdf), source id co-ai-part3-training-prepub-2025
- Pinpoint: Part 3 pre-publication, factor four (lost licensing)
- Quote: "Lost revenue in actual or potential licensing markets can also be an element of market harm."
- Checked: 2026-11-10

#### [M-0422] VERIFIED
- Claim: Bartz: downloading and keeping pirated copies for a central library was not excused; the court set a trial on the pirated copies and damages including willfulness.
- Jurisdiction: case-law
- Source: Bartz v. Anthropic PBC, No. 3:24-cv-05417-WHA, ECF 231, Order on Fair Use (N.D. Cal. June 23, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.cand.434709/gov.uscourts.cand.434709.231.0.pdf), source id ndcal-bartz-anthropic-2025
- Pinpoint: ECF 231, p. 31-32 (conclusion)
- Quote: "We will have a trial on the pirated copies used to create Anthropic’s central library and the resulting damages, actual or statutory (including for willfulness)."
- Checked: 2026-11-10

#### [M-0423] VERIFIED
- Claim: Kadrey v. Meta (N.D. Cal., Chhabria J., June 25, 2025): the court said in many circumstances it will be illegal to copy protected works to train generative AI without permission.
- Jurisdiction: case-law
- Source: Kadrey v. Meta Platforms, Inc., No. 3:23-cv-03417-VC, ECF 598, order on cross-motions for partial summary judgment (fair use) (N.D. Cal. June 25, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.cand.415175/gov.uscourts.cand.415175.598.0.pdf), source id ndcal-kadrey-meta-2025
- Pinpoint: ECF 598, Part on market harm
- Quote: "The upshot is that in many circumstances it will be illegal to copy copyright-protected works to train generative AI models without permission."
- Checked: 2026-11-10

#### [M-0424] VERIFIED
- Claim: UMG, Capitol and Sony sued Suno in D. Mass. (No. 1:24-cv-11611) in June 2024 alleging copying of recordings to train its model.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Suno, Inc., No. 1:24-cv-11611 (D. Mass.), ECF 1, Complaint (June 24, 2024) (https://storage.courtlistener.com/recap/gov.uscourts.mad.272063/gov.uscourts.mad.272063.1.0.pdf), source id dmass-umg-suno-complaint
- Pinpoint: ECF 1
- Quote: "copying protected sound recordings for the purpose of developing an AI product requires permission from rightsholders"
- Checked: 2026-11-10

#### [M-0430] VERIFIED
- Claim: The UMG v. Udio complaint pleaded that AI services built on unlicensed copying of sound recordings could saturate the market and compete with genuine recordings.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Uncharted Labs, Inc. (Udio), No. 1:24-cv-04777 (S.D.N.Y.), ECF 1, Complaint (June 24, 2024) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.623701/gov.uscourts.nysd.623701.1.0.pdf), source id sdny-umg-udio-complaint
- Pinpoint: ECF 1, p. 2
- Quote: "the service’s synthetic musical outputs could saturate the market with machine-generated content"
- Checked: 2026-11-10

#### [M-0011] VERIFIED
- Claim: UMG dismissed its claims against Udio on November 3, 2025 and Warner dismissed on November 25, 2025.
- Jurisdiction: case-law
- Source: UMG Recordings v. Uncharted Labs, No. 1:24-cv-04777-AKH, ECF 136, Stipulation of dismissal by UMG plaintiffs (Nov. 3, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.623701/gov.uscourts.nysd.623701.136.0.pdf), source id sdny-udio-umg-dismissal-2025
- Pinpoint: ECF 136 stipulation para. 1
- Quote: "all claims asserted by Plaintiffs UMG Recordings, Inc. and Capitol Records, LLC as against defendant Uncharted Labs, Inc. d/b/a Udio.com are hereby dismissed without prejudice."
- Checked: 2026-11-10

#### [M-0429] VERIFIED
- Claim: Warner plaintiffs also dismissed their claims against Udio without prejudice by stipulation filed Nov. 25, 2025 (Rule 41(a)(1)(A)(ii)).
- Jurisdiction: case-law
- Source: UMG Recordings v. Uncharted Labs, No. 1:24-cv-04777-AKH, ECF 140, Stipulation of dismissal by Warner plaintiffs (Nov. 25, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.nysd.623701/gov.uscourts.nysd.623701.140.0.pdf), source id sdny-udio-warner-dismissal-2025
- Pinpoint: ECF 140, para. 1
- Quote: "as against defendant Uncharted Labs, Inc. d/b/a Udio.com are hereby dismissed without prejudice."
- Checked: 2026-11-10

#### [M-0012] VERIFIED
- Claim: Warner Music plaintiffs and Suno stipulated to a voluntary dismissal of Warner's claims against Suno (letter filed Dec. 9, 2025).
- Jurisdiction: case-law
- Source: UMG Recordings v. Suno, No. 1:24-cv-11611-FDS, ECF 174, Warner plaintiffs' letter on settlement and dismissal of Warner's claims (Dec. 9, 2025) (https://storage.courtlistener.com/recap/gov.uscourts.mad.272063/gov.uscourts.mad.272063.174.0.pdf), source id dmass-suno-warner-letter-2025
- Pinpoint: letter to Judge Saylor, ECF 174, filed 12/09/25, p.1
- Quote: "Warner and Defendant Suno, Inc. (\"Suno\") have stipulated to a voluntary dismissal of Warner's claims against Suno"
- Checked: 2026-11-10

#### [M-0013] VERIFIED
- Claim: On August 18, 2026 the District of Massachusetts found the labels' 17 U.S.C. 1201(a)(1) anticircumvention (stream-ripping) claim against Suno plausible and granted leave to amend to add it.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Suno, Inc., No. 1:24-cv-11611-FDS, ECF 271, Memorandum and Order on plaintiffs' first motion to amend (17 U.S.C. 1201 claim) (D. Mass. Aug. 18, 2026) (https://www.govinfo.gov/content/pkg/USCOURTS-mad-1_24-cv-11611/pdf/USCOURTS-mad-1_24-cv-11611-4.pdf), source id dmass-umg-suno-2026
- Pinpoint: ECF 271, Memorandum and Order, p.2 (Aug. 18, 2026)
- Quote: "the complaint alleges a plausible claim for violation of § 1201(a)(1), and the Court will grant plaintiffs' motion for leave to amend."
- Checked: 2026-11-10

#### [M-0014] VERIFIED
- Claim: The labels filed an amended complaint against Suno on August 25, 2026.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Suno, Inc., No. 1:24-cv-11611 (D. Mass.), ECF 277, First Amended Complaint (Aug. 25, 2026) (plaintiffs UMG, Capitol, Sony) (https://storage.courtlistener.com/recap/gov.uscourts.mad.272063/gov.uscourts.mad.272063.277.0.pdf), source id dmass-umg-suno-fac-2026
- Pinpoint: ECF 277, First Amended Complaint, preamble (filed 08/25/26)
- Quote: "by and through their undersigned counsel, file this First Amended Complaint against Suno, Inc."
- Checked: 2026-11-10

#### [M-0427] VERIFIED
- Claim: Suno's defence in the 1201 motion: the YouTube measure inhibits copying but does not control access, and 1201 reaches access controls only.
- Jurisdiction: case-law
- Source: UMG Recordings, Inc. v. Suno, Inc., No. 1:24-cv-11611-FDS, ECF 271, Memorandum and Order on plaintiffs' first motion to amend (17 U.S.C. 1201 claim) (D. Mass. Aug. 18, 2026) (https://www.govinfo.gov/content/pkg/USCOURTS-mad-1_24-cv-11611/pdf/USCOURTS-mad-1_24-cv-11611-4.pdf), source id dmass-umg-suno-2026
- Pinpoint: ECF 271, p. 2
- Quote: "Section 1201 proscribes circumventing access controls but does not proscribe circumventing copy controls."
- Checked: 2026-11-10

#### [M-0489] VERIFIED
- Claim: 17 U.S.C. 1201(a)(1)(A): no person shall circumvent a technological measure that effectively controls access to a copyrighted work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1201 circumvention of copyright protection systems (https://www.law.cornell.edu/uscode/text/17/1201), source id usc17-1201
- Pinpoint: 17 U.S.C. 1201(a)(1)(A)
- Quote: "No person shall circumvent a technological measure that effectively controls access to a work protected under this title."
- Checked: 2026-11-10

#### [M-0490] VERIFIED
- Claim: 17 U.S.C. 1201(a)(2) bars trafficking in tools primarily designed to circumvent an access control.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1201 circumvention of copyright protection systems (https://www.law.cornell.edu/uscode/text/17/1201), source id usc17-1201
- Pinpoint: 17 U.S.C. 1201(a)(2)(A)
- Quote: "is primarily designed or produced for the purpose of circumventing a technological measure that effectively controls access to a work protected under this title"
- Checked: 2026-11-10

#### [M-0491] VERIFIED
- Claim: 17 U.S.C. 1201(c)(1): section 1201 does not affect fair use or other defences to infringement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1201 circumvention of copyright protection systems (https://www.law.cornell.edu/uscode/text/17/1201), source id usc17-1201
- Pinpoint: 17 U.S.C. 1201(c)(1)
- Quote: "Nothing in this section shall affect rights, remedies, limitations, or defenses to copyright infringement, including fair use, under this title."
- Checked: 2026-11-10

#### [M-0492] VERIFIED
- Claim: Concord v. Anthropic (N.D. Cal., Oct. 6, 2025, ECF 461): the court denied Anthropic's motion to dismiss the first amended complaint's contributory, vicarious and DMCA 1202(b) CMI removal claims over song lyrics output.
- Jurisdiction: case-law
- Source: Concord Music Group v. Anthropic, N.D. Cal. 5:24-cv-03811, order of 2025-10-06 (ECF 461) on motion to dismiss FAC (https://storage.courtlistener.com/recap/gov.uscourts.cand.431519/gov.uscourts.cand.431519.461.0_2.pdf), source id ndcal-concord-anthropic
- Pinpoint: ECF 461, caption
- Quote: "ORDER DENYING MOTION TO DISMISS FIRST AMENDED COMPLAINT"
- Checked: 2026-11-10

#### [M-0028] VERIFIED
- Claim: 17 U.S.C. 102(a) lists musical works, including any accompanying words, among the categories of copyrightable original works of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(2)
- Quote: "musical works, including any accompanying words; (3) dramatic"
- Checked: 2026-11-10

#### [M-0029] VERIFIED
- Claim: Sound recordings are listed as their own category of copyrightable work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 102 subject matter of copyright (https://www.law.cornell.edu/uscode/text/17/102), source id usc17-102
- Pinpoint: 17 U.S.C. 102(a)(7)
- Quote: "sound recordings; and (8)"
- Checked: 2026-11-10

#### [M-0417] VERIFIED
- Claim: Copyright Office does not recommend legislation on AI copyrightability and says courts will give further guidance.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 2: Copyrightability (January 2025) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-2-Copyrightability-Report.pdf), source id co-ai-part2-copyrightability-2025
- Pinpoint: Part 2, legislation discussion
- Quote: "Unless and until future developments raise new problems, the Office does not recommend a change in the law."
- Checked: 2026-11-10

#### [M-0478] VERIFIED
- Claim: S. 2455 (TRAIN Act) was introduced July 24, 2025 by Sen. Welch and referred to Senate Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 2455 (119th) TRAIN Act (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s2455.xml), source id s2455-train-act-status
- Pinpoint: BILLSTATUS S.2455
- Quote: "Sen. Welch, Peter [D-VT]"
- Checked: 2026-11-10

#### [M-0505] VERIFIED
- Claim: H.R. 7209 (identical House bill to S. 2455, TRAIN Act) was introduced January 22, 2026 by Rep. Dean and referred to House Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, H.R. 7209 (119th) TRAIN Act (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr7209.xml), source id hr7209-train-act-status
- Pinpoint: BILLSTATUS H.R.7209
- Quote: "Rep. Dean, Madeleine [D-PA-4]"
- Checked: 2026-11-10

#### [M-0479] VERIFIED
- Claim: S. 2455 (TRAIN Act, bill not law) would let a copyright owner ask a district court clerk to issue a subpoena to a generative AI model developer for copies or records sufficient to identify the owner's works used in training.
- Jurisdiction: US-federal
- Source: S. 2455 (119th), TRAIN Act (Transparency and Responsibility for Artificial Intelligence Networks), as introduced in Senate July 24, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s2455is/html/BILLS-119s2455is.htm), source id s2455-train-act-text
- Pinpoint: S.2455 proposed 17 U.S.C. 514(b)(1)
- Quote: "may request the clerk of any United States district court to issue a subpoena to a developer for disclosure of copies of, or records sufficient to identify with certainty, the copyrighted works"
- Checked: 2026-11-10

#### [M-0399] VERIFIED
- Claim: CDSM Art 3: TDM exception for research organisations and cultural heritage institutions for scientific research.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 3(1)
- Quote: "Member States shall provide for an exception to the rights provided for in Article 5(a) and Article 7(1) of Directive 96/9/EC"
- Checked: 2026-11-10

#### [M-0400] VERIFIED
- Claim: CDSM Art 4: general TDM exception for lawfully accessible works, available unless the rightholder has reserved use in an appropriate manner.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(1), (3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online"
- Checked: 2026-11-10

#### [M-0442] VERIFIED
- Claim: CDSM Art. 4(3): the TDM exception applies only if the use has not been expressly reserved by rightholders, for online content in machine-readable form.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online."
- Checked: 2026-11-10

#### [M-0439] VERIFIED
- Claim: EU AI Act Art. 53(1)(c): GPAI model providers must have a copyright compliance policy that identifies and honours Article 4(3) CDSM rights reservations.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 53(1)(c)
- Quote: "put in place a policy to comply with Union law on copyright and related rights, and in particular to identify and comply with, including through state-of-the-art technologies, a reservation of rights expressed pursuant to Article 4(3) of Directive (EU) 2019/790;"
- Checked: 2026-11-10

#### [M-0440] VERIFIED
- Claim: EU AI Act Art. 53(1)(d): GPAI providers must publish a sufficiently detailed summary of training content using the AI Office template.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 53(1)(d)
- Quote: "draw up and make publicly available a sufficiently detailed summary about the content used for training of the general-purpose AI model, according to a template provided by the AI Office."
- Checked: 2026-11-10

#### [M-0441] VERIFIED
- Claim: The GPAI obligations (Chapter V) apply from 2 August 2025.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 113(b)
- Quote: "Chapter V, Chapter VII and Chapter XII and Article 78 shall apply from 2 August 2025, with the exception of Article 101"
- Checked: 2026-11-10

#### [M-0493] VERIFIED
- Claim: EU GPAI Code of Practice copyright chapter, Measure 1.3(1): signatories commit to identify and comply with machine-readable reservations of rights under Article 4(3) of Directive 2019/790 when using web crawlers for text and data mining.
- Jurisdiction: EU
- Source: EU GPAI Code of Practice (copyright chapter) page (https://ec.europa.eu/newsroom/dae/redirection/document/118115), source id eu-gpai-code-copyright
- Pinpoint: Copyright chapter, Measure 1.3
- Quote: "machine-readable reservations of rights expressed pursuant to Article 4(3) of Directive (EU) 2019/790"
- Checked: 2026-11-10

#### [M-0494] VERIFIED
- Claim: EU GPAI Code of Practice (voluntary, copyright chapter) Measure 1.4(1)(a): to mitigate the risk that downstream AI systems built on a general-purpose model generate infringing output, signatories commit to appropriate and proportionate technical safeguards against the model generating outputs that reproduce protected training content in an infringing manner.
- Jurisdiction: EU
- Source: EU GPAI Code of Practice (copyright chapter) page (https://ec.europa.eu/newsroom/dae/redirection/document/118115), source id eu-gpai-code-copyright
- Pinpoint: Copyright chapter, Measure 1.4(1)(a)
- Quote: "to implement appropriate and proportionate technical safeguards to prevent their models from generating outputs that reproduce training content protected by Union law on copyright and related rights in an infringing manner"
- Checked: 2026-11-10

#### [M-0431] VERIFIED
- Claim: GEMA v. OpenAI (LG Munich I, Nov. 11, 2025, 42 O 14139/24): memorising works in a language model is a reproduction under UrhG s.16. Translation: memorisation of language works in the AI model is a reproduction because the work is physically fixed and can be made indirectly perceptible.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 2 (Rn. 181)
- Quote: "Die Memorisierung von Sprachwerken im KI-Sprachmodell stellt eine Vervielfältigung nach § 16 UrhG dar, weil das Werk körperlich festgelegt ist und es mittelbar wahrnehmbar gemacht werden kann."
- Checked: 2026-11-10

#### [M-0432] VERIFIED
- Claim: GEMA v. OpenAI: the TDM exception (UrhG s.44b) covers copies made to build training data but not the training of the model itself. Translation: the barrier of s.44b covers reproduction when creating training data material, but not training the model.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 4 (Rn. 193)
- Quote: "Unter die Schranke des § 44b UrhG unterfallen Vervielfältigung beim Erstellen des Trainigsdatenmaterials, nicht aber bei dem Training des Modells"
- Checked: 2026-11-10

#### [M-0433] VERIFIED
- Claim: GEMA v. OpenAI: the model operators, not the users, are liable for infringing outputs produced by simple prompts. Translation: operators of the language model are liable for infringement through outputs because they control the act.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 5 (Rn. 275-277)
- Quote: "Die Betreiber des Sprachmodells haften für Urheberrechtsverletzung durch Outputs, weil sie die Tatherrschaft ausüben."
- Checked: 2026-11-10

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0239] VERIFIED
- Claim: CDPA s.29A permits copies for text and data analysis only for the sole purpose of non-commercial research by a person with lawful access.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.29A Copies for text and data analysis for non-commercial research (https://www.legislation.gov.uk/ukpga/1988/48/section/29A), source id uk-cdpa-s29a
- Pinpoint: CDPA s.29A(1)(a)
- Quote: "the copy is made in order that a person who has lawful access to the work may carry out a computational analysis of anything recorded in the work for the sole purpose of research for a non-commercial purpose"
- Checked: 2026-11-10

#### [M-0434] VERIFIED
- Claim: UK DUAA 2025 s.135 requires an economic impact assessment of the four copyright and AI policy options within 9 months of the Act being passed.
- Jurisdiction: UK
- Source: Data (Use and Access) Act 2025 ss.135-137 Copyright works and artificial intelligence systems (economic impact assessment, report, progress statement) (https://www.legislation.gov.uk/ukpga/2025/18/part/7/crossheading/copyright-works-and-artificial-intelligence-systems), source id uk-duaa-2025-ai
- Pinpoint: Data (Use and Access) Act 2025 s.135(1)
- Quote: "must, before the end of the period of 9 months beginning with the day on which this Act is passed-- (a)prepare and publish an assessment of the economic impact in the United Kingdom of each of the four policy options"
- Checked: 2026-11-10

#### [M-0435] VERIFIED
- Claim: UK DUAA 2025 s.136 requires a report on use of copyright works in developing AI systems, laid before Parliament within 9 months.
- Jurisdiction: UK
- Source: Data (Use and Access) Act 2025 ss.135-137 Copyright works and artificial intelligence systems (economic impact assessment, report, progress statement) (https://www.legislation.gov.uk/ukpga/2025/18/part/7/crossheading/copyright-works-and-artificial-intelligence-systems), source id uk-duaa-2025-ai
- Pinpoint: DUAA 2025 s.136(1)
- Quote: "prepare and publish a report on the use of copyright works in the development of AI systems, and (b)lay the report before Parliament."
- Checked: 2026-11-10

#### [M-0436] VERIFIED
- Claim: The UK s.136 report (March 2026) says a broad copyright exception with opt-out is no longer the government's preferred way forward.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A, overview
- Quote: "broad copyright exception with opt-out is no longer the government’s preferred way forward."
- Checked: 2026-11-10

#### [M-0015] VERIFIED
- Claim: The UK government published its section 136 report on copyright and AI in March 2026; a text and data mining exception with opt-out is no longer its preferred option.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Report, Summary (March 2026)
- Quote: "a broad copyright exception with opt-out is no longer the government's preferred way forward."
- Checked: 2026-11-10

#### [M-0437] VERIFIED
- Claim: The s.136 report proposes removing copyright protection for wholly computer-generated works (CDPA s.9(3) type protection) while keeping protection for works made with AI assistance.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A, computer-generated works
- Quote: "we propose that this specific type of protection should be removed, while copyright should continue to protect works created with AI assistance."
- Checked: 2026-11-10

#### [M-0016] VERIFIED
- Claim: The UK government proposes to remove protection for computer-generated works under CDPA s.9(3).
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Report, Summary, Computer-generated works (s.9(3) discussed in Section I)
- Quote: "in the absence of evidence of its ongoing value, we propose that this specific type of protection should be removed, while copyright should continue to protect works created with AI assistance."
- Checked: 2026-11-10

#### [M-0438] VERIFIED
- Claim: The s.136 report says further consideration is being given to whether to introduce a new digital replica or personality right.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A overview, digital replicas
- Quote: "consideration of whether it would be beneficial to introduce a new digital replica or personality right."
- Checked: 2026-11-10

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0241] VERIFIED
- Claim: CDPA s.30A(2): a contract term that restricts an act permitted by the parody exception is unenforceable.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(2)
- Quote: "To the extent that a term of a contract purports to prevent or restrict the doing of any act which, by virtue of this section, would not infringe copyright, that term is"
- Checked: 2026-11-10

## M16 Voice clones and digital replicas
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Can a user put an AI clone of a famous singer's voice in a mix; Is a platform liable for a user mix that contains a voice clone; Does the NO FAKES Act apply to a mixing platform or a processing tool; Which states protect voice; Does a soundalike need a licence; What does the UK protect

### Bottom line
- Jurisdiction first: US federal law has no digital replica statute today. The NO FAKES Act (S. 4591, H.R. 8915) is a bill, not law. As of the saved status file (updated 2026-08-10, last listed action 2026-06-24) S. 4591 was reported and on the Senate calendar, with no floor vote in the file [M-0003, M-0004, M-0465]. H.R. 8915 was referred to committee with no later action in a file updated 2026-10-23 [M-0466].
- Today the rules are state law (Tennessee, California, New York, Illinois), the Lanham Act false endorsement claim, and older voice cases from the Ninth Circuit [M-0443, M-0446, M-0450, M-0456, M-0458, M-0462].
- A voice clone is its own right, apart from the composition and the master. A licence to a song does not clear a clone of a singer's voice. The person whose voice is copied (or an heir, or a label or union holding the right by contract) grants consent. Nobody here can promise a voice is cleared. (analysis)
- Whether any state or bill rule applies to a given platform or tool is a question for a licensed attorney. This card is not legal advice.
- For a platform that hosts user uploads, the main US risks are state voice claims against the person who made the clone and, under some statutes, against those who distribute it knowing it is unauthorized [M-0443, M-0456]. A tool that only re-encodes a user's own file privately likely sits outside the bill's online service definition (unverified) [M-0488].

### Rules
#### US federal (pending bills, not law)
- S. 1367 and H.R. 2794 (2025) were introduced 2025-04-09 and went no further than committee referral [M-0005, M-0463, M-0464]. S. 4591 and H.R. 8915 (2026) were introduced 2026-05-20 [M-0003].
- S. 4591 was reported with a substitute on 2026-06-24 and placed on the calendar (Calendar No. 446). Status file updated 2026-08-10, last listed action 2026-06-24, and may have moved [M-0004, M-0465].
- (pending bill) S. 4591 as reported defines online service to include a site or app that predominantly gives public access to user uploaded material. A UGC short-video platform would appear to fit (analysis) [M-0467, M-0487].
- (pending bill) Safe harbor conditions for a UGC service: remove or disable access to a noticed replica as soon as feasible [M-0469]; also remove later uploads that match the replica's fingerprint, called stay down [M-0470]; register a designated agent with the Copyright Office [M-0471]. The repeat violator policy condition is written for a different provider prong, not the UGC prong [M-0468, M-0487].
- (pending bill) Without the safe harbor, a UGC service is liable only if its agent received a compliant notice or court order, or it willfully avoided one [M-0472]. Voluntary use of removal tools does not alone give actual knowledge [M-0477].
- (pending bill) The extra exclusions (news, documentary, commentary, parody, fleeting use) do not apply to a replica used to depict sexually explicit conduct [M-0473].
- (pending bill) Section 230 would not shield a platform, because the right is treated as intellectual property [M-0475]. The Copyright Office recommended the same carve out in 2024 [M-0484].
- (pending bill) Preemption: state claims over replicas in expressive works are preempted, but state laws existing on 2025-01-02 and state laws on sexually explicit or election replicas are saved [M-0474]. The Office's 2024 recommendation was a federal floor with no full preemption [M-0483].
- (pending bill) The right lasts 10 years after death, renewable in 5 year periods on proof of use, and ends 70 years after death [M-0476].
- (regulator guidance) The Copyright Office report (July 2024) recommended a federal replica law with a notice safe harbor, and liability only on actual knowledge [M-0481, M-0482]. A recommendation, not law.
- The 2025 text differs from 2026: failure to register an agent was conclusive proof of no good faith in S. 1367, but a rebuttable presumption after 90 days in S. 4591 and H.R. 8915 [M-0499, M-0503, M-0471]. S. 1367 as introduced has the same UGC definition and stay down duty [M-0495, M-0497]. H.R. 2794 matches S. 1367 on definition, takedown and stay down [M-0500].
- H.R. 8915 has the same takedown and stay down conditions as S. 4591 [M-0501, M-0502].

#### US federal (law in force)
- Lanham Act 43(a)(1)(A) bars false or misleading statements likely to cause confusion about affiliation, sponsorship or approval. It is the base for a false endorsement claim when a cloned voice suggests a singer backs a product [M-0462].
- (court decision) Midler v. Ford (9th Cir. 1988): deliberately imitating a widely known singer's distinctive voice to sell a product is a California tort. Narrow: distinctive, widely known, deliberate, to sell [M-0458].
- (court decision) Waits v. Frito-Lay (9th Cir. 1992) affirmed voice misappropriation and Lanham Act false endorsement over a soundalike ad, but vacated the Lanham damages award as duplicative [M-0459].
- (court decision) Lehrman v. Lovo (S.D.N.Y., 2025-07-10), motion to dismiss stage: voice clone claims mostly failed under federal trademark and copyright law but could proceed under N.Y. Civil Rights Law 50 and 51. Copyright claims on use of an original recording, contract and consumer claims survived. Later history unchecked [M-0460, M-0461].

#### Tennessee
- (state statute) The ELVIS Act (Pub. Ch. 588, 2024) protects an individual's voice, including a simulation of the voice [M-0019, M-0444]. Effective 2024-07-01 [M-0443].
- Liability: publishing, performing, distributing or making available a voice or likeness knowing it was not authorized [M-0443].
- It also reaches distributors of a tool whose primary purpose is producing a particular person's voice or likeness, with knowledge it was unauthorized [M-0445].

#### California
- (state statute) Civ. Code 3344: knowing use of another's name, voice, signature, photograph or likeness on goods or to advertise or sell, without prior consent, is actionable [M-0446].
- Civ. Code 3344.1 defines digital replica as a computer generated, highly realistic representation readily identifiable as a person's voice or visual likeness. It excludes authorized sampling, remixing and mastering [M-0447].
- For a deceased personality, producing or making available a replica in an expressive audiovisual work or sound recording without consent carries the greater of $10,000 or actual damages, subject to listed exceptions [M-0448].

#### New York
- (state statute) Civil Rights Law 50 makes use of a living person's name, portrait, picture, likeness or voice for advertising or trade without written consent a misdemeanor. Section 51 gives an injunction and damages for knowing use [M-0450, M-0451].
- Section 50-f: using a deceased performer's replica in an audiovisual work, sound recording or live musical performance, knowing it was unauthorized, creates liability. The right ends 40 years after death [M-0452, M-0453].
- Section 50-f(9) exempts owners and employees of an advertising medium, including streaming services, unless they had actual knowledge by prior notice. Scope is advertising media and does not obviously cover a UGC host (analysis) [M-0454].
- General Obligations Law 5-302(1) voids a services contract clause that allows a replica in place of in person work, if it lacks a reasonably specific description of uses and meets the other conditions. All conditions are needed [M-0455].

#### Illinois
- (state statute) Right of Publicity Act s.30(b): no person may knowingly distribute or make available a sound recording or audiovisual work with actual knowledge it contains an unauthorized digital replica [M-0456].
- Public Act 103-0836 added digital replica provisions to that Act [M-0506]. The claimed effective date of 2025-01-01 is (unverified) [M-0017]. State no date as fact.
- The Digital Voice and Likeness Protection Act (P.A. 103-830) voids services contract clauses that allow a replica in place of work without a reasonably specific description, where the person also lacked counsel or union representation [M-0457]. P.A. 104-0282 amended it, effective 2026-01-01 [M-0018].

#### United Kingdom (foreign law)
- A performer's consent is needed to record a live performance or broadcast it live (CDPA s.182) [M-0243], to copy a recording of it (s.182A) [M-0244], and to make it available on demand (s.182CA) [M-0245].
- Showing, playing or communicating a performance by means of a recording the person knows or has reason to believe was made without consent infringes (s.183) [M-0247].
- Equitable remuneration is owed to the performer from the copyright owner when a published recording is played in public or communicated to the public, other than on demand (s.182D) [M-0246].
- Section 191HA lets a performer recover rights after 50 years if the producer does not issue or offer the recording. Rarely relevant to a short-video app [M-0248].
- These rights protect the performance itself. The ledger holds no UK row on whether an AI voice clone is a protected performance. Do not state that it is.

### Gotchas
- NO FAKES is not law. Every S. 4591, S. 1367, H.R. 2794 and H.R. 8915 statement is a bill description. Status is as of the status file updated 2026-08-10 for S. 4591 and the 2026-10-23 file for H.R. 8915 [M-0465, M-0466].
- Bill text changed between 2025 and 2026. Check which version a source describes [M-0499, M-0503].
- A US federal voice or likeness right does not exist yet. Lanham Act false endorsement needs confusion about sponsorship [M-0462].
- Lehrman v. Lovo is an early motion ruling. Do not read it as a final merits holding [M-0460].
- Soundalikes are not free. Midler and Waits turned on deliberate imitation of a famous voice to sell a product [M-0458, M-0459]. Whether a creator video that is not an ad fits those cases is open (analysis).
- A song licence, a library licence or a platform sound licence covers music, not a person's voice cloned to perform it (analysis). Do not tell a creator a library covers a platform without the saved terms text.
- State death periods differ: New York 40 years [M-0453], the bill 70 years at most [M-0476].
- The Illinois effective date is not confirmed (unverified) [M-0017].
- Needs source: Lehrman v. Lovo later history, live streaming under replica laws, and UK law on AI clones.

### Open questions for counsel
- US federal: does a UGC video app with creator uploads fit prong (i) of S. 4591 (online service), and does an agent registration plus stay down plan fit its file pipeline?
- Tennessee and Illinois: what counts as actual knowledge of an unauthorized clone for a host, a notice, or a pattern of reports?
- California and New York: do 3344 and 50 and 51 reach a non ad creator video on a UGC app, and does 50-f(9) cover a short-video host?
- Is a voice changing or voice cloning feature in a platform a tool within the Tennessee distributor rule [M-0445]?
- UK: does an AI clone of a performer's voice infringe CDPA performer rights, and who is liable if a platform serves UK users?
- What wording should a platform use in creator terms to require consent for any cloned voice and to allow quick removal?

### Sources
- s4591-status, s4591-nofakes-2026-reported-text: S. 4591 status and reported text (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml)
- s1367-status, s1367-nofakes-text, hr2794-status, hr2794-nofakes-text: 2025 NO FAKES bills (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s1367.xml)
- hr8915-status, hr8915-nofakes-2026-text: H.R. 8915 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr8915.xml)
- co-ai-part1-digital-replicas-2024: Copyright Office, Part 1: Digital Replicas, July 2024 (https://www.copyright.gov/ai/)
- tn-pc588-2024-elvis: Tennessee ELVIS Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf)
- ca-civ-3344, ca-civ-3344-1: California Civil Code 3344 and 3344.1 (https://california.public.law/codes/civil_code_section_3344)
- ny-cvr-50, ny-cvr-51, ny-cvr-50-f, ny-gol-5-302: New York Civil Rights Law and General Obligations Law (https://newyork.public.law/laws/n.y._civil_rights_law_section_50)
- il-765ilcs1075-30, il-pa103-0836-publicity, il-pa103-0830-dvlpa, il-pa104-0282-dvlpa-amend: Illinois statutes (https://ilga.gov/ftp/Public%20Acts/103/103-0830.htm)
- ca9-midler-1988, ca9-waits-1992: Midler and Waits (https://static.case.law/f2d/849/html/0460-01.html)
- sdny-lehrman-lovo-2025: Lehrman v. Lovo, ECF 45 (https://www.nysd.uscourts.gov/)
- usc15-1125: 15 U.S.C. 1125 (https://www.law.cornell.edu/uscode/text/15/1125)
- uk-cdpa-s182-s184, uk-cdpa-s191a-s191m: CDPA 1988 performers' rights (https://www.legislation.gov.uk/ukpga/1988/48)

### Claims cited in M16
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0003] VERIFIED
- Claim: The NO FAKES Act was reintroduced on May 20, 2026 as S. 4591 and H.R. 8915.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS actions, 2026-05-20 Introduced in Senate
- Quote: "Introduced in Senate"
- Checked: 2026-11-10

#### [M-0004] VERIFIED
- Claim: S. 4591 was reported with an amendment in the nature of a substitute on June 24, 2026 and placed on the Senate legislative calendar.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS actions, 2026-06-24 reported by Senator Grassley
- Quote: "Committee on the Judiciary. Reported by Senator Grassley with an amendment in the nature of a substitute. Without written report."
- Checked: 2026-11-10

#### [M-0465] VERIFIED
- Claim: S. 4591 (NO FAKES Act of 2026) was introduced May 20, 2026 by Sen. Coons, reported by Senate Judiciary June 24, 2026 and placed on the Senate calendar.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS S.4591
- Quote: "Placed on Senate Legislative Calendar under General Orders. Calendar No. 446."
- Checked: 2026-11-10

#### [M-0466] VERIFIED
- Claim: H.R. 8915 (NO FAKES Act of 2026) was introduced May 20, 2026 by Rep. Salazar and referred to House Judiciary; no later action in the status file.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, H.R. 8915 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr8915.xml), source id hr8915-status
- Pinpoint: BILLSTATUS H.R.8915
- Quote: "Referred to the House Committee on the Judiciary."
- Checked: 2026-11-10

#### [M-0443] VERIFIED
- Claim: ELVIS Act: a person is liable if they publish, perform, distribute or make available an individual's voice or likeness knowing it was not authorized.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.6, T.C.A. 47-25-1105(a)(2) as amended
- Quote: "publishes, performs, distributes, transmits, or otherwise makes available to the public an individual's voice or likeness, with knowledge that use of the voice or likeness was not authorized"
- Checked: 2026-11-10

#### [M-0446] VERIFIED
- Claim: Cal. Civ. Code 3344(a)(1): knowing use of another's name, voice, signature, photograph or likeness on goods or to advertise or sell products or services without prior consent is actionable.
- Jurisdiction: US-CA
- Source: California Civil Code s.3344 Use of another's name, voice, signature, photograph, or likeness (public.law mirror) (https://california.public.law/codes/civil_code_section_3344), source id ca-civ-3344
- Pinpoint: 3344(a)(1)
- Quote: "Any person who knowingly uses another’s name, voice, signature, photograph, or likeness, in any manner, on or in products, merchandise, or goods, or for purposes of advertising or selling"
- Checked: 2026-11-10

#### [M-0450] VERIFIED
- Claim: N.Y. Civ. Rights Law 50: use of a living person's name, portrait, picture, likeness or voice for advertising or trade without written consent is a misdemeanor.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50 Right of privacy (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50), source id ny-cvr-50
- Pinpoint: CRL s.50
- Quote: "A person, firm or corporation that uses for advertising purposes, or for the purposes of trade, the name, portrait, picture, likeness, or voice of any living person without having first obtained the written consent of such person"
- Checked: 2026-11-10

#### [M-0456] VERIFIED
- Claim: Illinois ROPA s.30(b): no person may knowingly distribute or make available to the public a sound recording or audiovisual work with actual knowledge it contains an unauthorized digital replica.
- Jurisdiction: US-IL
- Source: Illinois Right of Publicity Act 765 ILCS 1075/30 Limitations regarding use of an individual's identity; unauthorized digital replicas (current compiled text, P.A. 103-836, eff. 1-1-25) (https://ilga.gov/legislation/ilcs/documents/076510750K30.htm), source id il-765ilcs1075-30
- Pinpoint: 765 ILCS 1075/30(b)
- Quote: "A person may not knowingly distribute, transmit, or make available to the general public a sound recording or audiovisual work with actual knowledge that the work contains an unauthorized digital replica."
- Checked: 2026-11-10

#### [M-0458] VERIFIED
- Claim: Midler v. Ford: deliberately imitating a widely known professional singer's distinctive voice to sell a product is a tort in California.
- Jurisdiction: case-law
- Source: Midler v. Ford Motor Co., 849 F.2d 460 (9th Cir. 1988) (Caselaw Access Project mirror) (https://static.case.law/f2d/849/html/0460-01.html), source id ca9-midler-1988
- Pinpoint: 849 F.2d 460, 463
- Quote: "when a distinctive voice of a professional singer is widely known and is deliberately imitated in order to sell a product, the sellers have appropriated what is not theirs and have committed a tort in California."
- Checked: 2026-11-10

#### [M-0462] VERIFIED
- Claim: Lanham Act 43(a)(1)(A) bars false or misleading representations likely to cause confusion as to affiliation, sponsorship or approval.
- Jurisdiction: US-federal
- Source: 15 U.S.C. 1125 Lanham Act section 43(a) false designation of origin and false endorsement (https://www.law.cornell.edu/uscode/text/15/1125), source id usc15-1125
- Pinpoint: 15 U.S.C. 1125(a)(1)(A)
- Quote: "is likely to cause confusion, or to cause mistake, or to deceive as to the affiliation, connection, or association of such person with another person, or as to the origin, sponsorship, or approval"
- Checked: 2026-11-10

#### [M-0488] UNVERIFIED (unverified)
- Claim: Analysis: A tool that re-encodes a user's own video privately and does not host public user uploaded material probably falls outside the online service prong (i) of S.4591 (inference).
- Jurisdiction: analysis
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(a)(5)(A)(i)
- Quote: "predominantly provides public access to user uploaded material;"
- Checked: 2026-11-10

#### [M-0005] VERIFIED
- Claim: The 2025 NO FAKES bills, S. 1367 and H.R. 2794, did not advance past committee referral.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 1367 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s1367.xml), source id s1367-status
- Pinpoint: BILLSTATUS actions, 2025-04-09 (S. 1367)
- Quote: "Read twice and referred to the Committee on the Judiciary."
- Checked: 2026-11-10

#### [M-0463] VERIFIED
- Claim: S. 1367 (NO FAKES Act of 2025) was introduced April 9, 2025; sponsor Sen. Coons; referred to Senate Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 1367 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s1367.xml), source id s1367-status
- Pinpoint: BILLSTATUS S.1367
- Quote: "Sen. Coons, Christopher A. [D-DE]"
- Checked: 2026-11-10

#### [M-0464] VERIFIED
- Claim: H.R. 2794 (NO FAKES Act of 2025) was introduced April 9, 2025 by Rep. Salazar and referred to House Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, H.R. 2794 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr2794.xml), source id hr2794-status
- Pinpoint: BILLSTATUS H.R.2794
- Quote: "Rep. Salazar, Maria Elvira [R-FL-27]"
- Checked: 2026-11-10

#### [M-0467] VERIFIED
- Claim: S. 4591 as reported (substitute text; a bill, not law) defines online service to include any site or app that predominantly provides public access to user uploaded material; a UGC short-video platform would appear to fit.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(a)(5)(A)(i)
- Quote: "any website, online application, mobile application, or virtual reality environment that predominantly provides public access to user uploaded material;"
- Checked: 2026-11-10

#### [M-0487] VERIFIED
- Claim: Analysis: A UGC platform would appear to fall in S.4591 (reported) online service prong (i) and so would need a registered designated agent, a takedown process and fingerprint stay-down for replicas; the bill is not law.
- Jurisdiction: analysis
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(a)(5)(A)(i), 2(d)(1)(B)(ii)(I)(bb), 2(d)(2)(A)(i)
- Quote: "A provider of an online service described in clause (i) or (ii) of subsection (a)(5)(A) shall"
- Checked: 2026-11-10

#### [M-0469] VERIFIED
- Claim: S. 4591 as reported (bill, not law): to keep the online-service safe harbor, on a compliant notice the provider must remove or disable access to the noticed work as soon as technologically and practically feasible.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(1)(B)(ii)(I)(aa)
- Quote: "removes or disables access to the work embodying the claimed unauthorized use of a digital replica"
- Checked: 2026-11-10

#### [M-0470] VERIFIED
- Claim: S. 4591 as reported (bill, not law): to keep the safe harbor, a UGC online service (sec. 2(a)(5)(A)(i)) must also remove other publicly available instances that match the digital fingerprint of the noticed replica and were uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(1)(B)(ii)(I)(bb)
- Quote: "removes or disables access to all other publicly available instances of the work embodying the claimed unauthorized use of a digital replica that-- (AA) match the digital fingerprint"
- Checked: 2026-11-10

#### [M-0471] VERIFIED
- Claim: S. 4591 as reported (bill, not law): UGC online services (sec. 2(a)(5)(A)(i)) must register a designated agent with the Copyright Office; failure to register by the later of 90 days after the effective date or 90 days after becoming such a provider raises a presumption of no good faith effort.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(2)(A)(i) and (C)
- Quote: "There shall be established a presumption that a provider of an online service described in subparagraph (A)(i) has not undertaken a good faith effort to comply with this subsection if the provider has failed to register a designated agent"
- Checked: 2026-11-10

#### [M-0468] VERIFIED
- Claim: Pending bill, not law: under S. 4591 as reported, an online service provider is not liable for a violation if it has adopted and reasonably implemented a repeat-violator termination policy and acts on compliant notices (sec. 2(d)(1)(B)(i)-(ii)).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported substitute) sec. 2(d)(1)(B)(i)
- Quote: "has adopted and reasonably implemented, and has informed users of the online service of, a policy that provides for the termination in appropriate circumstances of account holders of the online service that are repeat violators"
- Checked: 2026-11-10

#### [M-0472] VERIFIED
- Claim: S. 4591 as reported (bill, not law): an online service described in sec. 2(c)(3)(A)(ii) (UGC sites, music providers for user uploaded recordings, other services for third-party material) incurs liability only if its designated agent received a compliant notification or court order, or willfully avoided receiving one.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(3)(A)(i)
- Quote: "must have received a notification that satisfies the requirements under subsection (d)(3), or a court order stating, or must have willfully avoided receipt of such a notification"
- Checked: 2026-11-10

#### [M-0477] VERIFIED
- Claim: S. 4591 as reported: voluntary use of tools to remove content does not alone confer actual knowledge of a violation.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(6)
- Quote: "The voluntary use of any tool to remove or disable access to content shall not alone confer actual knowledge of a particular violation of this section."
- Checked: 2026-11-10

#### [M-0473] VERIFIED
- Claim: S. 4591 as reported (bill, not law): the sec. 2(c)(5)(A) additional exclusions (news, documentary or historical, commentary or parody, fleeting use, related ads) do not apply where the digital replica is used to depict sexually explicit conduct (18 U.S.C. 2256(2)(A)).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(5)(B)
- Quote: "Subparagraph (A) shall not apply where the applicable digital replica is used to depict sexually explicit conduct"
- Checked: 2026-11-10

#### [M-0475] VERIFIED
- Claim: S. 4591 as reported treats the right as a law pertaining to intellectual property for 47 U.S.C. 230(e)(2), so Section 230 would not shield platforms.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(h)(1)
- Quote: "This section shall be considered to be a law pertaining to intellectual property for the purposes of section 230(e)(2) of the Communications Act of 1934 (47 U.S.C. 230(e)(2))."
- Checked: 2026-11-10

#### [M-0484] VERIFIED
- Claim: Part 1 recommends excluding a federal digital replica law from Section 230 to encourage prompt removal.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Section 230 discussion (Secondary Liability, p. 37)
- Quote: "The Copyright Office believes that exclusion from section 230 is advisable to encourage prompt removal of unauthorized digital replicas from online platforms."
- Checked: 2026-11-10

#### [M-0474] VERIFIED
- Claim: S. 4591 as reported (bill, not law) preempts state-law claims over digital replicas in expressive works but saves state statutes and common law in existence as of Jan. 2, 2025 and state statutes specifically regulating sexually explicit or election-related digital replicas.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(g)(2)
- Quote: "causes of action under State statutes specifically regulating a digital replica depicting sexually explicit conduct"
- Checked: 2026-11-10

#### [M-0483] VERIFIED
- Claim: Part 1 recommends no full federal preemption: federal law should be a floor and states may keep their laws.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary (Relationship to State Laws)
- Quote: "Given well-established state rights of publicity and privacy, the Office does not recommend full federal preemption."
- Checked: 2026-11-10

#### [M-0476] VERIFIED
- Claim: S. 4591 as reported (bill, not law): the digital replica right lasts 10 years after death, extendable in 5-year renewals on proof of active and authorized public use, and in all cases ends 70 years after death.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(b)(2)(A)(iv)-(v)
- Quote: "the date that is 70 years after the death of the individual."
- Checked: 2026-11-10

#### [M-0481] VERIFIED
- Claim: Copyright Office Part 1 recommends a new federal digital replica law with a safe harbor mechanism for online providers that remove replicas after effective notice or knowledge.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary (Secondary Liability)
- Quote: "The statute should include a safe harbor mechanism that incentivizes online service providers to remove unauthorized digital replicas after receiving effective notice or otherwise obtaining knowledge that they are unauthorized."
- Checked: 2026-11-10

#### [M-0482] VERIFIED
- Claim: Part 1 recommends liability require actual knowledge that the representation was a digital replica of a particular individual and was unauthorized.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary
- Quote: "It should require actual knowledge both that the representation was a digital replica of a particular individual and that it was unauthorized."
- Checked: 2026-11-10

#### [M-0499] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): failure of a clause (i) UGC service to register a designated agent shall establish that it made no good faith effort to comply (conclusive, no 90 day grace, unlike the 2026 text).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(2)(C)
- Quote: "shall establish that the provider has not undertaken a good faith effort to comply with this subsection"
- Checked: 2026-11-10

#### [M-0503] VERIFIED
- Claim: H.R. 8915 as introduced (bill, not law): failing to register a designated agent raises a rebuttable presumption of no good faith, applying after the later of 90 days after the effective date or 90 days after becoming a clause (i) provider.
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(2)(C)
- Quote: "There shall be established a presumption that a provider of an online service described in subparagraph (A)(i) has not undertaken a good faith effort to comply with this subsection if the provider has failed to register a designated agent"
- Checked: 2026-11-10

#### [M-0495] VERIFIED
- Claim: S. 1367 as introduced defines online service to include any site or app that predominantly provides public access to user uploaded material, so a UGC short-video platform would appear to fit (bill, not law).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(a)(5)(A)(i)
- Quote: "any website, online application, mobile application, or virtual reality environment that predominantly provides public access to user uploaded material;"
- Checked: 2026-11-10

#### [M-0497] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): the safe harbor also requires services in sec. 2(a)(5)(A)(i) or (ii) (UGC sites and music providers) to remove other public instances matching the digital fingerprint of the noticed replica and uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(1)(B)(ii)(II)
- Quote: "removes or disables access to all other publicly available instances of the work embodying the claimed unauthorized digital replica that-- (aa) match the digital fingerprint"
- Checked: 2026-11-10

#### [M-0500] VERIFIED
- Claim: H.R. 2794 as introduced has the same online service definition, notice and takedown condition and stay down duty as S. 1367 (the text differs only in header, sponsors and assigns/assignees).
- Jurisdiction: US-federal
- Source: H.R. 2794 (119th), NO FAKES Act of 2025, as introduced in House April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119hr2794ih/html/BILLS-119hr2794ih.htm), source id hr2794-nofakes-text
- Pinpoint: H.R.2794 sec. 2(d)(1)(B)(ii)(I)
- Quote: "upon receiving a notification that satisfies the requirements under paragraph (3), the provider-- (I) removes or disables access to the work embodying the claimed unauthorized digital replica"
- Checked: 2026-11-10

#### [M-0501] VERIFIED
- Claim: H.R. 8915 as introduced May 20, 2026 (bill, not law): on a compliant notice the service must, to keep the safe harbor, remove or disable access to the noticed work as soon as technologically and practically feasible.
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(1)(B)(ii)(I)(aa)
- Quote: "upon receiving a notification that satisfies the requirements under paragraph (3), the provider-- (aa) removes or disables access to the work embodying the claimed unauthorized digital replica"
- Checked: 2026-11-10

#### [M-0502] VERIFIED
- Claim: H.R. 8915 as introduced (bill, not law): to keep the safe harbor, a UGC service (sec. 2(a)(5)(A)(i)) must also remove other public instances matching the digital fingerprint of the noticed replica uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(1)(B)(ii)(I)(bb)
- Quote: "for the provider of an online service described in subsection (a)(5)(A)(i), as soon as is technologically and practically feasible for that provider, removes or disables access to all other publicly available instances"
- Checked: 2026-11-10

#### [M-0459] VERIFIED
- Claim: Waits v. Frito-Lay (9th Cir. 1992): the Ninth Circuit affirmed the judgment for voice misappropriation and Lanham Act s.43(a) false endorsement over a soundalike commercial, except that it vacated the Lanham Act damages award as duplicative.
- Jurisdiction: case-law
- Source: Waits v. Frito-Lay, Inc., 978 F.2d 1093 (9th Cir. 1992) (Caselaw Access Project mirror) (https://static.case.law/f2d/978/html/1093-01.html), source id ca9-waits-1992
- Pinpoint: 978 F.2d 1093, 1096
- Quote: "Because it is duplicative, we vacate the award of damages under the Lanham Act. We affirm in all other respects."
- Checked: 2026-11-10

#### [M-0460] VERIFIED
- Claim: Lehrman v. Lovo (S.D.N.Y. July 10, 2025): voice-clone claims mostly fail under federal trademark and copyright law but may proceed under N.Y. Civil Rights Law 50 and 51.
- Jurisdiction: case-law
- Source: Lehrman v. Lovo, Inc., No. 24-cv-3770 (JPO), ECF 45, Opinion and Order on motion to dismiss (S.D.N.Y. July 10, 2025) (https://www.nysd.uscourts.gov/sites/default/files/2025-07/Lovo%20v%20Lehrman.pdf), source id sdny-lehrman-lovo-2025
- Pinpoint: ECF 45, p. 1
- Quote: "claims for misappropriation of a voice, like the ones here, may be properly asserted under Sections 50 and 51 of the New York Civil Rights Law"
- Checked: 2026-11-10

#### [M-0461] VERIFIED
- Claim: Lehrman v. Lovo: motion denied as to copyright claims on use of an original voice recording and as to contract, NY Civil Rights Law and GBL claims.
- Jurisdiction: case-law
- Source: Lehrman v. Lovo, Inc., No. 24-cv-3770 (JPO), ECF 45, Opinion and Order on motion to dismiss (S.D.N.Y. July 10, 2025) (https://www.nysd.uscourts.gov/sites/default/files/2025-07/Lovo%20v%20Lehrman.pdf), source id sdny-lehrman-lovo-2025
- Pinpoint: ECF 45, p. 59 (Conclusion)
- Quote: "The motion is denied as to Sage’s copyright claims based on the use of her original voice recording"
- Checked: 2026-11-10

#### [M-0019] VERIFIED
- Claim: Tennessee's ELVIS Act (Pub. Ch. 588, 2024) adds an individual's voice to the protected rights of publicity.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Section 4 (amending T.C.A. 47-25-1103(a)); Section 3 defines Voice
- Quote: "Every individual has a property right in the use of that individual's name, photograph, voice, or likeness in any medium in any manner."
- Checked: 2026-11-10

#### [M-0444] VERIFIED
- Claim: ELVIS Act defines voice to include a simulation of the voice.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.3, T.C.A. 47-25-1102
- Quote: ""Voice" means a sound in a medium that is readily identifiable and attributable to a particular individual, regardless of whether the sound contains the actual voice or a simulation of the voice of the individual"
- Checked: 2026-11-10

#### [M-0445] VERIFIED
- Claim: ELVIS Act reaches distributors of a tool whose primary purpose is producing a particular identifiable individual's voice or likeness, with knowledge it was unauthorized.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.6, 47-25-1105(a)(3)
- Quote: "the primary purpose or function of such algorithm, software, tool, or other technology, service, or device is the production of a particular, identifiable individual's photograph, voice, or likeness"
- Checked: 2026-11-10

#### [M-0447] VERIFIED
- Claim: Cal. Civ. Code 3344.1 defines digital replica as a computer-generated, highly realistic electronic representation readily identifiable as an individual's voice or visual likeness.
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(B)(ii)(I)
- Quote: "“Digital replica” means a computer-generated, highly realistic electronic representation that is readily identifiable as the voice or visual likeness of an individual"
- Checked: 2026-11-10

#### [M-0448] VERIFIED
- Claim: Cal. Civ. Code 3344.1(a)(2)(A)(i): producing, distributing or making available a deceased personality's digital replica in an expressive audiovisual work or sound recording without prior consent carries liability of the greater of $10,000 or actual damages, subject to the exceptions in (a)(2)(A)(ii).
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(A)(i)
- Quote: "shall be liable to any injured party in an amount equal to the greater of ten thousand dollars ($10,000) or the actual damages suffered"
- Checked: 2026-11-10

#### [M-0451] VERIFIED
- Claim: N.Y. Civ. Rights Law 51 allows an injunction and damages against knowing use of name, portrait, picture, likeness or voice for advertising or trade without consent.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.51 Action for injunction and for damages (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_51), source id ny-cvr-51
- Pinpoint: CRL s.51
- Quote: "may maintain an equitable action in the supreme court of this state against the person, firm or corporation so using such person’s name, portrait, picture, likeness or voice, to prevent and restrain the use thereof"
- Checked: 2026-11-10

#### [M-0452] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f: using a deceased performer's digital replica in an audiovisual work, sound recording or live musical performance with knowledge it was unauthorized creates liability.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(2)(b)
- Quote: "uses a deceased performer’s digital replica in an audiovisual work, sound recording, or for the live performance of a musical work, with knowledge that the use was of a digital replica and was not authorized"
- Checked: 2026-11-10

#### [M-0453] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f post-mortem right ends forty years after death.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(8)
- Quote: "occurring after the expiration of forty years after the death of the deceased personality."
- Checked: 2026-11-10

#### [M-0454] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f(9) says it does not apply to owners or employees of an advertising medium (including streaming services) for the content, unless it is established that they had actual knowledge by prior notification of the unauthorized use.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(9)
- Quote: "streaming services, cable television systems, billboards, and transit advertisements, by whom any advertisement or solicitation in violation of this section is published or disseminated, unless it is established"
- Checked: 2026-11-10

#### [M-0455] VERIFIED
- Claim: N.Y. Gen. Oblig. Law 5-302(1) makes void and unenforceable, as to a new performance by digital replication, a services-contract provision that allows a digital replica in place of in-person work, lacks a reasonably specific description of uses, and meets the statute's remaining conditions.
- Jurisdiction: US-NY
- Source: New York General Obligations Law s.5-302 Contracts for the creation and use of digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._general_obligations_law_section_5-302), source id ny-gol-5-302
- Pinpoint: GOL s.5-302(1)
- Quote: "shall be void and unenforceable as it relates to a new performance by digital replication if the provision meets all of the following conditions"
- Checked: 2026-11-10

#### [M-0506] VERIFIED
- Claim: Illinois Public Act 103-0836 (HB4875) amended the Right of Publicity Act to add a definition of digital replica and related provisions; effective date not confirmed in saved text.
- Jurisdiction: US-IL
- Source: Illinois Public Act 103-0836 (HB4875, 2024) amending the Right of Publicity Act 765 ILCS 1075 for digital replicas (https://ilga.gov/legislation/publicacts/103/103-0836.htm), source id il-pa103-0836-publicity
- Pinpoint: Section 5, amending 765 ILCS 1075/5 (Definitions)
- Quote: ""Digital replica" means a newly created, electronic representation of the voice, image, or likeness of an actual individual"
- Checked: 2026-11-10

#### [M-0017] UNVERIFIED (unverified)
- Claim: Illinois Public Act 103-0836 added digital replica provisions to the Right of Publicity Act, effective January 1, 2025.
- Jurisdiction: US-IL
- Source: Illinois Public Act 103-0836 (HB4875, 2024) amending the Right of Publicity Act 765 ILCS 1075 for digital replicas (https://ilga.gov/legislation/publicacts/103/103-0836.htm), source id il-pa103-0836-publicity
- Pinpoint: effective date
- Quote: ""
- Checked: 2026-11-10

#### [M-0457] VERIFIED
- Claim: Illinois Digital Voice and Likeness Protection Act (P.A. 103-830) voids services-contract provisions that allow a digital replica in place of work without a reasonably specific description and representation.
- Jurisdiction: US-IL
- Source: Illinois Public Act 103-0830 (HB4762, 2024) Digital Voice and Likeness Protection Act (https://ilga.gov/ftp/Public%20Acts/103/103-0830.htm), source id il-pa103-0830-dvlpa
- Pinpoint: P.A. 103-830 s.10(a)
- Quote: "A provision in an agreement between an individual and any other person for the performance of personal or professional services is contrary to public policy and is deemed unenforceable if the provision meets all of the following conditions"
- Checked: 2026-11-10

#### [M-0018] VERIFIED
- Claim: Illinois Public Act 104-0282 amended the Digital Voice and Likeness Protection Act, effective January 1, 2026.
- Jurisdiction: US-IL
- Source: Illinois Public Act 104-0282 amending the Digital Voice and Likeness Protection Act (effective 1 January 2026) (https://ilga.gov/ftp/Public%20Acts/104/104-0282.htm), source id il-pa104-0282-dvlpa-amend
- Pinpoint: Section 99
- Quote: "Section 99. Effective date. This Act takes effect January 1, 2026."
- Checked: 2026-11-10

#### [M-0243] VERIFIED
- Claim: CDPA s.182(1): a performer's rights are infringed by making a recording of a live performance, or broadcasting it live, without the performer's consent.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182(1)
- Quote: "makes a recording of the whole or any substantial part of a qualifying performance directly from the live performance"
- Checked: 2026-11-10

#### [M-0244] VERIFIED
- Claim: CDPA s.182A: copying a recording of a performance without the performer's consent infringes the performer's right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182A(1)
- Quote: "a copy of a recording of the whole or any substantial part of a qualifying performance."
- Checked: 2026-11-10

#### [M-0245] VERIFIED
- Claim: CDPA s.182CA: making a recording of a performance available on demand without consent infringes the performer's right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182CA(1)
- Quote: "A performer’s rights are infringed by a person who, without his consent, makes available to the public a recording of the whole or any substantial part of a qualifying performance by electronic transmission"
- Checked: 2026-11-10

#### [M-0247] VERIFIED
- Claim: CDPA s.183: a performer's rights are infringed by showing, playing in public or communicating to the public a performance by means of a recording the person knows or has reason to believe was made without the performer's consent.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.183
- Quote: "by means of a recording which was, and which that person knows or has reason to believe was, made without the performer’s consent."
- Checked: 2026-11-10

#### [M-0246] VERIFIED
- Claim: CDPA s.182D(1): a performer is entitled to equitable remuneration from the copyright owner when a commercially published sound recording of the performance is played in public or communicated to the public (other than by on-demand making available under s.182CA).
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182D(1)
- Quote: "the performer is entitled to equitable remuneration from the owner of the copyright in the sound recording"
- Checked: 2026-11-10

#### [M-0248] VERIFIED
- Claim: CDPA s.191HA: where a performer has assigned reproduction, distribution and making available rights to the producer, and the producer fails at the end of the 50-year period to issue copies or make the recording available on demand, the performer may give notice of intention to terminate; if the failure continues 12 months the agreement terminates.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.191A-191M Performers' property rights (assignment, licences, equitable remuneration) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-property-rights), source id uk-cdpa-s191a-s191m
- Pinpoint: CDPA s.191HA(2)
- Quote: "If, at the end of the 50-year period, the producer has failed to meet one or both of the following conditions, the performer may give a notice"
- Checked: 2026-11-10

## M17 Publicity and false endorsement
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Can a user put a pop star's voice or a soundalike in a mix; Does an AI voice clone of a singer in an uploaded mix create liability for the platform; Does the ELVIS Act or California law reach a platform that hosts the mix; Would NO FAKES make a platform set up takedown and stay down; Does a processing tool face any digital replica duty when it processes user audio

### Bottom line
US state publicity law and the federal Lanham Act protect a person's voice and likeness separately from copyright in the song [M-0462, M-0019] (analysis). A licence for the composition and the master does not clear a singer's voice, a soundalike or an AI clone (analysis). Tennessee, California, New York and Illinois each have statutes on voice or digital replicas [M-0019, M-0446, M-0450, M-0456]. Federal NO FAKES (S. 4591, H.R. 8915) is a bill, not law, as of the 2026-08-10 and 2026-10-23 status captures [M-0465, M-0466].

### Rules
#### Federal false endorsement (US federal)
- Lanham Act 43(a)(1)(A) bars false or misleading representations likely to cause confusion about affiliation, sponsorship or approval [M-0462].
- Midler v. Ford (9th Cir. 1988) (court decision, Ninth Circuit only): deliberately imitating a widely known professional singer's distinctive voice to sell a product is a tort in California. It is limited to that fact pattern [M-0458].
- Waits v. Frito-Lay (9th Cir. 1992) (court decision, Ninth Circuit only): the Ninth Circuit affirmed judgment for voice misappropriation and Lanham Act false endorsement over a soundalike ad, but vacated the Lanham Act damages as duplicative [M-0459].
- Lehrman v. Lovo (S.D.N.Y. 2025-07-10) (court decision): at the motion to dismiss stage, voice clone claims mostly failed under federal trademark and copyright law but could proceed under N.Y. Civil Rights Law 50 and 51 [M-0460]. The motion was denied for the original voice recording copyright claim, contract, NY Civil Rights Law and GBL claims [M-0461]. Later history is unchecked.

#### Tennessee
- The ELVIS Act (Pub. Ch. 588, 2024) adds an individual's voice to the protected rights of publicity [M-0019]. Voice includes a simulation of the voice [M-0444].
- Liability attaches to publishing, performing, distributing or making available a voice or likeness knowing it was not authorized [M-0443]. Effective 2024-07-01 per the same row.
- It also reaches distributors of a tool whose primary purpose is producing a particular identifiable person's voice or likeness, with knowledge it was unauthorized [M-0445].

#### California
- Cal. Civ. Code 3344(a)(1): knowing use of another's name, voice, signature, photograph or likeness on goods, or to advertise or sell, without prior consent is actionable [M-0446].
- Section 3344.1 defines a digital replica as a computer generated, highly realistic representation readily identifiable as a person's voice or visual likeness. Authorized sampling, remixing and mastering are carved out of the definition [M-0447].
- For a deceased personality, producing or distributing a digital replica in an expressive audiovisual work or sound recording without prior consent carries the greater of $10,000 or actual damages, subject to the listed exceptions [M-0448].

#### New York
- Civil Rights Law 50: using a living person's name, portrait, picture, likeness or voice for advertising or trade without written consent is a misdemeanor [M-0450]. Section 51 allows an injunction and damages [M-0451].
- Section 50-f: using a deceased performer's digital replica in an audiovisual work, sound recording or live musical performance with knowledge it was unauthorized creates liability [M-0452]. The post mortem right ends forty years after death [M-0453].
- Section 50-f(9) exempts owners or employees of an advertising medium (including streaming services) unless they had actual knowledge by prior notification. The row notes it does not obviously cover user content hosts [M-0454].

#### Illinois
- 765 ILCS 1075/30(b): no person may knowingly distribute or make available to the public a sound recording or audiovisual work with actual knowledge it contains an unauthorized digital replica [M-0456].
- Public Act 103-0836 added a digital replica definition to the Right of Publicity Act [M-0506]. The January 1, 2025 effective date is unconfirmed; saved text has no effective date line [M-0017] (unverified). The compiled statute row also describes it as effective 1-1-25, not rechecked [M-0456].

#### Pending federal bills (not law)
- NO FAKES was reintroduced 2026-05-20 as S. 4591 and H.R. 8915 [M-0003]. S. 4591 was reported with a substitute on 2026-06-24 and placed on the Senate calendar [M-0004, M-0465]. H.R. 8915 was referred to House Judiciary with no later action [M-0466]. Status captures: S. 4591 2026-08-10, H.R. 8915 2026-10-23.
- The 2025 bills, S. 1367 and H.R. 2794, did not advance past committee referral [M-0005, M-0463, M-0464].
- As reported, S. 4591 defines online service to include a site or app that predominantly provides public access to user uploaded material [M-0467]. S. 1367 had the same definition [M-0495].
- Safe harbor conditions in S. 4591 as reported: act on compliant notices and remove or disable access as soon as feasible [M-0468, M-0469]. A UGC service must also remove later uploads matching the fingerprint of the noticed replica (stay down) [M-0470]. The same conditions appear in H.R. 8915 [M-0501, M-0502] and in the 2025 text [M-0496, M-0497, M-0500].
- The repeat violator termination policy condition is written for the prong (iii) services, not the UGC prong [M-0498, M-0487]. That is the S. 1367 text; the S. 4591 equivalent is not separately cited here.
- UGC services must register a designated agent with the Copyright Office. Failure raises a presumption of no good faith effort after 90 days [M-0471, M-0503]. The 2025 text made it conclusive with no grace period [M-0499].
- An online service is liable only if its agent got a compliant notice or court order, or it willfully avoided one [M-0472]. Voluntary tool use to remove content does not alone confer actual knowledge [M-0477].
- The extra exclusions (news, documentary, commentary or parody, fleeting use) do not apply where the replica depicts sexually explicit conduct [M-0473].
- It would treat the right as intellectual property law, so Section 230 would not shield platforms [M-0475].
- State law: it preempts state claims over digital replicas in expressive works but saves state laws in force by 2025-01-02 and state laws specifically on sexually explicit replicas [M-0474].
- Term: 10 years after death, renewable in 5 year periods on proof of use, ending at 70 years after death [M-0476].
- Copyright Office Part 1 (July 2024) (regulator guidance, recommendations only) urged a federal replica law with a notice safe harbor, an actual knowledge standard, no full preemption and no Section 230 shield [M-0481, M-0482, M-0483, M-0484].

### Gotchas
- Needs a licensed attorney: every application point above and the open questions below.
- A song licence is not a voice licence. Composition, master and the singer's voice are three separate permissions (analysis).
- Muting, pitch shifting or calling something a "tribute" is not consent (analysis). A soundalike can still be actionable [M-0458, M-0459]. Both cases are Ninth Circuit only.
- NO FAKES is not law. Do not tell a creator it applies or that it protects a platform. As of the 2026-08-10 capture, S. 4591 is on the Senate calendar and later action is unchecked [M-0004, M-0465].
- Several rows rest on mirror texts. Lehrman v. Lovo is a motion to dismiss ruling and later history is unchecked [M-0460].
- The Illinois effective date is not confirmed by saved source text (unverified) [M-0017, M-0506].
- Tennessee, California and New York have different consent forms: written consent in New York, prior consent in California [M-0450, M-0446].
- Post mortem terms differ: New York 40 years [M-0453]; S. 4591 would use a 10 to 70 year structure [M-0476].
- Currency: state replica laws and NO FAKES change fast. Re-check before relying after 2027-02-08 (90 days).

### Open questions for counsel
- Tennessee and Illinois: does a UGC host with no knowledge, but a takedown process, face liability for a user's voice clone under the ELVIS Act or 765 ILCS 1075/30(b)?
- New York: does 50-f(9) shield a short video app as an advertising medium, or only paid ad channels?
- California: does 3344 reach user posted soundalikes in non advertising videos hosted by a platform?
- Federal: if S. 4591 passes as reported, what notice and stay down build does a platform need, and who is its designated agent?
- Illinois: what is the confirmed effective date of Public Act 103-0836?
- Processing tools: on current facts, is a tool that only re-encodes a user's own file privately an online service under any prong of S. 4591?
- Section 230: do state publicity claims against a UGC host survive under the intellectual property carve out in each circuit that matters to the platform?

### Sources
- s4591-status, hr8915-status, s1367-status, hr2794-status: BILLSTATUS XML (govinfo.gov/bulkdata/BILLSTATUS/119/)
- s4591-nofakes-2026-reported-text: S. 4591 as reported (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm)
- s1367-nofakes-text, hr2794-nofakes-text, hr8915-nofakes-2026-text: bill texts (govinfo.gov)
- tn-pc588-2024-elvis: ELVIS Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf)
- ca-civ-3344, ca-civ-3344-1: California Civil Code 3344, 3344.1 (california.public.law)
- ny-cvr-50, ny-cvr-51, ny-cvr-50-f: N.Y. Civil Rights Law 50, 51, 50-f (newyork.public.law)
- il-765ilcs1075-30, il-pa103-0836-publicity: Illinois ROPA and Public Act 103-0836 (ilga.gov)
- ca9-midler-1988, ca9-waits-1992, sdny-lehrman-lovo-2025: cases
- usc15-1125: Lanham Act 43(a) (law.cornell.edu)
- co-ai-part1-digital-replicas-2024: Copyright Office Part 1 (copyright.gov)

### Claims cited in M17
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0462] VERIFIED
- Claim: Lanham Act 43(a)(1)(A) bars false or misleading representations likely to cause confusion as to affiliation, sponsorship or approval.
- Jurisdiction: US-federal
- Source: 15 U.S.C. 1125 Lanham Act section 43(a) false designation of origin and false endorsement (https://www.law.cornell.edu/uscode/text/15/1125), source id usc15-1125
- Pinpoint: 15 U.S.C. 1125(a)(1)(A)
- Quote: "is likely to cause confusion, or to cause mistake, or to deceive as to the affiliation, connection, or association of such person with another person, or as to the origin, sponsorship, or approval"
- Checked: 2026-11-10

#### [M-0019] VERIFIED
- Claim: Tennessee's ELVIS Act (Pub. Ch. 588, 2024) adds an individual's voice to the protected rights of publicity.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Section 4 (amending T.C.A. 47-25-1103(a)); Section 3 defines Voice
- Quote: "Every individual has a property right in the use of that individual's name, photograph, voice, or likeness in any medium in any manner."
- Checked: 2026-11-10

#### [M-0446] VERIFIED
- Claim: Cal. Civ. Code 3344(a)(1): knowing use of another's name, voice, signature, photograph or likeness on goods or to advertise or sell products or services without prior consent is actionable.
- Jurisdiction: US-CA
- Source: California Civil Code s.3344 Use of another's name, voice, signature, photograph, or likeness (public.law mirror) (https://california.public.law/codes/civil_code_section_3344), source id ca-civ-3344
- Pinpoint: 3344(a)(1)
- Quote: "Any person who knowingly uses another’s name, voice, signature, photograph, or likeness, in any manner, on or in products, merchandise, or goods, or for purposes of advertising or selling"
- Checked: 2026-11-10

#### [M-0450] VERIFIED
- Claim: N.Y. Civ. Rights Law 50: use of a living person's name, portrait, picture, likeness or voice for advertising or trade without written consent is a misdemeanor.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50 Right of privacy (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50), source id ny-cvr-50
- Pinpoint: CRL s.50
- Quote: "A person, firm or corporation that uses for advertising purposes, or for the purposes of trade, the name, portrait, picture, likeness, or voice of any living person without having first obtained the written consent of such person"
- Checked: 2026-11-10

#### [M-0456] VERIFIED
- Claim: Illinois ROPA s.30(b): no person may knowingly distribute or make available to the public a sound recording or audiovisual work with actual knowledge it contains an unauthorized digital replica.
- Jurisdiction: US-IL
- Source: Illinois Right of Publicity Act 765 ILCS 1075/30 Limitations regarding use of an individual's identity; unauthorized digital replicas (current compiled text, P.A. 103-836, eff. 1-1-25) (https://ilga.gov/legislation/ilcs/documents/076510750K30.htm), source id il-765ilcs1075-30
- Pinpoint: 765 ILCS 1075/30(b)
- Quote: "A person may not knowingly distribute, transmit, or make available to the general public a sound recording or audiovisual work with actual knowledge that the work contains an unauthorized digital replica."
- Checked: 2026-11-10

#### [M-0465] VERIFIED
- Claim: S. 4591 (NO FAKES Act of 2026) was introduced May 20, 2026 by Sen. Coons, reported by Senate Judiciary June 24, 2026 and placed on the Senate calendar.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS S.4591
- Quote: "Placed on Senate Legislative Calendar under General Orders. Calendar No. 446."
- Checked: 2026-11-10

#### [M-0466] VERIFIED
- Claim: H.R. 8915 (NO FAKES Act of 2026) was introduced May 20, 2026 by Rep. Salazar and referred to House Judiciary; no later action in the status file.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, H.R. 8915 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr8915.xml), source id hr8915-status
- Pinpoint: BILLSTATUS H.R.8915
- Quote: "Referred to the House Committee on the Judiciary."
- Checked: 2026-11-10

#### [M-0458] VERIFIED
- Claim: Midler v. Ford: deliberately imitating a widely known professional singer's distinctive voice to sell a product is a tort in California.
- Jurisdiction: case-law
- Source: Midler v. Ford Motor Co., 849 F.2d 460 (9th Cir. 1988) (Caselaw Access Project mirror) (https://static.case.law/f2d/849/html/0460-01.html), source id ca9-midler-1988
- Pinpoint: 849 F.2d 460, 463
- Quote: "when a distinctive voice of a professional singer is widely known and is deliberately imitated in order to sell a product, the sellers have appropriated what is not theirs and have committed a tort in California."
- Checked: 2026-11-10

#### [M-0459] VERIFIED
- Claim: Waits v. Frito-Lay (9th Cir. 1992): the Ninth Circuit affirmed the judgment for voice misappropriation and Lanham Act s.43(a) false endorsement over a soundalike commercial, except that it vacated the Lanham Act damages award as duplicative.
- Jurisdiction: case-law
- Source: Waits v. Frito-Lay, Inc., 978 F.2d 1093 (9th Cir. 1992) (Caselaw Access Project mirror) (https://static.case.law/f2d/978/html/1093-01.html), source id ca9-waits-1992
- Pinpoint: 978 F.2d 1093, 1096
- Quote: "Because it is duplicative, we vacate the award of damages under the Lanham Act. We affirm in all other respects."
- Checked: 2026-11-10

#### [M-0460] VERIFIED
- Claim: Lehrman v. Lovo (S.D.N.Y. July 10, 2025): voice-clone claims mostly fail under federal trademark and copyright law but may proceed under N.Y. Civil Rights Law 50 and 51.
- Jurisdiction: case-law
- Source: Lehrman v. Lovo, Inc., No. 24-cv-3770 (JPO), ECF 45, Opinion and Order on motion to dismiss (S.D.N.Y. July 10, 2025) (https://www.nysd.uscourts.gov/sites/default/files/2025-07/Lovo%20v%20Lehrman.pdf), source id sdny-lehrman-lovo-2025
- Pinpoint: ECF 45, p. 1
- Quote: "claims for misappropriation of a voice, like the ones here, may be properly asserted under Sections 50 and 51 of the New York Civil Rights Law"
- Checked: 2026-11-10

#### [M-0461] VERIFIED
- Claim: Lehrman v. Lovo: motion denied as to copyright claims on use of an original voice recording and as to contract, NY Civil Rights Law and GBL claims.
- Jurisdiction: case-law
- Source: Lehrman v. Lovo, Inc., No. 24-cv-3770 (JPO), ECF 45, Opinion and Order on motion to dismiss (S.D.N.Y. July 10, 2025) (https://www.nysd.uscourts.gov/sites/default/files/2025-07/Lovo%20v%20Lehrman.pdf), source id sdny-lehrman-lovo-2025
- Pinpoint: ECF 45, p. 59 (Conclusion)
- Quote: "The motion is denied as to Sage’s copyright claims based on the use of her original voice recording"
- Checked: 2026-11-10

#### [M-0444] VERIFIED
- Claim: ELVIS Act defines voice to include a simulation of the voice.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.3, T.C.A. 47-25-1102
- Quote: ""Voice" means a sound in a medium that is readily identifiable and attributable to a particular individual, regardless of whether the sound contains the actual voice or a simulation of the voice of the individual"
- Checked: 2026-11-10

#### [M-0443] VERIFIED
- Claim: ELVIS Act: a person is liable if they publish, perform, distribute or make available an individual's voice or likeness knowing it was not authorized.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.6, T.C.A. 47-25-1105(a)(2) as amended
- Quote: "publishes, performs, distributes, transmits, or otherwise makes available to the public an individual's voice or likeness, with knowledge that use of the voice or likeness was not authorized"
- Checked: 2026-11-10

#### [M-0445] VERIFIED
- Claim: ELVIS Act reaches distributors of a tool whose primary purpose is producing a particular identifiable individual's voice or likeness, with knowledge it was unauthorized.
- Jurisdiction: US-TN
- Source: Tennessee Public Chapter 588 (2024) Ensuring Likeness, Voice, and Image Security (ELVIS) Act (https://publications.tnsosfiles.com/acts/113/pub/pc0588.pdf), source id tn-pc588-2024-elvis
- Pinpoint: Pub. Ch. 588 s.6, 47-25-1105(a)(3)
- Quote: "the primary purpose or function of such algorithm, software, tool, or other technology, service, or device is the production of a particular, identifiable individual's photograph, voice, or likeness"
- Checked: 2026-11-10

#### [M-0447] VERIFIED
- Claim: Cal. Civ. Code 3344.1 defines digital replica as a computer-generated, highly realistic electronic representation readily identifiable as an individual's voice or visual likeness.
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(B)(ii)(I)
- Quote: "“Digital replica” means a computer-generated, highly realistic electronic representation that is readily identifiable as the voice or visual likeness of an individual"
- Checked: 2026-11-10

#### [M-0448] VERIFIED
- Claim: Cal. Civ. Code 3344.1(a)(2)(A)(i): producing, distributing or making available a deceased personality's digital replica in an expressive audiovisual work or sound recording without prior consent carries liability of the greater of $10,000 or actual damages, subject to the exceptions in (a)(2)(A)(ii).
- Jurisdiction: US-CA
- Source: California Civil Code s.3344.1 Deceased personality's name, voice, likeness; digital replicas, as amended by AB 1836 (2024) (public.law mirror) (https://california.public.law/codes/civil_code_section_3344.1), source id ca-civ-3344-1
- Pinpoint: 3344.1(a)(2)(A)(i)
- Quote: "shall be liable to any injured party in an amount equal to the greater of ten thousand dollars ($10,000) or the actual damages suffered"
- Checked: 2026-11-10

#### [M-0451] VERIFIED
- Claim: N.Y. Civ. Rights Law 51 allows an injunction and damages against knowing use of name, portrait, picture, likeness or voice for advertising or trade without consent.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.51 Action for injunction and for damages (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_51), source id ny-cvr-51
- Pinpoint: CRL s.51
- Quote: "may maintain an equitable action in the supreme court of this state against the person, firm or corporation so using such person’s name, portrait, picture, likeness or voice, to prevent and restrain the use thereof"
- Checked: 2026-11-10

#### [M-0452] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f: using a deceased performer's digital replica in an audiovisual work, sound recording or live musical performance with knowledge it was unauthorized creates liability.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(2)(b)
- Quote: "uses a deceased performer’s digital replica in an audiovisual work, sound recording, or for the live performance of a musical work, with knowledge that the use was of a digital replica and was not authorized"
- Checked: 2026-11-10

#### [M-0453] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f post-mortem right ends forty years after death.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(8)
- Quote: "occurring after the expiration of forty years after the death of the deceased personality."
- Checked: 2026-11-10

#### [M-0454] VERIFIED
- Claim: N.Y. Civ. Rights Law 50-f(9) says it does not apply to owners or employees of an advertising medium (including streaming services) for the content, unless it is established that they had actual knowledge by prior notification of the unauthorized use.
- Jurisdiction: US-NY
- Source: New York Civil Rights Law s.50-f Right of publicity for deceased performers and personalities; digital replicas (public.law mirror) (https://newyork.public.law/laws/n.y._civil_rights_law_section_50-f), source id ny-cvr-50-f
- Pinpoint: CRL s.50-f(9)
- Quote: "streaming services, cable television systems, billboards, and transit advertisements, by whom any advertisement or solicitation in violation of this section is published or disseminated, unless it is established"
- Checked: 2026-11-10

#### [M-0506] VERIFIED
- Claim: Illinois Public Act 103-0836 (HB4875) amended the Right of Publicity Act to add a definition of digital replica and related provisions; effective date not confirmed in saved text.
- Jurisdiction: US-IL
- Source: Illinois Public Act 103-0836 (HB4875, 2024) amending the Right of Publicity Act 765 ILCS 1075 for digital replicas (https://ilga.gov/legislation/publicacts/103/103-0836.htm), source id il-pa103-0836-publicity
- Pinpoint: Section 5, amending 765 ILCS 1075/5 (Definitions)
- Quote: ""Digital replica" means a newly created, electronic representation of the voice, image, or likeness of an actual individual"
- Checked: 2026-11-10

#### [M-0017] UNVERIFIED (unverified)
- Claim: Illinois Public Act 103-0836 added digital replica provisions to the Right of Publicity Act, effective January 1, 2025.
- Jurisdiction: US-IL
- Source: Illinois Public Act 103-0836 (HB4875, 2024) amending the Right of Publicity Act 765 ILCS 1075 for digital replicas (https://ilga.gov/legislation/publicacts/103/103-0836.htm), source id il-pa103-0836-publicity
- Pinpoint: effective date
- Quote: ""
- Checked: 2026-11-10

#### [M-0003] VERIFIED
- Claim: The NO FAKES Act was reintroduced on May 20, 2026 as S. 4591 and H.R. 8915.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS actions, 2026-05-20 Introduced in Senate
- Quote: "Introduced in Senate"
- Checked: 2026-11-10

#### [M-0004] VERIFIED
- Claim: S. 4591 was reported with an amendment in the nature of a substitute on June 24, 2026 and placed on the Senate legislative calendar.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 4591 (119th) NO FAKES Act of 2026 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s4591.xml), source id s4591-status
- Pinpoint: BILLSTATUS actions, 2026-06-24 reported by Senator Grassley
- Quote: "Committee on the Judiciary. Reported by Senator Grassley with an amendment in the nature of a substitute. Without written report."
- Checked: 2026-11-10

#### [M-0005] VERIFIED
- Claim: The 2025 NO FAKES bills, S. 1367 and H.R. 2794, did not advance past committee referral.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 1367 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s1367.xml), source id s1367-status
- Pinpoint: BILLSTATUS actions, 2025-04-09 (S. 1367)
- Quote: "Read twice and referred to the Committee on the Judiciary."
- Checked: 2026-11-10

#### [M-0463] VERIFIED
- Claim: S. 1367 (NO FAKES Act of 2025) was introduced April 9, 2025; sponsor Sen. Coons; referred to Senate Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, S. 1367 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/s/BILLSTATUS-119s1367.xml), source id s1367-status
- Pinpoint: BILLSTATUS S.1367
- Quote: "Sen. Coons, Christopher A. [D-DE]"
- Checked: 2026-11-10

#### [M-0464] VERIFIED
- Claim: H.R. 2794 (NO FAKES Act of 2025) was introduced April 9, 2025 by Rep. Salazar and referred to House Judiciary.
- Jurisdiction: US-federal
- Source: BILLSTATUS XML, H.R. 2794 (119th) NO FAKES Act of 2025 (https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr2794.xml), source id hr2794-status
- Pinpoint: BILLSTATUS H.R.2794
- Quote: "Rep. Salazar, Maria Elvira [R-FL-27]"
- Checked: 2026-11-10

#### [M-0467] VERIFIED
- Claim: S. 4591 as reported (substitute text; a bill, not law) defines online service to include any site or app that predominantly provides public access to user uploaded material; a UGC short-video platform would appear to fit.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(a)(5)(A)(i)
- Quote: "any website, online application, mobile application, or virtual reality environment that predominantly provides public access to user uploaded material;"
- Checked: 2026-11-10

#### [M-0495] VERIFIED
- Claim: S. 1367 as introduced defines online service to include any site or app that predominantly provides public access to user uploaded material, so a UGC short-video platform would appear to fit (bill, not law).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(a)(5)(A)(i)
- Quote: "any website, online application, mobile application, or virtual reality environment that predominantly provides public access to user uploaded material;"
- Checked: 2026-11-10

#### [M-0468] VERIFIED
- Claim: Pending bill, not law: under S. 4591 as reported, an online service provider is not liable for a violation if it has adopted and reasonably implemented a repeat-violator termination policy and acts on compliant notices (sec. 2(d)(1)(B)(i)-(ii)).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported substitute) sec. 2(d)(1)(B)(i)
- Quote: "has adopted and reasonably implemented, and has informed users of the online service of, a policy that provides for the termination in appropriate circumstances of account holders of the online service that are repeat violators"
- Checked: 2026-11-10

#### [M-0469] VERIFIED
- Claim: S. 4591 as reported (bill, not law): to keep the online-service safe harbor, on a compliant notice the provider must remove or disable access to the noticed work as soon as technologically and practically feasible.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(1)(B)(ii)(I)(aa)
- Quote: "removes or disables access to the work embodying the claimed unauthorized use of a digital replica"
- Checked: 2026-11-10

#### [M-0470] VERIFIED
- Claim: S. 4591 as reported (bill, not law): to keep the safe harbor, a UGC online service (sec. 2(a)(5)(A)(i)) must also remove other publicly available instances that match the digital fingerprint of the noticed replica and were uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(1)(B)(ii)(I)(bb)
- Quote: "removes or disables access to all other publicly available instances of the work embodying the claimed unauthorized use of a digital replica that-- (AA) match the digital fingerprint"
- Checked: 2026-11-10

#### [M-0501] VERIFIED
- Claim: H.R. 8915 as introduced May 20, 2026 (bill, not law): on a compliant notice the service must, to keep the safe harbor, remove or disable access to the noticed work as soon as technologically and practically feasible.
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(1)(B)(ii)(I)(aa)
- Quote: "upon receiving a notification that satisfies the requirements under paragraph (3), the provider-- (aa) removes or disables access to the work embodying the claimed unauthorized digital replica"
- Checked: 2026-11-10

#### [M-0502] VERIFIED
- Claim: H.R. 8915 as introduced (bill, not law): to keep the safe harbor, a UGC service (sec. 2(a)(5)(A)(i)) must also remove other public instances matching the digital fingerprint of the noticed replica uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(1)(B)(ii)(I)(bb)
- Quote: "for the provider of an online service described in subsection (a)(5)(A)(i), as soon as is technologically and practically feasible for that provider, removes or disables access to all other publicly available instances"
- Checked: 2026-11-10

#### [M-0496] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): an online service is not liable for user uploads only if, on a compliant notice, it removes or disables access to the noticed work as soon as technically and practically feasible (plus other conditions in (d)(1)(B)).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(1)(B)(ii)(I)
- Quote: "upon receiving a notification that satisfies the requirements under paragraph (3), the provider-- (I) removes or disables access to the work embodying the claimed unauthorized digital replica"
- Checked: 2026-11-10

#### [M-0497] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): the safe harbor also requires services in sec. 2(a)(5)(A)(i) or (ii) (UGC sites and music providers) to remove other public instances matching the digital fingerprint of the noticed replica and uploaded after the notice was processed (stay down).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(1)(B)(ii)(II)
- Quote: "removes or disables access to all other publicly available instances of the work embodying the claimed unauthorized digital replica that-- (aa) match the digital fingerprint"
- Checked: 2026-11-10

#### [M-0500] VERIFIED
- Claim: H.R. 2794 as introduced has the same online service definition, notice and takedown condition and stay down duty as S. 1367 (the text differs only in header, sponsors and assigns/assignees).
- Jurisdiction: US-federal
- Source: H.R. 2794 (119th), NO FAKES Act of 2025, as introduced in House April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119hr2794ih/html/BILLS-119hr2794ih.htm), source id hr2794-nofakes-text
- Pinpoint: H.R.2794 sec. 2(d)(1)(B)(ii)(I)
- Quote: "upon receiving a notification that satisfies the requirements under paragraph (3), the provider-- (I) removes or disables access to the work embodying the claimed unauthorized digital replica"
- Checked: 2026-11-10

#### [M-0498] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): the repeat violator termination policy condition in sec. 2(d)(1)(B)(i) is written for services in clause (a)(5)(A)(iii) (other than search engines), not for clause (i) UGC services.
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(1)(B)(i)
- Quote: "has adopted and reasonably implemented, and has informed users of the online service of, a policy that provides for the termination in appropriate circumstances of account holders of the online service that are repeat violators of subsection (c)(2)"
- Checked: 2026-11-10

#### [M-0487] VERIFIED
- Claim: Analysis: A UGC platform would appear to fall in S.4591 (reported) online service prong (i) and so would need a registered designated agent, a takedown process and fingerprint stay-down for replicas; the bill is not law.
- Jurisdiction: analysis
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(a)(5)(A)(i), 2(d)(1)(B)(ii)(I)(bb), 2(d)(2)(A)(i)
- Quote: "A provider of an online service described in clause (i) or (ii) of subsection (a)(5)(A) shall"
- Checked: 2026-11-10

#### [M-0471] VERIFIED
- Claim: S. 4591 as reported (bill, not law): UGC online services (sec. 2(a)(5)(A)(i)) must register a designated agent with the Copyright Office; failure to register by the later of 90 days after the effective date or 90 days after becoming such a provider raises a presumption of no good faith effort.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(d)(2)(A)(i) and (C)
- Quote: "There shall be established a presumption that a provider of an online service described in subparagraph (A)(i) has not undertaken a good faith effort to comply with this subsection if the provider has failed to register a designated agent"
- Checked: 2026-11-10

#### [M-0503] VERIFIED
- Claim: H.R. 8915 as introduced (bill, not law): failing to register a designated agent raises a rebuttable presumption of no good faith, applying after the later of 90 days after the effective date or 90 days after becoming a clause (i) provider.
- Jurisdiction: US-federal
- Source: H.R. 8915 (119th), NO FAKES Act of 2026, as introduced in House May 20, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119hr8915ih/html/BILLS-119hr8915ih.htm), source id hr8915-nofakes-2026-text
- Pinpoint: H.R.8915 sec. 2(d)(2)(C)
- Quote: "There shall be established a presumption that a provider of an online service described in subparagraph (A)(i) has not undertaken a good faith effort to comply with this subsection if the provider has failed to register a designated agent"
- Checked: 2026-11-10

#### [M-0499] VERIFIED
- Claim: S. 1367 as introduced (bill, not law): failure of a clause (i) UGC service to register a designated agent shall establish that it made no good faith effort to comply (conclusive, no 90 day grace, unlike the 2026 text).
- Jurisdiction: US-federal
- Source: S. 1367 (119th), NO FAKES Act of 2025, as introduced in Senate April 9, 2025 (https://www.govinfo.gov/content/pkg/BILLS-119s1367is/html/BILLS-119s1367is.htm), source id s1367-nofakes-text
- Pinpoint: S.1367 sec. 2(d)(2)(C)
- Quote: "shall establish that the provider has not undertaken a good faith effort to comply with this subsection"
- Checked: 2026-11-10

#### [M-0472] VERIFIED
- Claim: S. 4591 as reported (bill, not law): an online service described in sec. 2(c)(3)(A)(ii) (UGC sites, music providers for user uploaded recordings, other services for third-party material) incurs liability only if its designated agent received a compliant notification or court order, or willfully avoided receiving one.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(3)(A)(i)
- Quote: "must have received a notification that satisfies the requirements under subsection (d)(3), or a court order stating, or must have willfully avoided receipt of such a notification"
- Checked: 2026-11-10

#### [M-0477] VERIFIED
- Claim: S. 4591 as reported: voluntary use of tools to remove content does not alone confer actual knowledge of a violation.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(6)
- Quote: "The voluntary use of any tool to remove or disable access to content shall not alone confer actual knowledge of a particular violation of this section."
- Checked: 2026-11-10

#### [M-0473] VERIFIED
- Claim: S. 4591 as reported (bill, not law): the sec. 2(c)(5)(A) additional exclusions (news, documentary or historical, commentary or parody, fleeting use, related ads) do not apply where the digital replica is used to depict sexually explicit conduct (18 U.S.C. 2256(2)(A)).
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(c)(5)(B)
- Quote: "Subparagraph (A) shall not apply where the applicable digital replica is used to depict sexually explicit conduct"
- Checked: 2026-11-10

#### [M-0475] VERIFIED
- Claim: S. 4591 as reported treats the right as a law pertaining to intellectual property for 47 U.S.C. 230(e)(2), so Section 230 would not shield platforms.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(h)(1)
- Quote: "This section shall be considered to be a law pertaining to intellectual property for the purposes of section 230(e)(2) of the Communications Act of 1934 (47 U.S.C. 230(e)(2))."
- Checked: 2026-11-10

#### [M-0474] VERIFIED
- Claim: S. 4591 as reported (bill, not law) preempts state-law claims over digital replicas in expressive works but saves state statutes and common law in existence as of Jan. 2, 2025 and state statutes specifically regulating sexually explicit or election-related digital replicas.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(g)(2)
- Quote: "causes of action under State statutes specifically regulating a digital replica depicting sexually explicit conduct"
- Checked: 2026-11-10

#### [M-0476] VERIFIED
- Claim: S. 4591 as reported (bill, not law): the digital replica right lasts 10 years after death, extendable in 5-year renewals on proof of active and authorized public use, and in all cases ends 70 years after death.
- Jurisdiction: US-federal
- Source: S. 4591 (119th), NO FAKES Act of 2026, reported in Senate with amendment in the nature of a substitute June 24, 2026 (https://www.govinfo.gov/content/pkg/BILLS-119s4591rs/html/BILLS-119s4591rs.htm), source id s4591-nofakes-2026-reported-text
- Pinpoint: S.4591 (reported) sec. 2(b)(2)(A)(iv)-(v)
- Quote: "the date that is 70 years after the death of the individual."
- Checked: 2026-11-10

#### [M-0481] VERIFIED
- Claim: Copyright Office Part 1 recommends a new federal digital replica law with a safe harbor mechanism for online providers that remove replicas after effective notice or knowledge.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary (Secondary Liability)
- Quote: "The statute should include a safe harbor mechanism that incentivizes online service providers to remove unauthorized digital replicas after receiving effective notice or otherwise obtaining knowledge that they are unauthorized."
- Checked: 2026-11-10

#### [M-0482] VERIFIED
- Claim: Part 1 recommends liability require actual knowledge that the representation was a digital replica of a particular individual and was unauthorized.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary
- Quote: "It should require actual knowledge both that the representation was a digital replica of a particular individual and that it was unauthorized."
- Checked: 2026-11-10

#### [M-0483] VERIFIED
- Claim: Part 1 recommends no full federal preemption: federal law should be a floor and states may keep their laws.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Executive Summary (Relationship to State Laws)
- Quote: "Given well-established state rights of publicity and privacy, the Office does not recommend full federal preemption."
- Checked: 2026-11-10

#### [M-0484] VERIFIED
- Claim: Part 1 recommends excluding a federal digital replica law from Section 230 to encourage prompt removal.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Copyright and Artificial Intelligence, Part 1: Digital Replicas (July 2024) (https://www.copyright.gov/ai/Copyright-and-Artificial-Intelligence-Part-1-Digital-Replicas-Report.pdf), source id co-ai-part1-digital-replicas-2024
- Pinpoint: Part 1, Section 230 discussion (Secondary Liability, p. 37)
- Quote: "The Copyright Office believes that exclusion from section 230 is advisable to encourage prompt removal of unauthorized digital replicas from online platforms."
- Checked: 2026-11-10
