# Music law knowledge pack: UK and EU
- File: 05-uk-eu.md, part of the music law knowledge pack (remix edition).
- Contains: M18 UK music copyright; M19 EU music law for an upload platform. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-10.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M18 UK music copyright
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Do UK users need separate licences for the song and the recording; Is a mixing platform liable in the UK if a user uploads a mix with songs; Does the UK have a fair use rule or a parody exception a platform can rely on; Can a platform train or tune AI on UK music; Who owns a UK recording made by a producer or an employee; Do UK performers have rights over a recording used in a mix

### Bottom line
UK law, as of 2026-11-10: a recorded song has two separate copyrights, the musical work (composition) and the sound recording (master), and using both in a video needs permission for each [M-0238]. Putting a video with music online for UK viewers is a restricted act (communication to the public, including on demand) that needs a licence from the rights holders, and a platform can be liable for authorising it [M-0236, M-0237, M-0235, M-0255]. UK law has no US style statutory licence for sync, and no general fair use. The AI and copyright rules are under review and are not settled [M-0436].

### Rules
#### What is protected and who owns it (UK, statute)
- Copyright subsists in original musical works and in sound recordings as separate works [M-0238].
- A sound recording is a recording of sounds from which they may be reproduced, or a recording of a literary, dramatic or musical work from which sounds reproducing it may be produced [M-0094].
- No new copyright arises in a sound recording to the extent it is a copy taken from a previous sound recording [M-0095].
- The author of a work is its first owner, subject to the exceptions in s.11 [M-0090].
- Where an employee makes a literary, dramatic, musical or artistic work or film in the course of employment, the employer is first owner, subject to contrary agreement [M-0091].
- The author of a sound recording is the producer [M-0092]. (analysis) Because s.11(2) does not list sound recordings, the first owner of a recording is the producer unless assigned or agreed otherwise [M-0093]. This is an inference from the statute text.
- Assignment must be in writing signed by or on behalf of the assignor [M-0096]. An exclusive licence must also be in writing signed by or on behalf of the owner [M-0097].
- An agreement to assign future copyright, signed by the prospective owner, takes effect as an assignment when the copyright comes into existence [M-0098].

#### What the owner controls (UK, statute)
- The owner has the exclusive right to copy, issue copies, rent or lend, perform in public, communicate to the public and adapt [M-0234].
- Copyright is infringed by a person who, without licence, does or authorises another to do a restricted act [M-0235].
- Communication to the public covers a musical work, sound recording, film or broadcast [M-0236]. It includes making a work available on demand at a time and place individually chosen [M-0237].
- The High Court can grant an injunction against a service provider with actual knowledge of another person using its service to infringe (s.97A) [M-0242].

#### Performers (UK, statute)
- Performers have their own rights, separate from copyright. Recording a live performance, or broadcasting it live, without consent infringes them [M-0243].
- Copying a recording of a performance without consent infringes [M-0244]. Making a recording available on demand without consent infringes [M-0245].
- Showing, playing in public or communicating a performance by means of a recording the person knows or has reason to believe was made without consent infringes [M-0247].
- A performer is entitled to equitable remuneration from the copyright owner when a commercially published recording is played in public or communicated to the public, other than on demand under s.182CA [M-0246]. It is a payment right, not a bar to use, and is assignable only to a collecting society [M-0246].
- A performer who assigned rights to a producer can serve notice to terminate if the producer, after 50 years, fails to issue copies or make the recording available on demand [M-0248]. Rarely relevant to a short video app.

#### Exceptions (UK, statute)
- Fair dealing for caricature, parody or pastiche does not infringe [M-0240]. A contract term that restricts an act permitted by that exception is unenforceable [M-0241].
- The text and data analysis exception covers copies made only for non-commercial research by a person with lawful access, with acknowledgement [M-0239]. It does not cover commercial AI training.

#### AI and policy (UK, regulator report, not law)
- The Data (Use and Access) Act 2025 required an economic impact assessment of four policy options within 9 months [M-0434] and a report on copyright works in developing AI systems [M-0435].
- The government report of March 2026 says a broad exception with opt-out is no longer its preferred way forward [M-0436, M-0015]. This is a policy statement, not law, and no AI training exception has been enacted [M-0436].
- The report proposes removing protection for wholly computer generated works (the s.9(3) type) while keeping it for works made with AI assistance [M-0437, M-0016]. Proposal only.
- The government is considering whether to introduce a new digital replica or personality right [M-0438]. Exploration only, not law.

#### Market context (UK, regulator report)
- The CMA music streaming report records an argument that, because about 90% of Content ID claims are monetised rather than taken down, rightsholders do not see YouTube streams as cannibalising streaming revenue [M-0381]. That is an argument put to the CMA, not a CMA finding.

### Gotchas
- The UK has no fair use. Fair dealing exceptions are specific and narrow [M-0240, M-0239].
- "Producer" is the author of a recording, which can differ from the artist or the label [M-0092, M-0093].
- An assignment or exclusive licence not in signed writing fails the statute test [M-0096, M-0097].
- The 2026 AI report is a policy statement. Do not say the UK allows or bans AI training on music on this basis [M-0436].
- Cases on secondary liability from the US (BMG v. Cox 2018 and Cox v. Sony 2026) do not apply in the UK. See M09 for the US position.
- Currency, as of 2026-11-10: the March 2026 AI report and its proposals can change at any time. Volatility is high. Check the legislation.gov.uk text before relying on any section, since amendments may follow.
- Not in our sources: UK collecting society licence terms, UK case law on platform liability, UK moral rights, and UK term of protection. Needs source.

### Open questions for counsel
- UK: which societies or direct licences does a UK facing short video app need for composition and for recording?
- UK: is a platform liable for authorising infringement when creators upload videos with unlicensed music, and does a UK notice and takedown practice reduce that risk?
- UK: does a live stream playing a commercial recording need separate performance licences, and who pays performers' equitable remuneration?
- UK: does a platform's server side re-encoding of user audio make it a direct infringer?
- UK: can the parody or pastiche exception ever cover a short video using part of a track, and what are the limits?
- UK: what is the current status of the AI copyright and digital replica proposals after the March 2026 report?

### Sources
- uk-cdpa-s1: CDPA 1988 s.1 (https://www.legislation.gov.uk/ukpga/1988/48/section/1)
- uk-cdpa-s5a: CDPA 1988 s.5A (https://www.legislation.gov.uk/ukpga/1988/48/section/5A)
- uk-cdpa-s9-s11: CDPA 1988 ss.9 to 11 (https://www.legislation.gov.uk/ukpga/1988/48/part/I)
- uk-cdpa-s16-s21: CDPA 1988 ss.16 to 21 (https://www.legislation.gov.uk/ukpga/1988/48/part/I/c)
- uk-cdpa-s29a: CDPA 1988 s.29A (https://www.legislation.gov.uk/ukpga/1988/48/section/29A)
- uk-cdpa-s30a: CDPA 1988 s.30A (https://www.legislation.gov.uk/ukpga/1988/48/section/30A)
- uk-cdpa-s90-s93a: CDPA 1988 ss.90 to 93A (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright)
- uk-cdpa-s97a: CDPA 1988 s.97A (https://www.legislation.gov.uk/ukpga/1988/48/section/97A)
- uk-cdpa-s182-s184: CDPA 1988 ss.182 to 184 (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights)
- uk-cdpa-s191a-s191m: CDPA 1988 ss.191A to 191M (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-property-rights)
- uk-duaa-2025-ai: Data (Use and Access) Act 2025 ss.135 to 137 (https://www.legislation.gov.uk/ukpga/2025/18/part/7/crossheading/copyright-works-and-artificial-intelligence-systems)
- uk-gov-ai-copyright-report-s136: UK Government report on copyright and AI, March 2026 (https://www.gov.uk/government/publications/report-a)
- uk-cma-music-streaming-2022: CMA music and streaming market study, 29 November 2022 (https://assets.publishing.service.gov.uk/media/6384f43ee90e077898ccb48e/Music_and_streaming_final_report.pdf)

### Claims cited in M18
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0238] VERIFIED
- Claim: CDPA s.1(1): copyright subsists in original musical works and in sound recordings as separate works.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.1 Copyright and copyright works (https://www.legislation.gov.uk/ukpga/1988/48/section/1), source id uk-cdpa-s1
- Pinpoint: CDPA s.1(1)
- Quote: "original literary, dramatic, musical or artistic works, (b)sound recordings, films"
- Checked: 2026-11-10

#### [M-0236] VERIFIED
- Claim: CDPA s.20(1): communication to the public of a musical work (and a sound recording, film or broadcast) is an act restricted by the copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(1)
- Quote: "The communication to the public of the work is an act restricted by the copyright"
- Checked: 2026-11-10

#### [M-0237] VERIFIED
- Claim: CDPA s.20(2)(b): communication to the public includes making a work available on demand, individually chosen place and time.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(2)(b)
- Quote: "the making available to the public of the work by electronic transmission in such a way that members of the public may access it from a place and at a time individually chosen by"
- Checked: 2026-11-10

#### [M-0235] VERIFIED
- Claim: CDPA s.16(2): copyright is infringed by a person who without licence does, or authorises another to do, a restricted act.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(2)
- Quote: "Copyright in a work is infringed by a person who without the licence of the copyright owner does, or authorises another to do, any of the acts restricted by the"
- Checked: 2026-11-10

#### [M-0255] VERIFIED
- Claim: UK: under CDPA s.16(2) a person infringes who without licence does or authorises another to do an act restricted by copyright, and s.20(b) restricts making a work available on demand by electronic transmission, so (analysis) a UK-facing platform may face direct or authorising liability.
- Jurisdiction: analysis
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA ss.16(2), 20(b)
- Quote: "Copyright in a work is infringed by a person who without the licence of the copyright owner does, or authorises another to do, any of the acts restricted by the"
- Checked: 2026-11-10

#### [M-0436] VERIFIED
- Claim: The UK s.136 report (March 2026) says a broad copyright exception with opt-out is no longer the government's preferred way forward.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A, overview
- Quote: "broad copyright exception with opt-out is no longer the government’s preferred way forward."
- Checked: 2026-11-10

#### [M-0094] VERIFIED
- Claim: UK: a sound recording means a recording of sounds from which they may be reproduced, or a recording of a literary, dramatic or musical work from which sounds reproducing it may be produced.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.5A Sound recordings (https://www.legislation.gov.uk/ukpga/1988/48/section/5A), source id uk-cdpa-s5a
- Pinpoint: CDPA s.5A(1)
- Quote: "In this Part “sound recording” means-- (a)a recording of sounds, from which the sounds may be reproduced, or (b)a recording of the whole or any part of a literary, dramatic or musical work, from which"
- Checked: 2026-11-10

#### [M-0095] VERIFIED
- Claim: UK: copyright does not subsist in a sound recording to the extent it is a copy taken from a previous sound recording.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.5A Sound recordings (https://www.legislation.gov.uk/ukpga/1988/48/section/5A), source id uk-cdpa-s5a
- Pinpoint: CDPA s.5A(2)
- Quote: "Copyright does not subsist in a sound recording which is, or to the extent that it is, a copy taken from a previous sound recording.]"
- Checked: 2026-11-10

#### [M-0090] VERIFIED
- Claim: UK: the author of a work is its first owner of copyright, subject to the exceptions in s.11.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.11(1)
- Quote: "The author of a work is the first owner of any copyright in it, subject"
- Checked: 2026-11-10

#### [M-0091] VERIFIED
- Claim: UK: where a literary, dramatic, musical or artistic work or film is made by an employee in the course of employment, the employer is first owner subject to contrary agreement.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.11(2)
- Quote: "Where a literary, dramatic, musical or artistic work [F5, or a film,] is made by an employee in the course of his employment, his employer is the first owner of any copyright in the work"
- Checked: 2026-11-10

#### [M-0092] VERIFIED
- Claim: UK: the author of a sound recording is the producer.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA s.9(2)(aa)
- Quote: "in the case of a sound recording, the"
- Checked: 2026-11-10

#### [M-0093] VERIFIED
- Claim: UK: s.11(2) employer first ownership lists literary, dramatic, musical, artistic works and films but not sound recordings, so a sound recording's first owner is its author, the producer (s.9(2)(aa), s.11(1)), subject to assignment or agreement (inference).
- Jurisdiction: analysis
- Source: Copyright, Designs and Patents Act 1988 ss.9-11 Authorship and ownership of copyright (incl. s.9(3) computer-generated works) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/I/crossheading/authorship-and-ownership-of-copyright), source id uk-cdpa-s9-s11
- Pinpoint: CDPA ss.9(2)(aa), 11(1)-(2)
- Quote: "is made by an employee in the course of his employment, his employer is the first owner of any copyright in the"
- Checked: 2026-11-10

#### [M-0096] VERIFIED
- Claim: UK: copyright is transmissible by assignment, testamentary disposition or operation of law, and an assignment must be in writing signed by or on behalf of the assignor.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.90(1), (3)
- Quote: "An assignment of copyright is not effective unless it is in writing signed by or on behalf of the assignor. (4)A licence"
- Checked: 2026-11-10

#### [M-0097] VERIFIED
- Claim: UK: an exclusive licence means a licence in writing signed by or on behalf of the copyright owner authorising the licensee to the exclusion of all others to exercise a right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.92(1)
- Quote: "In this Part an “exclusive licence” means a licence in writing signed by or on behalf of the copyright owner authorising the licensee to the"
- Checked: 2026-11-10

#### [M-0098] VERIFIED
- Claim: UK: an agreement to assign future copyright, signed by the prospective owner, takes effect as an assignment when the copyright comes into existence.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.90-93A Dealings with rights in copyright works: assignment and licences, prospective ownership (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/V/crossheading/copyright), source id uk-cdpa-s90-s93a
- Pinpoint: CDPA s.91(1)
- Quote: "Where by an agreement made in relation to future copyright, and signed by or on behalf of the prospective owner of the copyright, the prospective"
- Checked: 2026-11-10

#### [M-0234] VERIFIED
- Claim: CDPA s.16(1): the copyright owner has the exclusive right to copy, issue copies, rent or lend, perform in public, communicate to the public and adapt.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(1)(a)-(e)
- Quote: "The owner of the copyright in a work has, in accordance with the following provisions of this Chapter, the exclusive right to do the following acts in the United Kingdom--"
- Checked: 2026-11-10

#### [M-0242] VERIFIED
- Claim: CDPA s.97A: the High Court can grant an injunction against a service provider with actual knowledge of another using its service to infringe.
- Jurisdiction: UK
- Source: CDPA 1988 s.97A injunctions against service providers (https://www.legislation.gov.uk/ukpga/1988/48/section/97A), source id uk-cdpa-s97a
- Pinpoint: CDPA s.97A(1)
- Quote: "The High Court (in Scotland, the Court of Session) shall have power to grant an injunction against a service provider, where that service provider has actual knowledge of another person using their service to infringe copyright."
- Checked: 2026-11-10

#### [M-0243] VERIFIED
- Claim: CDPA s.182(1): a performer's rights are infringed by making a recording of a live performance, or broadcasting it live, without the performer's consent.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182(1)
- Quote: "makes a recording of the whole or any substantial part of a qualifying performance directly from the live performance"
- Checked: 2026-11-10

#### [M-0244] VERIFIED
- Claim: CDPA s.182A: copying a recording of a performance without the performer's consent infringes the performer's right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182A(1)
- Quote: "a copy of a recording of the whole or any substantial part of a qualifying performance."
- Checked: 2026-11-10

#### [M-0245] VERIFIED
- Claim: CDPA s.182CA: making a recording of a performance available on demand without consent infringes the performer's right.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182CA(1)
- Quote: "A performer’s rights are infringed by a person who, without his consent, makes available to the public a recording of the whole or any substantial part of a qualifying performance by electronic transmission"
- Checked: 2026-11-10

#### [M-0247] VERIFIED
- Claim: CDPA s.183: a performer's rights are infringed by showing, playing in public or communicating to the public a performance by means of a recording the person knows or has reason to believe was made without the performer's consent.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.183
- Quote: "by means of a recording which was, and which that person knows or has reason to believe was, made without the performer’s consent."
- Checked: 2026-11-10

#### [M-0246] VERIFIED
- Claim: CDPA s.182D(1): a performer is entitled to equitable remuneration from the copyright owner when a commercially published sound recording of the performance is played in public or communicated to the public (other than by on-demand making available under s.182CA).
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.182-184 Performers' rights (consent required for recording, live transmission, use) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-rights), source id uk-cdpa-s182-s184
- Pinpoint: CDPA s.182D(1)
- Quote: "the performer is entitled to equitable remuneration from the owner of the copyright in the sound recording"
- Checked: 2026-11-10

#### [M-0248] VERIFIED
- Claim: CDPA s.191HA: where a performer has assigned reproduction, distribution and making available rights to the producer, and the producer fails at the end of the 50-year period to issue copies or make the recording available on demand, the performer may give notice of intention to terminate; if the failure continues 12 months the agreement terminates.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.191A-191M Performers' property rights (assignment, licences, equitable remuneration) (https://www.legislation.gov.uk/ukpga/1988/48/part/II/chapter/2/crossheading/performers-property-rights), source id uk-cdpa-s191a-s191m
- Pinpoint: CDPA s.191HA(2)
- Quote: "If, at the end of the 50-year period, the producer has failed to meet one or both of the following conditions, the performer may give a notice"
- Checked: 2026-11-10

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0241] VERIFIED
- Claim: CDPA s.30A(2): a contract term that restricts an act permitted by the parody exception is unenforceable.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(2)
- Quote: "To the extent that a term of a contract purports to prevent or restrict the doing of any act which, by virtue of this section, would not infringe copyright, that term is"
- Checked: 2026-11-10

#### [M-0239] VERIFIED
- Claim: CDPA s.29A permits copies for text and data analysis only for the sole purpose of non-commercial research by a person with lawful access.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.29A Copies for text and data analysis for non-commercial research (https://www.legislation.gov.uk/ukpga/1988/48/section/29A), source id uk-cdpa-s29a
- Pinpoint: CDPA s.29A(1)(a)
- Quote: "the copy is made in order that a person who has lawful access to the work may carry out a computational analysis of anything recorded in the work for the sole purpose of research for a non-commercial purpose"
- Checked: 2026-11-10

#### [M-0434] VERIFIED
- Claim: UK DUAA 2025 s.135 requires an economic impact assessment of the four copyright and AI policy options within 9 months of the Act being passed.
- Jurisdiction: UK
- Source: Data (Use and Access) Act 2025 ss.135-137 Copyright works and artificial intelligence systems (economic impact assessment, report, progress statement) (https://www.legislation.gov.uk/ukpga/2025/18/part/7/crossheading/copyright-works-and-artificial-intelligence-systems), source id uk-duaa-2025-ai
- Pinpoint: Data (Use and Access) Act 2025 s.135(1)
- Quote: "must, before the end of the period of 9 months beginning with the day on which this Act is passed-- (a)prepare and publish an assessment of the economic impact in the United Kingdom of each of the four policy options"
- Checked: 2026-11-10

#### [M-0435] VERIFIED
- Claim: UK DUAA 2025 s.136 requires a report on use of copyright works in developing AI systems, laid before Parliament within 9 months.
- Jurisdiction: UK
- Source: Data (Use and Access) Act 2025 ss.135-137 Copyright works and artificial intelligence systems (economic impact assessment, report, progress statement) (https://www.legislation.gov.uk/ukpga/2025/18/part/7/crossheading/copyright-works-and-artificial-intelligence-systems), source id uk-duaa-2025-ai
- Pinpoint: DUAA 2025 s.136(1)
- Quote: "prepare and publish a report on the use of copyright works in the development of AI systems, and (b)lay the report before Parliament."
- Checked: 2026-11-10

#### [M-0015] VERIFIED
- Claim: The UK government published its section 136 report on copyright and AI in March 2026; a text and data mining exception with opt-out is no longer its preferred option.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Report, Summary (March 2026)
- Quote: "a broad copyright exception with opt-out is no longer the government's preferred way forward."
- Checked: 2026-11-10

#### [M-0437] VERIFIED
- Claim: The s.136 report proposes removing copyright protection for wholly computer-generated works (CDPA s.9(3) type protection) while keeping protection for works made with AI assistance.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A, computer-generated works
- Quote: "we propose that this specific type of protection should be removed, while copyright should continue to protect works created with AI assistance."
- Checked: 2026-11-10

#### [M-0016] VERIFIED
- Claim: The UK government proposes to remove protection for computer-generated works under CDPA s.9(3).
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Report, Summary, Computer-generated works (s.9(3) discussed in Section I)
- Quote: "in the absence of evidence of its ongoing value, we propose that this specific type of protection should be removed, while copyright should continue to protect works created with AI assistance."
- Checked: 2026-11-10

#### [M-0438] VERIFIED
- Claim: The s.136 report says further consideration is being given to whether to introduce a new digital replica or personality right.
- Jurisdiction: UK
- Source: UK Government Report on Copyright and Artificial Intelligence (section 136 Data (Use and Access) Act 2025) (https://www.gov.uk/government/publications/report-and-impact-assessment-on-copyright-and-artificial-intelligence/report-on-copyright-and-artificial-intelligence), source id uk-gov-ai-copyright-report-s136
- Pinpoint: Section A overview, digital replicas
- Quote: "consideration of whether it would be beneficial to introduce a new digital replica or personality right."
- Checked: 2026-11-10

#### [M-0381] VERIFIED
- Claim: The CMA report records the argument that, because about 90% of Content ID claims are monetised rather than taken down, rightsholders do not treat YouTube streams as cannibalising streaming revenue.
- Jurisdiction: UK
- Source: CMA Music and streaming market study final report (29 November 2022) (https://assets.publishing.service.gov.uk/media/6384f43ee90e077898ccb48e/Music_and_streaming_final_report.pdf), source id uk-cma-music-streaming-2022
- Pinpoint: para 6.34
- Quote: "the fact that 90% of all Content ID claims are monetised rather than taken down"
- Checked: 2026-11-10

## M19 EU music law for an upload platform
- Law last checked: 2026-11-10. Volatility: high.
- Use for questions like: Would a platform that hosts user mixes be an online content sharing service provider in the EU; Does the EU hosting safe harbor protect a platform for user mixes with music; Who licenses music in the EU and on what terms; Can users rely on parody or quotation when uploading a mix; Does EU law let rightholders block AI training on their music; What does the AI Act require of model providers about copyright

### Bottom line
- EU law (foreign law): if a platform is an online content sharing service provider, it performs an act of communication to the public when users upload and must get authorisation, and the usual hosting safe harbor does not apply [M-0387, M-0388]. Without authorisation it is liable unless it meets the best efforts tests [M-0389, M-0390, M-0391].
- Authorisation means licences for both copyrights: the composition (usually publisher or a collective management organisation) and the master (label or distributor) (analysis). Collective bodies must license on objective and non-discriminatory terms [M-0310].
- Editing, muting or re-encoding a file is not a licence (analysis).
- Whether a given platform is in scope, and which national law applies, needs an EU licensed attorney. Nothing here says any song is cleared.

### Rules
#### Article 17 of Directive (EU) 2019/790 (foreign law, EU directive)
- Article 17(1): a provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation [M-0387].
- Article 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations [M-0388].
- Article 17(4)(a): without authorisation the provider is liable unless it made best efforts to obtain one [M-0389].
- Article 17(4)(b): best efforts, to high industry standards of professional diligence, to make unavailable works for which rightholders gave relevant and necessary information [M-0390].
- Article 17(4)(c): act expeditiously on a notice and make best efforts to prevent future uploads, called notice and stay down [M-0391].
- Article 17(6): a lighter regime for services available in the Union under three years with turnover under EUR 10 million [M-0392]. Check the full conditions of the Article with counsel before relying on this.
- Article 17(7): users can rely on quotation, criticism, review, caricature, parody or pastiche when uploading [M-0393].
- Article 17(8): no general monitoring obligation [M-0394].
- Article 17(9): complaints are processed without undue delay, and decisions to disable or remove get human review [M-0395].

#### Courts and the Commission
- CJEU Grand Chamber, Poland v Parliament and Council, C-401/19, 26 April 2022 (court decision): the Court dismissed the annulment action and upheld Article 17 [M-0396]. Its holding on Article 17(4)(b) and (c) depends on safeguards (see the ledger note on M-0396).
- Same case, para 90: providers cannot be required to filter content whose unlawfulness would need an independent assessment of context and exceptions [M-0397].
- Commission 2021 guidance (regulator guidance, non-binding): automated blocking at upload should in principle be limited to manifestly infringing uploads [M-0398].

#### Collective management of music (Directive 2014/26/EU, foreign law)
- Rightholders may authorise a collective management organisation of their choice for the rights and territories of their choice [M-0308].
- Organisations and users must negotiate licences in good faith and share necessary information [M-0309].
- Licensing terms must rest on objective and non-discriminatory criteria [M-0310].

#### AI and music in the EU (foreign law, court decision, voluntary code)
- CDSM Art 3: a text and data mining exception for research organisations and cultural heritage institutions, for scientific research [M-0399].
- CDSM Art 4(1), (3): a general mining exception for lawfully accessible works, unless the rightholder reserved use in an appropriate manner, such as machine readable means for content online [M-0400, M-0442]. National transposition varies [M-0442].
- AI Act Art 53(1)(c): providers of general purpose AI models need a copyright policy that identifies and honours Article 4(3) reservations [M-0439]. Art 53(1)(d): they must publish a training content summary using the AI Office template [M-0440]. These obligations apply from 2 August 2025 [M-0441].
- EU GPAI Code of Practice, copyright chapter (voluntary, binds signatories only): Measure 1.3(1) commits to honour machine readable reservations when crawling for mining [M-0493]. Measure 1.4(1)(a) commits to technical safeguards against outputs that reproduce protected training content [M-0494].
- GEMA v OpenAI, LG Munich I, 11 Nov 2025, 42 O 14139/24 (German first instance court decision, lyrics only, not audio): memorising works in a language model is a reproduction under UrhG s.16 [M-0431]. The s.44b mining exception covers copies made to build training data, not training the model [M-0432]. Model operators, not users, are liable for infringing outputs from simple prompts [M-0433]. Appeal pending per the source header; later status unchecked.

### Gotchas
- This is EU level text. Each Member State transposed the directives; national law and national courts decide details [M-0442].
- Article 17(7) exceptions are user rights, not a way for a platform to treat all uploads as exempt. Parody of a track does not make a full song under a video safe (analysis).
- The Article 17(6) lighter regime has an age and turnover test [M-0392]. It lapses as a platform ages (analysis).
- "No general monitoring" [M-0394] sits beside "best efforts to make unavailable" [M-0390]. The CJEU reconciles them with safeguards [M-0397].
- GEMA v OpenAI is one first instance German court on lyrics. It is not an EU wide rule and not about audio [M-0431].
- AI Act dates: Art 113(b) is unchanged by Regulation (EU) 2026/1744 per the ledger note on M-0441, which says the source file for that regulation is still needed.
- The GPAI Code is voluntary and its text was captured 2026-11-10 without a check for later Commission updates [M-0494].
- Open gaps: no saved row on live streaming under Article 17 or on any national transposition. Status as of 2026-11-10.

### Open questions for counsel
- EU: would a platform serving EU users with user uploaded short video be an online content sharing service provider under Article 17, and under which Member State law?
- EU: does a live stream count as upload and making available under Article 17(1)?
- EU: does a tool that re-encodes a creator's own file fall inside Article 17 if it never publishes the file?
- EU: which collective management organisations would license composition rights for EU launch?
- EU: does the Article 17(6) lighter regime fit a platform today and when does it end?
- EU and Germany: how should we treat the pending GEMA v OpenAI appeal before using AI features trained on music?

### Sources
- eu-cdsm-2019-790: Directive (EU) 2019/790 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790)
- eu-crm-2014-26: Directive 2014/26/EU (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026)
- cjeu-poland-c401-19: CJEU C-401/19 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401)
- eu-com-2021-288-art17: Commission guidance COM(2021) 288 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52021DC0288)
- eu-aiact-2024-1689: Regulation (EU) 2024/1689 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689)
- eu-gpai-code-copyright: GPAI Code of Practice copyright chapter (https://ec.europa.eu/newsroom/dae/redirection/document/118115)
- de-lgmuenchen-gema-openai-2025: LG Munich I, 42 O 14139/24 (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False)

### Claims cited in M19
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0390] VERIFIED
- Claim: Art 17(4)(b): best efforts, to high industry standards of professional diligence, to ensure unavailability of works the rightholder identified.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(b)
- Quote: "made, in accordance with high industry standards of professional diligence, best efforts to ensure the unavailability of specific works and other subject matter for which the rightholders have provided the service providers with the relevant and necessary information"
- Checked: 2026-11-10

#### [M-0391] VERIFIED
- Claim: Art 17(4)(c): act expeditiously on a substantiated notice and make best efforts to prevent future uploads (notice and stay down).
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(c)
- Quote: "made best efforts to prevent their future uploads in accordance with point (b)"
- Checked: 2026-11-10

#### [M-0310] VERIFIED
- Claim: EU licensing terms must rest on objective and non-discriminatory criteria.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 16(2)
- Quote: "Licensing terms shall be based on objective and non-discriminatory criteria"
- Checked: 2026-11-10

#### [M-0392] VERIFIED
- Claim: Art 17(6): new providers under three years old with turnover under EUR 10 million have a lighter regime.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(6)
- Quote: "the services of which have been available to the public in the Union for less than three years and which have an annual turnover below EUR 10 million"
- Checked: 2026-11-10

#### [M-0393] VERIFIED
- Claim: Art 17(7): users may rely on quotation, criticism, review, caricature, parody or pastiche exceptions when uploading.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(7)
- Quote: "Member States shall ensure that users in each Member State are able to rely on any of the following existing exceptions or limitations when uploading and making available content generated by users"
- Checked: 2026-11-10

#### [M-0394] VERIFIED
- Claim: Art 17(8): no general monitoring obligation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(8)
- Quote: "The application of this Article shall not lead to any general monitoring obligation"
- Checked: 2026-11-10

#### [M-0395] VERIFIED
- Claim: Art 17(9): complaint processed without undue delay, with human review of decisions to disable or remove.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(9)
- Quote: "decisions to disable access to or remove uploaded content shall be subject to human review"
- Checked: 2026-11-10

#### [M-0396] VERIFIED
- Claim: Poland v Parliament: the Court dismissed the annulment action, upholding Art 17.
- Jurisdiction: EU
- Source: CJEU Judgment C-401/19 Republic of Poland v European Parliament and Council (26 April 2022) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401), source id cjeu-poland-c401-19
- Pinpoint: Operative part, point 1
- Quote: "Dismisses the action"
- Checked: 2026-11-10

#### [M-0397] VERIFIED
- Claim: Poland: providers cannot be required to filter content whose unlawfulness would need an independent assessment of context and exceptions.
- Jurisdiction: EU
- Source: CJEU Judgment C-401/19 Republic of Poland v European Parliament and Council (26 April 2022) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62019CJ0401), source id cjeu-poland-c401-19
- Pinpoint: Judgment, para 90
- Quote: "cannot be required to prevent the uploading and making available to the public of content which, in order to be found unlawful, would require an independent assessment of the content by them"
- Checked: 2026-11-10

#### [M-0398] VERIFIED
- Claim: Commission 2021 guidance: automated blocking at upload should in principle be limited to manifestly infringing uploads.
- Jurisdiction: EU
- Source: European Commission COM(2021) 288 Guidance on Article 17 of Directive 2019/790 on Copyright in the Digital Single Market (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52021DC0288), source id eu-com-2021-288-art17
- Pinpoint: Part VI (safeguards)
- Quote: "automated blocking, i.e. preventing the upload by the use of technology, should in principle be limited to manifestly infringing uploads"
- Checked: 2026-11-10

#### [M-0308] VERIFIED
- Claim: In the EU, rightholders may authorise a collective management organisation of their choice to manage the rights and territories of their choice.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 5(2)
- Quote: "Rightholders shall have the right to authorise a collective management organisation of their choice to manage the rights, categories of rights or types of works and other subject-matter of their choice, for the territories of their choice"
- Checked: 2026-11-10

#### [M-0309] VERIFIED
- Claim: EU collective management organisations and users must negotiate licences in good faith and share necessary information.
- Jurisdiction: EU
- Source: Directive 2014/26/EU on collective management of copyright and related rights and multi-territorial licensing of rights in musical works for online use (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32014L0026), source id eu-crm-2014-26
- Pinpoint: Directive 2014/26/EU Art. 16(1)
- Quote: "conduct negotiations for the licensing of rights in good faith. Collective management organisations and users shall provide each other with all necessary information"
- Checked: 2026-11-10

#### [M-0399] VERIFIED
- Claim: CDSM Art 3: TDM exception for research organisations and cultural heritage institutions for scientific research.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 3(1)
- Quote: "Member States shall provide for an exception to the rights provided for in Article 5(a) and Article 7(1) of Directive 96/9/EC"
- Checked: 2026-11-10

#### [M-0400] VERIFIED
- Claim: CDSM Art 4: general TDM exception for lawfully accessible works, available unless the rightholder has reserved use in an appropriate manner.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(1), (3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online"
- Checked: 2026-11-10

#### [M-0442] VERIFIED
- Claim: CDSM Art. 4(3): the TDM exception applies only if the use has not been expressly reserved by rightholders, for online content in machine-readable form.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 4(3)
- Quote: "has not been expressly reserved by their rightholders in an appropriate manner, such as machine-readable means in the case of content made publicly available online."
- Checked: 2026-11-10

#### [M-0439] VERIFIED
- Claim: EU AI Act Art. 53(1)(c): GPAI model providers must have a copyright compliance policy that identifies and honours Article 4(3) CDSM rights reservations.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 53(1)(c)
- Quote: "put in place a policy to comply with Union law on copyright and related rights, and in particular to identify and comply with, including through state-of-the-art technologies, a reservation of rights expressed pursuant to Article 4(3) of Directive (EU) 2019/790;"
- Checked: 2026-11-10

#### [M-0440] VERIFIED
- Claim: EU AI Act Art. 53(1)(d): GPAI providers must publish a sufficiently detailed summary of training content using the AI Office template.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 53(1)(d)
- Quote: "draw up and make publicly available a sufficiently detailed summary about the content used for training of the general-purpose AI model, according to a template provided by the AI Office."
- Checked: 2026-11-10

#### [M-0441] VERIFIED
- Claim: The GPAI obligations (Chapter V) apply from 2 August 2025.
- Jurisdiction: EU
- Source: Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence (AI Act) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1689), source id eu-aiact-2024-1689
- Pinpoint: Art. 113(b)
- Quote: "Chapter V, Chapter VII and Chapter XII and Article 78 shall apply from 2 August 2025, with the exception of Article 101"
- Checked: 2026-11-10

#### [M-0493] VERIFIED
- Claim: EU GPAI Code of Practice copyright chapter, Measure 1.3(1): signatories commit to identify and comply with machine-readable reservations of rights under Article 4(3) of Directive 2019/790 when using web crawlers for text and data mining.
- Jurisdiction: EU
- Source: EU GPAI Code of Practice (copyright chapter) page (https://ec.europa.eu/newsroom/dae/redirection/document/118115), source id eu-gpai-code-copyright
- Pinpoint: Copyright chapter, Measure 1.3
- Quote: "machine-readable reservations of rights expressed pursuant to Article 4(3) of Directive (EU) 2019/790"
- Checked: 2026-11-10

#### [M-0494] VERIFIED
- Claim: EU GPAI Code of Practice (voluntary, copyright chapter) Measure 1.4(1)(a): to mitigate the risk that downstream AI systems built on a general-purpose model generate infringing output, signatories commit to appropriate and proportionate technical safeguards against the model generating outputs that reproduce protected training content in an infringing manner.
- Jurisdiction: EU
- Source: EU GPAI Code of Practice (copyright chapter) page (https://ec.europa.eu/newsroom/dae/redirection/document/118115), source id eu-gpai-code-copyright
- Pinpoint: Copyright chapter, Measure 1.4(1)(a)
- Quote: "to implement appropriate and proportionate technical safeguards to prevent their models from generating outputs that reproduce training content protected by Union law on copyright and related rights in an infringing manner"
- Checked: 2026-11-10

#### [M-0431] VERIFIED
- Claim: GEMA v. OpenAI (LG Munich I, Nov. 11, 2025, 42 O 14139/24): memorising works in a language model is a reproduction under UrhG s.16. Translation: memorisation of language works in the AI model is a reproduction because the work is physically fixed and can be made indirectly perceptible.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 2 (Rn. 181)
- Quote: "Die Memorisierung von Sprachwerken im KI-Sprachmodell stellt eine Vervielfältigung nach § 16 UrhG dar, weil das Werk körperlich festgelegt ist und es mittelbar wahrnehmbar gemacht werden kann."
- Checked: 2026-11-10

#### [M-0432] VERIFIED
- Claim: GEMA v. OpenAI: the TDM exception (UrhG s.44b) covers copies made to build training data but not the training of the model itself. Translation: the barrier of s.44b covers reproduction when creating training data material, but not training the model.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 4 (Rn. 193)
- Quote: "Unter die Schranke des § 44b UrhG unterfallen Vervielfältigung beim Erstellen des Trainigsdatenmaterials, nicht aber bei dem Training des Modells"
- Checked: 2026-11-10

#### [M-0433] VERIFIED
- Claim: GEMA v. OpenAI: the model operators, not the users, are liable for infringing outputs produced by simple prompts. Translation: operators of the language model are liable for infringement through outputs because they control the act.
- Jurisdiction: case-law
- Source: LG München I, Urteil vom 11.11.2025, 42 O 14139/24, GEMA v OpenAI (Bayern.Recht official text, German) (https://www.gesetze-bayern.de/Content/Pdf/Y-300-Z-GRURRS-B-2025-N-30204?all=False), source id de-lgmuenchen-gema-openai-2025
- Pinpoint: Leitsatz 5 (Rn. 275-277)
- Quote: "Die Betreiber des Sprachmodells haften für Urheberrechtsverletzung durch Outputs, weil sie die Tatherrschaft ausüben."
- Checked: 2026-11-10
