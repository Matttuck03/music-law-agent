# Music law knowledge pack: Remixes, covers, stem tools and DJ mixes
- File: 06-remixes-covers-dj-mixes.md, part of the music law knowledge pack (remix edition).
- Contains: M21 Remixes and derivative works; M22 Covers and the compulsory mechanical licence; M23 Stem tools and DJ mixes. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-13.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M21 Remixes and derivative works
- Law last checked: 2026-11-13. Volatility: medium.
- Use for questions like: Who has to give permission for a remix; Who owns a remix; Can I protect a remix I made without permission; Does changing a song enough make it mine; Is a re-played version safer than using the original recording; Can a remix or mashup be fair use

### Bottom line
- US federal law. A remix of a released track touches two copyrights: the song (composition) and the recording (master). They are separate works [M-0025]. Each owner holds its own right to make derivative works and to let others make them [M-0522]. So a remix built from the original audio needs a yes from both sides (analysis).
- Who usually says yes: the publisher or songwriter for the composition, the label or distributor for the master (industry practice, see card M01).
- The statute names remixing. The master owner's derivative right covers works in which the actual recorded sounds are "rearranged, remixed, or otherwise altered in sequence or quality" [M-0523].
- A remix made without permission gets no copyright protection in any part that uses the borrowed material unlawfully [M-0528]. Changing the song a lot does not fix that [M-0534, M-0552].
- A remix made with permission: the remixer can own only the new material added, never the underlying song or recording [M-0529].

### Rules
- US federal, 17 U.S.C. 101: a derivative work is a work based on one or more earlier works. The examples include a musical arrangement and a sound recording, and "any other form in which a work may be recast, transformed, or adapted" [M-0521, M-0035].
- US federal, 17 U.S.C. 106(2): the copyright owner has the exclusive right to prepare derivative works and to authorise others to do so [M-0522, M-0565].
- US federal (regulator guidance, Copyright Office Circular 56A): a sound recording is a separate work from the composition under it [M-0025]. The Office treats the recording as a derivative work of the composition [M-0026].
- US federal, 17 U.S.C. 114(b): the master owner's derivative right is limited to works where the actual sounds fixed in the recording are rearranged, remixed or otherwise altered in sequence or quality [M-0523]. The 1976 House Report says the wording was added to make that scope clear [M-0524].
- US federal, 17 U.S.C. 114(b): the master owner's reproduction right covers only copying that recaptures the actual sounds [M-0110]. A new recording made wholly of independently recorded sounds does not infringe the master, even if it imitates it. The composition is still a separate copyright (analysis in the row) [M-0111].
- US federal, 17 U.S.C. 103(a): protection for a work that uses earlier copyrighted material does not extend to any part where that material was used unlawfully [M-0528]. The Copyright Office says the same and adds that unauthorised adaptation may be infringement (regulator guidance) [M-0527].
- US federal (legislative history): the House Report says an unauthorised translation of a novel could not be copyrighted at all, while a use that is not unlawful, for example a fair use, leaves the new work copyrightable [M-0530].
- US federal, 17 U.S.C. 103(b): copyright in a derivative work or compilation covers only the new material the author added. It gives no right in the earlier material [M-0529]. Copyright Office Circular 14 says the same (regulator guidance) [M-0531].
- Seventh Circuit (court decision, Pickett v. Prince, 2000): section 103(a) does not let a stranger make a derivative work. The court read it, at least so far as that case went, to mean only that the right to make one does not authorise using material that infringes someone else's copyright [M-0532].
- Seventh Circuit (court decision, Pickett): the court found it very difficult to see how a derivative work not made by the owner of the original could fail to infringe it [M-0533]. It rejected the idea that a stranger may make one as long as the original does not pervade the new work [M-0534].
- Second Circuit (court decision, Keeling v. Hars, 2015): the maker of an unauthorised work that stays within fair use and adds enough originality may claim protection for her own original contributions [M-0535]. The facts were a parody stage show, not music, and a jury had found fair use [M-0536].
- US federal, 17 U.S.C. 501(a): anyone who violates an exclusive right of the copyright owner is an infringer [M-0220]. That sentence has no carve-out for giving credit or for not charging money (analysis).
- US federal, 17 U.S.C. 107: fair use is a four factor test. The factors are purpose and character, nature of the work, amount used, and market effect [M-0547]. The statute sets no number of seconds [M-0203]. It is judged case by case with no bright-line rules (court decision, Campbell) [M-0205].
- US federal (court decision, Campbell, 1994): parody needs to mimic the original to make its point, so it has some claim to use it. Satire can stand on its own and needs a reason for the borrowing [M-0548]. Commercial use is only one element of factor one [M-0549]. The amount taken is judged against the purpose of the copying [M-0550].
- US federal (court decision, Warhol, 2023): if the original and the new use share the same or a very similar purpose and the use is commercial, factor one is likely to weigh against fair use unless there is another justification [M-0551]. Treating any added new expression as enough would let "transformative use" swallow the owner's derivative right [M-0552]. Commercial nature is relevant but does not decide the matter [M-0553].
- Southern District of New York (court decision, Estate of Smith, 2017): fair use is a defence, and the party who raises it carries the burden [M-0211].
- Ownership of an authorised remix, US federal: a work is made for hire if an employee makes it within the job, or if it is specially commissioned, falls in a listed category and the parties sign a writing that says so [M-0537, M-0046]. The list does not name sound recordings (analysis row) [M-0047]. For a work made for hire the employer or commissioning party is the author [M-0048].
- US federal, 17 U.S.C. 201(d)(2) and 204(a): any exclusive right, or a slice of one, can be transferred and owned separately [M-0539]. A transfer is not valid without a writing signed by the owner of the right [M-0040].
- US federal (policy paper, Commerce Department white paper, January 2016, not law): remixes include mashups and sampling, and in many cases will be derivative works, compilations or collective works [M-0554]. Because remixes often rely on several copyrighted works, they can raise daunting licensing issues [M-0555].
- Same paper: the Task Force found no proven need for a remix exception or a compulsory remix licence. It recommended guidelines, more voluntary licensing and education [M-0556]. It said some remixes will clearly fall on one side of the fair use line and others will be uncertain [M-0557].

### Platform application
- A user blends two hit records. That mix can involve four owners: two compositions and two masters (analysis) [M-0025, M-0522]. Mixing more tracks adds more owners. This is the licensing problem the 2016 paper describes [M-0555].
- Who must authorise: both owners of each track, because the mix rearranges or alters the actual recorded sounds [M-0523] and each owner controls derivative works of its own work [M-0522]. No row in this base lets a platform or a user skip either side.
- Who owns a user's mix: at most, the user owns the new material the user added [M-0529]. If the tracks were used without permission, the unlawful parts get no protection [M-0528]. In the Second Circuit a user could still claim the original additions if the use is a fair use [M-0535]. The Seventh Circuit took a harder line [M-0532]. Other circuits are not in the saved set.
- Platform terms should not tell users "your mix is yours" without limits (analysis). The accurate line is: you own what you add, not the songs or recordings you used [M-0529].
- Official remix projects (an artist or label invites remixes): put the grant in a signed writing [M-0040]. Do not assume a commissioned remix is a work made for hire, since the commissioned categories are a closed list and sound recordings are not named [M-0046, M-0047]. The base has no saved source on standard remix deal terms (gap).
- Re-played versions: if a user re-records a part with new sounds, the master owner drops out but the composition owner does not [M-0111]. A stem pulled from the original recording is not a re-play, because it holds the actual recorded sounds (analysis) [M-0110].
- Fair use is a defence the user or platform would have to prove [M-0211]. A mix that plays songs as songs, for listening, shares the purpose of the originals, which Warhol says weighs against fair use when the use is commercial [M-0551]. The base has no case on whether a DJ mix or mashup is a fair use (gap).
- Risk carriers: the user who makes and shares the remix comes first. The platform carries risk as host, as tool maker and for anything it copies or performs itself (see cards M23 and M25). Claimants are labels and publishers.

### Gotchas
- "Change it enough and it is yours" is wrong. Pickett rejected the idea that a stranger may make a derivative work when the original does not pervade it [M-0534]. Warhol warns that adding new expression is not enough on its own [M-0552].
- "I own my remix because I made it" is at best half right. Protection covers only what you added [M-0529] and drops out where the borrowed material was used unlawfully [M-0528].
- Pickett is one circuit and its own wording is limited to that case [M-0532]. Keeling is not a music case and rested on a fair use finding [M-0536]. Do not present either as the national rule.
- A sound-alike avoids only the master. The composition still needs a licence [M-0111].
- Giving credit and not charging are not defences in the infringement statute (analysis) [M-0220]. Commercial nature is one fair use factor, not the test [M-0549, M-0553].
- The white paper is a 2016 policy paper, not law. As of 2026-11-13 the saved set has no later statute or Copyright Office action on a remix exception. Check before relying on [M-0556].
- Anderson v. Stallone is often quoted on this topic. The base has no primary text for it, so it is not cited here.
- Joint authorship of a remix (two users, or a user and the original artist) is not covered in the base (gap).

### Open questions for counsel
- US federal: when a platform's tool renders the mix, who is the maker of the derivative work, the user or the platform?
- US federal: outside the Second and Seventh Circuits, can a user claim copyright in the new parts of an unauthorised mix?
- US federal: can a transition-only blend, where each track plays mostly unchanged, be a fair use, and does the answer differ for a mashup that layers two tracks?
- US federal: for artist-approved remix projects, what grant wording gives users a safe right to make and share remixes, and who should own the result?
- US federal: has anything since January 2016 changed the white paper position that there is no remix exception or compulsory remix licence?

### Sources
- usc17-101: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101)
- usc17-103: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103)
- usc17-106: 17 U.S.C. 106 exclusive rights (https://www.law.cornell.edu/uscode/text/17/106)
- usc17-107: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107)
- usc17-114: 17 U.S.C. 114 sound recordings (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-201, usc17-204, usc17-501: ownership, transfers, infringement (https://www.law.cornell.edu/uscode/text/17)
- co-circular-14: Copyright Office Circular 14, derivative works and compilations (https://www.copyright.gov/circs/circ14.pdf)
- co-circular-56a: Copyright Office Circular 56A (https://www.copyright.gov/circs/circ56a.pdf)
- ca7-pickett-prince-2000: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json)
- ca2-keeling-hars-2015: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json)
- scotus-campbell-1994: Campbell v. Acuff-Rose Music, 510 U.S. 569 (1994) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf)
- scotus-warhol-2023: Andy Warhol Foundation v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf)
- sdny-estate-smith-2017: Estate of Smith v. Cash Money Records (https://static.case.law/f-supp-3d/253/html/0737-01.html)
- doc-white-paper-remixes-2016: Commerce Department white paper on remixes, January 2016 (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf)

### Claims cited in M21
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0528] VERIFIED
- Claim: Under Section 103(a), protection for a work employing preexisting copyrighted material does not extend to any part of the work in which the material has been used unlawfully.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(a)
- Quote: "protection for a work employing preexisting material in which copyright subsists does not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0534] VERIFIED
- Claim: Pickett rejected the idea that a stranger may make a derivative work without permission if the original does not pervade the derivative; it would undermine the 106(2) right.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402
- Quote: "would inject enormous uncertainty into the law of copyright and undermine the exclusive right that section 106(2) gives the owner of the copyright on the original work"
- Checked: 2026-11-13

#### [M-0552] VERIFIED
- Claim: Warhol: reading Campbell to favour any use adding new expression would let transformative use swallow the owner's right to prepare derivative works.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "transformative use would swallow the copyright owner’s exclusive right to prepare derivative works"
- Checked: 2026-11-13

#### [M-0529] VERIFIED
- Claim: Copyright in a derivative work or compilation covers only the new material the author contributed and gives no exclusive right in the preexisting material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(b)
- Quote: "The copyright in a compilation or derivative work extends only to the material contributed by the author of such work"
- Checked: 2026-11-13

#### [M-0521] VERIFIED
- Claim: A derivative work is one based on preexisting works; the statute's examples include a musical arrangement and a sound recording, and 'any other form in which a work may be recast, transformed, or adapted'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'derivative work'
- Quote: "any other form in which a work may be recast, transformed, or adapted"
- Checked: 2026-11-13

#### [M-0035] VERIFIED
- Claim: A derivative work is a work based upon one or more preexisting works, such as a sound recording or musical arrangement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "derivative work"
- Quote: "A “derivative work” is a work based upon one or more preexisting works, such as a translation, musical arrangement, dramatization, fictionalization, motion picture version, sound recording, art reproduction, abridgment, condensation"
- Checked: 2026-11-10

#### [M-0565] VERIFIED
- Claim: The owner of copyright in a work has the exclusive right to prepare derivative works based on it, separate from reproduction.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "to prepare derivative works based upon the copyrighted work"
- Checked: 2026-11-13

#### [M-0026] VERIFIED
- Claim: The Copyright Office treats a sound recording as a derivative work of the underlying musical composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a substitute for, copyright"
- Checked: 2026-11-10

#### [M-0524] VERIFIED
- Claim: The 1976 House Report says Section 114(b) was amended to make clear the scope of 106(2) for sound recordings, quoting the rearranged, remixed or altered actual sounds limit.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: H.R. Rep. 94-1476 note on 114
- Quote: "the Committee adopted an amendment to make clear the scope of rights under section 106(2) in this context"
- Checked: 2026-11-13

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0527] VERIFIED
- Claim: An unauthorised use of a copyrighted work: the Office states copyright protection does not extend to any part of the work in which the material has been used unlawfully, and that unauthorized adaptation may be infringement.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 14, Copyright in Derivative Works and Compilations (https://www.copyright.gov/circs/circ14.pdf), source id co-circular-14
- Pinpoint: Circular 14, derivative works
- Quote: "In any case where a copyrighted work is used without the permission of the copyright owner, copyright protection will not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0530] VERIFIED
- Claim: The House Report says an unauthorized translation of a novel could not be copyrighted at all, while use that is not unlawful (for example fair use) leaves the work copyrightable.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: H.R. Rep. 94-1476 note on 103(a)
- Quote: "an unauthorized translation of a novel could not be copyrighted at all"
- Checked: 2026-11-13

#### [M-0531] VERIFIED
- Claim: Copyright Office: the copyright in a derivative work covers only the new material added and does not extend to preexisting material owned by a third party.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 14, Copyright in Derivative Works and Compilations (https://www.copyright.gov/circs/circ14.pdf), source id co-circular-14
- Pinpoint: Circular 14, protection in derivative works
- Quote: "Protection does not extend to any preexisting material, that is, previously published or previously registered works or works in the public domain or owned by a third party"
- Checked: 2026-11-13

#### [M-0532] VERIFIED
- Claim: Pickett v. Prince (7th Cir. 2000): section 103(a) does not let a stranger make a derivative work; the court read it to mean, at least so far as bears on that case, only that the right to make one does not authorise using material that infringes someone else's copyright.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402, Posner C.J.
- Quote: "we do not read section 103(a) as qualifying the exclusive right of the owner of the copyright of the original work to make derivative works based on that work"
- Checked: 2026-11-13

#### [M-0533] VERIFIED
- Claim: Pickett: it is very difficult to see how a derivative work not made by the owner of the original could fail to infringe it, given the definition of derivative works.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402
- Quote: "It is very difficult to see how a derivative work not made by the owner of the original work could fail to infringe it, given the definition of derivative works"
- Checked: 2026-11-13

#### [M-0535] VERIFIED
- Claim: Keeling v. Hars (2d Cir. 2015): the creator of an unauthorized work that stays within fair use and adds sufficient originality may claim 103 protection for her original contributions.
- Jurisdiction: case-law
- Source: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json), source id ca2-keeling-hars-2015
- Pinpoint: 809 F.3d 43
- Quote: "if the creator of an unauthorized work stays within the bounds of fair use and adds sufficient originality, she may claim protection under the Copyright Act"
- Checked: 2026-11-13

#### [M-0536] VERIFIED
- Claim: Keeling v. Hars (2d Cir. 2015), facts: a parody stage adaptation whose author held no copyright or licence in the source film; a jury found the adaptation a fair use, and the court's holding on protection for her original contributions is in M-0535.
- Jurisdiction: case-law
- Source: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json), source id ca2-keeling-hars-2015
- Pinpoint: 809 F.3d 43, Background
- Quote: "Keeling possesses no copyright or license with regard to the Point Break motion picture"
- Checked: 2026-11-13

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0547] VERIFIED
- Claim: Section 107 lists four fair use factors: purpose and character (commercial or nonprofit), nature of the work, amount and substantiality used, and market effect.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "the amount and substantiality of the portion used in relation to the copyrighted work as a whole"
- Checked: 2026-11-13

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0205] VERIFIED
- Claim: Campbell: fair use requires case-by-case analysis and is not simplified by bright-line rules.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 577 (Part II.A, opinion of the Court)
- Quote: "The task is not to be simplified with bright-line rules, for the statute, like the doctrine it recognizes, calls for case-by-case analysis."
- Checked: 2026-11-10

#### [M-0548] VERIFIED
- Claim: Campbell: parody needs to mimic an original to make its point and so has some claim to use its victim's work, whereas satire can stand on its own two feet and so requires justification for the very act of borrowing.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 580-81
- Quote: "satire can stand on its own two feet and so requires justification for the very act of borrowing"
- Checked: 2026-11-13

#### [M-0549] VERIFIED
- Claim: Campbell: a commercial nature is only one element of factor one; no presumption that every commercial use is unfair.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus
- Quote: "The statute makes clear that a work's commercial nature is only one element of the first factor enquiry into its purpose and character"
- Checked: 2026-11-13

#### [M-0550] VERIFIED
- Claim: Campbell: even the original's heart can be taken for parody because the heart is what conjures up the song, so the amount used is judged against the purpose of the copying.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus (e), pp. 586-589
- Quote: "Even if 2 Live Crew's copying of the original's first line of lyrics and characteristic opening bass riff may be said to go to the original's"
- Checked: 2026-11-13

#### [M-0551] VERIFIED
- Claim: Warhol: if an original and the secondary use share the same or highly similar purposes and the use is commercial, factor one is likely to weigh against fair use absent another justification.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "if an original work and secondary use share the same or highly similar purposes, and the secondary use is commercial, the first fair use factor is likely to weigh against fair use"
- Checked: 2026-11-13

#### [M-0553] VERIFIED
- Claim: Warhol: commercial nature is relevant but not dispositive, and is weighed against the degree to which the use has a further purpose or different character.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "The commercial nature of a use is relevant, but not dispositive"
- Checked: 2026-11-13

#### [M-0211] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017): fair use is an affirmative defense and the party asserting it bears the burden.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 748 (Part on fair use; burden sentence follows)
- Quote: "Fair use is an affirmative defense to copyright infringement"
- Checked: 2026-11-10

#### [M-0537] VERIFIED
- Claim: A work made for hire is one prepared by an employee in scope of employment, or a specially commissioned work in listed categories (including a contribution to a collective work or a compilation) if the parties sign a written instrument saying so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'work made for hire'
- Quote: "if the parties expressly agree in a written instrument signed by them that the work shall be considered a work made for hire"
- Checked: 2026-11-13

#### [M-0046] VERIFIED
- Claim: A commissioned (non-employee) work counts as made for hire only if it falls in an enumerated category, including a contribution to a collective work, part of a motion picture or other audiovisual work, and a compilation, and the parties expressly agree in a signed written instrument.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "a work specially ordered or commissioned for use as a contribution to a collective work, as a part of a motion picture or other audiovisual work, as a translation, as a supplementary work, as a compilation, as an instructional text"
- Checked: 2026-11-10

#### [M-0047] VERIFIED
- Claim: The category list does not name sound recordings; whether a sound recording is made for hire turns on the employee prong or on fitting a listed category such as compilation or part of an audiovisual work (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "as a part of a motion picture or other audiovisual work, as a translation, as a"
- Checked: 2026-11-10

#### [M-0048] VERIFIED
- Claim: In a work made for hire the employer or commissioning party is the author and, unless the parties agree otherwise in a signed writing, owns all rights in the copyright.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(b)
- Quote: "In the case of a work made for hire, the employer or other person for whom the work was prepared is considered the author for purposes of this title, and, unless the parties have expressly agreed otherwise in a written"
- Checked: 2026-11-10

#### [M-0539] VERIFIED
- Claim: Any of the exclusive rights in a copyright, including any subdivision of the section 106 rights, may be transferred and owned separately (17 U.S.C. 201(d)(2)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(2)
- Quote: "Any of the exclusive rights comprised in a copyright, including any subdivision of any of the rights specified by section 106, may be transferred as provided by clause (1) and owned separately."
- Checked: 2026-11-13

#### [M-0040] VERIFIED
- Claim: A transfer of copyright ownership, other than by operation of law, is not valid unless in a writing signed by the owner of the rights conveyed or the owner's authorized agent.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 204 execution of transfers of copyright ownership (https://www.law.cornell.edu/uscode/text/17/204), source id usc17-204
- Pinpoint: 17 U.S.C. 204(a)
- Quote: "A transfer of copyright ownership, other than by operation of law, is not valid unless an instrument of conveyance, or a note or memorandum of the transfer, is in writing and signed by the owner"
- Checked: 2026-11-10

#### [M-0554] VERIFIED
- Claim: 2016 Commerce white paper: remixes include mashups and sampling, and in many cases they will be derivative works, compilations or collective works under the Copyright Act.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 7
- Quote: "In many cases, these remixes will constitute derivative works, compilations, or collective works, as defined in the Copyright Act"
- Checked: 2026-11-13

#### [M-0555] VERIFIED
- Claim: 2016 Commerce white paper: the Task Force's Green Paper had noted that, because remixes often rely on multiple copyrighted works, they can raise daunting licensing issues.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 19
- Quote: "because remixes often use multiple copyrighted works as source material, they can raise daunting licensing issues"
- Checked: 2026-11-13

#### [M-0556] VERIFIED
- Claim: The Task Force concluded the record had not established a need to create a specific remix exception or a compulsory licence for remix uses, and recommended guidelines, more voluntary licensing and education.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 4
- Quote: "the record has not established a need to amend existing law to create a specific exception or a compulsory license for remix uses"
- Checked: 2026-11-13

#### [M-0557] VERIFIED
- Claim: The Task Force noted some remixes will clearly fall on one side of the fair use line while the status of others will be uncertain, and it recommended steps to lessen that uncertainty and make licensing easier.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 27
- Quote: "While some remixes may clearly fall on one side or the other of the fair use line, the status of others will be uncertain"
- Checked: 2026-11-13

## M22 Covers and the compulsory mechanical licence
- Law last checked: 2026-11-13. Volatility: medium.
- Use for questions like: What does a cover licence allow; Can I change the arrangement of a song I cover; Does a cover licence cover a remix or mashup; Why does a cover in a video need a sync licence; Does a cover licence let me use the original recording; What do distributors require for a cover

### Bottom line
- US federal law. A cover is your own new recording of someone else's song. Section 115 gives a compulsory "mechanical" licence to make and distribute audio recordings of a song that has already been released, without asking the publisher, if you follow the statute's steps [M-0339, M-0545].
- The licence is for the composition only. It is not a licence of any sound recording [M-0542]. You may not copy the original recording with it [M-0543].
- You may arrange the song to fit your style. You may not change the basic melody or the fundamental character of the work [M-0540].
- It is audio only. It does not cover putting the song in a video. Video needs a sync licence agreed directly with the publisher [M-0544, M-0121, M-0140].
- A remix or mashup built from the original audio is not a cover, and a cover licence does not reach it (analysis from [M-0542, M-0540]).

### Rules
- US federal, 17 U.S.C. 115: the rights to make and to distribute phonorecords (audio copies) of nondramatic musical works are subject to compulsory licensing [M-0339]. The licence is limited to phonorecords made mainly for distribution to the public for private use [M-0120].
- First release belongs to the owner. US federal, 115(a)(1)(A): the compulsory licence is open only if phonorecords of the song were already distributed to the public in the US with the owner's authority. For a digital music provider's digital deliveries there is a second path: the first recording was made with the composition owner's authority and the recording owner authorised the deliveries [M-0545].
- Arrangement limit. US federal, 115(a)(2): the licence includes the privilege of making an arrangement only as far as needed to fit the style or manner of the performance. The arrangement may not change the basic melody or fundamental character of the work [M-0540].
- No new copyright in the arrangement. US federal, 115(a)(2): an arrangement made under the compulsory licence is not protected as a derivative work unless the composition owner gives express consent [M-0541].
- Composition only. US federal, 115(a)(1): the licence is for making and distributing phonorecords of the musical work. It is not a licence of any sound recording [M-0542]. The Copyright Office says you cannot copy a publicly distributed sound recording without permission, cannot change the basic melody, and cannot claim your arrangement as a derivative work (regulator guidance, Circular 73) [M-0543].
- No video. The Copyright Office says a phonorecord does not include sounds that accompany a motion picture or other audiovisual work, so the compulsory licence does not cover a song in video (regulator guidance) [M-0544]. The 1976 House Report says the same about sound tracks [M-0121]. The base's own reading reaches the same result for the blanket licence (analysis row) [M-0179].
- Sync is a free-market licence. The sync right is the industry term for the reproduction right in a song timed to pictures [M-0141]. The Copyright Office recommended in 2015 that consumer audiovisual uses stay in the free market with no compulsory licence (regulator report) [M-0140].
- Notice for physical copies. US federal, 115(b): for non-digital phonorecords, a notice of intention must be served before, or within 30 days after, making the phonorecords and before distributing them. Missing it closes off the compulsory licence and, without a voluntary licence, makes the making and distribution infringement [M-0546].
- Digital services. US federal, 115(d): a digital music provider can get a blanket mechanical licence through the Mechanical Licensing Collective for digital phonorecord deliveries [M-0023, M-0122]. The blanket licence covers the musical works available for compulsory licensing for covered activities [M-0125]. The base has no row on how notices changed over in 2021 (gap). Rates are in card M04 and are not quoted here.
- A cover avoids the master owner only if every sound is newly recorded. US federal, 114(b): an independent recording of other sounds does not infringe the sound recording copyright, even if it imitates the original [M-0111].
- Playing a cover to the public is a different right. Public performance of the song is separate from the reproduction and distribution rights that the mechanical licence covers (analysis row) [M-0183]. See card M05 for performing rights organisations.
- CD Baby (platform terms, help page, web archive copy dated 2026-02-16, captured 2026-11-13): a cover release needs a mechanical licence for digital downloads, which covers the composition but not the original recording [M-0596]. Derivative works such as samples cannot be cleared through its cover song process [M-0597]. Even for streaming-only plans it still requires at least a digital download licence to distribute a cover [M-0598].
- TuneCore (platform terms, help page, web archive copy dated 2020-05-07, captured 2026-11-13, possibly stale): a cover may need permission and possibly a licence from the original copyright holder before release [M-0594]. The same 2020 page says some stores did not accept soundalike covers [M-0595].

### Platform application
- A user records their own performance of a released song, audio only. That is a cover. The composition side can run through the compulsory mechanical licence [M-0339, M-0545]. The master belongs to whoever made the new recording (analysis) [M-0111].
- A user mixes the original recording of a song. That is not a cover. It uses the actual recorded sounds, which sit inside the master owner's rights [M-0110, M-0523], and the cover licence is not a licence of any sound recording [M-0542].
- A user layers the vocal of one song over the instrumental of another. Even on the composition side this is likely past the arrangement privilege, because it goes beyond fitting a style of performance (analysis) [M-0540]. It needs the publishers' direct consent, and the masters' owners too if original audio is used [M-0522].
- A user changes tempo, key or structure of a cover so far that the melody or character changes. That is outside the compulsory licence and needs the publisher's consent (analysis) [M-0540].
- A user makes a video of a cover or a mix. The mechanical licence stops at audio [M-0544]. A sync licence from the publisher is needed, and a master use licence too if the original recording is used [M-0140, M-0141].
- If the platform streams covers on demand, it also needs public performance licences for the compositions (see card M05) [M-0183]. Whether the platform can itself use the blanket mechanical licence depends on whether it qualifies as a digital music provider. That is a question for counsel [M-0122].
- If users send covers to stores through a distributor, the distributor's own rules apply on top of the law. The two saved pages both treat covers and sample-based works differently [M-0597, M-0594].
- Risk carriers: the user who records and releases the cover; the platform if it hosts, streams or distributes it; publishers as claimants. Labels become claimants only when original audio is used.

### Gotchas
- "A cover licence covers a remix" is wrong. The compulsory licence is composition only [M-0542], bars changes to the basic melody or fundamental character [M-0540], and one distributor says in terms that derivative works such as samples cannot go through its cover process [M-0597].
- "I bought a cover licence, so I can post the video" is wrong. No video under the compulsory licence [M-0544].
- "My arrangement is mine" is wrong under the compulsory licence. It is not protected as a derivative work without the owner's express consent [M-0541].
- A song that has never been released with the owner's authority is not open to the compulsory licence [M-0545].
- The TuneCore page is a 2020 archive copy and may be out of date. The CD Baby page is an archive copy dated 2026-02-16. Both were captured 2026-11-13. Re-check live terms before relying on them.
- DistroKid and SoundCloud cover and remix rules were not captured (pages blocked). The base makes no claim about them.
- Outside the US the compulsory mechanical licence in section 115 does not apply. The base has no rows on cover licensing in other countries (gap).

### Open questions for counsel
- US federal: does a platform that hosts and streams user covers qualify as a digital music provider that can use the blanket mechanical licence?
- US federal: where is the line between a permitted arrangement and a change to the "fundamental character" of a song, for tempo changes, key changes and re-ordered sections?
- US federal: how do the notice rules work today for a user who releases a cover as a download or on physical media, given the 2021 change to the blanket licence?
- US federal: what is the least a user needs to post a cover with video on the platform?
- Non-US: which licences replace section 115 for covers in the UK, EU, Canada and Australia?

### Sources
- usc17-115: 17 U.S.C. 115 compulsory licence for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115)
- usc17-114: 17 U.S.C. 114 sound recordings (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-106: 17 U.S.C. 106 exclusive rights (https://www.law.cornell.edu/uscode/text/17/106)
- co-circular-73: Copyright Office Circular 73, compulsory licence for phonorecords (https://www.copyright.gov/circs/circ73.pdf)
- co-music-marketplace-2015: Copyright Office, Copyright and the Music Marketplace, 2015 (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf)
- terms-cdbaby-covers: CD Baby help, cover songs, web archive copy 2026-02-16 (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby)
- terms-tunecore-covers: TuneCore help, cover songs, web archive copy 2020-05-07 (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-)

### Claims cited in M22
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0545] VERIFIED
- Claim: First-use rule: the compulsory licence is available only if phonorecords of the work have previously been distributed to the public in the US under the authority of the copyright owner, or, for a digital music provider's digital phonorecord deliveries, the first fixation of the sound recording was made under the musical work owner's authority and the recording owner authorised the deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)(i)-(ii)
- Quote: "phonorecords of such musical work have previously been distributed to the public in the United States under the authority of the copyright owner of the work"
- Checked: 2026-11-13

#### [M-0542] VERIFIED
- Claim: The compulsory licence is for making and distributing phonorecords of a nondramatic musical work (the composition); it is not a licence of any sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)-(B)
- Quote: "obtain a compulsory license to make and distribute phonorecords of a nondramatic musical work"
- Checked: 2026-11-13

#### [M-0543] VERIFIED
- Claim: The Office says that with the compulsory licence you cannot copy a sound recording publicly distributed in phonorecords without permission, and cannot change the basic melody or claim your arrangement as a derivative work.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "Change the basic melody or fundamental character of the work in the arrangement"
- Checked: 2026-11-13

#### [M-0540] VERIFIED
- Claim: A compulsory licence under 115 includes the privilege of an arrangement only to the extent necessary to conform the work to the style of the performance; it may not change the basic melody or fundamental character.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "the arrangement shall not change the basic melody or fundamental character of the work"
- Checked: 2026-11-13

#### [M-0544] VERIFIED
- Claim: The Office states a phonorecord does not include sounds accompanying a motion picture or other audiovisual work, so the compulsory licence does not cover putting a song in video.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "A phonorecord does not include sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-13

#### [M-0121] VERIFIED
- Claim: 1976 House Report: the 115 compulsory licence does not reach sound tracks accompanying a motion picture or other audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115, H.R. Rep. 94-1476 note on 115(a)(1)
- Quote: "(including disks and audio tapes but not the sound tracks or other sound records accompanying a motion picture or other audiovisual work)"
- Checked: 2026-11-10

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0120] VERIFIED
- Claim: The 115 compulsory licence is limited to phonorecords whose primary purpose is distribution to the public for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0541] VERIFIED
- Claim: An arrangement made under the compulsory licence is not protected as a derivative work except with the express consent of the composition owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "shall not be subject to protection as a derivative work under this title, except with the express consent of the copyright owner"
- Checked: 2026-11-13

#### [M-0179] VERIFIED
- Claim: Analysis: a 115 compulsory licence, including the MLC blanket licence under 115(d), is limited to phonorecords made mainly for distribution to the public for private use, and 101 excludes sounds accompanying audiovisual works from "phonorecords", so 115 does not license putting a song into a user video; sync stays a direct licence.
- Jurisdiction: analysis
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)
- Quote: "A person may obtain a compulsory license only if the primary purpose in making phonorecords of the musical work is to distribute them to the public for private use"
- Checked: 2026-11-10

#### [M-0141] VERIFIED
- Claim: The sync right is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), ch. 1 background
- Quote: "the right to synchronize musical works to visual content (e.g., in a music video). The synchronization (or synch right) is a species of the reproduction right and may also implicate the derivative work right."
- Checked: 2026-11-10

#### [M-0546] VERIFIED
- Claim: For non-digital phonorecords, notice of intention must be served on the owner before, or within 30 days after, making and before distributing any phonorecords; failure forecloses the compulsory licence and, absent a voluntary licence, makes the making and distribution actionable as infringement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(b)(1) and (b)(4)(A)
- Quote: "the failure to serve or file the notice of intention required by paragraph (1) forecloses the possibility of a compulsory license"
- Checked: 2026-11-13

#### [M-0023] VERIFIED
- Claim: Under the Music Modernization Act, a digital music provider can obtain a blanket mechanical license through the mechanical licensing collective.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0125] VERIFIED
- Claim: The blanket licence covers all musical works (or shares) available for compulsory licensing for covered activities, except as provided in subparagraph (C) (voluntary licences and individual download authority).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(i)
- Quote: "covers all musical works (or shares of such works) available for compulsory licensing under this section for purposes of engaging in covered activities, except as provided in subparagraph (C);"
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0596] VERIFIED
- Claim: CD Baby says a cover release needs a mechanical licence for digital downloads, which covers the composition but not the original recording.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Can I release a cover song
- Quote: "This license grants you the right to reproduce and distribute the song's composition (lyrics and melody), but not the original recording."
- Checked: 2026-11-13

#### [M-0597] VERIFIED
- Claim: CD Baby says derivative works such as samples cannot be cleared through its cover song licensing process.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Things to note
- Quote: "Derivative works, such as samples, cannot be cleared through the cover song licensing process."
- Checked: 2026-11-13

#### [M-0598] VERIFIED
- Claim: CD Baby says that even for streaming-only intent it still requires at least a digital download licence to distribute a cover.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: streaming sites
- Quote: "you still need to purchase at least a digital download license to distribute your cover song through CD Baby"
- Checked: 2026-11-13

#### [M-0594] VERIFIED
- Claim: TuneCore (help page, Wayback capture of 7 May 2020) says a cover may need permission and possibly a licence from the original copyright holder before release.
- Jurisdiction: platform-terms
- Source: TuneCore help: cover songs (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-), source id terms-tunecore-covers
- Pinpoint: TuneCore help: Can I distribute a cover song
- Quote: "you may need to first get permission (and possibly a license) from the original copyright holder to release your song digitally"
- Checked: 2026-11-13

#### [M-0595] VERIFIED
- Claim: TuneCore (2020 capture) says iTunes, Amazon Music and Rhapsody do not accept soundalike covers and that hidden content cannot be reversed or refunded.
- Jurisdiction: platform-terms
- Source: TuneCore help: cover songs (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-), source id terms-tunecore-covers
- Pinpoint: TuneCore help: Important
- Quote: "iTunes, Amazon Music, and Rhapsody do not accept soundalike cover songs"
- Checked: 2026-11-13

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

## M23 Stem tools and DJ mixes
- Law last checked: 2026-11-13. Volatility: high.
- Use for questions like: Is it legal to host or stream DJ mixes of commercial songs; Is the maker of a stem splitter or mixing tool liable for what users do; Does the statutory webcasting licence cover saved or on-demand mixes; How do licensed mix services clear the tracks; What does a live DJ stream need; Is splitting a song into stems a copy

### Bottom line
- US federal law. Nothing in this base lets a platform publish DJ mixes of commercial tracks without licences. Every track in a mix carries two copyrights, the song and the recording [M-0025]. A recorded mix copies both [M-0108]. Playing it to the public performs the songs [M-0106] and, online, the recordings [M-0107].
- The section 114 statutory licence does not fit a library of saved mixes that people play on demand. It bars interactive services [M-0115], archived programs under 5 hours [M-0578] and longer archives kept up more than 2 weeks [M-0579].
- The licensed mix services in the saved set describe direct deals with labels and paying rights holders in each mix. Neither says it relies on the statutory licence (company statements, captured 2026-11-13) [M-0589, M-0593].
- A tool maker is not contributorily liable just because the tool can be misused [M-0560, M-0563]. It is exposed when it promotes or shapes the tool for infringement [M-0562, M-0221]. No saved case applies this to a stem tool, and vicarious liability is a separate question [M-0252].
- Four things are unsettled or missing here: whether splitting stems is itself an infringing copy, whether a mix is a compilation or a derivative work, what a club or venue licence covers, and live-stream terms of services other than Mixcloud. This card says so and does not fill them.

### Rules
- Tool makers, the old baseline. US federal (court decision, Sony v. Universal, 1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses [M-0560]. The Court found the video recorder had such uses, in part because private, noncommercial home time-shifting of broadcast television was fair use [M-0561]. That holding is about TV recorders. No saved case applies it to a stem tool (analysis).
- Tool makers, inducement. US federal (court decision, Grokster, 2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for the resulting infringement by others [M-0562]. Mere knowledge that a product could be or is used to infringe is not enough, and ordinary product support is not inducement [M-0563].
- Services, the current rule. US federal (court decision, Cox v. Sony, decided March 25, 2026): contributory liability needs intent that the service be used for infringement, shown only by inducement or by a service tailored to infringement [M-0001, M-0221, M-0223]. Mere knowledge that the service will be used to infringe is not enough [M-0222]. The Court rejected the lower court's knowledge plus inaction rule [M-0224].
- What Cox left open. Cox was about contributory liability. Vicarious liability is a separate theory the Court did not decide (analysis row) [M-0252]. One Justice said other common-law theories such as aiding and abetting could apply [M-0225].
- Applying inducement to a stem or mixing tool: the researchers' reading is that a tool maker whose marketing or onboarding steers users to split and mix commercial songs they do not own is exposed through its own statements and design, not through the tool's ability alone (unverified) [M-0564].
- Direct liability. US federal, 17 U.S.C. 501(a): anyone who violates an exclusive right is an infringer [M-0220]. When the platform's own servers copy, split, render or stream music, the question becomes whether the platform itself did the act. The base has no row on that test (gap).
- Hosting user uploads. US federal, 17 U.S.C. 512(c): the safe harbor covers infringement by reason of storage at the direction of a user [M-0343]. Conditions include no actual or red flag knowledge [M-0344, M-0345], fast removal on knowledge or notice [M-0346, M-0348], no direct financial benefit from infringement the provider can control [M-0347], a designated agent [M-0349] and a repeat infringer policy [M-0357]. Card M08 has the detail.
- What a mix is, right by right. Reproduction: both the song and the recording carry it [M-0108]. Derivative works: each owner controls them [M-0522], and for the master that covers rearranging, remixing or altering the actual sounds [M-0523]. Performance: songs have a public performance right [M-0106]; recordings have one only for digital audio transmission [M-0107, M-0296].
- Compilation or derivative work. A compilation is a work formed by collecting and assembling existing materials, selected, coordinated or arranged so the whole is an original work [M-0569]. A derivative work recasts, transforms or adapts earlier works [M-0521]. A government paper says remixes will in many cases be derivative works, compilations or collective works (policy paper, 2016) [M-0554]. No saved authority decides which one a DJ mix is. Unsettled.
- Either way, the mix maker's own copyright covers only what the maker added [M-0529], and not any part where earlier material was used unlawfully [M-0528].
- Stem splitting. The master owner's reproduction right covers copying that recaptures the actual sounds [M-0110]. A stem holds the actual recorded sounds, so it falls within that wording (analysis). No saved case rules on stem separation, private or public. Unsettled.
- Home recording law is narrow. US federal, 17 U.S.C. 1008: no infringement action may be based on making or selling the listed recording devices and media, or on a consumer's noncommercial use of such a device or medium to make musical recordings [M-0572]. The device definition turns on a recording function designed or marketed mainly for making private-use digital audio copies [M-0573].
- Ninth Circuit (court decision, RIAA v. Diamond, 1999): a computer hard drive is outside the Act's definition of a digital music recording, and a player that copies only from a hard drive is not a covered device [M-0574, M-0575]. The court described the Act's purpose as private, noncommercial recording by consumers [M-0576]. Whether software stem splitting on a computer or server is inside this shelter is not decided, and Diamond makes it doubtful (analysis).
- US federal, 17 U.S.C. 117(a) lets the owner of a copy of a computer program make another copy or adaptation of that program on stated conditions. Its text names only computer programs [M-0577]. It gives no stated right to copy or adapt music files (analysis).
- The 114 statutory licence, entry test. It reaches subscription transmissions, eligible nonsubscription transmissions and one satellite category, if the listed conditions are met [M-0114]. The transmission must not be part of an interactive service [M-0115, M-0298]. An interactive service lets a member of the public receive a program made for the recipient or, on request, a particular sound recording [M-0113, M-0299]. Taking requests for the public at large does not alone make a service interactive, within limits [M-0585].
- The 114 licence, archive rules. The transmission may not be part of an archived program of less than 5 hours [M-0578]. An archived program of 5 hours or more may not stay available for more than 2 weeks [M-0579].
- The 114 licence, programming rules. The service may not exceed the sound recording performance complement or publish an advance schedule of the specific recordings [M-0580]. The complement caps, in any 3-hour period on a channel, how many selections come from one record or one featured artist [M-0581].
- The 114 licence, other conditions. The service may take no affirmative steps to cause or induce listeners to make copies [M-0582]. The transmission must be made from a phonorecord lawfully made under the copyright owner's authority [M-0583]. The service must show the title, record and featured artist in text while the recording plays [M-0584].
- What 114 does not do. It is about performing recordings by digital audio transmission [M-0114, M-0107]. An interactive service also needs a licence for each song inside the recordings [M-0301]. A digital audio transmission does not include any audiovisual work, so video of a DJ set is outside it [M-0112, M-0297].
- How licensed mix services clear tracks. Mixcloud (company blog, not terms and not law; blog dated 2024-03-28, page path after redirect dated 2025-01-01, captured 2026-11-13) says a streaming service must hold licences clearing both the composition and the sound recording of every track in a stream [M-0586]. It says it was the first streaming service to clear the copyrights for radio shows and mixes [M-0587]. Its checklist asks whether a platform has direct deals with the labels whose music is played [M-0589]. It says downloading needs an additional licensed right, the mechanical right [M-0588].
- Apple Music (company notice to artists dated 2021-11-16, captured 2026-11-13) says it developed a process to identify and compensate the individual creators in DJ mixes [M-0592], works with major and independent labels, and pays rights holders within DJ mixes directly [M-0593].
- Live sets. Mixcloud describes its live product as a licensed live streaming platform that also archives the stream as a recording (company blog, captured 2026-11-13) [M-0590]. It says that on a platform that has not cleared the music, rights holders can have a mix taken down or muted [M-0591].

### Platform application
- The tool itself. A stem splitter and mixer has lawful uses: a user's own songs, licensed stems, music whose owners agreed (analysis). Under Sony, Grokster and Cox the ability to misuse it is not what creates liability [M-0560, M-0563, M-0222]. What the platform says and builds is. Adverts, tutorials, presets or search features aimed at chart hits are the kind of affirmative steps Grokster describes [M-0562], and a product built around unlicensed hits risks being called tailored to infringement [M-0223].
- Keep the two roles apart. As a tool maker the platform is judged by intent [M-0221]. As a host of user mixes it is judged by the 512(c) conditions [M-0343]. As the party that itself copies, renders or streams, it may be judged as a direct infringer [M-0220]. Each role needs its own answer from counsel.
- Recorded mixes shared with the public. A saved mix that listeners start whenever they like looks like an archived program, and a user mix is almost always under 5 hours (analysis). The 114 licence bars that [M-0578]. So public mix hosting of commercial tracks needs direct master licences, plus licences for the songs [M-0301, M-0106]. This matches what the licensed services say they do [M-0586, M-0589].
- A radio-style channel of mixes could in theory use 114, but only with the complement, no advance track lists, no downloads, track text on screen and lawfully made source copies [M-0580, M-0581, M-0582, M-0583, M-0584]. A user-driven mixing product is a poor fit for those limits (analysis).
- Live mixing to an audience. Online, each track is performed as a song and as a recording [M-0106, M-0107]. The only saved service statement says both must be cleared by the service [M-0586]. If the live set is saved for replay, the archive rules above apply to the replay [M-0578, M-0579].
- Stems. Whether the split happens on the user's device or on the platform's servers changes who made the copy (analysis). Server-side splitting and storage put the platform closer to direct copying [M-0110, M-0220]. This is unsettled and is a lead question for counsel.
- Risk carriers: the user for what the user uploads, mixes and shares; the platform as tool maker, host and possibly direct actor; labels and publishers as claimants; a licensed service partner, if one is used, for what its own licences cover.

### Gotchas
- "DJs do it in clubs, so it is legal online" does not follow. The right to perform a song in public is separate from the right to copy it (analysis row) [M-0183]. The base has no saved text of a club or venue licence, so it makes no claim about what such a licence covers (gap). Online, the one saved service statement says both the song and the recording must be cleared for every track [M-0586].
- "We are just a tool" is not a shield by itself. Sony protects a product with substantial lawful uses [M-0560], but inducement is judged by what the maker says and does [M-0562, M-0221].
- "The webcasting licence covers our mixes" is wrong for on-demand or saved mixes [M-0115, M-0578, M-0579] and for any download feature [M-0582].
- "It is for private use, so home recording law covers it" is not established. The Act is tied to listed devices and media [M-0572], and the Ninth Circuit kept computer hard drives outside it [M-0575].
- The Mixcloud and Apple rows are company statements about their own services. They are not law and not terms of service. Capture date 2026-11-13.
- Live-stream music rules for Twitch, YouTube, Instagram and SoundCloud were not captured. The base makes no claim about them (gap).
- Cox v. Sony is from 2026. Outcomes on remand and any new stem or mixing cases are not tracked here. Re-check before relying.
- Statutory damages are counted per work [M-0216], and a single mix can hold many works (analysis). See card M12.

### Open questions for counsel
- US federal: is a stem split of a lawfully bought track a reproduction under 106(1) and 114(b), and does it matter whether the user's device or the platform's server does it?
- US federal: does the home recording shelter in section 1008 reach software stem splitting at all after RIAA v. Diamond?
- US federal: is a blended DJ mix a derivative work of each song and recording, a compilation, or both, and what turns on the label?
- US federal: when a user streams a live mix through the platform, who performs the works publicly, the user, the platform or both?
- US federal: which exact licences does an on-demand mix library need for masters and for songs, and can any part run through 114, the blanket mechanical licence or the performing rights organisations?
- US federal: does the 512(c) safe harbor cover a mix that the platform's own tool rendered from user-supplied tracks, or only files users upload ready-made?
- US federal: what marketing, onboarding and design choices would a court read as inducement or as tailoring the service to infringement after Cox?
- US federal: what does a club or venue performance licence actually cover, and does any of it carry over to online streaming?

### Sources
- scotus-sony-universal-1984: Sony v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf)
- scotus-grokster-2005: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf)
- scotus-cox-sony-2026: Cox Communications v. Sony Music Entertainment, No. 24-171 (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf)
- usc17-101, usc17-103, usc17-106: definitions, compilations and derivative works, exclusive rights (https://www.law.cornell.edu/uscode/text/17)
- usc17-114: 17 U.S.C. 114 sound recordings and the statutory licence (https://www.law.cornell.edu/uscode/text/17/114)
- usc17-117: 17 U.S.C. 117 computer programs (https://www.law.cornell.edu/uscode/text/17/117)
- usc17-512: 17 U.S.C. 512 online safe harbors (https://www.law.cornell.edu/uscode/text/17/512)
- usc17-1001, usc17-1008: Audio Home Recording Act definitions and bar on actions (https://www.law.cornell.edu/uscode/text/17/1008)
- ca9-riaa-diamond-1999: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json)
- doc-white-paper-remixes-2016: Commerce Department white paper on remixes, January 2016 (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf)
- terms-mixcloud-livestream: Mixcloud blog on live streaming music, captured 2026-11-13 (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues)
- terms-apple-dj-mixes: Apple Music for Artists notice on DJ mixes, 2021-11-16, captured 2026-11-13 (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators)

### Claims cited in M23
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0579] VERIFIED
- Claim: Under the 114 statutory licence a transmission may not be part of an archived program of 5 hours or more that is made available for more than 2 weeks, so a permanent on-demand mix archive does not meet that condition.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(II)
- Quote: "is not part of an archived program of 5 hours or greater in duration that is made available for a period exceeding 2 weeks"
- Checked: 2026-11-13

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0560] VERIFIED
- Claim: Sony v. Universal (1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 434-442)
- Quote: "does not constitute contributory infringement if the product is widely used for legitimate, unobjectionable purposes, or, indeed, is merely capable of substantial noninfringing uses"
- Checked: 2026-11-13

#### [M-0563] VERIFIED
- Claim: Grokster: mere knowledge that a product could be or is used to infringe is not enough for liability, and ordinary product support is not inducement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 937
- Quote: "mere knowledge of infringing potential or of actual infringing uses would not be enough here to subject a distributor to liability"
- Checked: 2026-11-13

#### [M-0562] VERIFIED
- Claim: Grokster (2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for third-party infringement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919 (syllabus Held; opinion at 936-937)
- Quote: "one who distributes a device with the object of promoting its use to infringe copyright, as shown by clear expression or other"
- Checked: 2026-11-13

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0561] VERIFIED
- Claim: Sony v. Universal: the VTR was capable of substantial noninfringing uses both because many copyright holders would not object to time-shifting and because unauthorised private, noncommercial home time-shifting of broadcast television was fair use.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 442-456)
- Quote: "even the unauthorized home timeshifting of respondents' programs is legitimate fair use"
- Checked: 2026-11-13

#### [M-0001] VERIFIED
- Claim: The Supreme Court decided Cox Communications v. Sony Music (No. 24-171) on March 25, 2026, reversing and remanding; contributory liability needs intent shown by inducement or a service tailored to infringement.
- Jurisdiction: case-law
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: Syllabus, Held (decided March 25, 2026; judgment 93 F.4th 222 reversed and remanded)
- Quote: "contributorily liable for a user's infringement only if it intended that the provided service be used for infringement, which can be shown only if the party induced the infringement or the provided service is tailored to that infringement"
- Checked: 2026-11-10

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0222] VERIFIED
- Claim: Cox (2026): mere knowledge that a service will be used to infringe is insufficient to establish the required intent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part II.B
- Quote: "mere knowledge that a service will be used to infringe is insufficient to establish the required intent to infringe."
- Checked: 2026-11-10

#### [M-0224] VERIFIED
- Claim: Cox (2026): the Fourth Circuit's knowledge-plus-insufficient-action rule went beyond the two recognised bases and conflicted with the Court's precedent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part III
- Quote: "contributory liability cannot rest only on a provider’s knowledge of infringement and insufficient action to prevent it."
- Checked: 2026-11-10

#### [M-0225] VERIFIED
- Claim: Cox (2026): Justice Sotomayor, concurring in the judgment, said other common-law theories such as aiding and abetting could apply in copyright.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Sotomayor concurrence
- Quote: "precedents have left open the possibility that other common-law theories of such liability, like aiding and abetting, could apply in the copyright context."
- Checked: 2026-11-10

#### [M-0564] UNVERIFIED (unverified)
- Claim: Analysis: a stem-splitting or mixing tool maker whose marketing or onboarding steers users to split and mix commercial songs they do not own is exposed to Grokster inducement through its own statements and design, not through the tool's capability alone.
- Jurisdiction: analysis
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919
- Quote: "going beyond mere distribution with knowledge of third-party action"
- Checked: 2026-11-13

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0296] VERIFIED
- Claim: Sound recording owners have only the 106(1), (2), (3) and (6) rights and no general public performance right under 106(4).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(a)
- Quote: "The exclusive rights of the owner of copyright in a sound recording are limited to the rights specified by clauses (1), (2), (3) and (6) of section 106, and do not include any right of performance under section 106(4)"
- Checked: 2026-11-10

#### [M-0569] VERIFIED
- Claim: A compilation is a work formed by collecting and assembling preexisting materials selected, coordinated or arranged so the whole is an original work of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'compilation'
- Quote: "selected, coordinated, or arranged in such a way that the resulting work as a whole constitutes an original work of authorship"
- Checked: 2026-11-13

#### [M-0521] VERIFIED
- Claim: A derivative work is one based on preexisting works; the statute's examples include a musical arrangement and a sound recording, and 'any other form in which a work may be recast, transformed, or adapted'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'derivative work'
- Quote: "any other form in which a work may be recast, transformed, or adapted"
- Checked: 2026-11-13

#### [M-0554] VERIFIED
- Claim: 2016 Commerce white paper: remixes include mashups and sampling, and in many cases they will be derivative works, compilations or collective works under the Copyright Act.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 7
- Quote: "In many cases, these remixes will constitute derivative works, compilations, or collective works, as defined in the Copyright Act"
- Checked: 2026-11-13

#### [M-0529] VERIFIED
- Claim: Copyright in a derivative work or compilation covers only the new material the author contributed and gives no exclusive right in the preexisting material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(b)
- Quote: "The copyright in a compilation or derivative work extends only to the material contributed by the author of such work"
- Checked: 2026-11-13

#### [M-0528] VERIFIED
- Claim: Under Section 103(a), protection for a work employing preexisting copyrighted material does not extend to any part of the work in which the material has been used unlawfully.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(a)
- Quote: "protection for a work employing preexisting material in which copyright subsists does not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0572] VERIFIED
- Claim: The Audio Home Recording Act bars infringement actions based on the manufacture, importation or distribution of a digital audio recording device, digital audio recording medium, analog recording device or analog recording medium, or on a consumer's noncommercial use of such a device or medium for making digital or analog musical recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1008 Prohibition on certain infringement actions (https://www.law.cornell.edu/uscode/text/17/1008), source id usc17-1008
- Pinpoint: 17 U.S.C. 1008
- Quote: "based on the noncommercial use by a consumer of such a device or medium for making digital musical recordings or analog musical recordings"
- Checked: 2026-11-13

#### [M-0573] VERIFIED
- Claim: The Act's digital audio recording device definition turns on a device whose digital recording function is designed or marketed for the primary purpose of making a digital audio copied recording for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1001 Definitions (Audio Home Recording) (https://www.law.cornell.edu/uscode/text/17/1001), source id usc17-1001
- Pinpoint: 17 U.S.C. 1001(3)
- Quote: "designed or marketed for the primary purpose of, and that is capable of, making a digital audio copied recording for private use"
- Checked: 2026-11-13

#### [M-0574] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): the Rio player was not a digital audio recording device because it copies only from a computer hard drive, not from transmissions or digital musical recordings.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, end of Part IV
- Quote: "Because the Rio cannot make copies from transmissions, but instead, can only make copies from a computer hard drive, it is not a digital audio recording device."
- Checked: 2026-11-13

#### [M-0575] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): a computer hard drive is excluded from the Act's definition of a digital music recording, so the Rio, which copies from a hard drive, does not record directly from a digital music recording.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "a hard drive is a material object in which one or more programs are fixed; thus, a hard drive is excluded from the definition of digital music recordings"
- Checked: 2026-11-13

#### [M-0576] VERIFIED
- Claim: RIAA v. Diamond describes the Act's purpose as the consumer right to make recordings of copyrighted music for private, noncommercial use, quoting the Senate Report.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "The purpose of the Act is to ensure the right of consumers to make analog or digital audio recordings of copyrighted music for their private, noncommercial use"
- Checked: 2026-11-13

#### [M-0577] VERIFIED
- Claim: 17 U.S.C. 117(a) lets the owner of a copy of a computer program make or authorise another copy or adaptation of that program on stated conditions (an essential step in using it with a machine, or archival purposes); its text names only computer programs.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 117 Computer programs (https://www.law.cornell.edu/uscode/text/17/117), source id usc17-117
- Pinpoint: 17 U.S.C. 117(a)
- Quote: "it is not an infringement for the owner of a copy of a computer program to make or authorize the making of another copy or adaptation of that computer program"
- Checked: 2026-11-13

#### [M-0114] VERIFIED
- Claim: 17 U.S.C. 114(d)(2) subjects subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite digital audio radio service transmissions to statutory licensing if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)
- Quote: "a subscription digital audio transmission not exempt under paragraph (1), an eligible nonsubscription transmission, or a transmission not exempt under paragraph (1) that is made by a preexisting satellite digital audio radio service shall be subject to statutory licensing"
- Checked: 2026-11-10

#### [M-0298] VERIFIED
- Claim: The 114 statutory licence reaches subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite DARS transmissions, and the transmission must not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service"
- Checked: 2026-11-10

#### [M-0113] VERIFIED
- Claim: Under 17 U.S.C. 114(j)(7), an interactive service is one that lets a member of the public receive on request a transmission of a particular sound recording selected by or for the recipient.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0299] VERIFIED
- Claim: An interactive service is one that lets a member of the public receive a program made for the recipient or, on request, a particular sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0585] VERIFIED
- Claim: A service is not interactive just because users can request recordings for the public at large, unless the channel programming substantially consists of recordings performed within 1 hour of the request or at a designated time.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "The ability of individuals to request that particular sound recordings be performed for reception by the public at large"
- Checked: 2026-11-13

#### [M-0580] VERIFIED
- Claim: Under the statutory licence the transmission may not exceed the sound recording performance complement, and the service may not publish an advance schedule of the specific recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(i)-(ii)
- Quote: "the transmitting entity does not cause to be published, or induce or facilitate the publication, by means of an advance program schedule or prior announcement, the titles of the specific sound recordings to be transmitted"
- Checked: 2026-11-13

#### [M-0581] VERIFIED
- Claim: The sound recording performance complement allows, in any 3-hour period on a channel, no more than 3 different selections from any one phonorecord (no more than 2 consecutively), or 4 different selections by the same featured artist or from any set or compilation of phonorecords (no more than 3 consecutively).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(13)
- Quote: "3 different selections of sound recordings from any one phonorecord lawfully distributed for public performance or sale in the United States, if no more than 2 such selections are transmitted consecutively"
- Checked: 2026-11-13

#### [M-0582] VERIFIED
- Claim: The statutory licence requires the service to take no affirmative steps to cause or induce the recipient to make a phonorecord, so a download button on mixes is outside it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vi)
- Quote: "the transmitting entity takes no affirmative steps to cause or induce the making of a phonorecord by the transmission recipient"
- Checked: 2026-11-13

#### [M-0583] VERIFIED
- Claim: The statutory licence requires the transmission to be made from a phonorecord lawfully made under the copyright owner's authority.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vii)
- Quote: "the transmitting entity makes the transmission from a phonorecord lawfully made under the authority of the copyright owner"
- Checked: 2026-11-13

#### [M-0584] VERIFIED
- Claim: The statutory licence requires the service to identify the title, record and featured artist in text while the recording plays.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(ix)
- Quote: "the transmitting entity identifies in textual data the sound recording during, but not before, the time it is performed"
- Checked: 2026-11-13

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0297] VERIFIED
- Claim: A digital audio transmission is a digital transmission that embodies a sound recording and does not include transmission of any audiovisual work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "A digital audio transmission is a digital transmission as defined in section 101, that embodies the transmission of a sound recording. This term does not include the transmission of any audiovisual work"
- Checked: 2026-11-10

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0587] VERIFIED
- Claim: Mixcloud says it was the first streaming service to clear the copyrights for radio shows and mixes.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud was the first streaming service to clear the copyrights for radio shows and mixes"
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0592] VERIFIED
- Claim: Apple Music (Nov 16, 2021 artist notice) says it developed a process to identify and compensate the individual creators in DJ mixes.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple has developed a new process to identify and fairly compensate all of the individual creators featured in thousands of DJ mixes"
- Checked: 2026-11-13

#### [M-0590] VERIFIED
- Claim: Mixcloud describes its live product as a licensed live streaming platform that also archives the stream as a recording.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud Live is the world's first music-focused, licensed live streaming platform."
- Checked: 2026-11-13

#### [M-0591] VERIFIED
- Claim: Mixcloud says that on a platform that has not cleared the music, rights holders can have a mix taken down and the mix muted.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'What is a DMCA takedown'
- Quote: "the copyright holders can ask for it to be taken down, and your mixes, shows or audio will be muted"
- Checked: 2026-11-13

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0216] VERIFIED
- Claim: Statutory damages are assessed per work for all infringements involved in the action; the owner may elect them any time before final judgment.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "an award of statutory damages for all infringements involved in the action, with respect to any one"
- Checked: 2026-11-10
