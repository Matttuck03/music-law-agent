# Music law knowledge pack: Remix platform, part 1
- File: 07-remix-platform-part1.md, part of the music law knowledge pack (remix edition).
- Contains: M24 Licensed platform models, distributor rules and stem model licences; M25 DJ-mix platform application, feature by feature; playbook Questions for a licensed music attorney. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: 2026-11-13.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## M24 Licensed platform models, distributor rules and stem model licences
- Law last checked: 2026-11-13. Volatility: high.
- Use for questions like: How do licensed mix platforms clear the music; Will a distributor take a remix or a cover; Can we use an open source stem splitter in a paid product; Is a code licence the same as a licence for the model weights; What does it mean when a model page says nothing about a licence; Which licences would a mix platform need to sign

### Bottom line
- The mix services in the saved set that describe themselves as licensed say they run on licences for both the songs and the recordings of every track, backed by direct deals with labels (company statements, captured 2026-11-13) [M-0586, M-0589, M-0593]. No saved source shows a mix platform running on commercial tracks without such deals.
- Distributors treat a cover and a remix differently. The saved pages offer a route for covers and say sample-based or derivative works cannot use it [M-0596, M-0597, M-0599].
- A stem splitter has two licences to check: one for the code and one for the trained model weights. An MIT licence on the code is not a licence for the weights [M-0600, M-0603]. Where a project says nothing about its weights, that is silence, not a grant [M-0604, M-0607].
- Of the stem models checked on 2026-11-13, none has weights with a stated licence that clearly allows commercial use. One is stated non-commercial [M-0606]. One maintainer says the weights are for personal or research use [M-0603]. The rest are silent [M-0604, M-0607, M-0609, M-0610].

### Rules
- Mixcloud (platform terms: company blog, not terms of service and not law; blog dated 2024-03-28, page path after redirect dated 2025-01-01, captured 2026-11-13): a streaming service must hold licences that clear both the composition and the sound recording of every track in a stream [M-0586]. It says it was the first streaming service to clear the copyrights for radio shows and mixes [M-0587].
- Mixcloud (same blog, same capture date): its checklist for choosing a platform asks whether the platform has direct deals with the labels whose music is played [M-0589]. It says downloading needs an additional licensed right, which it calls the mechanical right [M-0588]. That is the company's short version, not a statement of US law.
- Mixcloud (same blog, same capture date): it describes its live product as a licensed live streaming platform that also archives the stream [M-0590]. On a platform that has not cleared the music, rights holders can have a mix taken down or muted [M-0591].
- Apple Music (platform terms: company notice to artists dated 2021-11-16, captured 2026-11-13): it says it built a process to identify and compensate the individual creators in DJ mixes [M-0592]. It says it works with major and independent labels and pays rights holders within DJ mixes directly [M-0593].
- A large on-demand service's public filing (industry practice, Spotify annual report for fiscal year 2025): in the US, mechanical rights for audio-only use run through the section 115 compulsory licence, with a blanket licence run by the Mechanical Licensing Collective [M-0086]. Public performance rights for compositions come through the performing rights organisations ASCAP, BMI, GMR and SESAC under blanket licences [M-0088].
- US federal, 17 U.S.C. 114: the statutory licence for recordings is closed to interactive services [M-0115] and to archived programs under 5 hours [M-0578]. An interactive service also needs a licence for each song [M-0301]. So an on-demand mix library has to get its master rights by direct deal (analysis).
- US federal (court order, ASCAP consent decree): ASCAP may hold and license only non-exclusive public performance rights [M-0256]. It cannot grant sync rights (analysis row) [M-0311]. The decrees bind only ASCAP and BMI [M-0278]. An ASCAP licence therefore does not cover copying, remixing or video (analysis) [M-0183]. The base has no saved text on the scope of the other organisations' licences.
- CD Baby (platform terms, help page, web archive copy dated 2026-02-16, captured 2026-11-13): a cover release needs a mechanical licence for digital downloads. That licence covers the composition, not the original recording [M-0596]. Derivative works such as samples cannot be cleared through its cover song process [M-0597]. Even a streaming-only release of a cover needs at least a digital download licence under its rules [M-0598].
- CD Baby (platform terms, artist education article, live page, undated, captured 2026-11-13): using a sample of a recording means clearing the master with the label and the composition with the publisher. There is no standard rate, and the deal is negotiated directly [M-0599].
- TuneCore (platform terms, help page, web archive copy dated 2020-05-07, captured 2026-11-13, possibly stale): a cover may need permission and possibly a licence from the original copyright holder [M-0594]. Some stores did not accept soundalike covers, and content hidden by a store was not reversed or refunded [M-0595].
- Demucs (industry, checked 2026-11-13): the code licence file is MIT and says nothing about model weights [M-0600]. The project README says the licence of the weights is "not clear" because the training set includes research-only data [M-0601]. A maintainer says he cannot grant a licence for the weights [M-0602]. A maintainer comment dated 2022-09-29 says the code is free for commercial use under MIT, while the weights are research artefacts for personal or research usage [M-0603].
- Spleeter (industry, checked 2026-11-13): the code is MIT. The README is silent on a licence for the pretrained models: silence, not a grant [M-0604]. Its disclaimer tells users to get authorisation from right owners before using it on copyrighted material [M-0605].
- Open-Unmix (industry, checked 2026-11-13): the umxl weights are licensed CC BY-NC-SA 4.0, which is non-commercial [M-0606]. The umx and umxhq models were trained on the MUSDB18-HQ set, and no weights licence is stated for them: silence, not a grant [M-0607].
- python-audio-separator and the UVR models (industry, checked 2026-11-13): the tool's code is MIT, and it asks users to credit the UVR models. It gives no licence for the model files [M-0608]. Its default BS-Roformer checkpoint and its Mel-Band Roformer checkpoint are listed with no licence [M-0609, M-0610]. A separate BS-RoFormer code project is MIT and is silent on checkpoints [M-0611].
- UVR (industry, checked 2026-11-13): the developers say they trained all the models in the package except the Demucs v3 and v4 4-stem models [M-0612]. The README asks for credit under MIT and has no separate licence text for the models [M-0613].
- Training data (industry, checked 2026-11-13): the MUSDB18 set includes 46 tracks from MedleyDB that are licensed CC BY-NC-SA 4.0 [M-0614]. The dataset page does not state terms for the DSD100 tracks [M-0615].

### Platform application
- Model 1, direct deals for a mix library. The platform signs master licences with labels and distributors, and song licences with publishers and performing rights organisations. Every saved statement from a lawful mix service points to this model [M-0586, M-0589, M-0593]. It is slow and costly, and labels can say no (analysis).
- Model 2, partner with a service that already holds the licences. Mixes are published and streamed only inside the partner. The platform would rely on the partner's licences and terms. The base has only the partner's own public statements, not its contract terms [M-0586, M-0590]. Whether a partner's licences reach mixes made with split stems is unknown (gap).
- Model 3, radio-style streaming under the 114 statutory licence, plus performing rights licences for the songs. It works only for non-interactive listening with the programming limits in card M23 [M-0115, M-0578]. It does not fit saved mixes that users pick and play.
- Model 4, a licensed catalogue. Users mix only tracks or stems the platform has licensed for remixing. This removes the "any music" problem but needs remix-grade grants from owners, which are derivative work grants [M-0522]. The base has no saved terms from stem catalogue or sample pack services (gap).
- Sending user work to stores through a distributor. Covers have a path [M-0596]. Mixes and mashups built from original audio do not go through the cover path and need the master and the composition cleared one by one [M-0597, M-0599].
- Picking a stem model. Treat the code and the weights as two separate licence checks (analysis) [M-0600, M-0603]. For a paid product, do not ship weights that are stated non-commercial [M-0606] or stated research-only [M-0603]. Do not ship weights whose licence is silent without a written grant from whoever can give one [M-0604, M-0609, M-0610].
- Why the weights are a problem at the root: public stem models are commonly trained on a research set that includes non-commercial tracks [M-0614, M-0601]. Whether that limit carries over to trained weights is a legal question the base does not answer (unsettled).
- Clean options for the stem engine (analysis): train on audio the platform owns or has licensed for training, license a commercial stem engine under a written contract, or get a written commercial grant from a model's owner. The base has no saved terms for commercial stem engines (gap).
- A model's licence and the music's copyright are separate questions. A clean model licence does not make it lawful to split a song the user has no rights in [M-0605, M-0110].
- Risk carriers: the platform for the model it ships and for any deal it signs; the user for what goes to stores under the user's name; model owners and dataset owners as possible claimants on the weights; labels and publishers on the music.

### Gotchas
- "The repo is MIT, so we can sell it" is wrong for the weights. The Demucs maintainers say so in terms [M-0603].
- "It does not say we cannot" is not permission. Silence is not a grant [M-0604, M-0607].
- A credit request is not a licence. The UVR pages ask for credit and give no model licence text [M-0608, M-0613].
- The Mixcloud and Apple rows are public statements by the companies about themselves. They do not show the deal terms, the price, or whether stem-based mixes are covered.
- Mixcloud's line that downloads need "the mechanical right" is a simplification. In US law a download of a mix also copies and distributes the recordings (analysis) [M-0108].
- The TuneCore page is a 2020 archive copy. The CD Baby help page is an archive copy dated 2026-02-16. Service terms change. Re-capture before relying on them.
- Not captured: SoundCloud, DistroKid, Beatport, Beatsource, Splice, BandLab, Twitch, YouTube and Instagram terms. The base makes no claim about them.
- Model licences can change with a commit. All stem model rows were checked 2026-11-13. Pin the exact version checked.

### Open questions for counsel
- Which licences does an on-demand mix library need in the US, and from whom: labels, distributors, publishers, the Mechanical Licensing Collective, each performing rights organisation?
- If mixes are published only through a licensed partner service, what must the partner contract say for the platform to rely on its licences, and do those licences cover stem-based blends?
- Does a non-commercial or research-only limit on training data carry over to the trained weights, and who could enforce it?
- Who can grant a commercial licence for weights when the maintainer says he cannot?
- If the platform trains its own stem model, what rights does it need in the training audio? See card M15 for the open AI training questions.
- Can the platform pass distributor rules on to users in its own terms, and what should it check before sending a user's cover to stores?

### Sources
- terms-mixcloud-livestream: Mixcloud blog on live streaming music, captured 2026-11-13 (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues)
- terms-apple-dj-mixes: Apple Music for Artists notice on DJ mixes, 2021-11-16, captured 2026-11-13 (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators)
- sec-spotify-20f-fy2025: Spotify Form 20-F for fiscal year 2025 (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm)
- doj-ascap-afj2-2001: United States v. ASCAP, Second Amended Final Judgment (https://www.justice.gov/opa/file/850776/dl)
- usc17-114: 17 U.S.C. 114 sound recordings and the statutory licence (https://www.law.cornell.edu/uscode/text/17/114)
- terms-cdbaby-covers: CD Baby help, cover songs, web archive copy 2026-02-16 (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby)
- terms-cdbaby-licensing-covers: CD Baby article on licensing cover songs, captured 2026-11-13 (https://diymusician.cdbaby.com/music-rights/licensing-cover-songs/)
- terms-tunecore-covers: TuneCore help, cover songs, web archive copy 2020-05-07 (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-)
- demucs-license: Demucs LICENSE file (https://raw.githubusercontent.com/adefossez/demucs/main/LICENSE)
- demucs-readme: Demucs README (https://raw.githubusercontent.com/adefossez/demucs/main/README.md)
- demucs-issue-384: Demucs issue 384 on commercial use (https://github.com/facebookresearch/demucs/issues/384)
- spleeter-readme: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md)
- openunmix-readme: Open-Unmix README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md)
- audiosep-readme: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md)
- uvr-readme: Ultimate Vocal Remover README (https://raw.githubusercontent.com/Anjok07/ultimatevocalremovergui/master/README.md)
- lucidrains-bsroformer-license: BS-RoFormer LICENSE file (https://raw.githubusercontent.com/lucidrains/BS-RoFormer/main/LICENSE)
- musdb18-sigsep: MUSDB18 dataset page (https://sigsep.github.io/datasets/musdb.html)

### Claims cited in M24
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0596] VERIFIED
- Claim: CD Baby says a cover release needs a mechanical licence for digital downloads, which covers the composition but not the original recording.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Can I release a cover song
- Quote: "This license grants you the right to reproduce and distribute the song's composition (lyrics and melody), but not the original recording."
- Checked: 2026-11-13

#### [M-0597] VERIFIED
- Claim: CD Baby says derivative works such as samples cannot be cleared through its cover song licensing process.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Things to note
- Quote: "Derivative works, such as samples, cannot be cleared through the cover song licensing process."
- Checked: 2026-11-13

#### [M-0599] VERIFIED
- Claim: CD Baby's artist-education site says a sample of a recording means clearing both the master with the label and the composition with the publisher, with no standard rate and direct negotiation.
- Jurisdiction: platform-terms
- Source: CD Baby DIY Musician: licensing cover songs (https://diymusician.cdbaby.com/music-rights/licensing-cover-songs/), source id terms-cdbaby-licensing-covers
- Pinpoint: CD Baby DIY Musician: Use a Sample
- Quote: "Since you are creating a derivative work, this is an area that requires negotiating as there is no standard rate and will require direct contact with all parties."
- Checked: 2026-11-13

#### [M-0600] VERIFIED
- Claim: Demucs repository code licence: MIT, which grants rights to use, copy, modify, publish, distribute, sublicense and sell the software (code only; the file says nothing about trained weights).
- Jurisdiction: industry
- Source: Demucs repository LICENSE (MIT) (https://raw.githubusercontent.com/adefossez/demucs/main/LICENSE), source id demucs-license
- Pinpoint: LICENSE, MIT grant
- Quote: "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software"
- Checked: 2026-11-13

#### [M-0603] VERIFIED
- Claim: Demucs maintainer in issue 384 (2022-09-29): the code is free for commercial use under MIT, but the weights are research artefacts provided only for personal or research usage.
- Jurisdiction: industry
- Source: facebookresearch/demucs issue 384 Legality of publishing audio output (maintainer comment) (https://github.com/facebookresearch/demucs/issues/384), source id demucs-issue-384
- Pinpoint: Issue 384, comment by adefossez 2022-09-29
- Quote: "The weights themselves are however just a research artefacts and provided only for personal / research usage."
- Checked: 2026-11-13

#### [M-0604] VERIFIED
- Claim: Spleeter README: the code of Spleeter is MIT licensed. The License section states nothing separate about the pretrained model weights (silence, not a grant).
- Jurisdiction: industry
- Source: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md), source id spleeter-readme
- Pinpoint: README, License section
- Quote: "The code of Spleeter is MIT-licensed."
- Checked: 2026-11-13

#### [M-0607] VERIFIED
- Claim: Open-Unmix README: the umxhq weights were trained on MUSDB18-HQ. The README states no weights licence for umx or umxhq, which is silence and not a grant.
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxhq
- Quote: "which comprises the same tracks as in MUSDB18 but un-compressed which yield in a full bandwidth of 22050 Hz."
- Checked: 2026-11-13

#### [M-0606] VERIFIED
- Claim: Open-Unmix README: the default umxl weights are licensed for non-commercial use only (CC BY-NC-SA 4.0).
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxl
- Quote: "Note, that the weights are only licensed for non-commercial use (CC BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0609] VERIFIED
- Claim: python-audio-separator README: the default model is a BS-Roformer checkpoint file (model_bs_roformer_ep_317_sdr_12.9755), described as BS-Roformer-Viperx-1297; the README gives no licence for that checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, CLI options and supported model list
- Quote: "default: model_bs_roformer_ep_317_sdr_12.9755.yaml"
- Checked: 2026-11-13

#### [M-0610] VERIFIED
- Claim: python-audio-separator README lists a Mel-Band Roformer vocals checkpoint credited to Kimberley Jensen, with no licence stated for the checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, supported model list
- Quote: "vocals_mel_band_roformer.ckpt MDXC vocals* (12.6), other Roformer Model: MelBand Roformer | Vocals by Kimberley Jensen"
- Checked: 2026-11-13

#### [M-0587] VERIFIED
- Claim: Mixcloud says it was the first streaming service to clear the copyrights for radio shows and mixes.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud was the first streaming service to clear the copyrights for radio shows and mixes"
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0590] VERIFIED
- Claim: Mixcloud describes its live product as a licensed live streaming platform that also archives the stream as a recording.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud Live is the world's first music-focused, licensed live streaming platform."
- Checked: 2026-11-13

#### [M-0591] VERIFIED
- Claim: Mixcloud says that on a platform that has not cleared the music, rights holders can have a mix taken down and the mix muted.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'What is a DMCA takedown'
- Quote: "the copyright holders can ask for it to be taken down, and your mixes, shows or audio will be muted"
- Checked: 2026-11-13

#### [M-0592] VERIFIED
- Claim: Apple Music (Nov 16, 2021 artist notice) says it developed a process to identify and compensate the individual creators in DJ mixes.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple has developed a new process to identify and fairly compensate all of the individual creators featured in thousands of DJ mixes"
- Checked: 2026-11-13

#### [M-0086] VERIFIED
- Claim: For compositions Spotify generally obtains mechanical, public performance and lyric rights; for audio-only use in the US the mechanical rights run through the Section 115 compulsory licence, with a blanket licence administered by the MLC since January 2021.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Musical Composition License Agreements
- Quote: "With respect to musical compositions, we generally obtain licenses for mechanical rights, public performance rights, and lyric rights. With respect to mechanical rights for audio-only"
- Checked: 2026-11-10

#### [M-0088] VERIFIED
- Claim: In the US public performance rights for compositions come through PROs (ASCAP, BMI, GMR, SESAC) under blanket licences, with usage reporting duties and one to four year terms.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "In the United States, public performance rights are generally obtained through intermediaries known as performing rights organizations (“PROs”), which negotiate blanket licenses with copyright users for the public performance of"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0256] VERIFIED
- Claim: The ASCAP Second Amended Final Judgment bars ASCAP from licensing any rights in musical compositions other than public performance rights, and only on a non-exclusive basis.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(A)
- Quote: "Holding, acquiring, licensing, enforcing, or negotiating concerning any foreign or domestic rights in copyrighted musical compositions other than rights of public performance on a non-exclusive basis"
- Checked: 2026-11-10

#### [M-0311] VERIFIED
- Claim: Analysis: AFJ2 Sec. IV(A) enjoins ASCAP from licensing rights in musical compositions other than non-exclusive public performance rights, so ASCAP cannot grant sync rights; master rights are not compositions at all, so a platform would still need publisher sync and label master licences (inference; BMI, SESAC and GMR scope not shown by saved text).
- Jurisdiction: analysis
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(A)
- Quote: "Holding, acquiring, licensing, enforcing, or negotiating concerning any foreign or domestic rights in copyrighted musical compositions other than rights of public performance on a non-exclusive basis"
- Checked: 2026-11-10

#### [M-0278] VERIFIED
- Claim: DOJ's Jan. 15, 2021 statement closing its review observes that the ASCAP and BMI decrees regulate only those two PROs, leaving other PROs free of the same constraints.
- Jurisdiction: regulator
- Source: DOJ Antitrust Division, Statement on the Closing of the Review of the ASCAP and BMI Consent Decrees, remarks of AAG Makan Delrahim (January 15, 2021) (https://www.justice.gov/atr/page/file/1355391/dl), source id doj-ascap-bmi-closing-2021
- Pinpoint: DOJ statement Jan. 15, 2021
- Quote: "the decrees regulate only ASCAP and BMI, leaving other PROs free to operate without the same constraints"
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0598] VERIFIED
- Claim: CD Baby says that even for streaming-only intent it still requires at least a digital download licence to distribute a cover.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: streaming sites
- Quote: "you still need to purchase at least a digital download license to distribute your cover song through CD Baby"
- Checked: 2026-11-13

#### [M-0594] VERIFIED
- Claim: TuneCore (help page, Wayback capture of 7 May 2020) says a cover may need permission and possibly a licence from the original copyright holder before release.
- Jurisdiction: platform-terms
- Source: TuneCore help: cover songs (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-), source id terms-tunecore-covers
- Pinpoint: TuneCore help: Can I distribute a cover song
- Quote: "you may need to first get permission (and possibly a license) from the original copyright holder to release your song digitally"
- Checked: 2026-11-13

#### [M-0595] VERIFIED
- Claim: TuneCore (2020 capture) says iTunes, Amazon Music and Rhapsody do not accept soundalike covers and that hidden content cannot be reversed or refunded.
- Jurisdiction: platform-terms
- Source: TuneCore help: cover songs (https://web.archive.org/web/2026/https://support.tunecore.com/hc/en-us/articles/115006695208-Can-I-distribute-a-cover-song-through-TuneCore-), source id terms-tunecore-covers
- Pinpoint: TuneCore help: Important
- Quote: "iTunes, Amazon Music, and Rhapsody do not accept soundalike cover songs"
- Checked: 2026-11-13

#### [M-0601] VERIFIED
- Claim: Demucs README: the maintainer says the licence of the trained weights is not clear because MUSDB contains some data usable only for research.
- Jurisdiction: industry
- Source: Demucs repository README (https://raw.githubusercontent.com/adefossez/demucs/main/README.md), source id demucs-readme
- Pinpoint: README, License section
- Quote: "The license of the weights is not clear: MusDB contains some data that were only usable for research purpose."
- Checked: 2026-11-13

#### [M-0602] VERIFIED
- Claim: Demucs README: the maintainer says he cannot grant a licence for the weights, whether the data came from Meta custom data or from the original MUSDB data.
- Jurisdiction: industry
- Source: Demucs repository README (https://raw.githubusercontent.com/adefossez/demucs/main/README.md), source id demucs-readme
- Pinpoint: README, License section
- Quote: "I sadly cannot help granting a license, both coming from Meta custom data, or from the original MusDB data."
- Checked: 2026-11-13

#### [M-0605] VERIFIED
- Claim: Spleeter README disclaimer: a user who plans to use Spleeter on copyrighted material should make sure to get proper authorization from right owners beforehand.
- Jurisdiction: industry
- Source: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md), source id spleeter-readme
- Pinpoint: README, Disclaimer
- Quote: "If you plan to use Spleeter on copyrighted material, make sure you get proper authorization from right owners beforehand."
- Checked: 2026-11-13

#### [M-0608] VERIFIED
- Claim: python-audio-separator README: the project is MIT licensed, and users of its default or any UVR-trained model are asked to credit UVR and its developers; it states no separate licence for model files.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, License
- Quote: "please honor the MIT license by providing credit to UVR and its developers!"
- Checked: 2026-11-13

#### [M-0611] VERIFIED
- Claim: lucidrains BS-RoFormer repository LICENSE is MIT (Copyright (c) 2023 Phil Wang); the file covers the repository code and does not mention checkpoints trained by others.
- Jurisdiction: industry
- Source: lucidrains BS-RoFormer LICENSE (https://raw.githubusercontent.com/lucidrains/BS-RoFormer/main/LICENSE), source id lucidrains-bsroformer-license
- Pinpoint: LICENSE, MIT grant
- Quote: "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software"
- Checked: 2026-11-13

#### [M-0612] VERIFIED
- Claim: Ultimate Vocal Remover README: its core developers trained all models in the package except the Demucs v3 and v4 4-stem models.
- Jurisdiction: industry
- Source: Ultimate Vocal Remover GUI README (https://raw.githubusercontent.com/Anjok07/ultimatevocalremovergui/master/README.md), source id uvr-readme
- Pinpoint: README, intro
- Quote: "UVR's core developers trained all of the models provided in this package (except for the Demucs v3 and v4 4-stem models)."
- Checked: 2026-11-13

#### [M-0613] VERIFIED
- Claim: Ultimate Vocal Remover README asks third-party developers using its models to honor the MIT license by crediting UVR and its developers; no separate model licence text is given.
- Jurisdiction: industry
- Source: Ultimate Vocal Remover GUI README (https://raw.githubusercontent.com/Anjok07/ultimatevocalremovergui/master/README.md), source id uvr-readme
- Pinpoint: README, License
- Quote: "For all third-party application developers who wish to use our models, please honor the MIT license by providing credit to UVR and its developers."
- Checked: 2026-11-13

#### [M-0614] VERIFIED
- Claim: MUSDB18 includes 46 tracks from MedleyDB licensed under Creative Commons BY-NC-SA 4.0 (non-commercial, share-alike).
- Jurisdiction: industry
- Source: SigSep MUSDB18 dataset page (https://sigsep.github.io/datasets/musdb.html), source id musdb18-sigsep
- Pinpoint: MUSDB18 dataset page, composition list
- Quote: "46 tracks are taken from the MedleyDB (opens new window) licensed under Creative Commons (BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0615] VERIFIED
- Claim: MUSDB18 sends users to the original source for rights on its 100 DSD100 tracks, so the page itself does not state those terms.
- Jurisdiction: industry
- Source: SigSep MUSDB18 dataset page (https://sigsep.github.io/datasets/musdb.html), source id musdb18-sigsep
- Pinpoint: MUSDB18 dataset page, composition list
- Quote: "Please refer to this original resource for any question regarding your rights on your use of the DSD100 data."
- Checked: 2026-11-13

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

## M25 DJ-mix platform application, feature by feature
- Law last checked: 2026-11-13. Volatility: high.
- Use for questions like: Which features of a mixing app need licences; Is private mixing on my own device lower risk than sharing; What happens when users upload commercial tracks; Can users export or download their mixes; Does charging money change the legal risk; Do Canada, Australia, the UK or the EU treat user remixes differently

### Bottom line
- Risk rises in steps: mixing on the user's own device, then saving, then storing on the platform's servers, then sharing with the public, then downloads and paid features. Each step adds rights that need a licence and moves more of the risk from the user to the platform (analysis from the rows below).
- Nothing in the base makes any step fully safe with unlicensed commercial tracks. Private, on-device mixing is the lowest step, but whether it is lawful is unsettled, not cleared [M-0110, M-0575].
- Public sharing of mixes of commercial tracks needs licences for both the songs and the recordings [M-0301, M-0106, M-0107]. The statutory webcasting licence does not cover saved or on-demand mixes [M-0115, M-0578].
- Country rules differ sharply. Canada has a non-commercial user content exception for individuals [M-0616]. The UK and EU have narrow parody and pastiche exceptions [M-0240, M-0631]. Australia's saved sections cover parody or satire only [M-0622]. None of them is a general licence for a mix platform.

### Rules
- US federal: each track is two works, a song and a recording [M-0025]. Both carry a reproduction right [M-0108]. Each owner controls derivative works [M-0522]. For recordings that reaches works where the actual sounds are rearranged, remixed or altered [M-0523].
- US federal: songs carry a public performance right [M-0106]. Recordings carry one only for digital audio transmissions [M-0107]. Anyone who violates an exclusive right is an infringer [M-0220].
- US federal, tool maker tests: a product capable of substantial lawful uses is not contributory infringement by itself (court decision, Sony) [M-0560]. Promoting infringing use by clear words or affirmative steps creates liability (court decision, Grokster) [M-0562]. Contributory liability needs intent, shown by inducement or a service tailored to infringement (court decision, Cox v. Sony, 2026) [M-0221, M-0223].
- US federal, hosting: the 512(c) safe harbor covers storage at the direction of a user [M-0343], on conditions: no actual or red flag knowledge [M-0344, M-0345], fast removal [M-0346, M-0348], no direct financial benefit from infringement the provider can control [M-0347], a designated agent [M-0349], and a repeat infringer policy [M-0357]. The safe harbor is not conditioned on the provider monitoring its service [M-0358].
- US federal, 114 statutory licence: not for interactive services [M-0115], not for archived programs under 5 hours [M-0578], not for longer archives kept more than 2 weeks [M-0579], and not if the service induces listeners to make copies [M-0582].
- US federal, damages: statutory damages run from $750 to $30,000 per work [M-0215], up to $150,000 per work for willful infringement [M-0217], counted per work and not per view (analysis row) [M-0254]. They depend on timely registration [M-0214].
- Canada (foreign law), Copyright Act s.29.21: an individual may use an existing published work to make a new work, and use or share it, if the use is solely for non-commercial purposes [M-0616], the source is mentioned where reasonable [M-0617], the individual had reasonable grounds to believe the source copy was not infringing [M-0618], and the use has no substantial adverse effect on the market for the original, including that it is not a substitute for it [M-0619].
- Canada (foreign law): s.29.21(2) defines an intermediary as a person or entity who regularly provides space or means for works to be enjoyed by the public [M-0620]. The exception protects the individual's acts. Whether and how far it protects a platform is an inference, not saved text. Fair dealing in s.29 lists research, private study, education, parody and satire [M-0621]. The fairness test is case law and is not in the base. Moral rights (s.28.2) were not captured (gap).
- Australia (foreign law), Copyright Act 1968: fair dealing for parody or satire does not infringe copyright in a work [M-0622] or in an audio-visual item [M-0623], which includes a sound recording [M-0624]. Fair dealing for criticism or review needs sufficient acknowledgement [M-0625]. Authors have a right of integrity against derogatory treatment, which for a musical work includes material alteration or distortion that harms honour or reputation [M-0626]. The base holds no Australian user content exception and makes no claim about other parts of the Act.
- UK (foreign law), CDPA 1988: the owner controls copying, communication to the public and adaptation [M-0234]. Communication to the public covers music and recordings and includes on-demand access [M-0236, M-0237]. Fair dealing for caricature, parody or pastiche does not infringe [M-0240], and a contract cannot override it [M-0241].
- UK (foreign law), moral rights: the author of a musical work has the right not to have it subjected to derogatory treatment [M-0627]. Treatment is derogatory if it distorts or mutilates the work or otherwise harms the author's honour or reputation [M-0628]. Communicating a derogatory treatment to the public infringes the right [M-0629]. The exceptions in ss.81 and 82 were not reviewed.
- EU (court decision, Pelham I, 2019): a recognisable sample may be a quotation only if the use is in dialogue with the sampled work and the other conditions are met [M-0630].
- EU (court press release No 50/26, 14 April 2026, on Pelham II; unofficial summary, judgment text not saved): pastiche covers creations that evoke existing works while being noticeably different, including by sampling, in a recognisable artistic dialogue [M-0631]. The test is whether a person familiar with the work would recognise the pastiche, and intent is not required [M-0632]. Pastiche is not a catch-all and does not cover concealed imitation or plagiarism [M-0633]. Confirm against the judgment before relying.
- EU (foreign law), Copyright Directive 2019/790 Art 17: a content-sharing platform itself communicates user uploads to the public and must get authorisation [M-0387]. The hosting safe harbor does not apply to that act [M-0388]. Without authorisation it must show best efforts to license, to keep identified works unavailable, and to take down and keep down on notice [M-0389, M-0390, M-0391]. Providers under 3 years old with turnover under EUR 10 million have a lighter regime [M-0392]. Users may rely on quotation, parody and pastiche [M-0393]. There is no general monitoring duty [M-0394], and complaints need human review [M-0395].

### Platform application
- Feature 1, mixing privately on the user's own device.
  - What happens: the app plays and blends tracks in real time. Nothing is published.
  - Rights touched: playing music privately is outside the public performance right, which is limited to public performance (analysis) [M-0106]. The open points are the copies made on the way (stems are copies of the actual sounds) [M-0110] and whether a private blend "prepares" a derivative work [M-0522]. No saved case decides either. Unsettled.
  - Shelters that do not clearly apply: the home recording statute is tied to listed devices and media [M-0572], and the Ninth Circuit kept computer hard drives outside it [M-0575]. The Sony fair use finding was about home taping of TV [M-0561].
  - Who carries the risk: mainly the user (analysis). The platform is judged as a tool maker, so its marketing and design matter most [M-0562, M-0223]. Keeping all audio on the device keeps the platform's own servers out of the copying (analysis).
- Feature 2, saving a mix.
  - A saved mix is a fixed copy of every song and recording in it [M-0108], with the sounds rearranged or altered [M-0523].
  - Saved only on the user's device: the user made the copy. Saved to the platform's cloud: the platform now stores it. That can fit "storage at the direction of a user" [M-0343], but only if the 512(c) conditions are met, and counsel must confirm the fit when the platform's own tool rendered the file.
  - Who carries the risk: the user first; the platform once the file sits on its servers.
- Feature 3, sharing a mix publicly on the platform.
  - Needs: licences for the recordings and for the songs [M-0301, M-0106, M-0107]. The 114 statutory licence does not fit an on-demand or saved mix [M-0115, M-0578, M-0579]. The licensed services say they use direct deals [M-0589, M-0593].
  - Without licences the platform leans wholly on the 512(c) safe harbor [M-0343]. Red flag knowledge is a live risk on a service whose purpose is mixing well-known tracks (analysis) [M-0345]. A service built around unlicensed hits also risks the "tailored to infringement" label [M-0223].
  - Who carries the risk: the user as uploader; the platform as host and possibly as the party performing the works; labels and publishers are the claimants.
- Feature 4, live mixing to an audience.
  - Each track is publicly performed as a song [M-0106] and, online, as a recording [M-0107]. The one saved service statement says the service must clear both for every track [M-0586].
  - A non-interactive audio stream could in theory use the 114 licence with its programming limits (see card M23). Video is outside 114 [M-0112] and adds sync questions [M-0141]. A replay of the set is an archived program, so the archive limits of the 114 licence apply to it [M-0578, M-0579]. A replay that does not fit them needs direct licences.
  - Who carries the risk: the DJ user and the platform together. How the safe harbor applies to live streams is not covered in the base (gap).
- Feature 5, users uploading commercial tracks to mix.
  - This is the "any music" choice. The upload is storage at the user's direction [M-0343]. The platform needs the full 512(c) kit: a registered agent, renewed every 3 years [M-0349, M-0354], notice and takedown [M-0348], counter notice [M-0355, M-0356], and a repeat infringer policy that is actually applied [M-0357, M-0376].
  - The safe harbor does not require the platform to monitor [M-0358]. It is lost on actual or red flag knowledge without removal [M-0344, M-0345, M-0346].
  - Design matters. Features that invite users to bring chart hits, such as search by hit title or presets named after famous tracks, look like the affirmative steps in Grokster [M-0562].
  - Who carries the risk: the user for the upload; the platform if it loses the safe harbor or is found to induce.
- Feature 6, storing stems.
  - A stem holds the actual recorded sounds, so making and keeping it is within the reproduction wording for recordings (analysis) [M-0110]. No case rules on it. Unsettled.
  - Per-user stems kept at the user's direction are closer to user storage [M-0343]. A shared library of split hits that the platform builds and serves to other users is the platform's own copying and distribution, not user storage (analysis) [M-0220].
  - The stem model's own licence is a separate check (see card M24) [M-0603, M-0606].
  - Who carries the risk: the platform, more than for any other private feature, when the splitting and storage happen on its servers.
- Feature 7, export and download.
  - A download is a new copy that leaves the platform, so it is reproduction and distribution of each song and recording [M-0108]. The 114 licence bars inducing listeners to make copies [M-0582]. One licensed service says downloads need an extra licensed right [M-0588].
  - The compulsory mechanical licence does not cover it: that licence is for the composition only, bars changes to the basic melody or character, and is not a licence of any recording [M-0540, M-0542].
  - Export to other services passes the problem on. The saved distributor pages do not take sample-based works through their cover route [M-0597].
  - Who carries the risk: the user who exports and posts elsewhere; the platform for offering public downloads of other people's mixes.
- Feature 8, charging money.
  - Not charging is not a defence [M-0220]. But charging changes several tests. Commercial use weighs in fair use factor one [M-0549, M-0551, M-0553]. A direct financial benefit from infringement the platform can control costs it the safe harbor, and the benefit need not be large (court decision, Ninth Circuit) [M-0347, M-0515]. Canada's user content exception needs a solely non-commercial purpose on the individual's side [M-0616].
  - Vicarious liability, which turns on financial benefit and control, was left undecided in Cox (analysis row) [M-0252].
  - Lower-risk pricing (analysis): charge for the tool and for storage, not per mix of named commercial tracks, and keep adverts and payouts away from unlicensed mixes. Counsel should confirm. A subscription can still count as a financial benefit if infringing use is what draws users. The base has no row that decides this (gap).
- Country flags for rollout.
  - Canada: the s.29.21 exception may protect an individual user's non-commercial mix if all four conditions hold [M-0616, M-0617, M-0618, M-0619]. A mix that can stand in for the original tracks is at risk on the market condition [M-0619]. The platform's own position is not settled by the saved text [M-0620].
  - Australia: only parody or satire and criticism or review are in the saved set [M-0622, M-0625]. Add the integrity right [M-0626]. Treat as stricter than Canada until counsel says otherwise.
  - UK: pastiche and parody are fair dealing exceptions, not a blanket right [M-0240]. On-demand sharing is communication to the public [M-0237]. Moral rights can be asserted against a distorting mix [M-0628, M-0629].
  - EU: the platform is itself liable for user uploads under Art 17 unless it is licensed or meets the best efforts tests [M-0387, M-0389]. Users may rely on pastiche [M-0393], and the 2026 Pelham II press release reads pastiche to include some sampling [M-0631], but not as a catch-all [M-0633]. A straight DJ blend that plays whole tracks is not shown to qualify.
- Risk carriers overall: the user for what the user uploads, saves, shares and exports; the platform as tool maker, host, possible direct actor and payee; labels and publishers as claimants; authors as moral rights claimants in the UK and Australia.

### Gotchas
- "Private" must be real. Unlisted links, friends lists and "share with followers" are sharing. The base has no row on how many listeners make a performance public (gap). Ask counsel before calling any sharing feature private.
- Private mixing is the lowest-risk step, not a cleared one. The stem copy and the derivative work questions are both open [M-0110, M-0522].
- The safe harbor covers what users store. It does not clearly cover what the platform itself renders, splits, curates or promotes (analysis) [M-0343].
- Cox removed "knowledge plus inaction" as a route to contributory liability [M-0224]. It did not change the safe harbor conditions, and it left vicarious liability open [M-0252].
- Canada's exception is for individuals and needs a non-commercial purpose [M-0616]. It is not a licence for a paid platform.
- The Pelham II rows rest on a press release, not the judgment [M-0631]. EU member states also apply these exceptions through their own national laws, which are not in the base.
- One mix can hold many works, and statutory damages are per work [M-0254].
- Geo-blocking and age of the company change the EU answer [M-0392]. Re-check before an EU launch.

### Open questions for counsel
- US: is on-device stem splitting and real-time blending of a lawfully bought track an infringement by the user, and does the platform's exposure change if no audio ever reaches its servers?
- US: at what point does "sharing with friends" become a public performance or a distribution?
- US: does 512(c) protect the platform for mixes rendered by its own tool from user uploads, and for stems it stores per user?
- US: which pricing models avoid a "direct financial benefit" finding, and how should adverts and creator payouts be handled around unlicensed mixes?
- Canada: does s.29.21 protect the platform as an intermediary when it charges a subscription, and how do courts read "solely non-commercial" and the market effect test for a DJ mix?
- UK and Australia: can a blend or mashup be a derogatory treatment, and can the platform get moral rights waivers that hold?
- EU: after Pelham II, can any DJ mix or mashup count as pastiche, and what does Art 17 require of a new, small platform in its first 3 years?
- All countries: can the platform launch in one country only, and what blocking is enough to keep foreign law out?

### Sources
- usc17-106, usc17-114, usc17-501, usc17-504, usc17-512, usc17-1008: US Copyright Act sections (https://www.law.cornell.edu/uscode/text/17)
- scotus-sony-universal-1984: Sony v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf)
- scotus-grokster-2005: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf)
- scotus-cox-sony-2026: Cox Communications v. Sony Music Entertainment, No. 24-171 (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf)
- ca9-riaa-diamond-1999: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json)
- ca9-mavrix-livejournal-2017: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html)
- ca-copyright-s29-21: Canada Copyright Act s.29.21 (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html)
- ca-copyright-s29: Canada Copyright Act s.29 (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.html)
- au-copyright-s41a, au-copyright-s103aa: Australia Copyright Act 1968, parody or satire sections (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0))
- uk-cdpa-s30a: UK CDPA 1988 s.30A (https://www.legislation.gov.uk/ukpga/1988/48/section/30A)
- uk-cdpa-s80: UK CDPA 1988 s.80 (https://www.legislation.gov.uk/ukpga/1988/48/section/80)
- cjeu-pelham-c476-17: Pelham v. Hutter, Case C-476/17 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62017CJ0476)
- cjeu-pelham2-c590-23: Court of Justice press release No 50/26 on Pelham II (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf)
- eu-cdsm-2019-790: Directive (EU) 2019/790 (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790)
- terms-mixcloud-livestream: Mixcloud blog on live streaming music, captured 2026-11-13 (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues)

### Claims cited in M25
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0575] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): a computer hard drive is excluded from the Act's definition of a digital music recording, so the Rio, which copies from a hard drive, does not record directly from a digital music recording.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "a hard drive is a material object in which one or more programs are fixed; thus, a hard drive is excluded from the definition of digital music recordings"
- Checked: 2026-11-13

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0616] VERIFIED
- Claim: Canada s.29.21(1)(a): the use or the authorization to disseminate the new work must be solely for non-commercial purposes.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(a)
- Quote: "is done solely for non-commercial purposes;"
- Checked: 2026-11-13

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0631] VERIFIED
- Claim: CJEU Pelham II (C-590/23, 14 April 2026), per the Court's press release: pastiche covers creations that evoke existing works while noticeably different from them and use, including by sampling, characteristic protected elements to engage in a recognisable artistic or creative dialogue.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, summary of answer
- Quote: "covers creations which evoke one or more existing works, while being noticeably different from them, and which use, including by means of sampling, some of those works’ characteristic elements protected by copyright"
- Checked: 2026-11-13

#### [M-0622] VERIFIED
- Claim: Australia Copyright Act 1968 s.41A: a fair dealing with a literary, dramatic, musical or artistic work for the purpose of parody or satire is not infringement.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41A
- Quote: "musical or artistic work, or with an adaptation of a literary, dramatic or musical work, does not constitute an infringement of the copyright in the work if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0560] VERIFIED
- Claim: Sony v. Universal (1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 434-442)
- Quote: "does not constitute contributory infringement if the product is widely used for legitimate, unobjectionable purposes, or, indeed, is merely capable of substantial noninfringing uses"
- Checked: 2026-11-13

#### [M-0562] VERIFIED
- Claim: Grokster (2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for third-party infringement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919 (syllabus Held; opinion at 936-937)
- Quote: "one who distributes a device with the object of promoting its use to infringe copyright, as shown by clear expression or other"
- Checked: 2026-11-13

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0358] VERIFIED
- Claim: Applicability of 512(a)-(d) is not conditioned on a provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure under 512(i).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(m)(1)
- Quote: "a service provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure complying with the provisions of subsection (i)"
- Checked: 2026-11-10

#### [M-0579] VERIFIED
- Claim: Under the 114 statutory licence a transmission may not be part of an archived program of 5 hours or more that is made available for more than 2 weeks, so a permanent on-demand mix archive does not meet that condition.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(II)
- Quote: "is not part of an archived program of 5 hours or greater in duration that is made available for a period exceeding 2 weeks"
- Checked: 2026-11-13

#### [M-0582] VERIFIED
- Claim: The statutory licence requires the service to take no affirmative steps to cause or induce the recipient to make a phonorecord, so a download button on mixes is outside it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vi)
- Quote: "the transmitting entity takes no affirmative steps to cause or induce the making of a phonorecord by the transmission recipient"
- Checked: 2026-11-13

#### [M-0215] VERIFIED
- Claim: Statutory damages range from $750 to $30,000 per work, as the court considers just, at the owner's election.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "in a sum of not less than $750 or more than $30,000 as the court considers just."
- Checked: 2026-11-10

#### [M-0217] VERIFIED
- Claim: Willful infringement raises the statutory maximum to $150,000 per work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0254] VERIFIED
- Claim: Analysis: statutory damages are awarded per work infringed, up to $150,000 per work if willful (ordinary range $750 to $30,000), and only for works registered in time (s.412); exposure is per work, not per view.
- Jurisdiction: analysis
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0214] VERIFIED
- Claim: No statutory damages or fees for infringement of a published work that commenced before its registration, unless registered within three months of publication.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 412 registration as prerequisite to certain remedies (https://www.law.cornell.edu/uscode/text/17/412), source id usc17-412
- Pinpoint: 17 U.S.C. 412(2)
- Quote: "any infringement of copyright commenced after first publication of the work and before the effective date of its registration, unless such registration is made within three months after the first publication of the work."
- Checked: 2026-11-10

#### [M-0617] VERIFIED
- Claim: Canada s.29.21(1)(b): the source and, if given, the name of the author, performer, maker or broadcaster must be mentioned, if reasonable in the circumstances.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(b)
- Quote: "are mentioned, if it is reasonable in the circumstances to do so;"
- Checked: 2026-11-13

#### [M-0618] VERIFIED
- Claim: Canada s.29.21(1)(c): the individual must have had reasonable grounds to believe the source work was not infringing copyright.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(c)
- Quote: "the individual had reasonable grounds to believe that the existing work or other subject-matter or copy of it, as the case may be, was not infringing copyright"
- Checked: 2026-11-13

#### [M-0619] VERIFIED
- Claim: Canada s.29.21(1)(d): the use must not have a substantial adverse effect on the exploitation or potential exploitation of the source, or its market, including by being a substitute.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(d)
- Quote: "does not have a substantial adverse effect, financial or otherwise, on the exploitation or potential exploitation of the existing work"
- Checked: 2026-11-13

#### [M-0620] VERIFIED
- Claim: Canada s.29.21(2): an intermediary is a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(2) definition of intermediary
- Quote: "intermediary means a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public."
- Checked: 2026-11-13

#### [M-0621] VERIFIED
- Claim: Canada s.29: fair dealing for research, private study, education, parody or satire does not infringe copyright.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29 fair dealing (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.html), source id ca-copyright-s29
- Pinpoint: Copyright Act (Canada) s.29
- Quote: "Fair dealing for the purpose of research, private study, education, parody or satire does not infringe copyright."
- Checked: 2026-11-13

#### [M-0623] VERIFIED
- Claim: Australia s.103AA: a fair dealing with an audio-visual item for the purpose of parody or satire is not infringement of the item or works in it.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.103AA parody or satire (subject matter other than works) (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s103aa
- Pinpoint: Copyright Act 1968 (Cth) s.103AA
- Quote: "A fair dealing with an audio-visual item does not constitute an infringement of the copyright in the item or in any work or other audio-visual item included in the item if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0624] VERIFIED
- Claim: Australia: in Part IV Division 6 (s.100A) an audio-visual item means a sound recording, a cinematograph film, a sound broadcast or a television broadcast, so s.103AA reaches sound recordings.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.103AA parody or satire (subject matter other than works) (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s103aa
- Pinpoint: Copyright Act 1968 (Cth) s.100A (Part IV Division 6)
- Quote: "In this Division, audio-visual item means a sound recording, a cinematograph film, a sound broadcast or a television broadcast."
- Checked: 2026-11-13

#### [M-0625] VERIFIED
- Claim: Australia s.41: fair dealing for criticism or review needs a sufficient acknowledgement of the work.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41
- Quote: "for the purpose of criticism or review, whether of that work or of another work, and a sufficient acknowledgement of the work is made."
- Checked: 2026-11-13

#### [M-0626] VERIFIED
- Claim: Australia s.195AJ: derogatory treatment of a musical work includes material alteration or distortion prejudicial to the author's honour or reputation, under the author's right of integrity (s.195AI).
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) ss.195AI, 195AJ
- Quote: "the doing, in relation to the work, of anything that results in a material distortion of, the mutilation of, or a material alteration to, the work that is prejudicial to the author's honour or reputation"
- Checked: 2026-11-13

#### [M-0234] VERIFIED
- Claim: CDPA s.16(1): the copyright owner has the exclusive right to copy, issue copies, rent or lend, perform in public, communicate to the public and adapt.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(1)(a)-(e)
- Quote: "The owner of the copyright in a work has, in accordance with the following provisions of this Chapter, the exclusive right to do the following acts in the United Kingdom--"
- Checked: 2026-11-10

#### [M-0236] VERIFIED
- Claim: CDPA s.20(1): communication to the public of a musical work (and a sound recording, film or broadcast) is an act restricted by the copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(1)
- Quote: "The communication to the public of the work is an act restricted by the copyright"
- Checked: 2026-11-10

#### [M-0237] VERIFIED
- Claim: CDPA s.20(2)(b): communication to the public includes making a work available on demand, individually chosen place and time.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(2)(b)
- Quote: "the making available to the public of the work by electronic transmission in such a way that members of the public may access it from a place and at a time individually chosen by"
- Checked: 2026-11-10

#### [M-0241] VERIFIED
- Claim: CDPA s.30A(2): a contract term that restricts an act permitted by the parody exception is unenforceable.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(2)
- Quote: "To the extent that a term of a contract purports to prevent or restrict the doing of any act which, by virtue of this section, would not infringe copyright, that term is"
- Checked: 2026-11-10

#### [M-0627] VERIFIED
- Claim: UK CDPA s.80(1): the author of a copyright musical work has the right not to have the work subjected to derogatory treatment.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(1)
- Quote: "has the right in the circumstances mentioned in this section not to have his work subjected to derogatory treatment."
- Checked: 2026-11-13

#### [M-0628] VERIFIED
- Claim: UK CDPA s.80(2)(b): treatment is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(2)(b)
- Quote: "the treatment of a work is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author or director;"
- Checked: 2026-11-13

#### [M-0629] VERIFIED
- Claim: UK CDPA s.80(3): the right in a musical work is infringed by someone who publishes commercially, performs in public or communicates to the public a derogatory treatment, or issues copies of a sound recording of one.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(3)(a)-(b)
- Quote: "issues to the public copies of a film or sound recording of, or including, a derogatory treatment of the work."
- Checked: 2026-11-13

#### [M-0630] VERIFIED
- Claim: CJEU Pelham I: a recognisable sample may amount to a quotation under Art 5(3)(d) only if the use intends to enter into dialogue with the work sampled and the quotation conditions are met; no quotation where the work cannot be identified.
- Jurisdiction: EU
- Source: CJEU Judgment C-476/17 Pelham GmbH v Ralf Hütter and Florian Schneider-Esleben (29 July 2019) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62017CJ0476), source id cjeu-pelham-c476-17
- Pinpoint: C-476/17, paras 72-74 and operative part 4
- Quote: "does not extend to a situation in which it is not possible to identify the work concerned by the quotation in question."
- Checked: 2026-11-13

#### [M-0632] VERIFIED
- Claim: Pelham II press release: it is enough that the pastiche character be recognisable to a person familiar with the borrowed work; proof of the user's intent is not required.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26
- Quote: "it is sufficient that the ‘pastiche’ nature be recognisable for a person who is familiar with the existing work from which the elements have been borrowed."
- Checked: 2026-11-13

#### [M-0633] VERIFIED
- Claim: Pelham II press release: the pastiche exception in InfoSoc Art 5(3)(k) is not a catch-all covering every creative use, and does not cover concealed imitations or plagiarism.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, footnotes 5 and 6
- Quote: "that exception does not have a catch-all nature (Auffangtatbestand) covering every form of creative use of copyright-protected material."
- Checked: 2026-11-13

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0390] VERIFIED
- Claim: Art 17(4)(b): best efforts, to high industry standards of professional diligence, to ensure unavailability of works the rightholder identified.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(b)
- Quote: "made, in accordance with high industry standards of professional diligence, best efforts to ensure the unavailability of specific works and other subject matter for which the rightholders have provided the service providers with the relevant and necessary information"
- Checked: 2026-11-10

#### [M-0391] VERIFIED
- Claim: Art 17(4)(c): act expeditiously on a substantiated notice and make best efforts to prevent future uploads (notice and stay down).
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(c)
- Quote: "made best efforts to prevent their future uploads in accordance with point (b)"
- Checked: 2026-11-10

#### [M-0392] VERIFIED
- Claim: Art 17(6): new providers under three years old with turnover under EUR 10 million have a lighter regime.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(6)
- Quote: "the services of which have been available to the public in the Union for less than three years and which have an annual turnover below EUR 10 million"
- Checked: 2026-11-10

#### [M-0393] VERIFIED
- Claim: Art 17(7): users may rely on quotation, criticism, review, caricature, parody or pastiche exceptions when uploading.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(7)
- Quote: "Member States shall ensure that users in each Member State are able to rely on any of the following existing exceptions or limitations when uploading and making available content generated by users"
- Checked: 2026-11-10

#### [M-0394] VERIFIED
- Claim: Art 17(8): no general monitoring obligation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(8)
- Quote: "The application of this Article shall not lead to any general monitoring obligation"
- Checked: 2026-11-10

#### [M-0395] VERIFIED
- Claim: Art 17(9): complaint processed without undue delay, with human review of decisions to disable or remove.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(9)
- Quote: "decisions to disable access to or remove uploaded content shall be subject to human review"
- Checked: 2026-11-10

#### [M-0572] VERIFIED
- Claim: The Audio Home Recording Act bars infringement actions based on the manufacture, importation or distribution of a digital audio recording device, digital audio recording medium, analog recording device or analog recording medium, or on a consumer's noncommercial use of such a device or medium for making digital or analog musical recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1008 Prohibition on certain infringement actions (https://www.law.cornell.edu/uscode/text/17/1008), source id usc17-1008
- Pinpoint: 17 U.S.C. 1008
- Quote: "based on the noncommercial use by a consumer of such a device or medium for making digital musical recordings or analog musical recordings"
- Checked: 2026-11-13

#### [M-0561] VERIFIED
- Claim: Sony v. Universal: the VTR was capable of substantial noninfringing uses both because many copyright holders would not object to time-shifting and because unauthorised private, noncommercial home time-shifting of broadcast television was fair use.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 442-456)
- Quote: "even the unauthorized home timeshifting of respondents' programs is legitimate fair use"
- Checked: 2026-11-13

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0141] VERIFIED
- Claim: The sync right is an industry term for reproduction (and possibly derivative) rights in a musical work synchronized to visual content.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), ch. 1 background
- Quote: "the right to synchronize musical works to visual content (e.g., in a music video). The synchronization (or synch right) is a species of the reproduction right and may also implicate the derivative work right."
- Checked: 2026-11-10

#### [M-0354] VERIFIED
- Claim: A designation expires three years after registration unless renewed by amending or resubmitting it.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(c)(4)
- Quote: "A service provider's designation will expire and become invalid three years after it is registered with the Office"
- Checked: 2026-11-10

#### [M-0355] VERIFIED
- Claim: On a counter notice the provider replaces the removed material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells its designated agent (of a court action; see rest of 512(g)(2)(C)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(2)(C)
- Quote: "replaces the removed material and ceases disabling access to it not less than 10, nor more than 14, business days following receipt of the counter notice, unless its designated agent first receives notice from the person who submitted the notification"
- Checked: 2026-11-10

#### [M-0356] VERIFIED
- Claim: A counter notification must include a statement under penalty of perjury that the subscriber has a good faith belief the material was removed or disabled by mistake or misidentification.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(3)(C)
- Quote: "A statement under penalty of perjury that the subscriber has a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material to be removed or disabled"
- Checked: 2026-11-10

#### [M-0376] VERIFIED
- Claim: The report notes the Fourth Circuit reads 'repeat infringer' as repeat alleged infringer, not repeat adjudicated.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, repeat infringer policies
- Quote: "a “repeat infringer” under section 512 means repeat alleged infringer, not repeat adjudicated"
- Checked: 2026-11-10

#### [M-0603] VERIFIED
- Claim: Demucs maintainer in issue 384 (2022-09-29): the code is free for commercial use under MIT, but the weights are research artefacts provided only for personal or research usage.
- Jurisdiction: industry
- Source: facebookresearch/demucs issue 384 Legality of publishing audio output (maintainer comment) (https://github.com/facebookresearch/demucs/issues/384), source id demucs-issue-384
- Pinpoint: Issue 384, comment by adefossez 2022-09-29
- Quote: "The weights themselves are however just a research artefacts and provided only for personal / research usage."
- Checked: 2026-11-13

#### [M-0606] VERIFIED
- Claim: Open-Unmix README: the default umxl weights are licensed for non-commercial use only (CC BY-NC-SA 4.0).
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxl
- Quote: "Note, that the weights are only licensed for non-commercial use (CC BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0540] VERIFIED
- Claim: A compulsory licence under 115 includes the privilege of an arrangement only to the extent necessary to conform the work to the style of the performance; it may not change the basic melody or fundamental character.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "the arrangement shall not change the basic melody or fundamental character of the work"
- Checked: 2026-11-13

#### [M-0542] VERIFIED
- Claim: The compulsory licence is for making and distributing phonorecords of a nondramatic musical work (the composition); it is not a licence of any sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)-(B)
- Quote: "obtain a compulsory license to make and distribute phonorecords of a nondramatic musical work"
- Checked: 2026-11-13

#### [M-0597] VERIFIED
- Claim: CD Baby says derivative works such as samples cannot be cleared through its cover song licensing process.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Things to note
- Quote: "Derivative works, such as samples, cannot be cleared through the cover song licensing process."
- Checked: 2026-11-13

#### [M-0549] VERIFIED
- Claim: Campbell: a commercial nature is only one element of factor one; no presumption that every commercial use is unfair.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus
- Quote: "The statute makes clear that a work's commercial nature is only one element of the first factor enquiry into its purpose and character"
- Checked: 2026-11-13

#### [M-0551] VERIFIED
- Claim: Warhol: if an original and the secondary use share the same or highly similar purposes and the use is commercial, factor one is likely to weigh against fair use absent another justification.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "if an original work and secondary use share the same or highly similar purposes, and the secondary use is commercial, the first fair use factor is likely to weigh against fair use"
- Checked: 2026-11-13

#### [M-0553] VERIFIED
- Claim: Warhol: commercial nature is relevant but not dispositive, and is weighed against the degree to which the use has a further purpose or different character.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "The commercial nature of a use is relevant, but not dispositive"
- Checked: 2026-11-13

#### [M-0515] VERIFIED
- Claim: Ninth Circuit (Mavrix v. LiveJournal, 2017): the 512(c) financial benefit test is a common-sense, fact-based inquiry, and the benefit need not be substantial or a large proportion of revenue.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 512(c)(1)(B) discussion
- Quote: "The financial benefit need not be substantial or a large proportion of the service provider’s revenue."
- Checked: 2026-11-10

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0224] VERIFIED
- Claim: Cox (2026): the Fourth Circuit's knowledge-plus-insufficient-action rule went beyond the two recognised bases and conflicted with the Court's precedent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part III
- Quote: "contributory liability cannot rest only on a provider’s knowledge of infringement and insufficient action to prevent it."
- Checked: 2026-11-10

## playbook Questions for a licensed music attorney

Research tool, not legal advice. Law last checked 2026-11-13.

## Questions for a licensed music attorney

How to use this page: hand it to the attorney with the cards M21 to M25. Each question lists the rows that frame it. The rows are verified quotes from statutes, cases and service statements, but they do not answer the question. The attorney's answer does. Rows marked "(analysis)" are the researchers' reasoning.

### A. The stem tool

#### A1. Is splitting a lawfully obtained track into stems a reproduction or the making of a derivative work?
- Why it matters: every feature starts with a stem split. If the split itself infringes, private use is not a safe starting point.
- Rows that frame it: the recording owner's copy right covers copying that recaptures the actual sounds [M-0110]. The derivative right covers sounds rearranged, remixed or altered [M-0523]. Each owner controls derivative works [M-0522].
- Gap: no saved case rules on stem separation.

#### A2. Does it matter whether the split runs on the user's device or on our servers?
- Why it matters: it decides the product's architecture and who made the copy.
- Rows that frame it: anyone who violates an exclusive right is an infringer [M-0220]. The safe harbor covers storage at the direction of a user [M-0343].
- Gap: the base has no row on the test for who "does" the act when a server acts on a user's command.

#### A3. Does the home recording statute or the Sony fair use finding protect private stem splitting and mixing?
- Rows that frame it: section 1008 bars actions over a consumer's noncommercial use of listed devices and media [M-0572, M-0573]. The Ninth Circuit kept computer hard drives outside the Act [M-0574, M-0575] and described its purpose as private, noncommercial use [M-0576]. Sony's fair use finding was about home time-shifting of TV [M-0561]. Section 117 names only computer programs [M-0577].

#### A4. What can we say in marketing, onboarding and the product itself without inducing infringement?
- Why it matters: the tool maker cases turn on the maker's own words and design.
- Rows that frame it: Sony's staple article rule [M-0560]. Grokster's inducement rule [M-0562, M-0563]. Cox's intent rule and the "tailored to infringement" route [M-0221, M-0222, M-0223].
- The researchers' reading that inducement reaches a stem tool promoted for commercial songs is not confirmed by any case (unverified) [M-0564].

#### A5. Which theories did Cox leave open against us?
- Rows that frame it: vicarious liability was not decided (analysis row) [M-0252]. A concurrence pointed to other common-law theories [M-0225]. The Court rejected knowledge plus inaction for contributory liability [M-0224].

#### A6. Can we ship the stem model we want?
- Why it matters: a bad model licence is a problem separate from the music.
- Rows that frame it: code licence silent on weights [M-0600]; maintainer statements that the weights licence is unclear and that he cannot grant one [M-0601, M-0602, M-0603]; non-commercial weights [M-0606]; silent projects [M-0604, M-0607, M-0609, M-0610]; training set with non-commercial tracks [M-0614].
- Ask: does a non-commercial limit on training data bind the weights, who could enforce it, and who can give a commercial grant?

### B. What a mix is

#### B1. Is a DJ mix a derivative work of each track, a compilation, or both? What turns on the answer?
- Rows that frame it: definitions of derivative work [M-0521] and compilation [M-0569]. A 2016 policy paper says remixes are often derivative works, compilations or collective works [M-0554].
- Gap: no saved authority decides it.

#### B2. What, if anything, does a user own in a mix made without permission?
- Rows that frame it: no protection for parts using material unlawfully [M-0528]; protection only for new material [M-0529]; the Seventh Circuit's hard line [M-0532, M-0533]; the Second Circuit's fair use route [M-0535, M-0536].
- Ask: what should our user terms say about ownership?

#### B3. Can any kind of mix be fair use: a transition-only blend, a mashup, a short clip?
- Rows that frame it: the four factors [M-0547]; no bright lines [M-0205]; parody against satire [M-0548]; purpose and commerciality after Warhol [M-0551, M-0552]; burden on the user [M-0211]; the sampling split between circuits [M-0186, M-0188].
- Gap: no saved case on a DJ mix or mashup.

#### B4. For artist-approved remix projects, what should the grant say and who should own the result?
- Rows that frame it: transfers need a signed writing [M-0040]; rights can be split and owned separately [M-0539]; work made for hire is a closed list [M-0537, M-0047].
- Gap: no saved remix deal terms.

### C. Hosting, sharing and streaming

#### C1. Which exact licences does a public, on-demand library of user mixes need, and from whom?
- Rows that frame it: an interactive service needs song licences as well as recording licences [M-0301]; performance rights in songs and recordings [M-0106, M-0107]; the 114 licence bars interactive services and short archives [M-0115, M-0578, M-0579]; a large service's account of mechanical and performance licensing [M-0086, M-0088]; licensed mix services' statements about direct deals (captured 2026-11-13) [M-0586, M-0589, M-0593].

#### C2. Can any part of our service run under the section 114 statutory licence?
- Rows that frame it: eligible classes [M-0114]; interactive service definition and the request rule [M-0113, M-0585]; performance complement [M-0580, M-0581]; no inducing copies [M-0582]; lawful source copy [M-0583]; on-screen track text [M-0584].

#### C3. Does the 512(c) safe harbor cover mixes that our own tool rendered, stems we store per user, and live streams?
- Rows that frame it: storage at user direction [M-0343]; knowledge and red flag conditions [M-0344, M-0345]; removal [M-0346, M-0348]; financial benefit and control [M-0347, M-0515]; no monitoring condition [M-0358]; how one court read red flag knowledge for music in videos [M-0365, M-0366].
- Gap: no saved source on the safe harbor and live streams.

#### C4. What must our takedown system include on day one?
- Rows that frame it: registered agent and renewal [M-0349, M-0354]; notice elements [M-0350, M-0351]; counter notice and put-back timing [M-0355, M-0356]; repeat infringer policy [M-0357, M-0376]; liability for knowingly false notices [M-0359].

#### C5. When does "sharing with friends" become a public performance or distribution?
- Rows that frame it: the public performance right [M-0106]; the reproduction right [M-0108].
- Gap: the base has no row on the meaning of "publicly". Do not label any sharing feature private until this is answered.

#### C6. When a user streams a live mix through us, who performs the works?
- Rows that frame it: performance rights [M-0106, M-0107]; a licensed service's statement that the service must clear both rights (captured 2026-11-13) [M-0586, M-0590]; video is outside 114 [M-0112].

#### C7. What does a club or venue licence actually cover, and does any of it carry over online?
- Rows that frame it: performance is a separate right from reproduction (analysis row) [M-0183]; the consent decrees limit ASCAP to non-exclusive public performance rights [M-0256].
- Gap: no venue licence text is saved.

#### C8. If we publish only through a licensed partner service, what must the contract say?
- Rows that frame it: the partner's public statements (captured 2026-11-13) [M-0586, M-0590, M-0591].
- Gap: no partner contract terms are saved. Ask whether a partner's licences reach stem-based blends.

### D. Downloads, covers and money

#### D1. What rights does a mix download or export need?
- Rows that frame it: reproduction in both works [M-0108]; the compulsory mechanical licence is song only, audio only, and bars changes to the basic melody or character [M-0542, M-0540, M-0544]; a service's statement that downloads need an extra right (captured 2026-11-13) [M-0588].

#### D2. Can we qualify as a digital music provider and use the blanket mechanical licence for user covers?
- Rows that frame it: the blanket licence and who may use it [M-0023, M-0122, M-0125]; first-use rule [M-0545]; notice rule for physical copies [M-0546].
- Gap: no row on how notices changed over in 2021.

#### D3. Where is the line between a permitted cover arrangement and a change to the song's fundamental character?
- Rows that frame it: [M-0540, M-0541, M-0543].

#### D4. Which pricing, advert and payout models avoid a direct financial benefit finding and limit vicarious liability?
- Rows that frame it: safe harbor financial benefit condition [M-0347, M-0515]; vicarious liability left open (analysis row) [M-0252]; commerciality in fair use [M-0549, M-0553].

#### D5. What is our realistic damages exposure, and how does registration timing affect it?
- Rows that frame it: [M-0215, M-0216, M-0217, M-0214, M-0218].

### E. Other countries

#### E1. Canada: does s.29.21 protect our users, and us, when we charge a subscription?
- Rows that frame it: the four conditions [M-0616, M-0617, M-0618, M-0619]; intermediary definition [M-0620]; fair dealing purposes [M-0621].
- Gap: Canadian case law on fairness and moral rights (s.28.2) not captured.

#### E2. UK: can a mix be pastiche, and can it be a derogatory treatment?
- Rows that frame it: s.30A [M-0240, M-0241]; restricted acts and on-demand communication [M-0234, M-0236, M-0237]; moral rights [M-0627, M-0628, M-0629].
- Gap: ss.81 and 82 exceptions not reviewed.

#### E3. EU: after Pelham II, can any DJ mix or mashup count as pastiche, and what does Article 17 require of us in our first three years?
- Rows that frame it: Pelham I on quotation [M-0630]; the Pelham II press release [M-0631, M-0632, M-0633]; Article 17 duties and the lighter regime [M-0387, M-0388, M-0389, M-0390, M-0391, M-0392]; user exceptions and complaints [M-0393, M-0395].
- Note: the Pelham II rows rest on the Court's press release. Ask the attorney to read the judgment.

#### E4. Australia: which exceptions, if any, could a user mix rely on, and how do moral rights apply?
- Rows that frame it: parody or satire [M-0622, M-0623, M-0624]; criticism or review [M-0625]; integrity right [M-0626].
- Gap: the base makes no claim about other parts of the Australian Act.

#### E5. Can we launch in one country only, and what blocking is enough?
- Rows that frame it: none. The base has no rows on jurisdiction or geo-blocking (gap).

### F. Decisions the answers feed
- Private-only against public release: A1, A2, A3, C3, C5.
- Any music against a licensed catalogue: A4, A5, B4, C1, C8.
- Stem engine choice: A6.
- Pricing: D4, D5.
- Country order: E1 to E5.

### Claims cited in attorney-questions
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0572] VERIFIED
- Claim: The Audio Home Recording Act bars infringement actions based on the manufacture, importation or distribution of a digital audio recording device, digital audio recording medium, analog recording device or analog recording medium, or on a consumer's noncommercial use of such a device or medium for making digital or analog musical recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1008 Prohibition on certain infringement actions (https://www.law.cornell.edu/uscode/text/17/1008), source id usc17-1008
- Pinpoint: 17 U.S.C. 1008
- Quote: "based on the noncommercial use by a consumer of such a device or medium for making digital musical recordings or analog musical recordings"
- Checked: 2026-11-13

#### [M-0573] VERIFIED
- Claim: The Act's digital audio recording device definition turns on a device whose digital recording function is designed or marketed for the primary purpose of making a digital audio copied recording for private use.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1001 Definitions (Audio Home Recording) (https://www.law.cornell.edu/uscode/text/17/1001), source id usc17-1001
- Pinpoint: 17 U.S.C. 1001(3)
- Quote: "designed or marketed for the primary purpose of, and that is capable of, making a digital audio copied recording for private use"
- Checked: 2026-11-13

#### [M-0574] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): the Rio player was not a digital audio recording device because it copies only from a computer hard drive, not from transmissions or digital musical recordings.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, end of Part IV
- Quote: "Because the Rio cannot make copies from transmissions, but instead, can only make copies from a computer hard drive, it is not a digital audio recording device."
- Checked: 2026-11-13

#### [M-0575] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): a computer hard drive is excluded from the Act's definition of a digital music recording, so the Rio, which copies from a hard drive, does not record directly from a digital music recording.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "a hard drive is a material object in which one or more programs are fixed; thus, a hard drive is excluded from the definition of digital music recordings"
- Checked: 2026-11-13

#### [M-0576] VERIFIED
- Claim: RIAA v. Diamond describes the Act's purpose as the consumer right to make recordings of copyrighted music for private, noncommercial use, quoting the Senate Report.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "The purpose of the Act is to ensure the right of consumers to make analog or digital audio recordings of copyrighted music for their private, noncommercial use"
- Checked: 2026-11-13

#### [M-0561] VERIFIED
- Claim: Sony v. Universal: the VTR was capable of substantial noninfringing uses both because many copyright holders would not object to time-shifting and because unauthorised private, noncommercial home time-shifting of broadcast television was fair use.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 442-456)
- Quote: "even the unauthorized home timeshifting of respondents' programs is legitimate fair use"
- Checked: 2026-11-13

#### [M-0577] VERIFIED
- Claim: 17 U.S.C. 117(a) lets the owner of a copy of a computer program make or authorise another copy or adaptation of that program on stated conditions (an essential step in using it with a machine, or archival purposes); its text names only computer programs.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 117 Computer programs (https://www.law.cornell.edu/uscode/text/17/117), source id usc17-117
- Pinpoint: 17 U.S.C. 117(a)
- Quote: "it is not an infringement for the owner of a copy of a computer program to make or authorize the making of another copy or adaptation of that computer program"
- Checked: 2026-11-13

#### [M-0560] VERIFIED
- Claim: Sony v. Universal (1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 434-442)
- Quote: "does not constitute contributory infringement if the product is widely used for legitimate, unobjectionable purposes, or, indeed, is merely capable of substantial noninfringing uses"
- Checked: 2026-11-13

#### [M-0562] VERIFIED
- Claim: Grokster (2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for third-party infringement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919 (syllabus Held; opinion at 936-937)
- Quote: "one who distributes a device with the object of promoting its use to infringe copyright, as shown by clear expression or other"
- Checked: 2026-11-13

#### [M-0563] VERIFIED
- Claim: Grokster: mere knowledge that a product could be or is used to infringe is not enough for liability, and ordinary product support is not inducement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 937
- Quote: "mere knowledge of infringing potential or of actual infringing uses would not be enough here to subject a distributor to liability"
- Checked: 2026-11-13

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0222] VERIFIED
- Claim: Cox (2026): mere knowledge that a service will be used to infringe is insufficient to establish the required intent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part II.B
- Quote: "mere knowledge that a service will be used to infringe is insufficient to establish the required intent to infringe."
- Checked: 2026-11-10

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0564] UNVERIFIED (unverified)
- Claim: Analysis: a stem-splitting or mixing tool maker whose marketing or onboarding steers users to split and mix commercial songs they do not own is exposed to Grokster inducement through its own statements and design, not through the tool's capability alone.
- Jurisdiction: analysis
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919
- Quote: "going beyond mere distribution with knowledge of third-party action"
- Checked: 2026-11-13

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0225] VERIFIED
- Claim: Cox (2026): Justice Sotomayor, concurring in the judgment, said other common-law theories such as aiding and abetting could apply in copyright.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Sotomayor concurrence
- Quote: "precedents have left open the possibility that other common-law theories of such liability, like aiding and abetting, could apply in the copyright context."
- Checked: 2026-11-10

#### [M-0224] VERIFIED
- Claim: Cox (2026): the Fourth Circuit's knowledge-plus-insufficient-action rule went beyond the two recognised bases and conflicted with the Court's precedent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part III
- Quote: "contributory liability cannot rest only on a provider’s knowledge of infringement and insufficient action to prevent it."
- Checked: 2026-11-10

#### [M-0600] VERIFIED
- Claim: Demucs repository code licence: MIT, which grants rights to use, copy, modify, publish, distribute, sublicense and sell the software (code only; the file says nothing about trained weights).
- Jurisdiction: industry
- Source: Demucs repository LICENSE (MIT) (https://raw.githubusercontent.com/adefossez/demucs/main/LICENSE), source id demucs-license
- Pinpoint: LICENSE, MIT grant
- Quote: "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software"
- Checked: 2026-11-13

#### [M-0601] VERIFIED
- Claim: Demucs README: the maintainer says the licence of the trained weights is not clear because MUSDB contains some data usable only for research.
- Jurisdiction: industry
- Source: Demucs repository README (https://raw.githubusercontent.com/adefossez/demucs/main/README.md), source id demucs-readme
- Pinpoint: README, License section
- Quote: "The license of the weights is not clear: MusDB contains some data that were only usable for research purpose."
- Checked: 2026-11-13

#### [M-0602] VERIFIED
- Claim: Demucs README: the maintainer says he cannot grant a licence for the weights, whether the data came from Meta custom data or from the original MUSDB data.
- Jurisdiction: industry
- Source: Demucs repository README (https://raw.githubusercontent.com/adefossez/demucs/main/README.md), source id demucs-readme
- Pinpoint: README, License section
- Quote: "I sadly cannot help granting a license, both coming from Meta custom data, or from the original MusDB data."
- Checked: 2026-11-13

#### [M-0603] VERIFIED
- Claim: Demucs maintainer in issue 384 (2022-09-29): the code is free for commercial use under MIT, but the weights are research artefacts provided only for personal or research usage.
- Jurisdiction: industry
- Source: facebookresearch/demucs issue 384 Legality of publishing audio output (maintainer comment) (https://github.com/facebookresearch/demucs/issues/384), source id demucs-issue-384
- Pinpoint: Issue 384, comment by adefossez 2022-09-29
- Quote: "The weights themselves are however just a research artefacts and provided only for personal / research usage."
- Checked: 2026-11-13

#### [M-0606] VERIFIED
- Claim: Open-Unmix README: the default umxl weights are licensed for non-commercial use only (CC BY-NC-SA 4.0).
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxl
- Quote: "Note, that the weights are only licensed for non-commercial use (CC BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0604] VERIFIED
- Claim: Spleeter README: the code of Spleeter is MIT licensed. The License section states nothing separate about the pretrained model weights (silence, not a grant).
- Jurisdiction: industry
- Source: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md), source id spleeter-readme
- Pinpoint: README, License section
- Quote: "The code of Spleeter is MIT-licensed."
- Checked: 2026-11-13

#### [M-0607] VERIFIED
- Claim: Open-Unmix README: the umxhq weights were trained on MUSDB18-HQ. The README states no weights licence for umx or umxhq, which is silence and not a grant.
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxhq
- Quote: "which comprises the same tracks as in MUSDB18 but un-compressed which yield in a full bandwidth of 22050 Hz."
- Checked: 2026-11-13

#### [M-0609] VERIFIED
- Claim: python-audio-separator README: the default model is a BS-Roformer checkpoint file (model_bs_roformer_ep_317_sdr_12.9755), described as BS-Roformer-Viperx-1297; the README gives no licence for that checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, CLI options and supported model list
- Quote: "default: model_bs_roformer_ep_317_sdr_12.9755.yaml"
- Checked: 2026-11-13

#### [M-0610] VERIFIED
- Claim: python-audio-separator README lists a Mel-Band Roformer vocals checkpoint credited to Kimberley Jensen, with no licence stated for the checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, supported model list
- Quote: "vocals_mel_band_roformer.ckpt MDXC vocals* (12.6), other Roformer Model: MelBand Roformer | Vocals by Kimberley Jensen"
- Checked: 2026-11-13

#### [M-0614] VERIFIED
- Claim: MUSDB18 includes 46 tracks from MedleyDB licensed under Creative Commons BY-NC-SA 4.0 (non-commercial, share-alike).
- Jurisdiction: industry
- Source: SigSep MUSDB18 dataset page (https://sigsep.github.io/datasets/musdb.html), source id musdb18-sigsep
- Pinpoint: MUSDB18 dataset page, composition list
- Quote: "46 tracks are taken from the MedleyDB (opens new window) licensed under Creative Commons (BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0521] VERIFIED
- Claim: A derivative work is one based on preexisting works; the statute's examples include a musical arrangement and a sound recording, and 'any other form in which a work may be recast, transformed, or adapted'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'derivative work'
- Quote: "any other form in which a work may be recast, transformed, or adapted"
- Checked: 2026-11-13

#### [M-0569] VERIFIED
- Claim: A compilation is a work formed by collecting and assembling preexisting materials selected, coordinated or arranged so the whole is an original work of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'compilation'
- Quote: "selected, coordinated, or arranged in such a way that the resulting work as a whole constitutes an original work of authorship"
- Checked: 2026-11-13

#### [M-0554] VERIFIED
- Claim: 2016 Commerce white paper: remixes include mashups and sampling, and in many cases they will be derivative works, compilations or collective works under the Copyright Act.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 7
- Quote: "In many cases, these remixes will constitute derivative works, compilations, or collective works, as defined in the Copyright Act"
- Checked: 2026-11-13

#### [M-0528] VERIFIED
- Claim: Under Section 103(a), protection for a work employing preexisting copyrighted material does not extend to any part of the work in which the material has been used unlawfully.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(a)
- Quote: "protection for a work employing preexisting material in which copyright subsists does not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0529] VERIFIED
- Claim: Copyright in a derivative work or compilation covers only the new material the author contributed and gives no exclusive right in the preexisting material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(b)
- Quote: "The copyright in a compilation or derivative work extends only to the material contributed by the author of such work"
- Checked: 2026-11-13

#### [M-0532] VERIFIED
- Claim: Pickett v. Prince (7th Cir. 2000): section 103(a) does not let a stranger make a derivative work; the court read it to mean, at least so far as bears on that case, only that the right to make one does not authorise using material that infringes someone else's copyright.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402, Posner C.J.
- Quote: "we do not read section 103(a) as qualifying the exclusive right of the owner of the copyright of the original work to make derivative works based on that work"
- Checked: 2026-11-13

#### [M-0533] VERIFIED
- Claim: Pickett: it is very difficult to see how a derivative work not made by the owner of the original could fail to infringe it, given the definition of derivative works.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402
- Quote: "It is very difficult to see how a derivative work not made by the owner of the original work could fail to infringe it, given the definition of derivative works"
- Checked: 2026-11-13

#### [M-0535] VERIFIED
- Claim: Keeling v. Hars (2d Cir. 2015): the creator of an unauthorized work that stays within fair use and adds sufficient originality may claim 103 protection for her original contributions.
- Jurisdiction: case-law
- Source: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json), source id ca2-keeling-hars-2015
- Pinpoint: 809 F.3d 43
- Quote: "if the creator of an unauthorized work stays within the bounds of fair use and adds sufficient originality, she may claim protection under the Copyright Act"
- Checked: 2026-11-13

#### [M-0536] VERIFIED
- Claim: Keeling v. Hars (2d Cir. 2015), facts: a parody stage adaptation whose author held no copyright or licence in the source film; a jury found the adaptation a fair use, and the court's holding on protection for her original contributions is in M-0535.
- Jurisdiction: case-law
- Source: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json), source id ca2-keeling-hars-2015
- Pinpoint: 809 F.3d 43, Background
- Quote: "Keeling possesses no copyright or license with regard to the Point Break motion picture"
- Checked: 2026-11-13

#### [M-0547] VERIFIED
- Claim: Section 107 lists four fair use factors: purpose and character (commercial or nonprofit), nature of the work, amount and substantiality used, and market effect.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "the amount and substantiality of the portion used in relation to the copyrighted work as a whole"
- Checked: 2026-11-13

#### [M-0205] VERIFIED
- Claim: Campbell: fair use requires case-by-case analysis and is not simplified by bright-line rules.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 577 (Part II.A, opinion of the Court)
- Quote: "The task is not to be simplified with bright-line rules, for the statute, like the doctrine it recognizes, calls for case-by-case analysis."
- Checked: 2026-11-10

#### [M-0548] VERIFIED
- Claim: Campbell: parody needs to mimic an original to make its point and so has some claim to use its victim's work, whereas satire can stand on its own two feet and so requires justification for the very act of borrowing.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 580-81
- Quote: "satire can stand on its own two feet and so requires justification for the very act of borrowing"
- Checked: 2026-11-13

#### [M-0551] VERIFIED
- Claim: Warhol: if an original and the secondary use share the same or highly similar purposes and the use is commercial, factor one is likely to weigh against fair use absent another justification.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "if an original work and secondary use share the same or highly similar purposes, and the secondary use is commercial, the first fair use factor is likely to weigh against fair use"
- Checked: 2026-11-13

#### [M-0552] VERIFIED
- Claim: Warhol: reading Campbell to favour any use adding new expression would let transformative use swallow the owner's right to prepare derivative works.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "transformative use would swallow the copyright owner’s exclusive right to prepare derivative works"
- Checked: 2026-11-13

#### [M-0211] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017): fair use is an affirmative defense and the party asserting it bears the burden.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 748 (Part on fair use; burden sentence follows)
- Quote: "Fair use is an affirmative defense to copyright infringement"
- Checked: 2026-11-10

#### [M-0186] VERIFIED
- Claim: Sixth Circuit rule: for sampling a sound recording, the court says get a license or do not sample (no de minimis or substantial similarity inquiry).
- Jurisdiction: case-law
- Source: Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792 (6th Cir. 2005) (amended on rehearing) (Caselaw Access Project mirror) (https://static.case.law/f3d/410/html/0792-01.html), source id ca6-bridgeport-2005
- Pinpoint: 410 F.3d at 801
- Quote: "Get a license or .do not sample."
- Checked: 2026-11-10

#### [M-0188] VERIFIED
- Claim: The Ninth Circuit holds the de minimis exception applies to sound recording sampling, and expressly disagrees with the Sixth Circuit.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, Part II.B (slip op. at 32)
- Quote: "We hold that the “de minimis” exception applies to actions alleging infringement of a copyright to sound recordings."
- Checked: 2026-11-10

#### [M-0040] VERIFIED
- Claim: A transfer of copyright ownership, other than by operation of law, is not valid unless in a writing signed by the owner of the rights conveyed or the owner's authorized agent.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 204 execution of transfers of copyright ownership (https://www.law.cornell.edu/uscode/text/17/204), source id usc17-204
- Pinpoint: 17 U.S.C. 204(a)
- Quote: "A transfer of copyright ownership, other than by operation of law, is not valid unless an instrument of conveyance, or a note or memorandum of the transfer, is in writing and signed by the owner"
- Checked: 2026-11-10

#### [M-0539] VERIFIED
- Claim: Any of the exclusive rights in a copyright, including any subdivision of the section 106 rights, may be transferred and owned separately (17 U.S.C. 201(d)(2)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 201 ownership of copyright (https://www.law.cornell.edu/uscode/text/17/201), source id usc17-201
- Pinpoint: 17 U.S.C. 201(d)(2)
- Quote: "Any of the exclusive rights comprised in a copyright, including any subdivision of any of the rights specified by section 106, may be transferred as provided by clause (1) and owned separately."
- Checked: 2026-11-13

#### [M-0537] VERIFIED
- Claim: A work made for hire is one prepared by an employee in scope of employment, or a specially commissioned work in listed categories (including a contribution to a collective work or a compilation) if the parties sign a written instrument saying so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'work made for hire'
- Quote: "if the parties expressly agree in a written instrument signed by them that the work shall be considered a work made for hire"
- Checked: 2026-11-13

#### [M-0047] VERIFIED
- Claim: The category list does not name sound recordings; whether a sound recording is made for hire turns on the employee prong or on fitting a listed category such as compilation or part of an audiovisual work (inference).
- Jurisdiction: analysis
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 "work made for hire" (2)
- Quote: "as a part of a motion picture or other audiovisual work, as a translation, as a"
- Checked: 2026-11-10

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0579] VERIFIED
- Claim: Under the 114 statutory licence a transmission may not be part of an archived program of 5 hours or more that is made available for more than 2 weeks, so a permanent on-demand mix archive does not meet that condition.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(II)
- Quote: "is not part of an archived program of 5 hours or greater in duration that is made available for a period exceeding 2 weeks"
- Checked: 2026-11-13

#### [M-0086] VERIFIED
- Claim: For compositions Spotify generally obtains mechanical, public performance and lyric rights; for audio-only use in the US the mechanical rights run through the Section 115 compulsory licence, with a blanket licence administered by the MLC since January 2021.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4, Musical Composition License Agreements
- Quote: "With respect to musical compositions, we generally obtain licenses for mechanical rights, public performance rights, and lyric rights. With respect to mechanical rights for audio-only"
- Checked: 2026-11-10

#### [M-0088] VERIFIED
- Claim: In the US public performance rights for compositions come through PROs (ASCAP, BMI, GMR, SESAC) under blanket licences, with usage reporting duties and one to four year terms.
- Jurisdiction: industry
- Source: Spotify Technology S.A., Form 20-F for fiscal year ended December 31, 2025 (filed February 10, 2026) (https://web.archive.org/web/20260210214925id_/https://www.sec.gov/Archives/edgar/data/1639920/000162828026006874/ck0001639920-20251231.htm), source id sec-spotify-20f-fy2025
- Pinpoint: Spotify 20-F FY2025, Item 4
- Quote: "In the United States, public performance rights are generally obtained through intermediaries known as performing rights organizations (“PROs”), which negotiate blanket licenses with copyright users for the public performance of"
- Checked: 2026-11-10

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0114] VERIFIED
- Claim: 17 U.S.C. 114(d)(2) subjects subscription digital audio transmissions, eligible nonsubscription transmissions and preexisting satellite digital audio radio service transmissions to statutory licensing if the listed conditions are met.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)
- Quote: "a subscription digital audio transmission not exempt under paragraph (1), an eligible nonsubscription transmission, or a transmission not exempt under paragraph (1) that is made by a preexisting satellite digital audio radio service shall be subject to statutory licensing"
- Checked: 2026-11-10

#### [M-0113] VERIFIED
- Claim: Under 17 U.S.C. 114(j)(7), an interactive service is one that lets a member of the public receive on request a transmission of a particular sound recording selected by or for the recipient.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "An interactive service is one that enables a member of the public to receive a transmission of a program specially created for the recipient, or on request, a transmission of a particular sound recording"
- Checked: 2026-11-10

#### [M-0585] VERIFIED
- Claim: A service is not interactive just because users can request recordings for the public at large, unless the channel programming substantially consists of recordings performed within 1 hour of the request or at a designated time.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(7)
- Quote: "The ability of individuals to request that particular sound recordings be performed for reception by the public at large"
- Checked: 2026-11-13

#### [M-0580] VERIFIED
- Claim: Under the statutory licence the transmission may not exceed the sound recording performance complement, and the service may not publish an advance schedule of the specific recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(i)-(ii)
- Quote: "the transmitting entity does not cause to be published, or induce or facilitate the publication, by means of an advance program schedule or prior announcement, the titles of the specific sound recordings to be transmitted"
- Checked: 2026-11-13

#### [M-0581] VERIFIED
- Claim: The sound recording performance complement allows, in any 3-hour period on a channel, no more than 3 different selections from any one phonorecord (no more than 2 consecutively), or 4 different selections by the same featured artist or from any set or compilation of phonorecords (no more than 3 consecutively).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(13)
- Quote: "3 different selections of sound recordings from any one phonorecord lawfully distributed for public performance or sale in the United States, if no more than 2 such selections are transmitted consecutively"
- Checked: 2026-11-13

#### [M-0582] VERIFIED
- Claim: The statutory licence requires the service to take no affirmative steps to cause or induce the recipient to make a phonorecord, so a download button on mixes is outside it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vi)
- Quote: "the transmitting entity takes no affirmative steps to cause or induce the making of a phonorecord by the transmission recipient"
- Checked: 2026-11-13

#### [M-0583] VERIFIED
- Claim: The statutory licence requires the transmission to be made from a phonorecord lawfully made under the copyright owner's authority.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vii)
- Quote: "the transmitting entity makes the transmission from a phonorecord lawfully made under the authority of the copyright owner"
- Checked: 2026-11-13

#### [M-0584] VERIFIED
- Claim: The statutory licence requires the service to identify the title, record and featured artist in text while the recording plays.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(ix)
- Quote: "the transmitting entity identifies in textual data the sound recording during, but not before, the time it is performed"
- Checked: 2026-11-13

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0515] VERIFIED
- Claim: Ninth Circuit (Mavrix v. LiveJournal, 2017): the 512(c) financial benefit test is a common-sense, fact-based inquiry, and the benefit need not be substantial or a large proportion of revenue.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 512(c)(1)(B) discussion
- Quote: "The financial benefit need not be substantial or a large proportion of the service provider’s revenue."
- Checked: 2026-11-10

#### [M-0358] VERIFIED
- Claim: Applicability of 512(a)-(d) is not conditioned on a provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure under 512(i).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(m)(1)
- Quote: "a service provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure complying with the provisions of subsection (i)"
- Checked: 2026-11-10

#### [M-0365] VERIFIED
- Claim: Capitol v. Vimeo: employee viewing of a video containing a recognizable copyrighted song does not alone establish red flag knowledge.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (summary and Part II)
- Quote: "viewed in some fashion by a service provider’s employee is insufficient to prove knowledge or red flag knowledge of infringement"
- Checked: 2026-11-10

#### [M-0366] VERIFIED
- Claim: Capitol v. Vimeo: the red flag test uses an ordinary person without specialized knowledge of music or copyright law.
- Jurisdiction: case-law
- Source: Capitol Records, LLC v. Vimeo, LLC, 826 F.3d 78 (2d Cir. 2016) (https://www.govinfo.gov/content/pkg/USCOURTS-ca2-14-01048/pdf/USCOURTS-ca2-14-01048-0.pdf), source id ca2-capitol-vimeo-2016
- Pinpoint: 826 F.3d 78 (Part II red flag)
- Quote: "obvious is an ordinary person--not endowed with specialized knowledge or"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0354] VERIFIED
- Claim: A designation expires three years after registration unless renewed by amending or resubmitting it.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(c)(4)
- Quote: "A service provider's designation will expire and become invalid three years after it is registered with the Office"
- Checked: 2026-11-10

#### [M-0350] VERIFIED
- Claim: One required element of an effective 512(c)(3) notice is a physical or electronic signature of a person authorized to act for the owner of an exclusive right allegedly infringed.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(i)
- Quote: "A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0351] VERIFIED
- Claim: A 512(c)(3) notice must include a statement, under penalty of perjury, that the complaining party is authorized to act for the owner of an exclusive right allegedly infringed (and that the notice information is accurate).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(3)(A)(vi)
- Quote: "under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"
- Checked: 2026-11-10

#### [M-0355] VERIFIED
- Claim: On a counter notice the provider replaces the removed material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells its designated agent (of a court action; see rest of 512(g)(2)(C)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(2)(C)
- Quote: "replaces the removed material and ceases disabling access to it not less than 10, nor more than 14, business days following receipt of the counter notice, unless its designated agent first receives notice from the person who submitted the notification"
- Checked: 2026-11-10

#### [M-0356] VERIFIED
- Claim: A counter notification must include a statement under penalty of perjury that the subscriber has a good faith belief the material was removed or disabled by mistake or misidentification.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(3)(C)
- Quote: "A statement under penalty of perjury that the subscriber has a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material to be removed or disabled"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0376] VERIFIED
- Claim: The report notes the Fourth Circuit reads 'repeat infringer' as repeat alleged infringer, not repeat adjudicated.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Section 512 of Title 17: A Report of the Register of Copyrights (May 2020) (https://www.copyright.gov/policy/section512/section-512-full-report.pdf), source id co-section512-report-2020
- Pinpoint: Executive Summary, repeat infringer policies
- Quote: "a “repeat infringer” under section 512 means repeat alleged infringer, not repeat adjudicated"
- Checked: 2026-11-10

#### [M-0359] VERIFIED
- Claim: A person who knowingly materially misrepresents under 512 that material or activity is infringing is liable for damages, including costs and attorneys’ fees, incurred by the alleged infringer and others (512(f)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(f)(1)
- Quote: "Any person who knowingly materially misrepresents under this section-- (1) that material or activity is infringing"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0590] VERIFIED
- Claim: Mixcloud describes its live product as a licensed live streaming platform that also archives the stream as a recording.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud Live is the world's first music-focused, licensed live streaming platform."
- Checked: 2026-11-13

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0256] VERIFIED
- Claim: The ASCAP Second Amended Final Judgment bars ASCAP from licensing any rights in musical compositions other than public performance rights, and only on a non-exclusive basis.
- Jurisdiction: case-law
- Source: United States v. ASCAP, Second Amended Final Judgment (S.D.N.Y. June 11, 2001), entered text as Exhibit A to the United States' May 12, 2016 contempt petition (Doc. 747, Civ. No. 41-1395) (https://www.justice.gov/opa/file/850776/dl), source id doj-ascap-afj2-2001
- Pinpoint: AFJ2 Sec. IV(A)
- Quote: "Holding, acquiring, licensing, enforcing, or negotiating concerning any foreign or domestic rights in copyrighted musical compositions other than rights of public performance on a non-exclusive basis"
- Checked: 2026-11-10

#### [M-0591] VERIFIED
- Claim: Mixcloud says that on a platform that has not cleared the music, rights holders can have a mix taken down and the mix muted.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'What is a DMCA takedown'
- Quote: "the copyright holders can ask for it to be taken down, and your mixes, shows or audio will be muted"
- Checked: 2026-11-13

#### [M-0542] VERIFIED
- Claim: The compulsory licence is for making and distributing phonorecords of a nondramatic musical work (the composition); it is not a licence of any sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)-(B)
- Quote: "obtain a compulsory license to make and distribute phonorecords of a nondramatic musical work"
- Checked: 2026-11-13

#### [M-0540] VERIFIED
- Claim: A compulsory licence under 115 includes the privilege of an arrangement only to the extent necessary to conform the work to the style of the performance; it may not change the basic melody or fundamental character.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "the arrangement shall not change the basic melody or fundamental character of the work"
- Checked: 2026-11-13

#### [M-0544] VERIFIED
- Claim: The Office states a phonorecord does not include sounds accompanying a motion picture or other audiovisual work, so the compulsory licence does not cover putting a song in video.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "A phonorecord does not include sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0023] VERIFIED
- Claim: Under the Music Modernization Act, a digital music provider can obtain a blanket mechanical license through the mechanical licensing collective.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0125] VERIFIED
- Claim: The blanket licence covers all musical works (or shares) available for compulsory licensing for covered activities, except as provided in subparagraph (C) (voluntary licences and individual download authority).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(B)(i)
- Quote: "covers all musical works (or shares of such works) available for compulsory licensing under this section for purposes of engaging in covered activities, except as provided in subparagraph (C);"
- Checked: 2026-11-10

#### [M-0545] VERIFIED
- Claim: First-use rule: the compulsory licence is available only if phonorecords of the work have previously been distributed to the public in the US under the authority of the copyright owner, or, for a digital music provider's digital phonorecord deliveries, the first fixation of the sound recording was made under the musical work owner's authority and the recording owner authorised the deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)(i)-(ii)
- Quote: "phonorecords of such musical work have previously been distributed to the public in the United States under the authority of the copyright owner of the work"
- Checked: 2026-11-13

#### [M-0546] VERIFIED
- Claim: For non-digital phonorecords, notice of intention must be served on the owner before, or within 30 days after, making and before distributing any phonorecords; failure forecloses the compulsory licence and, absent a voluntary licence, makes the making and distribution actionable as infringement.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(b)(1) and (b)(4)(A)
- Quote: "the failure to serve or file the notice of intention required by paragraph (1) forecloses the possibility of a compulsory license"
- Checked: 2026-11-13

#### [M-0541] VERIFIED
- Claim: An arrangement made under the compulsory licence is not protected as a derivative work except with the express consent of the composition owner.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "shall not be subject to protection as a derivative work under this title, except with the express consent of the copyright owner"
- Checked: 2026-11-13

#### [M-0543] VERIFIED
- Claim: The Office says that with the compulsory licence you cannot copy a sound recording publicly distributed in phonorecords without permission, and cannot change the basic melody or claim your arrangement as a derivative work.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "Change the basic melody or fundamental character of the work in the arrangement"
- Checked: 2026-11-13

#### [M-0549] VERIFIED
- Claim: Campbell: a commercial nature is only one element of factor one; no presumption that every commercial use is unfair.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus
- Quote: "The statute makes clear that a work's commercial nature is only one element of the first factor enquiry into its purpose and character"
- Checked: 2026-11-13

#### [M-0553] VERIFIED
- Claim: Warhol: commercial nature is relevant but not dispositive, and is weighed against the degree to which the use has a further purpose or different character.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "The commercial nature of a use is relevant, but not dispositive"
- Checked: 2026-11-13

#### [M-0215] VERIFIED
- Claim: Statutory damages range from $750 to $30,000 per work, as the court considers just, at the owner's election.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "in a sum of not less than $750 or more than $30,000 as the court considers just."
- Checked: 2026-11-10

#### [M-0216] VERIFIED
- Claim: Statutory damages are assessed per work for all infringements involved in the action; the owner may elect them any time before final judgment.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "an award of statutory damages for all infringements involved in the action, with respect to any one"
- Checked: 2026-11-10

#### [M-0217] VERIFIED
- Claim: Willful infringement raises the statutory maximum to $150,000 per work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0214] VERIFIED
- Claim: No statutory damages or fees for infringement of a published work that commenced before its registration, unless registered within three months of publication.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 412 registration as prerequisite to certain remedies (https://www.law.cornell.edu/uscode/text/17/412), source id usc17-412
- Pinpoint: 17 U.S.C. 412(2)
- Quote: "any infringement of copyright commenced after first publication of the work and before the effective date of its registration, unless such registration is made within three months after the first publication of the work."
- Checked: 2026-11-10

#### [M-0218] VERIFIED
- Claim: The civil statute of limitations is three years after the claim accrued.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 507 limitations on actions (https://www.law.cornell.edu/uscode/text/17/507), source id usc17-507
- Pinpoint: 17 U.S.C. 507(b)
- Quote: "No civil action shall be maintained under the provisions of this title unless it is commenced within three years after the claim accrued."
- Checked: 2026-11-10

#### [M-0616] VERIFIED
- Claim: Canada s.29.21(1)(a): the use or the authorization to disseminate the new work must be solely for non-commercial purposes.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(a)
- Quote: "is done solely for non-commercial purposes;"
- Checked: 2026-11-13

#### [M-0617] VERIFIED
- Claim: Canada s.29.21(1)(b): the source and, if given, the name of the author, performer, maker or broadcaster must be mentioned, if reasonable in the circumstances.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(b)
- Quote: "are mentioned, if it is reasonable in the circumstances to do so;"
- Checked: 2026-11-13

#### [M-0618] VERIFIED
- Claim: Canada s.29.21(1)(c): the individual must have had reasonable grounds to believe the source work was not infringing copyright.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(c)
- Quote: "the individual had reasonable grounds to believe that the existing work or other subject-matter or copy of it, as the case may be, was not infringing copyright"
- Checked: 2026-11-13

#### [M-0619] VERIFIED
- Claim: Canada s.29.21(1)(d): the use must not have a substantial adverse effect on the exploitation or potential exploitation of the source, or its market, including by being a substitute.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(d)
- Quote: "does not have a substantial adverse effect, financial or otherwise, on the exploitation or potential exploitation of the existing work"
- Checked: 2026-11-13

#### [M-0620] VERIFIED
- Claim: Canada s.29.21(2): an intermediary is a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(2) definition of intermediary
- Quote: "intermediary means a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public."
- Checked: 2026-11-13

#### [M-0621] VERIFIED
- Claim: Canada s.29: fair dealing for research, private study, education, parody or satire does not infringe copyright.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29 fair dealing (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.html), source id ca-copyright-s29
- Pinpoint: Copyright Act (Canada) s.29
- Quote: "Fair dealing for the purpose of research, private study, education, parody or satire does not infringe copyright."
- Checked: 2026-11-13

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0241] VERIFIED
- Claim: CDPA s.30A(2): a contract term that restricts an act permitted by the parody exception is unenforceable.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(2)
- Quote: "To the extent that a term of a contract purports to prevent or restrict the doing of any act which, by virtue of this section, would not infringe copyright, that term is"
- Checked: 2026-11-10

#### [M-0234] VERIFIED
- Claim: CDPA s.16(1): the copyright owner has the exclusive right to copy, issue copies, rent or lend, perform in public, communicate to the public and adapt.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.16(1)(a)-(e)
- Quote: "The owner of the copyright in a work has, in accordance with the following provisions of this Chapter, the exclusive right to do the following acts in the United Kingdom--"
- Checked: 2026-11-10

#### [M-0236] VERIFIED
- Claim: CDPA s.20(1): communication to the public of a musical work (and a sound recording, film or broadcast) is an act restricted by the copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(1)
- Quote: "The communication to the public of the work is an act restricted by the copyright"
- Checked: 2026-11-10

#### [M-0237] VERIFIED
- Claim: CDPA s.20(2)(b): communication to the public includes making a work available on demand, individually chosen place and time.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 ss.16-21 The acts restricted by copyright (incl. s.20 communication to the public) (https://www.legislation.gov.uk/ukpga/1988/48/part/I/chapter/II/crossheading/the-acts-restricted-by-copyright), source id uk-cdpa-s16-s21
- Pinpoint: CDPA s.20(2)(b)
- Quote: "the making available to the public of the work by electronic transmission in such a way that members of the public may access it from a place and at a time individually chosen by"
- Checked: 2026-11-10

#### [M-0627] VERIFIED
- Claim: UK CDPA s.80(1): the author of a copyright musical work has the right not to have the work subjected to derogatory treatment.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(1)
- Quote: "has the right in the circumstances mentioned in this section not to have his work subjected to derogatory treatment."
- Checked: 2026-11-13

#### [M-0628] VERIFIED
- Claim: UK CDPA s.80(2)(b): treatment is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(2)(b)
- Quote: "the treatment of a work is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author or director;"
- Checked: 2026-11-13

#### [M-0629] VERIFIED
- Claim: UK CDPA s.80(3): the right in a musical work is infringed by someone who publishes commercially, performs in public or communicates to the public a derogatory treatment, or issues copies of a sound recording of one.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(3)(a)-(b)
- Quote: "issues to the public copies of a film or sound recording of, or including, a derogatory treatment of the work."
- Checked: 2026-11-13

#### [M-0630] VERIFIED
- Claim: CJEU Pelham I: a recognisable sample may amount to a quotation under Art 5(3)(d) only if the use intends to enter into dialogue with the work sampled and the quotation conditions are met; no quotation where the work cannot be identified.
- Jurisdiction: EU
- Source: CJEU Judgment C-476/17 Pelham GmbH v Ralf Hütter and Florian Schneider-Esleben (29 July 2019) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:62017CJ0476), source id cjeu-pelham-c476-17
- Pinpoint: C-476/17, paras 72-74 and operative part 4
- Quote: "does not extend to a situation in which it is not possible to identify the work concerned by the quotation in question."
- Checked: 2026-11-13

#### [M-0631] VERIFIED
- Claim: CJEU Pelham II (C-590/23, 14 April 2026), per the Court's press release: pastiche covers creations that evoke existing works while noticeably different from them and use, including by sampling, characteristic protected elements to engage in a recognisable artistic or creative dialogue.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, summary of answer
- Quote: "covers creations which evoke one or more existing works, while being noticeably different from them, and which use, including by means of sampling, some of those works’ characteristic elements protected by copyright"
- Checked: 2026-11-13

#### [M-0632] VERIFIED
- Claim: Pelham II press release: it is enough that the pastiche character be recognisable to a person familiar with the borrowed work; proof of the user's intent is not required.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26
- Quote: "it is sufficient that the ‘pastiche’ nature be recognisable for a person who is familiar with the existing work from which the elements have been borrowed."
- Checked: 2026-11-13

#### [M-0633] VERIFIED
- Claim: Pelham II press release: the pastiche exception in InfoSoc Art 5(3)(k) is not a catch-all covering every creative use, and does not cover concealed imitations or plagiarism.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, footnotes 5 and 6
- Quote: "that exception does not have a catch-all nature (Auffangtatbestand) covering every form of creative use of copyright-protected material."
- Checked: 2026-11-13

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0390] VERIFIED
- Claim: Art 17(4)(b): best efforts, to high industry standards of professional diligence, to ensure unavailability of works the rightholder identified.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(b)
- Quote: "made, in accordance with high industry standards of professional diligence, best efforts to ensure the unavailability of specific works and other subject matter for which the rightholders have provided the service providers with the relevant and necessary information"
- Checked: 2026-11-10

#### [M-0391] VERIFIED
- Claim: Art 17(4)(c): act expeditiously on a substantiated notice and make best efforts to prevent future uploads (notice and stay down).
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(c)
- Quote: "made best efforts to prevent their future uploads in accordance with point (b)"
- Checked: 2026-11-10

#### [M-0392] VERIFIED
- Claim: Art 17(6): new providers under three years old with turnover under EUR 10 million have a lighter regime.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(6)
- Quote: "the services of which have been available to the public in the Union for less than three years and which have an annual turnover below EUR 10 million"
- Checked: 2026-11-10

#### [M-0393] VERIFIED
- Claim: Art 17(7): users may rely on quotation, criticism, review, caricature, parody or pastiche exceptions when uploading.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(7)
- Quote: "Member States shall ensure that users in each Member State are able to rely on any of the following existing exceptions or limitations when uploading and making available content generated by users"
- Checked: 2026-11-10

#### [M-0395] VERIFIED
- Claim: Art 17(9): complaint processed without undue delay, with human review of decisions to disable or remove.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(9)
- Quote: "decisions to disable access to or remove uploaded content shall be subject to human review"
- Checked: 2026-11-10

#### [M-0622] VERIFIED
- Claim: Australia Copyright Act 1968 s.41A: a fair dealing with a literary, dramatic, musical or artistic work for the purpose of parody or satire is not infringement.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41A
- Quote: "musical or artistic work, or with an adaptation of a literary, dramatic or musical work, does not constitute an infringement of the copyright in the work if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0623] VERIFIED
- Claim: Australia s.103AA: a fair dealing with an audio-visual item for the purpose of parody or satire is not infringement of the item or works in it.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.103AA parody or satire (subject matter other than works) (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s103aa
- Pinpoint: Copyright Act 1968 (Cth) s.103AA
- Quote: "A fair dealing with an audio-visual item does not constitute an infringement of the copyright in the item or in any work or other audio-visual item included in the item if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0624] VERIFIED
- Claim: Australia: in Part IV Division 6 (s.100A) an audio-visual item means a sound recording, a cinematograph film, a sound broadcast or a television broadcast, so s.103AA reaches sound recordings.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.103AA parody or satire (subject matter other than works) (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s103aa
- Pinpoint: Copyright Act 1968 (Cth) s.100A (Part IV Division 6)
- Quote: "In this Division, audio-visual item means a sound recording, a cinematograph film, a sound broadcast or a television broadcast."
- Checked: 2026-11-13

#### [M-0625] VERIFIED
- Claim: Australia s.41: fair dealing for criticism or review needs a sufficient acknowledgement of the work.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41
- Quote: "for the purpose of criticism or review, whether of that work or of another work, and a sufficient acknowledgement of the work is made."
- Checked: 2026-11-13

#### [M-0626] VERIFIED
- Claim: Australia s.195AJ: derogatory treatment of a musical work includes material alteration or distortion prejudicial to the author's honour or reputation, under the author's right of integrity (s.195AI).
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) ss.195AI, 195AJ
- Quote: "the doing, in relation to the work, of anything that results in a material distortion of, the mutilation of, or a material alteration to, the work that is prejudicial to the author's honour or reputation"
- Checked: 2026-11-13
