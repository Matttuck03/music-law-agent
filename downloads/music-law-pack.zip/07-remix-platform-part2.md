# Music law knowledge pack: Remix platform, part 2
- File: 07-remix-platform-part2.md, part of the music law knowledge pack (remix edition).
- Contains: playbook DJ-mix platform playbook; playbook Quick answers for the DJ-mix platform team. Each card is followed by the claims it cites, with source, pinpoint and verbatim quote.
- Law last checked: not stated.
- Research tool, not legal advice. Have a licensed music attorney confirm anything before you act on it.
- Claim ids are M- plus four digits in square brackets. VERIFIED claims were checked against the saved source text. Claims tagged (unverified) were not confirmed; say so when you rely on one.

## playbook DJ-mix platform playbook

Research tool, not legal advice. Law last checked 2026-11-13.

## DJ-mix platform playbook

### What this page is
- A plain-words map for the team building a platform where ordinary people mix existing songs: blends, transitions, mashups, recorded mixes and maybe live mixes, fed by a tool that splits a song into stems.
- It assumes users may feed in anything, including commercial hits.
- It covers US law in depth and flags Canada, Australia, the UK and the EU where they differ sharply.
- Every legal statement carries a row id in square brackets. Rows marked "(analysis)" are reasoning, not quoted law. Where the law is unsettled or the base has no source, the page says so.
- Detail lives in cards M21 (remixes), M22 (covers), M23 (stem tools and DJ mixes), M24 (licensed models, distributors, stem model licences) and M25 (feature by feature).

### The ground rules in six lines
- Every track is two copyrights: the song and the recording [M-0025]. Each owner controls copies and derivative works [M-0108, M-0522].
- Remixing the actual recorded sounds is named in the statute as part of the recording owner's rights [M-0523].
- Playing songs to the public needs a performance licence [M-0106]. Streaming recordings online does too [M-0107].
- No saved source shows a remix exception or a compulsory remix licence in US law. A 2016 government paper looked at both and recommended neither (policy paper, not law) [M-0556].
- A tool maker's contributory liability turns on intent: what it says and what it builds the product to do [M-0562, M-0221, M-0223]. Vicarious and direct liability are separate theories that the 2026 ruling did not decide (analysis row) [M-0252].
- A host of user uploads can use the 512(c) safe harbor only if it meets every condition [M-0343, M-0345, M-0347, M-0349, M-0357].

### What needs no label deal (lowest risk, not cleared)
These are the lowest-risk pieces. None is risk-free. Each has open questions for the attorney.
- A mixing and stem tool that runs on the user's own device, where no commercial audio reaches the platform's servers.
  - Why (analysis): selling a product that is capable of substantial lawful uses is not, by that fact alone, contributory infringement [M-0560], and mere knowledge that some users infringe is not enough for contributory liability [M-0563, M-0222]. No saved case applies these rulings to a stem or mixing tool, and they do not cover direct or vicarious liability [M-0220, M-0252].
  - Condition: marketing, onboarding and design must not steer users to commercial hits [M-0562, M-0223].
  - Open: whether a stem split is an infringing copy, even in private, is unsettled [M-0110]. The home recording statute does not clearly help [M-0572, M-0575].
- Mixing of music where the user owns both the song and the recording, or has written permission from the owners of both.
  - Why: the owner of a work may authorise derivative works [M-0522], and the song and the recording are separate works [M-0025]. Get every permission in a signed writing (good practice; a transfer of ownership is not valid without one) [M-0040].
- An opt-in catalogue: artists and small labels who own both the song and the recording and grant the platform remix rights in writing.
  - Why: this is a direct licence from the owners of both works [M-0025, M-0522]. No major label deal is needed for music the majors do not control (analysis).
  - Condition: the grant must cover copying, stem splitting, derivative works, public performance and any download or export the product offers (analysis) [M-0108, M-0106, M-0107].
- Public sharing of mixes built wholly from that opt-in catalogue, or from music the user owns on both sides, the song and the recording [M-0025]. Condition (analysis): the grants cover public performance and sharing [M-0106, M-0107], and the platform can act when a user's ownership claim turns out to be false [M-0345, M-0348].
- User covers, audio only, where the user records every sound. No label is involved, because no original recording is used (analysis) [M-0111]. Publisher-side licences are still needed: a mechanical licence for each song, which is compulsory only if the statute's steps are followed [M-0339, M-0545], and public performance licences for the songs if the platform streams the covers (see card M05) [M-0183]. Whether the platform itself can use the blanket mechanical licence is an open question for counsel [M-0122]. Limits are in card M22 [M-0540, M-0542].
- The compliance kit, which costs nothing in deals: a registered copyright agent [M-0349], notice and takedown [M-0348], counter notice [M-0355], and a repeat infringer policy [M-0357].
- Needed before any item above: a stem model with a clean licence for its weights. This is a precondition, not something that can launch today. None of the public models checked on 2026-11-13 has weights with a stated licence that clearly allows commercial use [M-0603, M-0606, M-0604]. See card M24.

### What needs deals
- Public sharing of saved mixes that contain commercial tracks.
  - Needs: licences for the recordings and for the songs [M-0301, M-0106, M-0107]. The 114 statutory licence does not fit saved or on-demand mixes [M-0115, M-0578, M-0579].
  - How others do it: one licensed service says it has direct deals with labels, and another says it pays rights holders in each mix directly (company statements, captured 2026-11-13) [M-0589, M-0593].
- Live mixing of commercial tracks to an audience. Both the song and the recording are performed for every track [M-0106, M-0107]. One licensed service says the service must clear both (company blog, captured 2026-11-13) [M-0586].
- Downloads and export of mixes that contain commercial tracks. A download is a copy and a distribution of every work in the mix [M-0108]. One licensed service says downloads need an extra licensed right (company blog, captured 2026-11-13) [M-0588].
- Video of mixes. Video is outside the 114 licence [M-0112] and outside the compulsory mechanical licence [M-0544]. Sync is licensed directly [M-0140].
- An EU launch with public sharing. The platform itself needs authorisation for user uploads, or must meet the best efforts tests [M-0387, M-0389].
- The partner route: publish mixes only inside a service that already holds the licences. This still needs a contract with that service. The base has only such services' public statements, not their contract terms (gap) [M-0586, M-0590].

### What stays off limits
- Marketing or onboarding that invites users to split and mix commercial songs they do not own. This is the conduct Grokster punishes [M-0562].
- Presets, search or templates built around named hit records. This risks the "tailored to infringement" finding in Cox [M-0223].
- A platform-built shared library of stems split from commercial tracks. That is the platform's own copying, not user storage (analysis) [M-0110, M-0220, M-0343].
- Public downloads of mixes that contain unlicensed commercial tracks [M-0108, M-0582].
- Relying on the 114 statutory licence for saved or on-demand mixes [M-0115, M-0578].
- Telling users any of these: that changing a song enough makes it theirs [M-0534, M-0552]; that crediting the artist makes it fine [M-0220]; that a set number of seconds is fair use [M-0203, M-0205]; that a cover licence covers a remix [M-0542, M-0540]; that not selling it makes it legal [M-0220, M-0549].
- Telling users they own their mixes without limits. They own at most what they added [M-0529], and nothing in parts that use others' material unlawfully [M-0528].
- Shipping stem model weights in a paid product when the weights are stated non-commercial or research-only [M-0606, M-0603], or when the licence is silent and no one has given a written grant [M-0604, M-0609].
- Ads or creator payouts tied to mixes of unlicensed tracks. A direct financial benefit from infringement the platform can control costs it the safe harbor [M-0347, M-0515].
- Ignoring takedown notices or repeat infringers [M-0348, M-0357].

### Decision page: the two open choices
Two choices are not yet made. Each path below lists what it needs. The four combinations follow.

#### Choice A: private-only use, or public release
- Path A1, private only. Users mix and save on their own device. Nothing is shared through the platform.
  - Needs: on-device processing where possible; no public links; lawful-use marketing; a stem model with a clean licence; clear user terms.
  - Rights in play: copies and the derivative work question on the user's side [M-0110, M-0522]. No public performance by the platform (analysis) [M-0106].
  - Main risk: tool maker liability if the product is promoted or shaped for infringement [M-0562, M-0223]. The open stem copy question [M-0110].
  - Who carries it: mostly the user (analysis). The platform as tool maker.
  - What it gives up: sharing, audience, most network growth.
- Path A2, public release. Users publish mixes for others to hear.
  - Needs: licences for recordings and songs [M-0301, M-0106, M-0107], or a licensed partner; the full 512(c) kit as a backstop [M-0343]; a plan for the EU [M-0387].
  - Main risk: direct and secondary liability for hosted and streamed mixes; loss of the safe harbor through red flag knowledge or financial benefit [M-0345, M-0347]; statutory damages per work [M-0215, M-0217].
  - Who carries it: the user and the platform together.

#### Choice B: any music, or a licensed catalogue
- Path B1, any music. Users bring any track, including commercial hits.
  - Needs: the full 512(c) kit [M-0343, M-0349, M-0357]; design and marketing that do not induce [M-0562]; a view from counsel on stems stored server-side.
  - Main risk: most uploads will be tracks no one cleared. The safe harbor has knowledge and financial benefit conditions [M-0344, M-0345, M-0347]. Cox narrowed contributory liability but left vicarious liability open [M-0222, M-0252].
- Path B2, licensed catalogue. Users mix only tracks the platform has rights to: opt-in artists, direct deals, or a partner's catalogue.
  - Needs: written grants that cover remixing, since remixing is a derivative work right [M-0522, M-0523], plus the performance and copy rights the features use.
  - Main risk: small catalogue at first; the cost and time of deals. Legal risk is far lower because the owners agreed (analysis).

#### The four combinations
- A1 plus B1, private tool, any music. Launch needs: no label or publisher deals, but a stem model whose weights are licensed for commercial use [M-0603, M-0606], marketing and design that do not steer users to commercial hits [M-0562, M-0223], and counsel's answer on whether a stem split is itself an infringing copy [M-0110]. Risk: unsettled and not rated. No saved case applies the tool maker rulings to a stem or mixing tool [M-0560, M-0562, M-0221], and the home recording statute does not clearly help [M-0575].
- A1 plus B2, private tool, licensed catalogue. Launch needs: opt-in grants. Risk: lowest of the four (analysis), if the grants cover both the song and the recording and the stem model licence is clean.
- A2 plus B2, public release, licensed catalogue. Launch needs: grants that cover public performance and sharing. Risk: low (analysis) if the grants are complete and each grantor really owns both the song and the recording. This is the first public feature to ship.
- A2 plus B1, public release, any music. Launch needs: label and publisher deals or a licensed partner [M-0589, M-0593]. Without them the platform stands on the safe harbor alone [M-0343], in a product whose purpose makes red flag knowledge more likely (analysis) [M-0345]. Risk: highest. Do not ship this without counsel's sign-off.

### Risk register
- Risk 1, inducement by marketing or design.
  - What: the platform is held liable for users' infringement because of its own words or design [M-0562, M-0223]. The researchers' reading that this applies to a stem or mixing tool is their analysis and no case confirms it (unverified) [M-0564].
  - Who carries it: platform.
  - Lower it: lawful-use marketing, no hit-based presets, written review of all launch copy.
- Risk 2, direct liability for server-side copies and streams.
  - What: the platform itself copies, splits, renders or streams works [M-0220, M-0110]. The base has no row on the test for who "does" the act (gap).
  - Who carries it: platform.
  - Lower it: process on the device; store per user only; ask counsel.
- Risk 3, loss of the safe harbor.
  - What: red flag knowledge without removal [M-0345, M-0346], direct financial benefit [M-0347, M-0515], no registered agent or a lapsed one [M-0349, M-0354], no real repeat infringer policy [M-0357].
  - Who carries it: platform.
  - Lower it: run the kit from day one; keep money away from unlicensed mixes.
- Risk 4, statutory damages at scale.
  - What: $750 to $30,000 per work, up to $150,000 if willful [M-0215, M-0217], counted per work (analysis row) [M-0254]. One mix can hold many works.
  - Who carries it: user and platform.
  - Lower it: licensed catalogue; fast takedown; no public downloads.
- Risk 5, the stem copy question.
  - What: a court could hold that splitting a track is an infringing reproduction even in private [M-0110]. Unsettled.
  - Who carries it: user first; platform if the split happens on its servers.
  - Lower it: on-device splitting; attorney opinion before launch.
- Risk 6, stem model licence.
  - What: weights that are non-commercial, research-only or silent [M-0606, M-0603, M-0604], trained on a set with non-commercial tracks [M-0614].
  - Who carries it: platform.
  - Lower it: licensed or self-trained model; written grant.
- Risk 7, wrong statutory licence.
  - What: treating saved mixes as covered by section 114 [M-0115, M-0578, M-0579] or remixes as covered by a cover licence [M-0542].
  - Who carries it: platform.
  - Lower it: use these licences only where card M22 and card M23 say they fit.
- Risk 8, foreign law.
  - What: EU platform liability for uploads [M-0387, M-0388]; UK and Australian moral rights [M-0628, M-0626]; narrow exceptions only [M-0240, M-0622]; Canada's exception limited to non-commercial acts by individuals [M-0616].
  - Who carries it: platform and user.
  - Lower it: launch in one country first; get local advice before each new country.
- Risk 9, user ownership claims.
  - What: users believe they own mixes and try to license or monetise them [M-0529, M-0528].
  - Who carries it: user; platform through support load and disputes.
  - Lower it: plain terms and in-app wording.
- Risk 10, vicarious liability.
  - What: liability based on control plus financial benefit. Cox did not decide it (analysis row) [M-0252].
  - Who carries it: platform.
  - Lower it: pricing that does not earn from infringing mixes; counsel review.

### Rollout order
- Step 0, before building further.
  - Put the attorney questions (the page "Questions for a licensed music attorney") to a licensed music attorney.
  - Pick a stem model with a clean weights licence or get a written grant.
  - Write marketing rules: lawful uses only, no hit names.
- Step 1, private tool. On-device mixing and stem splitting, local save, no sharing. User's own files.
- Step 2, opt-in catalogue. Sign written remix grants with independent artists and labels. Let users mix that catalogue.
- Step 3, public sharing of mixes built wholly from the opt-in catalogue or the user's own music. Launch the 512(c) kit at the same time.
- Step 4, cloud save for private mixes, per user, only after counsel confirms the storage design.
- Step 5, commercial tracks in public mixes, only through direct deals or a licensed partner.
- Step 6, live mixing, on the same licensed footing as Step 5.
- Step 7, downloads and export, only for content whose licences cover downloads.
- Step 8, other countries, one at a time, with local advice. Canada, the UK, the EU and Australia each have their own rules (card M25).

### What this page does not settle
- Whether stem splitting is itself a reproduction. No saved case.
- Whether a DJ mix is a compilation, a derivative work or both. No saved authority decides [M-0569, M-0521].
- What a club or venue licence covers. No venue licence text is saved.
- Live-stream music terms of services other than Mixcloud. Not captured.
- The contract terms and prices of any licensed mix service. Not public in the saved set.

### Claims cited in dj-platform
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0556] VERIFIED
- Claim: The Task Force concluded the record had not established a need to create a specific remix exception or a compulsory licence for remix uses, and recommended guidelines, more voluntary licensing and education.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 4
- Quote: "the record has not established a need to amend existing law to create a specific exception or a compulsory license for remix uses"
- Checked: 2026-11-13

#### [M-0562] VERIFIED
- Claim: Grokster (2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for third-party infringement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919 (syllabus Held; opinion at 936-937)
- Quote: "one who distributes a device with the object of promoting its use to infringe copyright, as shown by clear expression or other"
- Checked: 2026-11-13

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0560] VERIFIED
- Claim: Sony v. Universal (1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 434-442)
- Quote: "does not constitute contributory infringement if the product is widely used for legitimate, unobjectionable purposes, or, indeed, is merely capable of substantial noninfringing uses"
- Checked: 2026-11-13

#### [M-0563] VERIFIED
- Claim: Grokster: mere knowledge that a product could be or is used to infringe is not enough for liability, and ordinary product support is not inducement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 937
- Quote: "mere knowledge of infringing potential or of actual infringing uses would not be enough here to subject a distributor to liability"
- Checked: 2026-11-13

#### [M-0222] VERIFIED
- Claim: Cox (2026): mere knowledge that a service will be used to infringe is insufficient to establish the required intent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part II.B
- Quote: "mere knowledge that a service will be used to infringe is insufficient to establish the required intent to infringe."
- Checked: 2026-11-10

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0572] VERIFIED
- Claim: The Audio Home Recording Act bars infringement actions based on the manufacture, importation or distribution of a digital audio recording device, digital audio recording medium, analog recording device or analog recording medium, or on a consumer's noncommercial use of such a device or medium for making digital or analog musical recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1008 Prohibition on certain infringement actions (https://www.law.cornell.edu/uscode/text/17/1008), source id usc17-1008
- Pinpoint: 17 U.S.C. 1008
- Quote: "based on the noncommercial use by a consumer of such a device or medium for making digital musical recordings or analog musical recordings"
- Checked: 2026-11-13

#### [M-0575] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): a computer hard drive is excluded from the Act's definition of a digital music recording, so the Rio, which copies from a hard drive, does not record directly from a digital music recording.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "a hard drive is a material object in which one or more programs are fixed; thus, a hard drive is excluded from the definition of digital music recordings"
- Checked: 2026-11-13

#### [M-0040] VERIFIED
- Claim: A transfer of copyright ownership, other than by operation of law, is not valid unless in a writing signed by the owner of the rights conveyed or the owner's authorized agent.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 204 execution of transfers of copyright ownership (https://www.law.cornell.edu/uscode/text/17/204), source id usc17-204
- Pinpoint: 17 U.S.C. 204(a)
- Quote: "A transfer of copyright ownership, other than by operation of law, is not valid unless an instrument of conveyance, or a note or memorandum of the transfer, is in writing and signed by the owner"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0545] VERIFIED
- Claim: First-use rule: the compulsory licence is available only if phonorecords of the work have previously been distributed to the public in the US under the authority of the copyright owner, or, for a digital music provider's digital phonorecord deliveries, the first fixation of the sound recording was made under the musical work owner's authority and the recording owner authorised the deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)(i)-(ii)
- Quote: "phonorecords of such musical work have previously been distributed to the public in the United States under the authority of the copyright owner of the work"
- Checked: 2026-11-13

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0122] VERIFIED
- Claim: The blanket licence lets a qualifying digital music provider obtain a licence through the MLC for digital phonorecord deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(d)(1)(A)
- Quote: "A digital music provider that qualifies for a compulsory license under subsection (a) may, by complying with the terms and conditions of this subsection, obtain a blanket license from copyright owners through the mechanical licensing collective"
- Checked: 2026-11-10

#### [M-0540] VERIFIED
- Claim: A compulsory licence under 115 includes the privilege of an arrangement only to the extent necessary to conform the work to the style of the performance; it may not change the basic melody or fundamental character.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "the arrangement shall not change the basic melody or fundamental character of the work"
- Checked: 2026-11-13

#### [M-0542] VERIFIED
- Claim: The compulsory licence is for making and distributing phonorecords of a nondramatic musical work (the composition); it is not a licence of any sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)-(B)
- Quote: "obtain a compulsory license to make and distribute phonorecords of a nondramatic musical work"
- Checked: 2026-11-13

#### [M-0355] VERIFIED
- Claim: On a counter notice the provider replaces the removed material not less than 10 nor more than 14 business days after receipt, unless the notifier first tells its designated agent (of a court action; see rest of 512(g)(2)(C)).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(g)(2)(C)
- Quote: "replaces the removed material and ceases disabling access to it not less than 10, nor more than 14, business days following receipt of the counter notice, unless its designated agent first receives notice from the person who submitted the notification"
- Checked: 2026-11-10

#### [M-0603] VERIFIED
- Claim: Demucs maintainer in issue 384 (2022-09-29): the code is free for commercial use under MIT, but the weights are research artefacts provided only for personal or research usage.
- Jurisdiction: industry
- Source: facebookresearch/demucs issue 384 Legality of publishing audio output (maintainer comment) (https://github.com/facebookresearch/demucs/issues/384), source id demucs-issue-384
- Pinpoint: Issue 384, comment by adefossez 2022-09-29
- Quote: "The weights themselves are however just a research artefacts and provided only for personal / research usage."
- Checked: 2026-11-13

#### [M-0606] VERIFIED
- Claim: Open-Unmix README: the default umxl weights are licensed for non-commercial use only (CC BY-NC-SA 4.0).
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxl
- Quote: "Note, that the weights are only licensed for non-commercial use (CC BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0604] VERIFIED
- Claim: Spleeter README: the code of Spleeter is MIT licensed. The License section states nothing separate about the pretrained model weights (silence, not a grant).
- Jurisdiction: industry
- Source: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md), source id spleeter-readme
- Pinpoint: README, License section
- Quote: "The code of Spleeter is MIT-licensed."
- Checked: 2026-11-13

#### [M-0301] VERIFIED
- Claim: An interactive service may not publicly perform a sound recording unless a licence has been granted for the public performance of any copyrighted musical work contained in it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(3)(C)
- Quote: "an interactive service may not publicly perform a sound recording unless a license has been granted for the public performance of any copyrighted musical work contained in the sound recording"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0579] VERIFIED
- Claim: Under the 114 statutory licence a transmission may not be part of an archived program of 5 hours or more that is made available for more than 2 weeks, so a permanent on-demand mix archive does not meet that condition.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(II)
- Quote: "is not part of an archived program of 5 hours or greater in duration that is made available for a period exceeding 2 weeks"
- Checked: 2026-11-13

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0544] VERIFIED
- Claim: The Office states a phonorecord does not include sounds accompanying a motion picture or other audiovisual work, so the compulsory licence does not cover putting a song in video.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "A phonorecord does not include sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-13

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0590] VERIFIED
- Claim: Mixcloud describes its live product as a licensed live streaming platform that also archives the stream as a recording.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Mixcloud Live is the world's first music-focused, licensed live streaming platform."
- Checked: 2026-11-13

#### [M-0582] VERIFIED
- Claim: The statutory licence requires the service to take no affirmative steps to cause or induce the recipient to make a phonorecord, so a download button on mixes is outside it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vi)
- Quote: "the transmitting entity takes no affirmative steps to cause or induce the making of a phonorecord by the transmission recipient"
- Checked: 2026-11-13

#### [M-0534] VERIFIED
- Claim: Pickett rejected the idea that a stranger may make a derivative work without permission if the original does not pervade the derivative; it would undermine the 106(2) right.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402
- Quote: "would inject enormous uncertainty into the law of copyright and undermine the exclusive right that section 106(2) gives the owner of the copyright on the original work"
- Checked: 2026-11-13

#### [M-0552] VERIFIED
- Claim: Warhol: reading Campbell to favour any use adding new expression would let transformative use swallow the owner's right to prepare derivative works.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "transformative use would swallow the copyright owner’s exclusive right to prepare derivative works"
- Checked: 2026-11-13

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0205] VERIFIED
- Claim: Campbell: fair use requires case-by-case analysis and is not simplified by bright-line rules.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 577 (Part II.A, opinion of the Court)
- Quote: "The task is not to be simplified with bright-line rules, for the statute, like the doctrine it recognizes, calls for case-by-case analysis."
- Checked: 2026-11-10

#### [M-0549] VERIFIED
- Claim: Campbell: a commercial nature is only one element of factor one; no presumption that every commercial use is unfair.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus
- Quote: "The statute makes clear that a work's commercial nature is only one element of the first factor enquiry into its purpose and character"
- Checked: 2026-11-13

#### [M-0529] VERIFIED
- Claim: Copyright in a derivative work or compilation covers only the new material the author contributed and gives no exclusive right in the preexisting material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(b)
- Quote: "The copyright in a compilation or derivative work extends only to the material contributed by the author of such work"
- Checked: 2026-11-13

#### [M-0528] VERIFIED
- Claim: Under Section 103(a), protection for a work employing preexisting copyrighted material does not extend to any part of the work in which the material has been used unlawfully.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(a)
- Quote: "protection for a work employing preexisting material in which copyright subsists does not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0609] VERIFIED
- Claim: python-audio-separator README: the default model is a BS-Roformer checkpoint file (model_bs_roformer_ep_317_sdr_12.9755), described as BS-Roformer-Viperx-1297; the README gives no licence for that checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, CLI options and supported model list
- Quote: "default: model_bs_roformer_ep_317_sdr_12.9755.yaml"
- Checked: 2026-11-13

#### [M-0515] VERIFIED
- Claim: Ninth Circuit (Mavrix v. LiveJournal, 2017): the 512(c) financial benefit test is a common-sense, fact-based inquiry, and the benefit need not be substantial or a large proportion of revenue.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 512(c)(1)(B) discussion
- Quote: "The financial benefit need not be substantial or a large proportion of the service provider’s revenue."
- Checked: 2026-11-10

#### [M-0215] VERIFIED
- Claim: Statutory damages range from $750 to $30,000 per work, as the court considers just, at the owner's election.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "in a sum of not less than $750 or more than $30,000 as the court considers just."
- Checked: 2026-11-10

#### [M-0217] VERIFIED
- Claim: Willful infringement raises the statutory maximum to $150,000 per work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0564] UNVERIFIED (unverified)
- Claim: Analysis: a stem-splitting or mixing tool maker whose marketing or onboarding steers users to split and mix commercial songs they do not own is exposed to Grokster inducement through its own statements and design, not through the tool's capability alone.
- Jurisdiction: analysis
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919
- Quote: "going beyond mere distribution with knowledge of third-party action"
- Checked: 2026-11-13

#### [M-0346] VERIFIED
- Claim: On gaining knowledge or awareness the provider must act expeditiously to remove or disable access.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(iii)
- Quote: "upon obtaining such knowledge or awareness, acts expeditiously to remove, or disable access to, the material"
- Checked: 2026-11-10

#### [M-0354] VERIFIED
- Claim: A designation expires three years after registration unless renewed by amending or resubmitting it.
- Jurisdiction: US-federal
- Source: 37 CFR 201.38 designation of agent to receive notification of claimed infringement (eCFR as of 2026-10-26) (https://www.ecfr.gov/api/versioner/v1/full/2026-10-26/title-37.xml?part=201&section=201.38), source id cfr37-201-38
- Pinpoint: 37 CFR 201.38(c)(4)
- Quote: "A service provider's designation will expire and become invalid three years after it is registered with the Office"
- Checked: 2026-11-10

#### [M-0254] VERIFIED
- Claim: Analysis: statutory damages are awarded per work infringed, up to $150,000 per work if willful (ordinary range $750 to $30,000), and only for works registered in time (s.412); exposure is per work, not per view.
- Jurisdiction: analysis
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0614] VERIFIED
- Claim: MUSDB18 includes 46 tracks from MedleyDB licensed under Creative Commons BY-NC-SA 4.0 (non-commercial, share-alike).
- Jurisdiction: industry
- Source: SigSep MUSDB18 dataset page (https://sigsep.github.io/datasets/musdb.html), source id musdb18-sigsep
- Pinpoint: MUSDB18 dataset page, composition list
- Quote: "46 tracks are taken from the MedleyDB (opens new window) licensed under Creative Commons (BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0388] VERIFIED
- Claim: Art 17(3): the Article 14(1) e-Commerce hosting safe harbor does not apply to these situations.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(3)
- Quote: "the limitation of liability established in Article 14(1) of Directive 2000/31/EC shall not apply to the situations covered by this Article"
- Checked: 2026-11-10

#### [M-0628] VERIFIED
- Claim: UK CDPA s.80(2)(b): treatment is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author.
- Jurisdiction: UK
- Source: CDPA 1988 s.80 right to object to derogatory treatment of work (https://www.legislation.gov.uk/ukpga/1988/48/section/80), source id uk-cdpa-s80
- Pinpoint: CDPA s.80(2)(b)
- Quote: "the treatment of a work is derogatory if it amounts to distortion or mutilation of the work or is otherwise prejudicial to the honour or reputation of the author or director;"
- Checked: 2026-11-13

#### [M-0626] VERIFIED
- Claim: Australia s.195AJ: derogatory treatment of a musical work includes material alteration or distortion prejudicial to the author's honour or reputation, under the author's right of integrity (s.195AI).
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) ss.195AI, 195AJ
- Quote: "the doing, in relation to the work, of anything that results in a material distortion of, the mutilation of, or a material alteration to, the work that is prejudicial to the author's honour or reputation"
- Checked: 2026-11-13

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0622] VERIFIED
- Claim: Australia Copyright Act 1968 s.41A: a fair dealing with a literary, dramatic, musical or artistic work for the purpose of parody or satire is not infringement.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41A
- Quote: "musical or artistic work, or with an adaptation of a literary, dramatic or musical work, does not constitute an infringement of the copyright in the work if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0616] VERIFIED
- Claim: Canada s.29.21(1)(a): the use or the authorization to disseminate the new work must be solely for non-commercial purposes.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(a)
- Quote: "is done solely for non-commercial purposes;"
- Checked: 2026-11-13

#### [M-0569] VERIFIED
- Claim: A compilation is a work formed by collecting and assembling preexisting materials selected, coordinated or arranged so the whole is an original work of authorship.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'compilation'
- Quote: "selected, coordinated, or arranged in such a way that the resulting work as a whole constitutes an original work of authorship"
- Checked: 2026-11-13

#### [M-0521] VERIFIED
- Claim: A derivative work is one based on preexisting works; the statute's examples include a musical arrangement and a sound recording, and 'any other form in which a work may be recast, transformed, or adapted'.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 101 definitions (https://www.law.cornell.edu/uscode/text/17/101), source id usc17-101
- Pinpoint: 17 U.S.C. 101 'derivative work'
- Quote: "any other form in which a work may be recast, transformed, or adapted"
- Checked: 2026-11-13

## playbook Quick answers for the DJ-mix platform team

Research tool, not legal advice. Law last checked 2026-11-13.

## Quick answers for the DJ-mix platform team

How to read this page: each answer is short and carries claim ids in square brackets. US law unless a country is named. "(analysis)" marks reasoning. "Gap" or "unsettled" means the base has no source that decides the point. Service statements carry their capture date. "The base" means the research behind these pages.

### The myths

#### 1. If I change a song enough, is it mine?
- No. Only the owner may make or authorise works based on the original [M-0522]. One appeals court rejected the idea that a stranger may make one when the original does not pervade the new work [M-0534]. The Supreme Court warned that adding new expression is not enough by itself [M-0552].
- You can own only what you added [M-0529], and not even that in parts where others' material is used unlawfully [M-0528].

#### 2. Is anything under a set number of seconds safe?
- No. The fair use statute has four factors and no number of seconds [M-0203, M-0547]. Courts decide case by case with no bright-line rules [M-0205]. The base's own summary: there is no safe length (analysis row) [M-0251].
- One trial court found a 35-second sample a fair use of the song (the composition) on its facts. That is one case, not a rule, and the base has not checked its later history [M-0212]. One appeals court said of recordings: get a licence or do not sample [M-0186]. Another allows very small uses only if an average listener would not recognise them [M-0188, M-0191].

#### 3. Does crediting the artist make it fine?
- No. Anyone who violates an exclusive right is an infringer [M-0220]. That rule has no credit exception (analysis).
- Credit matters only as one condition inside some foreign exceptions, such as Canada's user content exception [M-0617]. It never works alone.

#### 4. I am not selling it. Is that enough?
- No. Infringement does not depend on a sale [M-0220] (analysis). Commercial use is only one element of one fair use factor [M-0549, M-0553].
- Statutory damages are set per work, not by what you earned [M-0215, M-0254].

#### 5. Does a cover licence cover a remix?
- No. The compulsory cover licence is for the song only and is not a licence of any recording [M-0542]. It bars changes to the basic melody or fundamental character [M-0540].
- One distributor says derivative works such as samples cannot go through its cover process (web archive copy dated 2026-02-16, captured 2026-11-13) [M-0597].

#### 6. DJs do it in clubs, so is it legal online?
- That does not follow. Permission to perform a song in public does not supply the right to copy it (analysis row) [M-0183].
- The base has no saved club or venue licence text, so it makes no claim about what such a licence covers (gap).
- Online, a licensed mix service says both the song and the recording of every track must be cleared by the service (company blog, captured 2026-11-13) [M-0586].

### Rights basics

#### 7. What rights sit in one track?
- Two separate copyrights: the song and the recording [M-0025]. Both carry a right to copy [M-0108]. Songs carry a public performance right [M-0106]. Recordings carry one only for digital audio transmission [M-0107].

#### 8. Who has to say yes to a remix?
- Both owners of each track. Each controls derivative works of its own work [M-0522]. For the recording that covers rearranging, remixing or altering the actual sounds [M-0523].

#### 9. I bought the track. Can I mix it and share the mix?
- Buying a copy is not shown in the base to carry the rights to copy, remix or perform in public. Those rights belong to the owners [M-0108, M-0522, M-0106]. The base has no row on what a download store's terms allow (gap).

#### 10. Who owns a mix I make?
- At most, you own the new material you added [M-0529]. Parts that use others' material unlawfully get no protection [M-0528].
- Courts differ at the edges. The Second Circuit allows a claim to original additions when the use is fair [M-0535]. The Seventh Circuit took a harder line [M-0532].

#### 11. Is re-playing a part myself safer than using the original audio?
- Only if every sound is newly recorded, and then it removes the recording owner only. A new recording of independently made sounds does not infringe the recording, but the song is still a separate copyright [M-0111].

#### 12. Could my mix be fair use?
- Perhaps, but do not plan on it. Fair use is a defence and the user carries the burden [M-0211]. When the new use shares the purpose of the original and is commercial, factor one likely weighs against it [M-0551].
- The base has no case on whether a DJ mix or mashup is fair use (gap).

#### 13. Is a mashup a parody?
- Only if it comments on the original. Parody needs to mimic the original to make its point. Satire that uses a song to comment on something else needs its own justification [M-0548]. Applying this to a mashup is analysis.

#### 14. Is there a remix exception or a compulsory remix licence in the US?
- No saved source shows one. A 2016 government paper found no proven need for either (policy paper, not law) [M-0556].

### Covers and video

#### 15. What does a cover licence allow?
- Making and distributing your own audio recording of a song that was already released [M-0339, M-0545], with an arrangement that fits your style [M-0540]. Nothing more.

#### 16. Can I post a video of my cover or mix?
- Not under the cover licence. It does not reach audiovisual works [M-0544]. Video needs a sync licence agreed directly with the publisher [M-0140], plus the recording owner's licence if original audio is used (analysis) [M-0522].

#### 17. Will a distributor release my remix or mashup?
- The saved pages give covers a route [M-0596] and say sample-based works need the master cleared with the label and the song with the publisher, by direct deal [M-0599]. Captured 2026-11-13. Other distributors were not captured.

### The tool and the platform

#### 18. Is it illegal to make a stem splitter?
- Not by itself on the contributory liability cases (analysis; no saved case is about a stem or mixing tool). Selling a product capable of substantial lawful uses is not contributory infringement [M-0560], and mere knowledge of misuse is not enough [M-0563]. Vicarious and direct liability are separate questions [M-0252].
- It becomes a problem when the maker promotes infringing use or tailors the product to it [M-0562, M-0223].

#### 19. Is splitting a song into stems an infringing copy?
- Unsettled. A stem holds the actual recorded sounds, which is what the recording owner's copy right covers [M-0110] (analysis). No saved case rules on stem splitting, in private or in public.

#### 20. Does home recording law cover private mixing?
- Doubtful. The statute protects consumers' noncommercial use of listed recording devices and media [M-0572]. An appeals court kept computer hard drives outside the Act [M-0575]. No case applies it to stem software.

#### 21. Can our marketing get us into trouble?
- Yes. Liability for inducement turns on clear expression or other affirmative steps to foster infringement [M-0562].
- The researchers read this as reaching a tool maker whose marketing steers users to commercial songs they do not own. That reading is not confirmed by any case (unverified) [M-0564].

#### 22. Did Cox v. Sony make platforms safe?
- No. It held that contributory liability needs intent, and mere knowledge is not enough [M-0221, M-0222]. It did not decide vicarious liability (analysis row) [M-0252], and one Justice said other theories could apply [M-0225].

#### 23. Does the DMCA safe harbor protect us when users upload hits?
- Only if every condition is met: user-directed storage [M-0343], no actual or red flag knowledge [M-0344, M-0345], fast removal [M-0348], no direct financial benefit from infringement you can control [M-0347], a registered agent [M-0349], and a repeat infringer policy [M-0357].
- Whether it covers files the platform's own tool rendered is a question for counsel.

#### 24. Do we have to scan every upload?
- Not for the US safe harbor. It is not conditioned on monitoring [M-0358]. Actual knowledge that material is infringing, or awareness of facts that make it apparent, still removes the protection [M-0344, M-0345].
- The EU differs. A platform must make best efforts to keep identified works unavailable [M-0390], though there is no general monitoring duty [M-0394].

#### 25. Can we host saved mixes under the webcasting licence?
- No. The section 114 licence bars interactive services [M-0115], archived programs under 5 hours [M-0578], and longer archives kept up more than 2 weeks [M-0579].

#### 26. Could a radio-style stream of mixes use that licence?
- In theory, with strict limits: caps on tracks per record and per artist in any 3 hours [M-0581], no advance track list [M-0580], track details on screen [M-0584], no help with copying [M-0582], lawfully made source copies [M-0583]. The songs need their own performance licences [M-0106].

#### 27. What does a live DJ stream need?
- Each track is performed as a song and as a recording [M-0106, M-0107]. One licensed service says the service must clear both (company blog, captured 2026-11-13) [M-0586]. Video is outside the 114 licence [M-0112].
- Other services' live-stream terms were not captured (gap).

#### 28. How do the licensed mix services do it?
- By their own account, with direct label deals and a way to pay rights holders inside each mix [M-0589, M-0592, M-0593]. Mixcloud statements captured 2026-11-13. Apple notice dated 2021-11-16, captured 2026-11-13. These are company statements, not law.

#### 29. Can users download or export mixes?
- That adds copying and distribution of every work in the mix [M-0108]. The 114 licence bars inducing copies [M-0582]. One licensed service says downloads need an extra licensed right (captured 2026-11-13) [M-0588].

#### 30. Does charging money change the risk?
- Yes, in several tests. A direct financial benefit from infringement can cost the safe harbor, and it need not be large [M-0347, M-0515]. Commercial use weighs in fair use [M-0551]. Canada's user exception needs a solely non-commercial purpose [M-0616].

#### 31. How large can damages be?
- Statutory damages run $750 to $30,000 per work [M-0215], up to $150,000 per work if willful [M-0217], counted per work, not per view (analysis row) [M-0254]. They depend on timely registration [M-0214].

### Stem models

#### 32. The stem model's code is MIT. Can we ship it in a paid app?
- The code, yes on its face. The weights are a separate question. For Demucs the licence file is silent on weights [M-0600] and a maintainer says the weights are for personal or research usage [M-0603]. Checked 2026-11-13.

#### 33. The model page says nothing about a licence. Is that permission?
- No. Silence is not a grant [M-0604, M-0607, M-0609]. Get a written grant from someone able to give it.

#### 34. Which of the checked models are clearly fine for commercial use?
- None, on their stated weights terms as checked 2026-11-13. One is non-commercial [M-0606]. One is described as research or personal use [M-0603]. The others are silent [M-0604, M-0609, M-0610].

### Other countries

#### 35. Does Canada's user content exception make mixes legal there?
- It can protect an individual, not clearly a platform. Conditions: solely non-commercial [M-0616], source named where reasonable [M-0617], reasonable belief the source copy was lawful [M-0618], and no substantial harm to the market for the original [M-0619]. The platform's own position rests on inference [M-0620].

#### 36. Do the UK and EU pastiche rules cover mixes?
- Not as a general rule. The UK has a fair dealing exception for caricature, parody or pastiche [M-0240]. The EU court's 2026 press release reads pastiche to include some sampling in artistic dialogue [M-0631], and says it is not a catch-all [M-0633]. That row rests on a press release, not the judgment.

#### 37. Is the platform itself liable for uploads in the EU?
- Yes, if the service counts as an online content-sharing service provider, unless it is licensed or meets the best efforts tests. A content-sharing platform communicates user uploads to the public and must get authorisation [M-0387, M-0389]. New, small providers have a lighter regime [M-0392].

#### 38. What about Australia?
- The saved sections cover parody or satire [M-0622, M-0623] and criticism or review with acknowledgement [M-0625]. Authors also have an integrity right [M-0626]. The base holds no Australian user content exception and makes no claim about the rest of the Act.

### Claims cited in quick-answers
Each claim below gives its status, source, pinpoint and verbatim quote. In quotes a long dash in the source is shown as --.

#### [M-0522] VERIFIED
- Claim: The copyright owner has the exclusive right to prepare derivative works, and to authorize others to do so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(2)
- Quote: "the owner of copyright under this title has the exclusive rights to do and to authorize any of the following"
- Checked: 2026-11-13

#### [M-0534] VERIFIED
- Claim: Pickett rejected the idea that a stranger may make a derivative work without permission if the original does not pervade the derivative; it would undermine the 106(2) right.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402
- Quote: "would inject enormous uncertainty into the law of copyright and undermine the exclusive right that section 106(2) gives the owner of the copyright on the original work"
- Checked: 2026-11-13

#### [M-0552] VERIFIED
- Claim: Warhol: reading Campbell to favour any use adding new expression would let transformative use swallow the owner's right to prepare derivative works.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "transformative use would swallow the copyright owner’s exclusive right to prepare derivative works"
- Checked: 2026-11-13

#### [M-0529] VERIFIED
- Claim: Copyright in a derivative work or compilation covers only the new material the author contributed and gives no exclusive right in the preexisting material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(b)
- Quote: "The copyright in a compilation or derivative work extends only to the material contributed by the author of such work"
- Checked: 2026-11-13

#### [M-0528] VERIFIED
- Claim: Under Section 103(a), protection for a work employing preexisting copyrighted material does not extend to any part of the work in which the material has been used unlawfully.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 103 compilations and derivative works (https://www.law.cornell.edu/uscode/text/17/103), source id usc17-103
- Pinpoint: 17 U.S.C. 103(a)
- Quote: "protection for a work employing preexisting material in which copyright subsists does not extend to any part of the work in which such material has been used unlawfully"
- Checked: 2026-11-13

#### [M-0203] VERIFIED
- Claim: Section 107 makes fair use a four-factor, non-exhaustive test; the statute states no number of seconds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0547] VERIFIED
- Claim: Section 107 lists four fair use factors: purpose and character (commercial or nonprofit), nature of the work, amount and substantiality used, and market effect.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "the amount and substantiality of the portion used in relation to the copyrighted work as a whole"
- Checked: 2026-11-13

#### [M-0205] VERIFIED
- Claim: Campbell: fair use requires case-by-case analysis and is not simplified by bright-line rules.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 577 (Part II.A, opinion of the Court)
- Quote: "The task is not to be simplified with bright-line rules, for the statute, like the doctrine it recognizes, calls for case-by-case analysis."
- Checked: 2026-11-10

#### [M-0251] VERIFIED
- Claim: Analysis: fair use is decided case by case on the four factors in 17 U.S.C. 107, including commercial nature and amount used; the statute sets no safe length or seconds rule, so background music in a monetised video must be argued on its facts.
- Jurisdiction: analysis
- Source: 17 U.S.C. 107 fair use (https://www.law.cornell.edu/uscode/text/17/107), source id usc17-107
- Pinpoint: 17 U.S.C. 107
- Quote: "In determining whether the use made of a work in any particular case is a fair use the factors to be considered shall include--"
- Checked: 2026-11-10

#### [M-0212] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017) held a 35-second sample in Pound Cake was a fair use of the Jimmy Smith composition.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 752
- Quote: "this Court concludes that Defendants’ inclusion of the copied portions of JSR in the recording of Pound Cake is a fair use and"
- Checked: 2026-11-10

#### [M-0186] VERIFIED
- Claim: Sixth Circuit rule: for sampling a sound recording, the court says get a license or do not sample (no de minimis or substantial similarity inquiry).
- Jurisdiction: case-law
- Source: Bridgeport Music, Inc. v. Dimension Films, 410 F.3d 792 (6th Cir. 2005) (amended on rehearing) (Caselaw Access Project mirror) (https://static.case.law/f3d/410/html/0792-01.html), source id ca6-bridgeport-2005
- Pinpoint: 410 F.3d at 801
- Quote: "Get a license or .do not sample."
- Checked: 2026-11-10

#### [M-0188] VERIFIED
- Claim: The Ninth Circuit holds the de minimis exception applies to sound recording sampling, and expressly disagrees with the Sixth Circuit.
- Jurisdiction: case-law
- Source: VMG Salsoul, LLC v. Ciccone, 824 F.3d 871 (9th Cir. 2016) (de minimis sampling) (https://cdn.ca9.uscourts.gov/datastore/opinions/2016/06/02/13-57104.pdf), source id ca9-vmg-salsoul-2016
- Pinpoint: 824 F.3d 871, Part II.B (slip op. at 32)
- Quote: "We hold that the “de minimis” exception applies to actions alleging infringement of a copyright to sound recordings."
- Checked: 2026-11-10

#### [M-0191] VERIFIED
- Claim: In the Ninth Circuit a taking is de minimis only if the average audience would not recognize the appropriation.
- Jurisdiction: case-law
- Source: Newton v. Diamond, 388 F.3d 1189 (9th Cir. 2004) (amended opinion) (https://cdn.ca9.uscourts.gov/datastore/opinions/2004/11/09/0255983.pdf), source id ca9-newton-diamond-2004
- Pinpoint: 388 F.3d 1189, de minimis discussion
- Quote: "observed that a use is de minimis only if the average audience would not recognize the appropriation."
- Checked: 2026-11-10

#### [M-0220] VERIFIED
- Claim: Anyone who violates an exclusive right of the copyright owner is an infringer.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 501 infringement of copyright (https://www.law.cornell.edu/uscode/text/17/501), source id usc17-501
- Pinpoint: 17 U.S.C. 501(a)
- Quote: "Anyone who violates any of the exclusive rights of the copyright owner as provided by sections 106 through"
- Checked: 2026-11-10

#### [M-0617] VERIFIED
- Claim: Canada s.29.21(1)(b): the source and, if given, the name of the author, performer, maker or broadcaster must be mentioned, if reasonable in the circumstances.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(b)
- Quote: "are mentioned, if it is reasonable in the circumstances to do so;"
- Checked: 2026-11-13

#### [M-0549] VERIFIED
- Claim: Campbell: a commercial nature is only one element of factor one; no presumption that every commercial use is unfair.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, syllabus
- Quote: "The statute makes clear that a work's commercial nature is only one element of the first factor enquiry into its purpose and character"
- Checked: 2026-11-13

#### [M-0553] VERIFIED
- Claim: Warhol: commercial nature is relevant but not dispositive, and is weighed against the degree to which the use has a further purpose or different character.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "The commercial nature of a use is relevant, but not dispositive"
- Checked: 2026-11-13

#### [M-0215] VERIFIED
- Claim: Statutory damages range from $750 to $30,000 per work, as the court considers just, at the owner's election.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(1)
- Quote: "in a sum of not less than $750 or more than $30,000 as the court considers just."
- Checked: 2026-11-10

#### [M-0254] VERIFIED
- Claim: Analysis: statutory damages are awarded per work infringed, up to $150,000 per work if willful (ordinary range $750 to $30,000), and only for works registered in time (s.412); exposure is per work, not per view.
- Jurisdiction: analysis
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0542] VERIFIED
- Claim: The compulsory licence is for making and distributing phonorecords of a nondramatic musical work (the composition); it is not a licence of any sound recording.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)-(B)
- Quote: "obtain a compulsory license to make and distribute phonorecords of a nondramatic musical work"
- Checked: 2026-11-13

#### [M-0540] VERIFIED
- Claim: A compulsory licence under 115 includes the privilege of an arrangement only to the extent necessary to conform the work to the style of the performance; it may not change the basic melody or fundamental character.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(2)
- Quote: "the arrangement shall not change the basic melody or fundamental character of the work"
- Checked: 2026-11-13

#### [M-0597] VERIFIED
- Claim: CD Baby says derivative works such as samples cannot be cleared through its cover song licensing process.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Things to note
- Quote: "Derivative works, such as samples, cannot be cleared through the cover song licensing process."
- Checked: 2026-11-13

#### [M-0183] VERIFIED
- Claim: Analysis: 106(4) gives the owner of a musical work the exclusive right to perform it publicly, a right separate from the 106(1) reproduction and 106(3) distribution rights that mechanical licensing concerns and from sync; what a PRO licence covers is checked in other rows.
- Jurisdiction: analysis
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0586] VERIFIED
- Claim: Mixcloud's own blog says the streaming service must hold licences clearing both the composition and the sound recording of every track in a stream.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, 'How can you live stream safely'
- Quote: "the streaming service you use needs licences that clear both the musical composition and the sound recording of every track you play"
- Checked: 2026-11-13

#### [M-0025] VERIFIED
- Claim: A sound recording is a separate work from the musical composition; a sound recording copyright is not a substitute for copyright in the underlying composition.
- Jurisdiction: US-federal
- Source: U.S. Copyright Office, Circular 56A: Copyright Registration of Musical Compositions and Sound Recordings (https://www.copyright.gov/circs/circ56a.pdf), source id co-circular-56a
- Pinpoint: Circular 56A p.1
- Quote: "Sound recordings and musical compositions are considered two separate works for copyright purposes. Even though a sound recording is a derivative work of the underlying musical composition, a copyright in a sound recording is not the same as, or a"
- Checked: 2026-11-10

#### [M-0108] VERIFIED
- Claim: Both musical works and sound recordings carry the reproduction right (copies or phonorecords).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(1)
- Quote: "to reproduce the copyrighted work in copies or phonorecords;"
- Checked: 2026-11-10

#### [M-0106] VERIFIED
- Claim: Musical works carry an exclusive right of public performance.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(4)
- Quote: "in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly;"
- Checked: 2026-11-10

#### [M-0107] VERIFIED
- Claim: Sound recordings carry a public performance right only by digital audio transmission.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 106 exclusive rights in copyrighted works (https://www.law.cornell.edu/uscode/text/17/106), source id usc17-106
- Pinpoint: 17 U.S.C. 106(6)
- Quote: "in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission."
- Checked: 2026-11-10

#### [M-0523] VERIFIED
- Claim: The sound recording owner's derivative right (106(2)) is limited to works in which the actual sounds fixed in the recording are rearranged, remixed, or otherwise altered in sequence or quality.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "limited to the right to prepare a derivative work in which the actual sounds fixed in the sound recording are rearranged, remixed, or otherwise altered in sequence or quality"
- Checked: 2026-11-13

#### [M-0535] VERIFIED
- Claim: Keeling v. Hars (2d Cir. 2015): the creator of an unauthorized work that stays within fair use and adds sufficient originality may claim 103 protection for her original contributions.
- Jurisdiction: case-law
- Source: Keeling v. Hars, 809 F.3d 43 (2d Cir. 2015) (https://static.case.law/f3d/809/cases/0043-01.json), source id ca2-keeling-hars-2015
- Pinpoint: 809 F.3d 43
- Quote: "if the creator of an unauthorized work stays within the bounds of fair use and adds sufficient originality, she may claim protection under the Copyright Act"
- Checked: 2026-11-13

#### [M-0532] VERIFIED
- Claim: Pickett v. Prince (7th Cir. 2000): section 103(a) does not let a stranger make a derivative work; the court read it to mean, at least so far as bears on that case, only that the right to make one does not authorise using material that infringes someone else's copyright.
- Jurisdiction: case-law
- Source: Pickett v. Prince, 207 F.3d 402 (7th Cir. 2000) (https://static.case.law/f3d/207/cases/0402-01.json), source id ca7-pickett-prince-2000
- Pinpoint: 207 F.3d 402, Posner C.J.
- Quote: "we do not read section 103(a) as qualifying the exclusive right of the owner of the copyright of the original work to make derivative works based on that work"
- Checked: 2026-11-13

#### [M-0111] VERIFIED
- Claim: Sound-alike recordings that are an independent fixation do not infringe the sound recording copyright (114(b) imitation rule). The musical work remains a separate copyright, so (analysis) a sound-alike still needs a musical work licence.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "do not extend to the making or duplication of another sound recording that consists entirely of an independent fixation of other sounds, even though such sounds imitate or simulate those in the copyrighted sound recording."
- Checked: 2026-11-10

#### [M-0211] VERIFIED
- Claim: Estate of Smith (S.D.N.Y. 2017): fair use is an affirmative defense and the party asserting it bears the burden.
- Jurisdiction: case-law
- Source: Estate of Smith v. Cash Money Records, Inc., 253 F. Supp. 3d 737 (S.D.N.Y. 2017) (Caselaw Access Project mirror) (https://static.case.law/f-supp-3d/253/html/0737-01.html), source id sdny-estate-smith-2017
- Pinpoint: 253 F. Supp. 3d at 748 (Part on fair use; burden sentence follows)
- Quote: "Fair use is an affirmative defense to copyright infringement"
- Checked: 2026-11-10

#### [M-0551] VERIFIED
- Claim: Warhol: if an original and the secondary use share the same or highly similar purposes and the use is commercial, factor one is likely to weigh against fair use absent another justification.
- Jurisdiction: case-law
- Source: Andy Warhol Foundation for the Visual Arts, Inc. v. Goldsmith, 598 U.S. 508 (2023) (https://www.supremecourt.gov/opinions/22pdf/21-869_87ad.pdf), source id scotus-warhol-2023
- Pinpoint: 598 U.S. 508, syllabus
- Quote: "if an original work and secondary use share the same or highly similar purposes, and the secondary use is commercial, the first fair use factor is likely to weigh against fair use"
- Checked: 2026-11-13

#### [M-0548] VERIFIED
- Claim: Campbell: parody needs to mimic an original to make its point and so has some claim to use its victim's work, whereas satire can stand on its own two feet and so requires justification for the very act of borrowing.
- Jurisdiction: case-law
- Source: Campbell v. Acuff-Rose Music, Inc., 510 U.S. 569 (1994) (U.S. Reports via Library of Congress) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep510/usrep510569/usrep510569.pdf), source id scotus-campbell-1994
- Pinpoint: 510 U.S. 569, 580-81
- Quote: "satire can stand on its own two feet and so requires justification for the very act of borrowing"
- Checked: 2026-11-13

#### [M-0556] VERIFIED
- Claim: The Task Force concluded the record had not established a need to create a specific remix exception or a compulsory licence for remix uses, and recommended guidelines, more voluntary licensing and education.
- Jurisdiction: US-federal
- Source: Dept of Commerce Internet Policy Task Force, White Paper on Remixes, First Sale, and Statutory Damages (Jan. 2016) (https://www.uspto.gov/sites/default/files/documents/copyrightwhitepaper.pdf), source id doc-white-paper-remixes-2016
- Pinpoint: White Paper (Jan. 2016), p. 4
- Quote: "the record has not established a need to amend existing law to create a specific exception or a compulsory license for remix uses"
- Checked: 2026-11-13

#### [M-0339] VERIFIED
- Claim: Section 115 makes the 106(1) and 106(3) rights to make and distribute phonorecords of nondramatic musical works subject to compulsory licensing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115 (opening paragraph)
- Quote: "to make and to distribute phonorecords of such works, are subject to compulsory licensing under the conditions specified by this section"
- Checked: 2026-11-10

#### [M-0545] VERIFIED
- Claim: First-use rule: the compulsory licence is available only if phonorecords of the work have previously been distributed to the public in the US under the authority of the copyright owner, or, for a digital music provider's digital phonorecord deliveries, the first fixation of the sound recording was made under the musical work owner's authority and the recording owner authorised the deliveries.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 115 compulsory license for making and distributing phonorecords (https://www.law.cornell.edu/uscode/text/17/115), source id usc17-115
- Pinpoint: 17 U.S.C. 115(a)(1)(A)(i)-(ii)
- Quote: "phonorecords of such musical work have previously been distributed to the public in the United States under the authority of the copyright owner of the work"
- Checked: 2026-11-13

#### [M-0544] VERIFIED
- Claim: The Office states a phonorecord does not include sounds accompanying a motion picture or other audiovisual work, so the compulsory licence does not cover putting a song in video.
- Jurisdiction: US-federal
- Source: Copyright Office Circular 73, Compulsory license for making and distributing phonorecords (https://www.copyright.gov/circs/circ73.pdf), source id co-circular-73
- Pinpoint: Circular 73
- Quote: "A phonorecord does not include sounds accompanying a motion picture or other audiovisual work"
- Checked: 2026-11-13

#### [M-0140] VERIFIED
- Claim: Copyright Office 2015: consumer audiovisual (sync) uses should stay in the free market; no compulsory licence recommended.
- Jurisdiction: industry
- Source: U.S. Copyright Office, Copyright and the Music Marketplace (February 2015) (https://www.copyright.gov/policy/musiclicensingstudy/copyright-and-the-music-marketplace.pdf), source id co-music-marketplace-2015
- Pinpoint: Copyright and the Music Marketplace (2015), Executive Summary, 'Maintain audiovisual uses in the free market'
- Quote: "uses that have traditionally required a synchronization license negotiated in the free market."
- Checked: 2026-11-10

#### [M-0596] VERIFIED
- Claim: CD Baby says a cover release needs a mechanical licence for digital downloads, which covers the composition but not the original recording.
- Jurisdiction: platform-terms
- Source: CD Baby help: cover songs (https://web.archive.org/web/2026/https://support.cdbaby.com/hc/en-us/articles/204498285-Can-I-release-a-cover-song-through-CD-Baby), source id terms-cdbaby-covers
- Pinpoint: CD Baby help: Can I release a cover song
- Quote: "This license grants you the right to reproduce and distribute the song's composition (lyrics and melody), but not the original recording."
- Checked: 2026-11-13

#### [M-0599] VERIFIED
- Claim: CD Baby's artist-education site says a sample of a recording means clearing both the master with the label and the composition with the publisher, with no standard rate and direct negotiation.
- Jurisdiction: platform-terms
- Source: CD Baby DIY Musician: licensing cover songs (https://diymusician.cdbaby.com/music-rights/licensing-cover-songs/), source id terms-cdbaby-licensing-covers
- Pinpoint: CD Baby DIY Musician: Use a Sample
- Quote: "Since you are creating a derivative work, this is an area that requires negotiating as there is no standard rate and will require direct contact with all parties."
- Checked: 2026-11-13

#### [M-0560] VERIFIED
- Claim: Sony v. Universal (1984): selling copying equipment is not contributory infringement if the product is widely used for legitimate purposes or is merely capable of substantial noninfringing uses.
- Jurisdiction: case-law
- Source: Sony Corp. of America v. Universal City Studios, 464 U.S. 417 (1984) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep464/usrep464417/usrep464417.pdf), source id scotus-sony-universal-1984
- Pinpoint: 464 U.S. 417, syllabus (Pp. 434-442)
- Quote: "does not constitute contributory infringement if the product is widely used for legitimate, unobjectionable purposes, or, indeed, is merely capable of substantial noninfringing uses"
- Checked: 2026-11-13

#### [M-0563] VERIFIED
- Claim: Grokster: mere knowledge that a product could be or is used to infringe is not enough for liability, and ordinary product support is not inducement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 937
- Quote: "mere knowledge of infringing potential or of actual infringing uses would not be enough here to subject a distributor to liability"
- Checked: 2026-11-13

#### [M-0252] VERIFIED
- Claim: Analysis: after Cox v. Sony (U.S. 2026) a service provider is contributorily liable for a user's infringement only if it induced the infringement or the service is tailored to it; knowing that some users infringe is not enough. Vicarious liability is a separate theory that the Court did not decide (cert limited to contributory).
- Jurisdiction: analysis
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0562] VERIFIED
- Claim: Grokster (2005): one who distributes a device with the object of promoting its use to infringe, shown by clear expression or other affirmative steps, is liable for third-party infringement.
- Jurisdiction: case-law
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919 (syllabus Held; opinion at 936-937)
- Quote: "one who distributes a device with the object of promoting its use to infringe copyright, as shown by clear expression or other"
- Checked: 2026-11-13

#### [M-0223] VERIFIED
- Claim: Cox (2026): intent can be shown by inducement or by a service tailored to infringement (not capable of substantial or commercially significant noninfringing uses).
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "A service is tailored to infringement if it is “not capable of ‘substantial’ or ‘commercially significant’ noninfringing uses.”"
- Checked: 2026-11-10

#### [M-0110] VERIFIED
- Claim: The sound recording reproduction right covers only duplication that recaptures the actual sounds.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(b)
- Quote: "is limited to the right to duplicate the sound recording in the form of phonorecords or copies that directly or indirectly recapture the actual sounds fixed in the recording."
- Checked: 2026-11-10

#### [M-0572] VERIFIED
- Claim: The Audio Home Recording Act bars infringement actions based on the manufacture, importation or distribution of a digital audio recording device, digital audio recording medium, analog recording device or analog recording medium, or on a consumer's noncommercial use of such a device or medium for making digital or analog musical recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 1008 Prohibition on certain infringement actions (https://www.law.cornell.edu/uscode/text/17/1008), source id usc17-1008
- Pinpoint: 17 U.S.C. 1008
- Quote: "based on the noncommercial use by a consumer of such a device or medium for making digital musical recordings or analog musical recordings"
- Checked: 2026-11-13

#### [M-0575] VERIFIED
- Claim: RIAA v. Diamond (9th Cir. 1999): a computer hard drive is excluded from the Act's definition of a digital music recording, so the Rio, which copies from a hard drive, does not record directly from a digital music recording.
- Jurisdiction: case-law
- Source: RIAA v. Diamond Multimedia, 180 F.3d 1072 (9th Cir. 1999) (https://static.case.law/f3d/180/cases/1072-01.json), source id ca9-riaa-diamond-1999
- Pinpoint: 180 F.3d 1072, Part III
- Quote: "a hard drive is a material object in which one or more programs are fixed; thus, a hard drive is excluded from the definition of digital music recordings"
- Checked: 2026-11-13

#### [M-0564] UNVERIFIED (unverified)
- Claim: Analysis: a stem-splitting or mixing tool maker whose marketing or onboarding steers users to split and mix commercial songs they do not own is exposed to Grokster inducement through its own statements and design, not through the tool's capability alone.
- Jurisdiction: analysis
- Source: MGM Studios v. Grokster, 545 U.S. 913 (2005) (https://tile.loc.gov/storage-services/service/ll/usrep/usrep545/usrep545913/usrep545913.pdf), source id scotus-grokster-2005
- Pinpoint: 545 U.S. 913, 919
- Quote: "going beyond mere distribution with knowledge of third-party action"
- Checked: 2026-11-13

#### [M-0221] VERIFIED
- Claim: Cox (2026): contributory liability requires that the provider intended its service be used for infringement, shown only by inducement or a service tailored to infringement.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), syllabus
- Quote: "Held: The provider of a service is contributorily liable for a user’s infringement only if it intended that the provided service be used for infringement,"
- Checked: 2026-11-10

#### [M-0222] VERIFIED
- Claim: Cox (2026): mere knowledge that a service will be used to infringe is insufficient to establish the required intent.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Part II.B
- Quote: "mere knowledge that a service will be used to infringe is insufficient to establish the required intent to infringe."
- Checked: 2026-11-10

#### [M-0225] VERIFIED
- Claim: Cox (2026): Justice Sotomayor, concurring in the judgment, said other common-law theories such as aiding and abetting could apply in copyright.
- Jurisdiction: US-federal
- Source: Cox Communications, Inc. v. Sony Music Entertainment, No. 24-171, 607 U.S. ___ (Mar. 25, 2026) (https://www.supremecourt.gov/opinions/25pdf/24-171_new_3dq3.pdf), source id scotus-cox-sony-2026
- Pinpoint: 607 U.S. ___ (2026), Sotomayor concurrence
- Quote: "precedents have left open the possibility that other common-law theories of such liability, like aiding and abetting, could apply in the copyright context."
- Checked: 2026-11-10

#### [M-0343] VERIFIED
- Claim: The 512(c) safe harbor covers infringement by reason of storage at the direction of a user on the provider's system.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)
- Quote: "for infringement of copyright by reason of the storage at the direction of a user of material that resides on a system or network controlled or operated by or for the service provider"
- Checked: 2026-11-10

#### [M-0344] VERIFIED
- Claim: The provider must lack actual knowledge that material is infringing.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(i)
- Quote: "does not have actual knowledge that the material or an activity using the material on the system or network is infringing"
- Checked: 2026-11-10

#### [M-0345] VERIFIED
- Claim: Absent actual knowledge, the provider must not be aware of facts or circumstances from which infringement is apparent (red flag knowledge).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(A)(ii)
- Quote: "is not aware of facts or circumstances from which infringing activity is apparent"
- Checked: 2026-11-10

#### [M-0348] VERIFIED
- Claim: On a compliant notice the provider must respond expeditiously to remove or disable the claimed material.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(C)
- Quote: "upon notification of claimed infringement as described in paragraph (3), responds expeditiously to remove, or disable access to, the material that is claimed to be infringing"
- Checked: 2026-11-10

#### [M-0347] VERIFIED
- Claim: The provider must not receive a financial benefit directly attributable to infringement where it has the right and ability to control it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(1)(B)
- Quote: "does not receive a financial benefit directly attributable to the infringing activity, in a case in which the service provider has the right and ability to control such activity"
- Checked: 2026-11-10

#### [M-0349] VERIFIED
- Claim: The 512(c) safe harbor applies only if the provider has designated an agent, by making it available on its service including its website and by providing it to the Copyright Office.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(c)(2)
- Quote: "by making available through its service, including on its website in a location accessible to the public, and by providing to the Copyright Office"
- Checked: 2026-11-10

#### [M-0357] VERIFIED
- Claim: Under 512(i)(1)(A) a provider must have adopted and reasonably implemented, and inform subscribers of, a policy providing for termination in appropriate circumstances of subscribers and account holders who are repeat infringers; the 512 limitations apply only if so.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(i)(1)(A)
- Quote: "has adopted and reasonably implemented, and informs subscribers and account holders of the service provider’s system or network of, a policy that provides for the termination in appropriate circumstances of subscribers and account holders"
- Checked: 2026-11-10

#### [M-0358] VERIFIED
- Claim: Applicability of 512(a)-(d) is not conditioned on a provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure under 512(i).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 512 limitations on liability relating to material online (https://www.law.cornell.edu/uscode/text/17/512), source id usc17-512
- Pinpoint: 17 U.S.C. 512(m)(1)
- Quote: "a service provider monitoring its service or affirmatively seeking facts indicating infringing activity, except to the extent consistent with a standard technical measure complying with the provisions of subsection (i)"
- Checked: 2026-11-10

#### [M-0390] VERIFIED
- Claim: Art 17(4)(b): best efforts, to high industry standards of professional diligence, to ensure unavailability of works the rightholder identified.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(b)
- Quote: "made, in accordance with high industry standards of professional diligence, best efforts to ensure the unavailability of specific works and other subject matter for which the rightholders have provided the service providers with the relevant and necessary information"
- Checked: 2026-11-10

#### [M-0394] VERIFIED
- Claim: Art 17(8): no general monitoring obligation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(8)
- Quote: "The application of this Article shall not lead to any general monitoring obligation"
- Checked: 2026-11-10

#### [M-0115] VERIFIED
- Claim: The statutory licence requires that the transmission not be part of an interactive service.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(A)(i)
- Quote: "the transmission is not part of an interactive service;"
- Checked: 2026-11-10

#### [M-0578] VERIFIED
- Claim: The 114(d)(2) statutory licence for eligible nonsubscription transmissions requires that the transmission is not part of an archived program of less than 5 hours.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(I)
- Quote: "is not part of an archived program of less than 5 hours duration"
- Checked: 2026-11-13

#### [M-0579] VERIFIED
- Claim: Under the 114 statutory licence a transmission may not be part of an archived program of 5 hours or more that is made available for more than 2 weeks, so a permanent on-demand mix archive does not meet that condition.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(iii)(II)
- Quote: "is not part of an archived program of 5 hours or greater in duration that is made available for a period exceeding 2 weeks"
- Checked: 2026-11-13

#### [M-0581] VERIFIED
- Claim: The sound recording performance complement allows, in any 3-hour period on a channel, no more than 3 different selections from any one phonorecord (no more than 2 consecutively), or 4 different selections by the same featured artist or from any set or compilation of phonorecords (no more than 3 consecutively).
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(13)
- Quote: "3 different selections of sound recordings from any one phonorecord lawfully distributed for public performance or sale in the United States, if no more than 2 such selections are transmitted consecutively"
- Checked: 2026-11-13

#### [M-0580] VERIFIED
- Claim: Under the statutory licence the transmission may not exceed the sound recording performance complement, and the service may not publish an advance schedule of the specific recordings.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(i)-(ii)
- Quote: "the transmitting entity does not cause to be published, or induce or facilitate the publication, by means of an advance program schedule or prior announcement, the titles of the specific sound recordings to be transmitted"
- Checked: 2026-11-13

#### [M-0584] VERIFIED
- Claim: The statutory licence requires the service to identify the title, record and featured artist in text while the recording plays.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(ix)
- Quote: "the transmitting entity identifies in textual data the sound recording during, but not before, the time it is performed"
- Checked: 2026-11-13

#### [M-0582] VERIFIED
- Claim: The statutory licence requires the service to take no affirmative steps to cause or induce the recipient to make a phonorecord, so a download button on mixes is outside it.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vi)
- Quote: "the transmitting entity takes no affirmative steps to cause or induce the making of a phonorecord by the transmission recipient"
- Checked: 2026-11-13

#### [M-0583] VERIFIED
- Claim: The statutory licence requires the transmission to be made from a phonorecord lawfully made under the copyright owner's authority.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(d)(2)(C)(vii)
- Quote: "the transmitting entity makes the transmission from a phonorecord lawfully made under the authority of the copyright owner"
- Checked: 2026-11-13

#### [M-0112] VERIFIED
- Claim: A "digital audio transmission" under 17 U.S.C. 114(j)(5) does not include the transmission of any audiovisual work, so the 114(d)(2) statutory licence for digital audio transmissions does not extend to audiovisual transmission such as a video with music.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 114 scope of exclusive rights in sound recordings (https://www.law.cornell.edu/uscode/text/17/114), source id usc17-114
- Pinpoint: 17 U.S.C. 114(j)(5)
- Quote: "This term does not include the transmission of any audiovisual work."
- Checked: 2026-11-10

#### [M-0589] VERIFIED
- Claim: Mixcloud's live-stream checklist asks whether the platform has direct deals with the record labels whose music is played.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28, checklist
- Quote: "Does it have direct deals with the record labels whose music you play?"
- Checked: 2026-11-13

#### [M-0592] VERIFIED
- Claim: Apple Music (Nov 16, 2021 artist notice) says it developed a process to identify and compensate the individual creators in DJ mixes.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple has developed a new process to identify and fairly compensate all of the individual creators featured in thousands of DJ mixes"
- Checked: 2026-11-13

#### [M-0593] VERIFIED
- Claim: Apple Music says it works with major and independent labels and pays rights holders within DJ mixes directly.
- Jurisdiction: platform-terms
- Source: Apple Music for Artists: Apple is using Shazam to identify and compensate all DJ mix creators (https://artists.apple.com/support/1982-apple-is-using-shazam-to-identify-and-compensate-all-dj-mix-creators), source id terms-apple-dj-mixes
- Pinpoint: Apple Music for Artists notice 2021-11-16
- Quote: "Apple Music is directly paying rights holders within these DJ mixes and creating long-term monetary value for all creators involved"
- Checked: 2026-11-13

#### [M-0588] VERIFIED
- Claim: Mixcloud says downloading music needs an additional licensed right, the mechanical right.
- Jurisdiction: platform-terms
- Source: Mixcloud blog: how to live stream music without copyright takedown issues (Mixcloud's own blog) (https://www.mixcloud.com/blog/2024/03/28/how-to-live-stream-music-without-copyright-takedown-issues), source id terms-mixcloud-livestream
- Pinpoint: Mixcloud blog 2024-03-28
- Quote: "Downloading music online requires an additional licensed right, the mechanical right."
- Checked: 2026-11-13

#### [M-0515] VERIFIED
- Claim: Ninth Circuit (Mavrix v. LiveJournal, 2017): the 512(c) financial benefit test is a common-sense, fact-based inquiry, and the benefit need not be substantial or a large proportion of revenue.
- Jurisdiction: case-law
- Source: Mavrix Photographs v. LiveJournal, 873 F.3d 1045 (9th Cir. 2017) (https://static.case.law/f3d/873/html/1045-01.html), source id ca9-mavrix-livejournal-2017
- Pinpoint: 512(c)(1)(B) discussion
- Quote: "The financial benefit need not be substantial or a large proportion of the service provider’s revenue."
- Checked: 2026-11-10

#### [M-0616] VERIFIED
- Claim: Canada s.29.21(1)(a): the use or the authorization to disseminate the new work must be solely for non-commercial purposes.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(a)
- Quote: "is done solely for non-commercial purposes;"
- Checked: 2026-11-13

#### [M-0217] VERIFIED
- Claim: Willful infringement raises the statutory maximum to $150,000 per work.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 504 remedies, damages and profits (https://www.law.cornell.edu/uscode/text/17/504), source id usc17-504
- Pinpoint: 17 U.S.C. 504(c)(2)
- Quote: "the court in its discretion may increase the award of statutory damages to a sum of not more than $150,000."
- Checked: 2026-11-10

#### [M-0214] VERIFIED
- Claim: No statutory damages or fees for infringement of a published work that commenced before its registration, unless registered within three months of publication.
- Jurisdiction: US-federal
- Source: 17 U.S.C. 412 registration as prerequisite to certain remedies (https://www.law.cornell.edu/uscode/text/17/412), source id usc17-412
- Pinpoint: 17 U.S.C. 412(2)
- Quote: "any infringement of copyright commenced after first publication of the work and before the effective date of its registration, unless such registration is made within three months after the first publication of the work."
- Checked: 2026-11-10

#### [M-0600] VERIFIED
- Claim: Demucs repository code licence: MIT, which grants rights to use, copy, modify, publish, distribute, sublicense and sell the software (code only; the file says nothing about trained weights).
- Jurisdiction: industry
- Source: Demucs repository LICENSE (MIT) (https://raw.githubusercontent.com/adefossez/demucs/main/LICENSE), source id demucs-license
- Pinpoint: LICENSE, MIT grant
- Quote: "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software"
- Checked: 2026-11-13

#### [M-0603] VERIFIED
- Claim: Demucs maintainer in issue 384 (2022-09-29): the code is free for commercial use under MIT, but the weights are research artefacts provided only for personal or research usage.
- Jurisdiction: industry
- Source: facebookresearch/demucs issue 384 Legality of publishing audio output (maintainer comment) (https://github.com/facebookresearch/demucs/issues/384), source id demucs-issue-384
- Pinpoint: Issue 384, comment by adefossez 2022-09-29
- Quote: "The weights themselves are however just a research artefacts and provided only for personal / research usage."
- Checked: 2026-11-13

#### [M-0604] VERIFIED
- Claim: Spleeter README: the code of Spleeter is MIT licensed. The License section states nothing separate about the pretrained model weights (silence, not a grant).
- Jurisdiction: industry
- Source: Spleeter README (https://raw.githubusercontent.com/deezer/spleeter/master/README.md), source id spleeter-readme
- Pinpoint: README, License section
- Quote: "The code of Spleeter is MIT-licensed."
- Checked: 2026-11-13

#### [M-0607] VERIFIED
- Claim: Open-Unmix README: the umxhq weights were trained on MUSDB18-HQ. The README states no weights licence for umx or umxhq, which is silence and not a grant.
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxhq
- Quote: "which comprises the same tracks as in MUSDB18 but un-compressed which yield in a full bandwidth of 22050 Hz."
- Checked: 2026-11-13

#### [M-0609] VERIFIED
- Claim: python-audio-separator README: the default model is a BS-Roformer checkpoint file (model_bs_roformer_ep_317_sdr_12.9755), described as BS-Roformer-Viperx-1297; the README gives no licence for that checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, CLI options and supported model list
- Quote: "default: model_bs_roformer_ep_317_sdr_12.9755.yaml"
- Checked: 2026-11-13

#### [M-0606] VERIFIED
- Claim: Open-Unmix README: the default umxl weights are licensed for non-commercial use only (CC BY-NC-SA 4.0).
- Jurisdiction: industry
- Source: Open-Unmix pytorch README (https://raw.githubusercontent.com/sigsep/open-unmix-pytorch/master/README.md), source id openunmix-readme
- Pinpoint: README, Pre-trained models, umxl
- Quote: "Note, that the weights are only licensed for non-commercial use (CC BY-NC-SA 4.0)."
- Checked: 2026-11-13

#### [M-0610] VERIFIED
- Claim: python-audio-separator README lists a Mel-Band Roformer vocals checkpoint credited to Kimberley Jensen, with no licence stated for the checkpoint.
- Jurisdiction: industry
- Source: python-audio-separator README (https://raw.githubusercontent.com/nomadkaraoke/python-audio-separator/main/README.md), source id audiosep-readme
- Pinpoint: README, supported model list
- Quote: "vocals_mel_band_roformer.ckpt MDXC vocals* (12.6), other Roformer Model: MelBand Roformer | Vocals by Kimberley Jensen"
- Checked: 2026-11-13

#### [M-0618] VERIFIED
- Claim: Canada s.29.21(1)(c): the individual must have had reasonable grounds to believe the source work was not infringing copyright.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(c)
- Quote: "the individual had reasonable grounds to believe that the existing work or other subject-matter or copy of it, as the case may be, was not infringing copyright"
- Checked: 2026-11-13

#### [M-0619] VERIFIED
- Claim: Canada s.29.21(1)(d): the use must not have a substantial adverse effect on the exploitation or potential exploitation of the source, or its market, including by being a substitute.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(1)(d)
- Quote: "does not have a substantial adverse effect, financial or otherwise, on the exploitation or potential exploitation of the existing work"
- Checked: 2026-11-13

#### [M-0620] VERIFIED
- Claim: Canada s.29.21(2): an intermediary is a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public.
- Jurisdiction: Canada
- Source: Copyright Act (Canada) s.29.21 non-commercial user-generated content (https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.21.html), source id ca-copyright-s29-21
- Pinpoint: s.29.21(2) definition of intermediary
- Quote: "intermediary means a person or entity who regularly provides space or means for works or other subject-matter to be enjoyed by the public."
- Checked: 2026-11-13

#### [M-0240] VERIFIED
- Claim: CDPA s.30A: fair dealing for caricature, parody or pastiche does not infringe copyright.
- Jurisdiction: UK
- Source: Copyright, Designs and Patents Act 1988 s.30A Caricature, parody or pastiche (https://www.legislation.gov.uk/ukpga/1988/48/section/30A), source id uk-cdpa-s30a
- Pinpoint: CDPA s.30A(1)
- Quote: "Fair dealing with a work for the purposes of caricature, parody or pastiche does not infringe copyright in"
- Checked: 2026-11-10

#### [M-0631] VERIFIED
- Claim: CJEU Pelham II (C-590/23, 14 April 2026), per the Court's press release: pastiche covers creations that evoke existing works while noticeably different from them and use, including by sampling, characteristic protected elements to engage in a recognisable artistic or creative dialogue.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, summary of answer
- Quote: "covers creations which evoke one or more existing works, while being noticeably different from them, and which use, including by means of sampling, some of those works’ characteristic elements protected by copyright"
- Checked: 2026-11-13

#### [M-0633] VERIFIED
- Claim: Pelham II press release: the pastiche exception in InfoSoc Art 5(3)(k) is not a catch-all covering every creative use, and does not cover concealed imitations or plagiarism.
- Jurisdiction: EU
- Source: CJEU Judgment C-590/23 Pelham II (14 April 2026) (https://curia.europa.eu/site/upload/docs/application/pdf/2026-04/cp260050en.pdf), source id cjeu-pelham2-c590-23
- Pinpoint: Press Release No 50/26, footnotes 5 and 6
- Quote: "that exception does not have a catch-all nature (Auffangtatbestand) covering every form of creative use of copyright-protected material."
- Checked: 2026-11-13

#### [M-0387] VERIFIED
- Claim: CDSM Art 17(1): an online content-sharing service provider performs an act of communication to the public when it gives access to user uploads, and must get authorisation.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(1)
- Quote: "performs an act of communication to the public or an act of making available to the public for the purposes of this Directive when it gives the public access to copyright-protected works"
- Checked: 2026-11-10

#### [M-0389] VERIFIED
- Claim: Art 17(4)(a): absent authorisation the provider is liable unless it made best efforts to obtain one.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(4)(a)
- Quote: "made best efforts to obtain an authorisation"
- Checked: 2026-11-10

#### [M-0392] VERIFIED
- Claim: Art 17(6): new providers under three years old with turnover under EUR 10 million have a lighter regime.
- Jurisdiction: EU
- Source: Directive (EU) 2019/790 on copyright and related rights in the Digital Single Market (CDSM Directive) (https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32019L0790), source id eu-cdsm-2019-790
- Pinpoint: Art. 17(6)
- Quote: "the services of which have been available to the public in the Union for less than three years and which have an annual turnover below EUR 10 million"
- Checked: 2026-11-10

#### [M-0622] VERIFIED
- Claim: Australia Copyright Act 1968 s.41A: a fair dealing with a literary, dramatic, musical or artistic work for the purpose of parody or satire is not infringement.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41A
- Quote: "musical or artistic work, or with an adaptation of a literary, dramatic or musical work, does not constitute an infringement of the copyright in the work if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0623] VERIFIED
- Claim: Australia s.103AA: a fair dealing with an audio-visual item for the purpose of parody or satire is not infringement of the item or works in it.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.103AA parody or satire (subject matter other than works) (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s103aa
- Pinpoint: Copyright Act 1968 (Cth) s.103AA
- Quote: "A fair dealing with an audio-visual item does not constitute an infringement of the copyright in the item or in any work or other audio-visual item included in the item if it is for the purpose of parody or satire."
- Checked: 2026-11-13

#### [M-0625] VERIFIED
- Claim: Australia s.41: fair dealing for criticism or review needs a sufficient acknowledgement of the work.
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) s.41
- Quote: "for the purpose of criticism or review, whether of that work or of another work, and a sufficient acknowledgement of the work is made."
- Checked: 2026-11-13

#### [M-0626] VERIFIED
- Claim: Australia s.195AJ: derogatory treatment of a musical work includes material alteration or distortion prejudicial to the author's honour or reputation, under the author's right of integrity (s.195AI).
- Jurisdiction: Australia
- Source: Copyright Act 1968 (Cth) s.41A parody or satire (https://api.prod.legislation.gov.au/v1/documents/find(titleId='C1968A00063',asAtSpecification='Latest',type='Primary',format='Pdf',uniqueTypeNumber=0,volumeNumber=0,rectificationVersionNumber=0)), source id au-copyright-s41a
- Pinpoint: Copyright Act 1968 (Cth) ss.195AI, 195AJ
- Quote: "the doing, in relation to the work, of anything that results in a material distortion of, the mutilation of, or a material alteration to, the work that is prejudicial to the author's honour or reputation"
- Checked: 2026-11-13
